# 划分器 v1.1

本目录把原有 L3、L2、L1 流程串成一个完整层级划分器，并在 L1 下展开 L0 单器件簇：

```text
L3 电压域
└─ L2 功能域
   └─ L1 功能簇
      └─ L0 单器件簇
```

输入只需要网表文件；L3 由 DeepSeek 完成电压域划分。每个 L3 域内部依次执行“DeepSeek 器件功能识别 → 算法 L2 初划分 → DeepSeek 小元件补划分”，再按原有 L1 逻辑生成细功能簇和 L0 单器件簇。任何 L2/L1 簇都不会跨越高低压域，最终会校验每个输入器件恰好出现在一个 L0 簇中。

## 启动

Windows 下双击 `启动划分器.cmd` 打开统一界面，也可以在命令行运行：

```powershell
python run_flow.py C:\path\to\netlist.enet `
  --api-key-file C:\path\to\DeepSeek接口文档.txt `
  --out C:\path\to\partition-output
```

接口文档可使用 `模型名`、`Base URL`、`API` 字段。也可通过环境变量 `DEEPSEEK_API_KEY`、`DEEPSEEK_BASE_URL`、`DEEPSEEK_MODEL` 配置 DeepSeek。

## Dry-run

```powershell
python run_flow.py netlist.enet --dry-run --out output
```

Dry-run 不访问任何模型。为了贯通本地算法和检查输出结构，它会临时把所有器件放入 L3 `low_voltage` 域，并将每个器件标记为不确定、置信度 0。该层级结果仅用于流程测试，不能作为实际电压域划分。

## 输出

- `hierarchy.json`：完整的嵌套 L3 → L2 → L1 → L0 结构和逐器件归属。
- `hierarchical_assignments.csv`：每个器件对应的 L3、L2、L1、L0 ID，以及 `is_connector` 列。连接器按 J/P/CN/CON/USB 等位号、类型和器件描述、封装（如 CONN、USB-C、HDR、插座、端子等）综合识别并记为 `True`，其他元件留空。
- `L3_assignments.csv`、`L2_assignments.csv`、`L1_assignments.csv`、`L0_assignments.csv`：按层级分别导出的逐器件 CSV；每张表包含该层耗时，L0 表也包含连接器标记。
- `hierarchy.json` 和 `run.json`：各层累计耗时（秒）；L2/L1/L0 另按所属 L3 域提供耗时明细。
- `l3/`：L3 请求、模型响应、两电压域分配及审计文件。
- `domains/<L3域>/l2/`：该电压域自己的 L2 请求、算法结果、标注和最终结果。
- `domains/<L3域>/l1/`：该电压域内的 L1 配对分数和分配表。

## 目录

五个原工程作为源码副本保存在同目录下：`划分器_针对L3`、`划分器_针对L2`、`划分器_针对L1`、`划分器算法部分`、`划分器LLM部分`。算法、提示词和知识库运行路径均指向此目录内的副本，可整体移动。
