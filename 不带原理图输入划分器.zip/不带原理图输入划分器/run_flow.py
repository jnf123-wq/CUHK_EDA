#!/usr/bin/env python3
"""Run the complete L3 -> L2 -> L1 -> L0 partitioning flow."""

from __future__ import annotations

import argparse
import csv
import importlib.util
import json
import re
import sys
import time
from collections import Counter
from pathlib import Path
from typing import Any, Mapping


ROOT = Path(__file__).resolve().parent
L3_DIR = ROOT / "划分器_针对L3"
L2_DIR = ROOT / "划分器_针对L2"
L1_DIR = ROOT / "划分器_针对L1"

for _path in (L3_DIR, L1_DIR):
    if str(_path) not in sys.path:
        sys.path.insert(0, str(_path))

from llm_base.api_client import _JSONClient, resolve_api_config  # noqa: E402
import voltage_partition as l3_flow  # noqa: E402
import l1_flow  # noqa: E402


def _load_l2_module():
    path = L2_DIR / "run_flow.py"
    spec = importlib.util.spec_from_file_location("partitioner_v1_l2_flow", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"无法加载 L2 流程：{path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


l2_flow = _load_l2_module()


def save_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def _subset_netlist(netlist: Mapping[str, Any], component_ids: set[str]) -> dict[str, Any]:
    components = [dict(row) for row in netlist["components"] if str(row["id"]) in component_ids]
    nets = []
    for net in netlist["nets"]:
        pins = [dict(pin) for pin in net.get("pins", []) if str(pin.get("component")) in component_ids]
        if pins:
            nets.append({**dict(net), "pins": pins})
    return {**dict(netlist), "components": components, "nets": nets}


def _is_connector(component: Mapping[str, Any]) -> bool:
    """Return whether a normalized netlist component is a physical connector.

    EasyEDA/JLC exports use several connector reference conventions.  Some
    parts are also misclassified by their leading letter (for example ``CN``
    as a capacitor or ``USB`` as an IC module), so inspect both the reference
    and descriptive metadata, including the footprint.
    """
    ref = str(component.get("id", component.get("ref", component.get("designator", "")))).strip().upper()
    if re.match(r"^(?:J|P|CN|CON|USB)(?:\d|[-_]|$)", ref):
        return True
    kind = str(component.get("kind", component.get("type", ""))).strip().casefold().replace("-", "_")
    if kind in {"connector", "connectors", "conn", "plug", "socket", "header", "terminal_block"}:
        return True
    fields = (
        "kind", "type", "category", "part", "value", "name", "description",
        "footprint", "manufacturer_part", "manufacturerPart", "device_name", "deviceName",
    )
    text = " ".join(str(component.get(key, "")) for key in fields).casefold()
    connector_tokens = (
        "connector", "conn-", "conn_", "usb", "type-c", "type c", "usba",
        "header", "socket", "plug", "terminal", "插座", "连接器", "端子", "排针", "排母",
    )
    return any(token in text for token in connector_tokens)


def _run_l3(netlist: Mapping[str, Any], args: argparse.Namespace, out: Path) -> dict[str, Any]:
    out.mkdir(parents=True, exist_ok=True)
    prompt = l3_flow.build_prompt(netlist, args.threshold_v)
    save_json(out / "input_netlist.json", netlist)
    save_json(out / "request.json", prompt)

    if args.dry_run:
        # This explicit placeholder lets the local L2/L1/L0 code paths run
        # without a network request. It must never be mistaken for a result.
        raw = {
            "assignments": [
                {"component_id": str(component["id"]), "cluster_id": "low_voltage", "confidence": 0.0}
                for component in netlist["components"]
            ],
            "uncertain_component_ids": [str(component["id"]) for component in netlist["components"]],
        }
        result = l3_flow.validate_result(raw, netlist)
        result["dry_run"] = True
        save_json(out / "voltage_partition.json", result)
        l3_flow.write_csv(out / "voltage_partition.csv", result)
        save_json(out / "run.json", {
            "status": "dry_run", "component_count": len(netlist["components"]),
            "assignment_placeholder": "all components temporarily placed in low_voltage to exercise downstream stages",
            "model_called": False,
        })
        return result

    key, base_url, model = resolve_api_config(
        str(args.api_key_file) if args.api_key_file else None,
        env_key="DEEPSEEK_API_KEY", env_base="DEEPSEEK_BASE_URL", env_model="DEEPSEEK_MODEL",
        explicit_base=args.base_url, explicit_model=args.model,
        default_base="https://api.deepseek.com/v1", default_model="deepseek-chat",
    )
    client = _JSONClient(base_url=base_url, model=model, api_key=key, timeout=args.timeout)
    disable_thinking = "deepseek" in model.lower() and any(word in model.lower() for word in ("v4", "reason", "pro"))
    system = "你是谨慎的电路电压域分析工程师。只按给定阈值输出 JSON。"
    try:
        raw = client.ask(system, prompt, temperature=args.temperature, max_tokens=8192,
                         disable_thinking=disable_thinking)
    except RuntimeError as exc:
        if disable_thinking and "HTTP 400" in str(exc):
            raw = client.ask(system, prompt, temperature=args.temperature, max_tokens=8192)
        elif "model response did not contain a valid JSON object" in str(exc):
            raw = client.ask(
                system + " 必须仅返回覆盖全部器件的完整 JSON object，不要 Markdown 或额外文字。",
                prompt, temperature=args.temperature, max_tokens=8192,
                disable_thinking=disable_thinking,
            )
        else:
            raise
    save_json(out / "model_response.json", raw)
    try:
        result = l3_flow.validate_result(raw, netlist)
    except ValueError as first_error:
        repair = {**prompt, "repair_instruction": f"{first_error}；请修复并覆盖全部输入器件。"}
        raw = client.ask(system + " 只返回符合 schema 的完整 JSON。", repair,
                         temperature=args.temperature, max_tokens=8192,
                         disable_thinking=disable_thinking)
        save_json(out / "model_response.json", raw)
        result = l3_flow.validate_result(raw, netlist)
    save_json(out / "voltage_partition.json", result)
    l3_flow.write_csv(out / "voltage_partition.csv", result)
    save_json(out / "run.json", {
        "status": "completed", "provider": "DeepSeek", "model": model,
        "base_url": base_url, "threshold_v": args.threshold_v,
        "component_count": len(netlist["components"]),
        "cluster_counts": {row["cluster_id"]: len(row["component_ids"]) for row in result["clusters"]},
        "uncertain_component_ids": result["uncertain_component_ids"],
    })
    return result


def _run_l2_l1_for_domain(
    netlist: Mapping[str, Any], component_ids: set[str], cluster_id: str,
    args: argparse.Namespace, out: Path,
) -> dict[str, Any]:
    l2_started = time.perf_counter()
    scope_netlist = _subset_netlist(netlist, component_ids)
    out.mkdir(parents=True, exist_ok=True)
    scope_input = out / "input_netlist.json"
    save_json(scope_input, scope_netlist)

    l2_out = out / "l2"
    l2_args = argparse.Namespace(
        netlist=str(scope_input), out=str(l2_out),
        api_key_file=str(args.api_key_file) if args.api_key_file else None,
        base_url=args.base_url, model=args.model,
        timeout=args.timeout, temperature=args.temperature, dry_run=args.dry_run,
        algorithm_dir=str(args.algorithm_dir.resolve()),
    )
    print(f"  {cluster_id}: 运行 L2（{len(component_ids)} 个器件）…", flush=True)
    l2_manifest = l2_flow.run_flow(l2_args)
    l2_result = json.loads((l2_out / "l2_final_result.json").read_text(encoding="utf-8-sig"))
    l2_seconds = time.perf_counter() - l2_started

    l1_started = time.perf_counter()
    annotations = json.loads((l2_out / "device_function_annotations.json").read_text(encoding="utf-8-sig"))
    l1_result = l1_flow.run_flow(
        l1_flow.normalize_netlist(scope_netlist),
        {"l2_domains": l2_result["domains"]}, annotations,
    )
    l1_out = out / "l1"
    l1_flow.write_outputs(l1_result, l1_out)
    l1_seconds = time.perf_counter() - l1_started
    return {"l2_manifest": l2_manifest, "l2_result": l2_result, "l1_result": l1_result,
            "analysis_times_seconds": {"L2": l2_seconds, "L1": l1_seconds}}


def build_hierarchy(
    netlist: Mapping[str, Any], l3_result: Mapping[str, Any],
    domain_results: Mapping[str, Mapping[str, Any]], *, dry_run: bool = False,
    l3_seconds: float = 0.0,
) -> dict[str, Any]:
    """Nest L2 and L1 results under L3, then create one L0 cluster per device."""
    l3_domains: list[dict[str, Any]] = []
    assignment_rows: list[dict[str, Any]] = []
    component_owner: dict[str, dict[str, Any]] = {}
    components = {str(component["id"]): component for component in netlist["components"]}
    l2_number = l1_number = l0_number = 0
    l0_seconds_by_l3: dict[str, float] = {}
    l0_seconds_total = 0.0

    for l3_cluster in l3_result["clusters"]:
        source_l3_id = str(l3_cluster["cluster_id"])
        l3_id = f"L3-{source_l3_id}"
        members = sorted(map(str, l3_cluster["component_ids"]))
        scope_result = domain_results.get(source_l3_id)
        nested_l2: list[dict[str, Any]] = []
        if scope_result:
            l2_result = scope_result["l2_result"]
            l1_result = scope_result["l1_result"]
            l0_seconds_for_l3 = 0.0
            l1_by_l2: dict[str, list[Mapping[str, Any]]] = {}
            for cluster in l1_result["l1_clusters"]:
                l1_by_l2.setdefault(str(cluster["l2_domain"]), []).append(cluster)

            for source_domain in l2_result["domains"]:
                l2_number += 1
                source_l2_id = str(source_domain["id"])
                l2_id = f"L2-{l2_number:04d}"
                nested_l1: list[dict[str, Any]] = []
                for source_l1 in l1_by_l2.get(source_l2_id, []):
                    l1_number += 1
                    l1_id = f"L1-{l1_number:04d}"
                    l0_clusters = []
                    l1_members = sorted(map(str, source_l1["members"]))
                    l0_started = time.perf_counter()
                    for component_id in l1_members:
                        l0_number += 1
                        l0_id = f"L0-{l0_number:05d}"
                        connector = _is_connector(components[component_id])
                        l0_clusters.append({
                            "id": l0_id, "level": "L0", "component_id": component_id,
                            "members": [component_id], "is_connector": True if connector else None,
                        })
                        if component_id in component_owner:
                            raise ValueError(f"器件重复归属：{component_id}")
                        component_owner[component_id] = {
                            "l3_id": l3_id, "l2_id": l2_id, "l1_id": l1_id, "l0_id": l0_id,
                            "is_connector": True if connector else None,
                        }
                    l0_elapsed = time.perf_counter() - l0_started
                    l0_seconds_for_l3 += l0_elapsed
                    l0_seconds_total += l0_elapsed
                    nested_l1.append({
                        **dict(source_l1), "source_id": str(source_l1["id"]), "id": l1_id,
                        "level": "L1", "l2_domain": l2_id, "members": l1_members,
                        "l0_clusters": l0_clusters, "l0_generation_seconds": round(l0_elapsed, 9),
                    })
                nested_l2.append({
                    **dict(source_domain), "source_id": source_l2_id, "id": l2_id,
                    "level": "L2", "l3_domain": l3_id,
                    "members": sorted(map(str, source_domain.get("members", []))),
                    "l1_clusters": nested_l1,
                })
            l0_seconds_by_l3[source_l3_id] = l0_seconds_for_l3

        l3_domains.append({
            "id": l3_id, "level": "L3", "cluster_id": source_l3_id,
            "cluster_name": l3_cluster.get("cluster_name", source_l3_id),
            "component_ids": members, "l2_domains": nested_l2,
            "downstream_analysis_times_seconds": {
                "L2": round(float(scope_result.get("analysis_times_seconds", {}).get("L2", 0.0)), 6)
                if scope_result else 0.0,
                "L1": round(float(scope_result.get("analysis_times_seconds", {}).get("L1", 0.0)), 6)
                if scope_result else 0.0,
                "L0": round(l0_seconds_by_l3.get(source_l3_id, 0.0), 6),
            },
        })

    expected = {str(component["id"]) for component in netlist["components"]}
    if set(component_owner) != expected:
        missing = sorted(expected - set(component_owner))
        extra = sorted(set(component_owner) - expected)
        raise ValueError(f"L0 全覆盖校验失败：missing={missing}, extra={extra}")
    for component_id in sorted(expected):
        assignment_rows.append({"component_id": component_id, **component_owner[component_id]})

    l2_by_l3 = {cluster_id: float(domain_results.get(cluster_id, {}).get("analysis_times_seconds", {}).get("L2", 0.0))
                for cluster_id in (str(row["cluster_id"]) for row in l3_result["clusters"])}
    l1_by_l3 = {cluster_id: float(domain_results.get(cluster_id, {}).get("analysis_times_seconds", {}).get("L1", 0.0))
                for cluster_id in (str(row["cluster_id"]) for row in l3_result["clusters"])}
    analysis_times = {
        "L3": {"total_seconds": round(l3_seconds, 6)},
        "L2": {"total_seconds": round(sum(l2_by_l3.values()), 6),
               "by_l3_domain_seconds": {key: round(value, 6) for key, value in l2_by_l3.items()}},
        "L1": {"total_seconds": round(sum(l1_by_l3.values()), 6),
               "by_l3_domain_seconds": {key: round(value, 6) for key, value in l1_by_l3.items()}},
        "L0": {"total_seconds": round(l0_seconds_total, 6),
               "by_l3_domain_seconds": {key: round(value, 6) for key, value in l0_seconds_by_l3.items()}},
    }

    return {
        "schema": "partitioner-hierarchy-l3-l0-v1", "status": "dry_run" if dry_run else "completed",
        "levels": ["L3", "L2", "L1", "L0"],
        "component_count": len(expected), "l3_domains": l3_domains,
        "assignments": assignment_rows, "all_components_once": True,
        "analysis_times_seconds": analysis_times,
        "dry_run_note": (
            "L3 临时将全部器件放入 low_voltage 以验证后续流程；此结果不是有效的电压域划分。"
            if dry_run else None
        ),
    }


def write_assignments_csv(path: Path, hierarchy: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = ["component_id", "l3_id", "l2_id", "l1_id", "l0_id", "is_connector"]
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(hierarchy["assignments"])


def _write_csv(path: Path, fieldnames: list[str], rows: list[Mapping[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows({key: row.get(key, "") for key in fieldnames} for row in rows)


def _csv_value(value: Any) -> Any:
    if isinstance(value, (list, tuple, set)):
        return ";".join(map(str, value))
    return value


def write_layer_assignments(
    out: Path, hierarchy: Mapping[str, Any], l3_result: Mapping[str, Any],
    domain_results: Mapping[str, Mapping[str, Any]],
) -> list[str]:
    """Write one device-assignment CSV for each hierarchy level."""
    l3_by_component = {
        str(row["component_id"]): row for row in l3_result.get("assignments", [])
    }
    l2_rows: list[dict[str, Any]] = []
    l1_rows: list[dict[str, Any]] = []
    l0_rows: list[dict[str, Any]] = []

    for l3_domain in hierarchy["l3_domains"]:
        l3_id = str(l3_domain["id"])
        source_l3_id = str(l3_domain["cluster_id"])
        downstream_times = l3_domain["downstream_analysis_times_seconds"]
        scope_result = domain_results.get(source_l3_id, {})
        l2_result = scope_result.get("l2_result", {})
        completion_by_ref = {
            str(row["component_id"]): row for row in l2_result.get("completion_assignments", [])
        }

        for l2_domain in l3_domain["l2_domains"]:
            l2_id = str(l2_domain["id"])
            for component_id in map(str, l2_domain["members"]):
                completion = completion_by_ref.get(component_id)
                row = completion or {}
                l2_rows.append({
                    "component_id": component_id, "l3_id": l3_id, "l2_id": l2_id,
                    "anchor": l2_domain.get("anchor") or "",
                    "cluster_kind": l2_domain.get("cluster_kind", "major_device_domain"),
                    "function_label": l2_domain.get("function_label", ""),
                    "cluster_type": l2_domain.get("cluster_type", ""),
                    "assignment_source": row.get("source", "algorithm_l2"),
                    "assignment_reason": row.get("reason", l2_domain.get("assignment_reason", "")),
                    "assignment_mode": row.get("assignment_mode", "algorithm_l2"),
                    "evidence_nets": _csv_value(row.get("visible_evidence", row.get("evidence_nets", []))),
                    "confidence": row.get("confidence", ""),
                    "analysis_seconds": downstream_times["L2"],
                })
            for l1_cluster in l2_domain["l1_clusters"]:
                l1_id = str(l1_cluster["id"])
                for component_id in map(str, l1_cluster["members"]):
                    l1_rows.append({
                        "component_id": component_id, "l3_id": l3_id, "l2_id": l2_id,
                        "l1_id": l1_id, "source": l1_cluster.get("source", ""),
                        "aggregate_score": l1_cluster.get("aggregate_score", ""),
                        "topology_score": l1_cluster.get("topology_score", ""),
                        "function_score": l1_cluster.get("function_score", ""),
                        "analysis_seconds": downstream_times["L1"],
                    })
                for l0_cluster in l1_cluster["l0_clusters"]:
                    l0_rows.append({
                        "component_id": str(l0_cluster["component_id"]), "l3_id": l3_id,
                        "l2_id": l2_id, "l1_id": l1_id, "l0_id": str(l0_cluster["id"]),
                        "is_connector": l0_cluster.get("is_connector"),
                        "analysis_seconds": l1_cluster.get("l0_generation_seconds", 0.0),
                    })

    expected = {str(row["component_id"]) for row in hierarchy["assignments"]}
    for level, rows in (("L3", l3_result.get("assignments", [])), ("L2", l2_rows),
                        ("L1", l1_rows), ("L0", l0_rows)):
        refs = [str(row["component_id"]) for row in rows]
        counts = Counter(refs)
        duplicates = sorted(ref for ref, count in counts.items() if count > 1)
        if set(refs) != expected or duplicates:
            raise ValueError(f"{level} CSV 覆盖/唯一性校验失败：missing={sorted(expected-set(refs))}, "
                             f"extra={sorted(set(refs)-expected)}, duplicates={duplicates}")

    paths = {
        "L3_assignments.csv": (
            ["component_id", "l3_id", "cluster_id", "cluster_name", "operating_voltage_v",
             "confidence", "evidence_nets", "reason", "analysis_seconds"],
            [{
                "component_id": str(row["component_id"]),
                "l3_id": f"L3-{row['cluster_id']}", "cluster_id": row.get("cluster_id", ""),
                "cluster_name": row.get("cluster_name", ""),
                "operating_voltage_v": row.get("operating_voltage_v", ""),
                "confidence": row.get("confidence", ""),
                "evidence_nets": _csv_value(row.get("evidence_nets", [])),
                "reason": row.get("reason", ""),
                "analysis_seconds": hierarchy["analysis_times_seconds"]["L3"]["total_seconds"],
            } for row in l3_result.get("assignments", [])],
        ),
        "L2_assignments.csv": (
            ["component_id", "l3_id", "l2_id", "anchor", "cluster_kind", "function_label",
             "cluster_type", "assignment_source", "assignment_reason", "assignment_mode",
             "evidence_nets", "confidence", "analysis_seconds"], l2_rows,
        ),
        "L1_assignments.csv": (
            ["component_id", "l3_id", "l2_id", "l1_id", "source", "aggregate_score",
             "topology_score", "function_score", "analysis_seconds"], l1_rows,
        ),
        "L0_assignments.csv": (
            ["component_id", "l3_id", "l2_id", "l1_id", "l0_id", "is_connector", "analysis_seconds"],
            l0_rows,
        ),
    }
    for filename, (fieldnames, rows) in paths.items():
        _write_csv(out / filename, fieldnames, rows)
    return list(paths)


def run_flow(args: argparse.Namespace) -> dict[str, Any]:
    flow_started = time.perf_counter()
    input_path = Path(args.netlist).resolve()
    out = Path(args.out).resolve()
    out.mkdir(parents=True, exist_ok=True)
    l3_started = time.perf_counter()
    netlist, _topology = l2_flow.load_inputs(input_path)
    save_json(out / "normalized_netlist.json", netlist)

    print(f"开始 L3 电压域划分：{len(netlist['components'])} 个器件。", flush=True)
    l3_result = _run_l3(netlist, args, out / "l3")
    l3_seconds = time.perf_counter() - l3_started
    domain_results: dict[str, dict[str, Any]] = {}
    for cluster in l3_result["clusters"]:
        cluster_id = str(cluster["cluster_id"])
        members = set(map(str, cluster["component_ids"]))
        if not members:
            continue
        domain_results[cluster_id] = _run_l2_l1_for_domain(
            netlist, members, cluster_id, args, out / "domains" / cluster_id,
        )

    hierarchy = build_hierarchy(netlist, l3_result, domain_results, dry_run=args.dry_run,
                                l3_seconds=l3_seconds)
    save_json(out / "hierarchy.json", hierarchy)
    write_assignments_csv(out / "hierarchical_assignments.csv", hierarchy)
    layer_csvs = write_layer_assignments(out, hierarchy, l3_result, domain_results)
    manifest = {
        "schema": "partitioner-v1-flow-manifest-v1",
        "status": "dry_run" if args.dry_run else "completed",
        "input": str(input_path), "output": str(out),
        "threshold_v": args.threshold_v, "temperature": args.temperature,
        "dry_run": bool(args.dry_run),
        "analysis_times_seconds": hierarchy["analysis_times_seconds"],
        "total_elapsed_seconds": round(time.perf_counter() - flow_started, 6),
        "counts": {
            "components": hierarchy["component_count"], "l3_domains": len(hierarchy["l3_domains"]),
            "l2_domains": sum(len(row["l2_domains"]) for row in hierarchy["l3_domains"]),
            "l1_clusters": sum(len(l2["l1_clusters"]) for row in hierarchy["l3_domains"] for l2 in row["l2_domains"]),
            "l0_clusters": len(hierarchy["assignments"]),
        },
        "artifacts": ["normalized_netlist.json", "l3/voltage_partition.json", "hierarchy.json",
                      "hierarchical_assignments.csv", *layer_csvs],
    }
    save_json(out / "run.json", manifest)
    print(f"完成：L3 {manifest['counts']['l3_domains']} 域，L2 {manifest['counts']['l2_domains']} 域，"
          f"L1 {manifest['counts']['l1_clusters']} 簇，L0 {manifest['counts']['l0_clusters']} 个单器件簇。", flush=True)
    print(f"层级结果：{out / 'hierarchy.json'}", flush=True)
    return manifest


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="完整层级划分器：L3 电压域 → L2 功能域 → L1 功能簇 → L0 单器件簇")
    parser.add_argument("netlist", help="标准 JSON 网表或 EasyEDA .enet")
    parser.add_argument("--out", type=Path, default=ROOT / "output", help="输出目录")
    parser.add_argument("--api-key-file", "--deepseek-api-key-file", dest="api_key_file", type=Path,
                        help="DeepSeek 接口配置；也可使用 DEEPSEEK_API_KEY")
    parser.add_argument("--base-url", help="DeepSeek 兼容 API Base URL")
    parser.add_argument("--model", help="DeepSeek 模型名")
    parser.add_argument("--threshold-v", type=float, default=12.0, help="L3 高低压阈值，默认 12 V")
    parser.add_argument("--temperature", type=float, default=0.0, help="模型采样温度，范围 0 到 2")
    parser.add_argument("--timeout", type=int, default=180, help="模型请求超时秒数")
    parser.add_argument("--algorithm-dir", type=Path, default=ROOT / "划分器算法部分",
                        help="确定性划分算法目录")
    parser.add_argument("--dry-run", action="store_true",
                        help="不调用模型；用标记为临时的 L3 占位归属贯通本地 L2/L1/L0")
    args = parser.parse_args(argv)
    if args.threshold_v <= 0:
        parser.error("--threshold-v 必须大于 0")
    if not 0 <= args.temperature <= 2:
        parser.error("--temperature 必须在 0 到 2 之间")
    if args.timeout <= 0:
        parser.error("--timeout 必须是正整数")
    return args


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    try:
        run_flow(args)
        return 0
    except Exception as exc:
        out = Path(args.out).resolve()
        try:
            save_json(out / "flow_error.json", {
                "schema": "partitioner-v1-flow-error-v1", "error_type": type(exc).__name__,
                "error": str(exc), "input": str(Path(args.netlist).resolve()),
            })
        except OSError:
            pass
        print(f"运行失败：{exc}", file=sys.stderr, flush=True)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
