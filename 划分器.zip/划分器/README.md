# 划分器 v1.3（自下而上）

当前划分顺序为：

```text
L0 单器件簇
└─ L1 功能簇
   └─ L2 高/低电压域（从 L1 核心芯片电源脚聚合；混合证据保留为未决边界）
```

功能算法先在完整网表上生成 L1 分簇，再为每个 L1 簇创建 L0 单器件子节点。`.epro2` 使用 L1 短输出流程：确定性算法先分簇，DeepSeek 只接收有合格近邻锚点的小器件补划分候选；超过 4 英寸的已分配小器件会重新进入候选池，候选目标和距离门槛由程序校验。L2 不再逐器件调用模型，而是检查 L1 簇内核心芯片的电源输入引脚和网络名；无数值的电源网及无核心芯片的簇按实验规则归低压，跨越阈值两侧的簇保留在“未决电压边界”。L1 不拆分。流程校验每个器件恰好属于一个 L0、一个 L1 和一个 L2 父域，并校验父子成员完整重建。

主入口 `run_flow.py` 只接受 EasyEDA Pro `.epro2` 工程。L1 直接运行集成自“划分器_针对L1”的短输出流程：确定性算法初划分后，仅对有合格近邻锚点的小器件执行补划分；**不运行 LLM 功能识别**。L2 直接使用集成自“划分器_针对L2”的核心芯片电源输入脚规则聚合。L1、L2 各自调用主项目 `extractors/l1/`、`extractors/l2/` 下的专用提取器，保留两阶段网络语义差异；提取结果分别保存，运行前校验器件 ID 集合一致。

多板 `.epro2` 工程按 EasyEDA 原生 UUID 关系分别划分：原理图文档 `META.board` 必须与 PCB 文档 `META.board` 精确一致，原理图页再通过 `META.schematic` UUID 归属原理图文档。映射后用 PCB 器件位号与所属原理图页面位号做完整性核验；缺失、重复或含糊的 UUID 关系会停止运行，不按标题或相似位号猜测。每块板单独执行 L0/L1/L2，并保存到 `boards/<板名>/`；顶层生成 `board_mapping.json` 和汇总的 `multi_board_hierarchy.json`。同一位号出现在不同板上会作为不同板级器件分别划分。

L1 的提取结果保存在顶层 `epro2_extracted.json` 和 `normalized_netlist.json`；L2 的独立提取结果保存在 `l2/epro2_extracted.json` 和 `l2/normalized_netlist.json`。`schematic.components[].pins[].canvas` 是镜像、旋转、平移后的原理图坐标；`footprint_pad.local` 保留 PCB mil 坐标；`pad_to_canvas` 表示按引脚编号找到的对应原理图引脚位置。原始完整提取代码仍保留在 `epro2_extract.py`，需要完整资源/图片索引时可单独运行：

```powershell
python epro2_extract.py C:\path\to\project.epro2 --out C:\path\to\project.extracted.json
```

单独使用集成的 L1 提取器生成精简结果：

```powershell
python extractors\l1\epro2_extract_slim.py C:\path\to\project.epro2 --out C:\path\to\project.l1.extracted.json
```

图片不内嵌在 JSON 中；脚本会把资源导出到 JSON 同目录的 `<json名>_assets` 文件夹，JSON 记录压缩包路径、导出路径、格式、尺寸和 SHA-256，后续可直接交给视觉模型。原理图线段和 PCB 焊盘网络均会保留，但原理图引脚精确连通关系仍需结合符号/器件引脚定义及坐标变换继续解析，不能把 PCB 网络表当作原理图连通关系的无损替代。

## 启动

Windows 下双击 `启动划分器.cmd`，或在命令行运行：

```powershell
python run_flow.py C:\path\to\project.epro2 `
  --api-key-file C:\path\to\DeepSeek接口文档.txt `
  --out C:\path\to\partition-output
```

接口文档可使用 `模型名`、`Base URL`、`API` 字段，也可通过环境变量 `DEEPSEEK_API_KEY`、`DEEPSEEK_BASE_URL`、`DEEPSEEK_MODEL` 配置。

## Dry-run

```powershell
python run_flow.py project.epro2 --dry-run --out output
```

Dry-run 不访问 DeepSeek；L1 仍运行确定性算法，L2 仍按本地电源网名规则计算。小器件补划分不会调用模型，因此输出仅用于流程检查，不代表有效的模型补划分结果。

## 输出

- `hierarchy.json`：包含严格父子关系的 L2 → L1 → L0 树；`flow_order` 标记实际计算顺序为 L0 → L1 → L2。
- `hierarchical_assignments.csv`：每个器件对应的 L2、L1、L0 ID 和连接器标记。
- `L2_assignments.csv`、`L1_assignments.csv`、`L0_assignments.csv`：按层级导出的器件归属表。
- `l0/base_clusters.json`：流程起点创建的单器件 L0 基础节点。
- `l1/`：算法初划分、短输出补划分请求和 L1 结果；仅在 `.epro2` 输入时启用更新的 L1 实验流程。
- `l2/`：按核心芯片电源输入脚和网络名得到的 L1 电压特征、L2 高/低压结果及未决边界。

主流程使用项目内 `l1_flow.py` 的 L1 短输出补划分流程（无 LLM 功能识别）、`l1_voltage_aggregate.py` 的 L2 电压规则聚合，以及 `划分器算法部分` 中的确定性算法。两份阶段提取器分别集成在 `extractors/l1/` 与 `extractors/l2/`，运行时不再依赖桌面上的两个实验目录。输入格式为 `.epro2`；`.enet` 和普通网表 JSON 目前不支持。
