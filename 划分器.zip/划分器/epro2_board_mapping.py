"""Reliable EasyEDA Pro schematic-to-PCB board mapping and board netlists."""
from __future__ import annotations

import copy
import zipfile
from collections import defaultdict
from pathlib import Path
from typing import Any, Mapping


def map_project_boards(path: Path, extracted: Mapping[str, Any], extractor: Any) -> list[dict[str, Any]]:
    """Map schematic pages to PCBs through EasyEDA's native board UUID metadata.

    No title/ref-name heuristic is used. A missing or ambiguous native link is
    an error, because silently grouping the wrong board would corrupt results.
    """
    docs = list(extracted.get("documents", []))
    schematic_docs = {str(d.get("document_uuid")): d for d in docs
                      if d.get("doc_type") == "SCH" and d.get("document_uuid")}
    grouped: dict[int, list[dict[str, Any]]] = defaultdict(list)
    with zipfile.ZipFile(path) as archive:
        epru = extracted.get("source", {}).get("epru_path")
        if not epru:
            raise ValueError("提取结果缺少 EPRU 路径，无法可靠映射板卡")
        for row in extractor._read_records(archive.read(epru).decode("utf-8-sig")):
            grouped[int(row["segment"])].append(row)

    pages_by_schematic: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for doc in docs:
        if doc.get("doc_type") != "SCH_PAGE":
            continue
        metadata = doc.get("metadata") or {}
        schematic_uuid = str(metadata.get("schematic") or "")
        if not schematic_uuid:
            raise ValueError(f"原理图页 {doc.get('segment')} 缺少所属原理图 UUID")
        if schematic_uuid not in schematic_docs:
            raise ValueError(f"原理图页 {doc.get('segment')} 指向不存在的原理图 {schematic_uuid}")
        pages_by_schematic[schematic_uuid].append(doc)

    boards = []
    seen_board_ids: set[str] = set()
    for pcb in (d for d in docs if d.get("doc_type") == "PCB"):
        meta = pcb.get("metadata") or {}
        board_uuid = str(meta.get("board") or "")
        pcb_uuid = str(pcb.get("document_uuid") or "")
        rows = grouped.get(int(pcb["segment"]), [])
        component_rows = [row for row in rows if row["type"] == "COMPONENT"]
        if not board_uuid:
            # EasyEDA projects may contain empty mechanical/outline PCB
            # documents that are not linked to a schematic board. They carry
            # no circuit devices and must not block partitioning of the real
            # UUID-linked boards. Never skip an unlinked PCB that has devices.
            if not component_rows:
                continue
            raise ValueError(f"PCB {meta.get('title') or pcb.get('segment')} 缺少 board UUID，拒绝猜测映射")
        if board_uuid in seen_board_ids:
            raise ValueError(f"多个 PCB 文档共享 board UUID {board_uuid}，无法唯一映射")
        seen_board_ids.add(board_uuid)
        matching_schematics = [d for d in schematic_docs.values()
                               if str((d.get("metadata") or {}).get("board") or "") == board_uuid]
        if len(matching_schematics) != 1:
            raise ValueError(f"PCB {meta.get('title')} 的 board UUID {board_uuid} 对应 {len(matching_schematics)} 份原理图，要求唯一")
        schematic = matching_schematics[0]
        schematic_uuid = str(schematic["document_uuid"])
        pages = pages_by_schematic.get(schematic_uuid, [])
        if not pages:
            raise ValueError(f"板卡 {meta.get('title')} 对应原理图 {schematic_uuid} 没有页面")
        attrs = extractor._attrs(rows)
        pcb_refs = set()
        for row in rows:
            if row["type"] == "COMPONENT":
                ref = extractor._number(attrs.get(row["id"], {}).get("Designator")).strip()
                if ref and not ref.startswith("@"):
                    pcb_refs.add(ref)
        page_ids = {int(page["segment"]) for page in pages}
        schematic_rows = [c for c in extracted.get("schematic", {}).get("components", [])
                          if int(c.get("document_segment", -1)) in page_ids]
        schematic_refs = {str(c.get("designator", "")).strip() for c in schematic_rows}
        missing = sorted(pcb_refs - schematic_refs)
        if missing:
            raise ValueError(f"板卡 {meta.get('title')} 有 {len(missing)} 个 PCB 器件未在对应原理图找到：{missing[:12]}")
        if not pcb_refs:
            raise ValueError(f"板卡 {meta.get('title')} 的 PCB 没有已标注位号的器件")
        boards.append({"board_id": board_uuid, "pcb_uuid": pcb_uuid,
                       "name": str(meta.get("title") or f"PCB_{pcb.get('segment')}"),
                       "pcb_segment": int(pcb["segment"]), "schematic_uuid": schematic_uuid,
                       "schematic_name": str((schematic.get("metadata") or {}).get("title") or schematic_uuid),
                       "schematic_pages": [{"segment": int(p["segment"]),
                                            "uuid": p.get("document_uuid"),
                                            "name": str((p.get("metadata") or {}).get("title") or p["segment"])}
                                           for p in pages],
                       "pcb_component_ids": sorted(pcb_refs),
                       "schematic_component_count": len(schematic_refs),
                       "pcb_component_count": len(pcb_refs),
                       "unplaced_schematic_component_ids": sorted(schematic_refs - pcb_refs)})
    if not boards:
        raise ValueError("工程中未找到含原生 board UUID 的 PCB 板卡")
    return boards


def board_extracted(extracted: Mapping[str, Any], board: Mapping[str, Any]) -> dict[str, Any]:
    """Return L1/L2 extractor data limited to one reliably mapped board."""
    page_segments = {int(p["segment"]) for p in board["schematic_pages"]}
    refs = set(map(str, board["pcb_component_ids"]))
    subset = copy.deepcopy(dict(extracted))
    schematic = subset.get("schematic", {})
    schematic["components"] = [c for c in schematic.get("components", [])
                               if int(c.get("document_segment", -1)) in page_segments
                               and str(c.get("designator", "")).strip() in refs]
    schematic["wires"] = [w for w in schematic.get("wires", [])
                          if int(w.get("document_segment", -1)) in page_segments]
    subset["board"] = dict(board)
    return subset


def board_netlist(extracted: Mapping[str, Any], board: Mapping[str, Any], extractor: Any) -> dict[str, Any]:
    """Build a fresh netlist from only this board's schematic pages and PCB refs."""
    refs = set(map(str, board["pcb_component_ids"]))
    subset = board_extracted(extracted, board)
    netlist = extractor.to_partition_netlist(subset)
    got = {str(c["ref"]) for c in netlist.get("components", [])}
    if got != refs:
        raise ValueError(f"板卡 {board['name']} 网表位号和 PCB 清单不一致：missing={sorted(refs-got)}, extra={sorted(got-refs)}")
    netlist["name"] = f"{extracted.get('source', {}).get('archive', 'project')}__{board['name']}"
    netlist["board"] = dict(board)
    return netlist
