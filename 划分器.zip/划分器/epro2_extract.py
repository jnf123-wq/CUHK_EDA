"""Extract useful, auditable design data from an EasyEDA Pro .epro2 archive."""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import zipfile
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any


RECORD_RE = re.compile(r'(\{"type":"([A-Z_]+)"[^\n]*?\}\|\|)([^|]*)\|')
# A value-like token used when a library part id contains the electrical value.
# The unit is intentional: it prevents IDs such as ``CGA0603...`` from being
# mistaken for a capacitor value merely because they contain digits.
VALUE_TOKEN_RE = re.compile(
    r"(?i)(?<![a-z0-9])(?:\d+(?:\.\d+)?|\.\d+)\s*"
    r"(?:pF|nF|uF|µF|μF|mF|F|pH|nH|uH|µH|μH|mH|H|mΩ|kΩ|MΩ|Ω|ohm|[kKmMgG]|V|A|W|%)"
    r"(?![a-z0-9])"
)


def _normalize_value_token(value: Any, *, from_part_id: bool = False) -> str | None:
    """Return a stable value string, without changing the raw source field."""
    if value is None:
        return None
    text = str(value).strip()
    if not text or text.casefold() in {"none", "null", "n/a", "na", "-", "?"}:
        return None
    # EasyEDA may store unresolved attribute expressions (for example
    # ``={ManufacturerPart}``) in Name. They are not component values.
    if any(marker in text for marker in ("{", "}", "=")):
        return None
    if from_part_id:
        # EasyEDA library IDs commonly append the unit/variant as ``.1``.
        text = re.sub(r"\.\d+$", "", text).strip()
        match = VALUE_TOKEN_RE.search(text)
        if not match:
            return None
        text = match.group(0)
    return re.sub(r"\s+", "", text).replace("μ", "u").replace("µ", "u")


def _apply_normalized_value(component: dict[str, Any]) -> None:
    """Add derived value fields while retaining all original component data."""
    attrs = component.get("attributes") if isinstance(component.get("attributes"), dict) else {}
    candidates = [
        (component.get("value"), "Value", 1.0, False),
        (attrs.get("Value"), "Value", 1.0, False),
        (component.get("name"), "Name", 0.9, False),
        (attrs.get("Name"), "Name", 0.9, False),
        (component.get("part_id"), "part_id", 0.8, True),
    ]
    for raw, source, confidence, from_part_id in candidates:
        normalized = _normalize_value_token(raw, from_part_id=from_part_id)
        if normalized is not None:
            component["value_normalized"] = normalized
            component["value_source"] = source
            component["value_confidence"] = confidence
            return
    component["value_normalized"] = None
    component["value_source"] = None
    component["value_confidence"] = 0.0


def _records(text: str) -> list[dict[str, Any]]:
    """Parse records while retaining their document segment and header metadata."""
    result: list[dict[str, Any]] = []
    document: dict[str, Any] = {}
    segment = 0
    for match in RECORD_RE.finditer(text):
        try:
            header = json.loads(match.group(1)[:-2])
            payload = json.loads(match.group(3))
        except (ValueError, TypeError):
            continue
        if not isinstance(header, dict) or not isinstance(payload, dict):
            continue
        if header.get("type") == "DOCHEAD":
            document = payload
            segment += 1
            continue
        result.append({"doc_type": document.get("docType", "UNKNOWN"),
                       "document_uuid": document.get("uuid"), "segment": segment,
                       "type": header.get("type", ""), "id": str(header.get("id", "")),
                       "ticket": header.get("ticket"), "data": payload})
    # Repeated entity versions are scoped to a document segment, not globally.
    latest: dict[tuple[int, str, str], dict[str, Any]] = {}
    for row in result:
        latest[(row["segment"], row["type"], row["id"])] = row
    return list(latest.values())


def _webp_size(data: bytes) -> tuple[int | None, int | None]:
    try:
        if data[:4] != b"RIFF" or data[8:12] != b"WEBP":
            return None, None
        kind = data[12:16]
        if kind == b"VP8X":
            return 1 + int.from_bytes(data[24:27], "little"), 1 + int.from_bytes(data[27:30], "little")
        if kind == b"VP8 " and data[23:26] == b"\x9d\x01\x2a":
            return int.from_bytes(data[26:28], "little") & 0x3FFF, int.from_bytes(data[28:30], "little") & 0x3FFF
        if kind == b"VP8L" and data[20] == 0x2F:
            b1, b2, b3, b4 = data[21:25]
            return 1 + (((b2 & 0x3F) << 8) | b1), 1 + (((b4 & 0x0F) << 10) | (b3 << 2) | (b2 >> 6))
    except (IndexError, ValueError):
        pass
    return None, None


def extract_epro2(path: Path, *, asset_dir: Path | None = None) -> dict[str, Any]:
    path = Path(path).resolve()
    if asset_dir is not None:
        asset_dir = Path(asset_dir).resolve()
    try:
        with zipfile.ZipFile(path) as archive:
            names = archive.namelist()
            epru = next((name for name in names if name.lower().endswith(".epru")), None)
            if not epru:
                raise ValueError(".epro2 压缩包中没有 .epru 项目数据")
            records = _records(archive.read(epru).decode("utf-8-sig"))
            assets = []
            for name in names:
                if not name.lower().startswith("image/") or name.endswith("/"):
                    continue
                blob = archive.read(name)
                width, height = _webp_size(blob) if name.lower().endswith(".webp") else (None, None)
                extracted_path = None
                if asset_dir is not None:
                    asset_dir.mkdir(parents=True, exist_ok=True)
                    filename = hashlib.sha256(name.encode("utf-8")).hexdigest()[:10] + "_" + Path(name).name
                    extracted_path = asset_dir / filename
                    extracted_path.write_bytes(blob)
                assets.append({"archive_path": name, "format": Path(name).suffix.lstrip(".").lower() or "unknown",
                               "size_bytes": len(blob), "sha256": hashlib.sha256(blob).hexdigest(),
                               "width": width, "height": height,
                               "extracted_path": str(extracted_path) if extracted_path else None,
                               "note": "原图仍在 epro2 压缩包中；此处不内嵌二进制，供后续视觉模型按需读取。"})
    except (OSError, zipfile.BadZipFile, UnicodeDecodeError) as exc:
        raise ValueError(f"无法读取 .epro2 文件：{exc}") from exc

    by_segment: dict[int, list[dict[str, Any]]] = defaultdict(list)
    for row in records:
        by_segment[row["segment"]].append(row)
    docs = []
    component_index: dict[str, dict[str, Any]] = {}
    pcb_components = []
    pcb_pad_nets = []
    pcb_boards = []
    libraries: dict[str, list[dict[str, Any]]] = {"footprints": [], "symbols": [], "devices": []}
    for segment, rows in by_segment.items():
        doc_type = rows[0]["doc_type"]
        segment_component_refs: dict[str, str] = {}
        segment_pad_nets = []
        segment_nets: dict[str, dict[tuple[str, str], dict[str, Any]]] = defaultdict(dict)
        attrs: dict[str, dict[str, Any]] = defaultdict(dict)
        for row in rows:
            if row["type"] == "ATTR":
                data = row["data"]
                attrs[str(data.get("parentId", ""))][str(data.get("key", ""))] = data.get("value")
        entities = []
        for row in rows:
            data = row["data"]
            if row["type"] == "COMPONENT":
                properties = attrs.get(row["id"], {})
                item = {"entity_id": row["id"], "part_id": data.get("partId"),
                        "designator": properties.get("Designator"),
                        "name": properties.get("Name"), "value": properties.get("Value"),
                        "footprint": properties.get("Footprint"), "device": properties.get("Device"),
                        "attributes": properties, "placement": {k: data.get(k) for k in
                         ("x", "y", "rotation", "isMirror") if k in data}}
                _apply_normalized_value(item)
                entities.append({"type": "COMPONENT", "id": row["id"], "data": data, "attributes": properties})
                if doc_type == "SCH_PAGE" and item["designator"]:
                    component_index[str(item["designator"])] = item
                if doc_type == "PCB":
                    item["document_segment"] = segment
                    pcb_components.append(item)
                    if item["designator"]:
                        segment_component_refs[row["id"]] = str(item["designator"])
            elif row["type"] == "WIRE" and doc_type == "SCH_PAGE":
                net_name = str(attrs.get(row["id"], {}).get("NET") or "").strip()
                lines = [r["data"] for r in rows if r["type"] == "LINE" and str(r["data"].get("lineGroup")) == row["id"]]
                entities.append({"type": "WIRE", "id": row["id"], "net": net_name or None, "segments": lines})
            elif row["type"] == "PAD_NET" and doc_type == "PCB":
                try:
                    _, comp_entity, pin_number, pad_entity, *_ = json.loads(row["id"])
                except (ValueError, TypeError):
                    comp_entity, pin_number, pad_entity = "", "", ""
                value = {"entity_id": row["id"], "component_entity_id": str(comp_entity),
                         "component": segment_component_refs.get(str(comp_entity)),
                         "pin": str(pin_number), "pad_entity_id": str(pad_entity), "net": data.get("padNet")}
                pcb_pad_nets.append(value)
                segment_pad_nets.append(value)
                if value["net"]:
                    segment_nets[str(value["net"])][(value["component_entity_id"], value["pin"])] = value
            elif row["type"] in {"PAD", "TRACK", "LINE", "ARC", "PRIMITIVE", "POLY", "FILL",
                                   "VIA", "POURED", "POUR", "NET", "RULE", "BOARD", "REGION",
                                   "LAYER", "LAYER_PHYS"}:
                entities.append({"type": row["type"], "id": row["id"], "data": data})
        docs.append({"doc_type": doc_type, "document_uuid": rows[0]["document_uuid"],
                     "segment": segment, "record_counts": dict(Counter(r["type"] for r in rows)),
                     "entities": entities})
        if doc_type in {"FOOTPRINT", "SYMBOL", "DEVICE"}:
            library_attrs = [r["data"] for r in rows if r["type"] == "ATTR"]
            top_attrs = {str(a.get("key")): a.get("value") for a in library_attrs if not a.get("parentId")}
            library = {"document_uuid": rows[0]["document_uuid"], "name": top_attrs.get("Footprint") or top_attrs.get("Symbol") or top_attrs.get("Name"),
                       "record_counts": dict(Counter(r["type"] for r in rows))}
            if doc_type == "FOOTPRINT":
                pads = [r for r in rows if r["type"] == "PAD"]
                library["pads"] = [{"entity_id": r["id"], "number": r["data"].get("num"),
                                    "x": r["data"].get("centerX"), "y": r["data"].get("centerY"),
                                    "shape": r["data"].get("defaultPad")} for r in pads]
                library["pad_count"] = len(pads)
                libraries["footprints"].append(library)
            elif doc_type == "SYMBOL":
                library["pins"] = [{"entity_id": r["id"], "data": r["data"],
                                    "attributes": {str(a.get("key")): a.get("value") for a in library_attrs
                                                   if a.get("parentId") == r["id"]}}
                                   for r in rows if r["type"] == "PIN"]
                libraries["symbols"].append(library)
            else:
                library["records"] = [{"type": r["type"], "id": r["id"], "data": r["data"]}
                                       for r in rows if r["type"] in {"COMPONENT", "PIN", "PART", "ATTR"}]
                libraries["devices"].append(library)
        if doc_type == "PCB":
            nets = [{"name": net, "endpoints": sorted(values.values(), key=lambda x: (x["component_entity_id"], x["pin"]))}
                    for net, values in sorted(segment_nets.items())]
            pcb_boards.append({"document_uuid": rows[0]["document_uuid"], "segment": segment,
                               "components": [dict(c, segment=segment) for c in pcb_components
                                              if c.get("document_segment") == segment],
                               "pad_nets": segment_pad_nets, "nets": nets})
    schematic_by_ref = {str(c.get("designator")): c for c in component_index.values() if c.get("designator")}
    footprint_by_id = {str(item["document_uuid"]): item for item in libraries["footprints"]}
    device_by_id = {str(item["document_uuid"]): item for item in libraries["devices"]}
    for component in pcb_components:
        footprint_info = footprint_by_id.get(str(component.get("footprint") or ""))
        device_info = device_by_id.get(str(component.get("device") or ""))
        component["footprint_id"] = component.get("footprint")
        component["footprint_name"] = footprint_info.get("name") if footprint_info else None
        component["device_name"] = device_info.get("name") if device_info else None
        schematic_component = schematic_by_ref.get(str(component.get("designator")))
        if schematic_component:
            component["schematic_attributes"] = schematic_component.get("attributes", {})
            component["value"] = schematic_component.get("value") or schematic_component.get("name") or schematic_component.get("part_id")
            component["value_normalized"] = schematic_component.get("value_normalized")
            component["value_source"] = schematic_component.get("value_source")
            component["value_confidence"] = schematic_component.get("value_confidence", 0.0)
    for board in pcb_boards:
        for component in board["components"]:
            footprint_info = footprint_by_id.get(str(component.get("footprint") or ""))
            component["footprint_id"] = component.get("footprint")
            component["footprint_name"] = footprint_info.get("name") if footprint_info else None
            schematic_component = schematic_by_ref.get(str(component.get("designator")))
            if schematic_component:
                component["schematic_attributes"] = schematic_component.get("attributes", {})
                component["value"] = schematic_component.get("value") or schematic_component.get("name") or schematic_component.get("part_id")
                component["value_normalized"] = schematic_component.get("value_normalized")
                component["value_source"] = schematic_component.get("value_source")
                component["value_confidence"] = schematic_component.get("value_confidence", 0.0)
    schematic_wires = [{"document_segment": doc["segment"], **wire} for doc in docs if doc["doc_type"] == "SCH_PAGE"
                       for wire in doc["entities"] if wire["type"] == "WIRE"]
    schematic_nets: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for wire in schematic_wires:
        if wire.get("net"):
            schematic_nets[str(wire["net"])].append({"wire_id": wire["id"], "document_segment": wire["document_segment"],
                                                     "segments": wire.get("segments", [])})
    return {"schema": "easyeda-pro-extraction-v1", "source": {"path": str(path), "archive": path.name,
            "epru_path": epru}, "documents": docs,
            "schematic": {"components": sorted(component_index.values(), key=lambda x: str(x.get("designator"))),
                          "wires": schematic_wires,
                          "nets": [{"name": name, "wires": wires} for name, wires in sorted(schematic_nets.items())],
                          "connectivity_note": "原理图网络按 WIRE 上的 NET 标签分组并保留线段；标签/线段到符号引脚的精确连通关系仍需结合 SYMBOL/DEVICE pin 变换解析，PCB PAD_NET 端点仅提供独立交叉核对。"},
            "pcb": {"boards": pcb_boards, "components": pcb_components, "pad_nets": pcb_pad_nets,
                    "nets": [{"board_segment": board["segment"], **net} for board in pcb_boards for net in board["nets"]],
                    "net_count": sum(len(board["nets"]) for board in pcb_boards),
                    "note": "按 PCB 文档段分别汇总；原始实体保留焊盘、走线、过孔、铺铜和板框等几何（若存在）。"},
            "assets": assets,
            "libraries": libraries,
            "extraction_notes": ["图片以压缩包内路径、格式、尺寸和 SHA-256 索引；未复制或转成 Base64。",
                                 "Designator/Value/Footprint 等均来自工程 ATTR；库文件记录与工程文档按 DOCHEAD 隔离。",
                                 "原理图导线标签和 PCB 焊盘网络不保证完全一致，应由后续处理做交叉校验。"]}


def main() -> int:
    parser = argparse.ArgumentParser(description="提取 EasyEDA Pro .epro2 工程信息为统一 JSON")
    parser.add_argument("input", type=Path)
    parser.add_argument("--out", type=Path, default=None)
    args = parser.parse_args()
    output = args.out or args.input.with_suffix(".extracted.json")
    asset_dir = output.parent / (output.stem + "_assets")
    result = extract_epro2(args.input, asset_dir=asset_dir)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
