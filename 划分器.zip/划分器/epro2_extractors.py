"""Load the stage-specific EasyEDA Pro extractors used by the partition flow."""
from __future__ import annotations

import importlib.util
import sys
from pathlib import Path
from types import ModuleType


ROOT = Path(__file__).resolve().parent
EXPERIMENTS = {
    "L1": ROOT / "extractors" / "l1" / "epro2_extract_slim.py",
    "L2": ROOT / "extractors" / "l2" / "epro2_extract_slim.py",
}


def load_extractor(stage: str) -> ModuleType:
    """Load the requested experiment's extractor without module-name collisions."""
    try:
        path = EXPERIMENTS[stage.upper()]
    except KeyError as exc:
        raise ValueError(f"Unsupported extraction stage: {stage}") from exc
    if not path.is_file():
        raise FileNotFoundError(f"{stage.upper()} .epro2 extractor not found: {path}")

    module_name = f"partitioner_{stage.lower()}_epro2_extract_slim"
    cached = sys.modules.get(module_name)
    if cached is not None:
        return cached
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load {stage.upper()} .epro2 extractor: {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    try:
        spec.loader.exec_module(module)
    except Exception:
        sys.modules.pop(module_name, None)
        raise
    return module
