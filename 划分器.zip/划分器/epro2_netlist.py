"""Convert EasyEDA Pro .epro2 schematic extraction into the voltage-flow netlist.

Connectivity and component IDs follow the bottom-up L1 flow so an L1 result
created from the same project can be matched to this voltage aggregation.
"""
from __future__ import annotations
from pathlib import Path
from typing import Any

from epro2_extractors import load_extractor


def extract_input(path: str | Path) -> tuple[dict[str, Any], dict[str, Any]]:
    source=Path(path)
    if source.suffix.lower() != ".epro2":
        raise ValueError(f"只接受 .epro2 工程文件: {source}")
    extractor=load_extractor("L2")
    extracted=extractor.extract_epro2_slim(source)
    netlist=extractor.to_partition_netlist(extracted)
    netlist["source_path"]=str(source.resolve())
    netlist["extraction_summary"]={
        "document_count":len(extracted.get("documents",[])),
        "schematic_component_count":len(extracted.get("schematic",{}).get("components",[])),
        "schematic_wire_count":len(extracted.get("schematic",{}).get("wires",[])),
        "normalized_component_count":len(netlist.get("components",[])),
        "normalized_net_count":len(netlist.get("nets",[])),
        "source_format":"easyeda-pro-epro2-schematic-first",
    }
    return netlist,extracted


def load_input(path: str | Path) -> dict[str, Any]:
    """Compatibility helper returning only the normalized netlist."""
    return extract_input(path)[0]
