"""精简版 EasyEDA Pro .epro2 提取器。

保留原始完整提取器 ``epro2_extract.py``；本文件只输出 source、documents、
schematic、libraries 四个根字段。它还把符号引脚从器件局部坐标变换到原理图画布坐标，
并按引脚编号关联封装焊盘。封装焊盘本身仍保留 PCB/封装坐标，不能直接冒充原理图坐标。
"""
from __future__ import annotations

import argparse
import json
import math
import re
import zipfile
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

# Each ``.epru`` record is stored on one line as ``header||payload|``.
# Do not assume compact JSON here: exported fixtures and some EasyEDA
# versions include spaces after ``:``/``,``.  Matching line-by-line also
# lets the payload contain ``|`` inside a JSON string; the final pipe on the
# line is the record terminator.
RECORD_RE = re.compile(r'(?m)^(?P<header>\{.*?\})\|\|(?P<data>\{.*\})\|\s*$')


def _read_records(text: str) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    doc: dict[str, Any] = {}
    segment = 0
    for match in RECORD_RE.finditer(text):
        try:
            header = json.loads(match.group("header"))
            data = json.loads(match.group("data"))
        except (TypeError, ValueError):
            continue
        if not isinstance(header, dict) or not isinstance(data, dict):
            continue
        if header.get("type") == "DOCHEAD":
            doc = data
            segment += 1
            continue
        rows.append({"doc_type": doc.get("docType", "UNKNOWN"),
                     "document_uuid": doc.get("uuid"), "segment": segment,
                     "type": str(header.get("type", "")), "id": str(header.get("id", "")),
                     "ticket": header.get("ticket"), "data": data})
    latest: dict[tuple[int, str, str], dict[str, Any]] = {}
    for row in rows:
        latest[(row["segment"], row["type"], row["id"])] = row
    return list(latest.values())


def _attrs(rows: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = defaultdict(dict)
    for row in rows:
        if row["type"] == "ATTR":
            data = row["data"]
            result[str(data.get("parentId", ""))][str(data.get("key", ""))] = data.get("value")
    return result


def _pin_attrs(pin_id: str, attrs: dict[str, dict[str, Any]]) -> dict[str, Any]:
    values = attrs.get(pin_id, {})
    return {"pin_name": values.get("Pin Name"), "pin_number": values.get("Pin Number"),
            "pin_type": values.get("Pin Type")}


def _transform(local_x: float, local_y: float, origin_x: float, origin_y: float,
               rotation: float, mirror: bool) -> tuple[float, float]:
    """镜像（局部 Y 轴）→旋转→平移，单位保持 schematic_native。"""
    x, y = -float(local_x) if mirror else float(local_x), float(local_y)
    angle = math.radians(float(rotation or 0))
    return (origin_x + math.cos(angle) * x - math.sin(angle) * y,
            origin_y + math.sin(angle) * x + math.cos(angle) * y)


def _number(value: Any) -> str:
    return "" if value is None else str(value)


def _library_data(rows: list[dict[str, Any]]) -> tuple[dict[str, Any], dict[str, Any]]:
    attrs = _attrs(rows)
    doc_type = rows[0]["doc_type"]
    if doc_type == "SYMBOL":
        part = next((r["data"] for r in rows if r["type"] == "PART"), {})
        part_id = str(part.get("title") or "")
        top = attrs.get("") or {}
        pins = []
        for row in rows:
            if row["type"] != "PIN":
                continue
            data = row["data"]
            pin = {"entity_id": row["id"], "local": {k: data.get(k) for k in
                    ("x", "y", "rotation", "length") if k in data},
                   "coordinate_system": "schematic_native"}
            pin.update(_pin_attrs(row["id"], attrs))
            pins.append(pin)
        record = {"document_uuid": rows[0]["document_uuid"], "part_id": part_id,
                  "name": top.get("Symbol") or top.get("Name") or part_id,
                  "coordinate_system": "schematic_native", "bbox": part.get("BBOX"),
                  "bbox_unit": "schematic_native", "pins": pins,
                  "record_counts": dict(Counter(r["type"] for r in rows))}
        return record, {part_id: record} if part_id else {}
    if doc_type == "FOOTPRINT":
        top = attrs.get("") or {}
        pads = []
        for row in rows:
            if row["type"] != "PAD":
                continue
            data = row["data"]
            pads.append({"entity_id": row["id"], "number": _number(data.get("num")),
                         "local": {"x": data.get("centerX"), "y": data.get("centerY")},
                         "coordinate_system": "pcb_mil",
                         "rotation": data.get("padAngle"), "shape": data.get("defaultPad"),
                         "hole": data.get("hole"), "layer_id": data.get("layerId")})
        name = top.get("Footprint") or top.get("Name")
        record = {"document_uuid": rows[0]["document_uuid"], "name": name,
                  "coordinate_system": "pcb_mil",
                  "pads": pads, "pad_count": len(pads),
                  "record_counts": dict(Counter(r["type"] for r in rows))}
        return record, {str(rows[0]["document_uuid"]): record}
    return {}, {}


def extract_epro2_slim(path: Path) -> dict[str, Any]:
    path = Path(path).resolve()
    try:
        with zipfile.ZipFile(path) as archive:
            epru = next((name for name in archive.namelist() if name.lower().endswith(".epru")), None)
            if not epru:
                raise ValueError(".epro2 压缩包中没有 .epru 项目数据")
            rows = _read_records(archive.read(epru).decode("utf-8-sig"))
    except (OSError, zipfile.BadZipFile, UnicodeDecodeError) as exc:
        raise ValueError(f"无法读取 .epro2 文件：{exc}") from exc

    grouped: dict[int, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        grouped[row["segment"]].append(row)
    documents = []
    symbols: list[dict[str, Any]] = []
    footprints: list[dict[str, Any]] = []
    symbol_by_part: dict[str, dict[str, Any]] = {}
    footprint_by_id: dict[str, dict[str, Any]] = {}
    for segment, segment_rows in grouped.items():
        doc_type = segment_rows[0]["doc_type"]
        metadata = next((row["data"] for row in segment_rows if row["type"] == "META"), {})
        documents.append({"doc_type": doc_type, "document_uuid": segment_rows[0]["document_uuid"],
                          "segment": segment, "record_counts": dict(Counter(r["type"] for r in segment_rows)),
                          "record_count": len(segment_rows), "metadata": metadata})
        if doc_type == "SYMBOL":
            record, lookup = _library_data(segment_rows)
            if record:
                symbols.append(record)
                symbol_by_part.update(lookup)
        elif doc_type == "FOOTPRINT":
            record, lookup = _library_data(segment_rows)
            if record:
                footprints.append(record)
                footprint_by_id.update(lookup)

    pcb_footprint_by_ref: dict[str, str] = {}
    for segment_rows in grouped.values():
        if segment_rows[0]["doc_type"] != "PCB":
            continue
        attrs = _attrs(segment_rows)
        for row in segment_rows:
            if row["type"] != "COMPONENT":
                continue
            properties = attrs.get(row["id"], {})
            ref = _number(properties.get("Designator"))
            footprint_id = _number(properties.get("Footprint"))
            if ref and footprint_id:
                pcb_footprint_by_ref[ref] = footprint_id

    schematic_components: list[dict[str, Any]] = []
    schematic_wires: list[dict[str, Any]] = []
    schematic_net_labels: list[dict[str, Any]] = []
    symbol_by_uuid = {str(symbol.get("document_uuid")): symbol for symbol in symbols
                      if symbol.get("document_uuid")}
    schematic_net_wires: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for segment_rows in grouped.values():
        if segment_rows[0]["doc_type"] != "SCH_PAGE":
            continue
        attrs = _attrs(segment_rows)
        for row in segment_rows:
            if row["type"] == "COMPONENT":
                data = row["data"]
                properties = attrs.get(row["id"], {})
                ref = _number(properties.get("Designator"))
                # EasyEDA Pro stores power/global net symbols as COMPONENTs;
                # their net name is an ATTR on the component, not on a WIRE.
                global_net_name = str(properties.get("Global Net Name") or "").strip()
                if global_net_name and data.get("x") is not None and data.get("y") is not None:
                    label_symbol = symbol_by_uuid.get(str(properties.get("Symbol") or ""))
                    label_pins = (label_symbol or {}).get("pins", [])
                    anchor_x, anchor_y = data["x"], data["y"]
                    if label_pins:
                        local = label_pins[0].get("local", {})
                        if local.get("x") is not None and local.get("y") is not None:
                            anchor_x, anchor_y = _transform(
                                local["x"], local["y"], data["x"], data["y"],
                                data.get("rotation", 0), bool(data.get("isMirror", False)))
                    schematic_net_labels.append({
                        "component_entity_id": row["id"], "name": global_net_name,
                        "anchor": {"x": anchor_x, "y": anchor_y, "unit": "schematic_native"},
                    })
                if not ref or ref.startswith("@"):
                    continue
                origin_x, origin_y = data.get("x"), data.get("y")
                component = {"entity_id": row["id"], "document_segment": row["segment"],
                             "document_uuid": row["document_uuid"], "designator": ref,
                             "part_id": data.get("partId"), "name": properties.get("Name"),
                             "value": properties.get("Value"), "attributes": properties,
                             "placement": {"x": origin_x, "y": origin_y,
                                           "rotation": data.get("rotation", 0),
                                           "is_mirror": bool(data.get("isMirror", False)),
                                           "coordinate_system": "schematic_native"},
                             "coordinate_system": "schematic_native"}
                symbol = symbol_by_part.get(_number(data.get("partId")))
                footprint_id = _number(properties.get("Footprint")) or pcb_footprint_by_ref.get(ref)
                footprint = footprint_by_id.get(footprint_id)
                pin_rows = []
                if symbol and origin_x is not None and origin_y is not None:
                    for pin in symbol["pins"]:
                        local = pin["local"]
                        if local.get("x") is None or local.get("y") is None:
                            continue
                        canvas_x, canvas_y = _transform(local["x"], local["y"], origin_x, origin_y,
                                                        data.get("rotation", 0), bool(data.get("isMirror", False)))
                        item = {"pin_number": pin.get("pin_number"), "pin_name": pin.get("pin_name"),
                                "pin_type": pin.get("pin_type"), "symbol_pin_entity_id": pin["entity_id"],
                                "symbol_local": local, "canvas": {"x": canvas_x, "y": canvas_y,
                                "unit": "schematic_native", "unit_mm": 0.254}}
                        if footprint:
                            pad = next((p for p in footprint["pads"] if p["number"] == _number(pin.get("pin_number"))), None)
                            if pad:
                                item["footprint_pad"] = {"entity_id": pad["entity_id"], "number": pad["number"],
                                                         "local": pad["local"], "unit": "pcb_mil"}
                                item["pad_to_canvas"] = {"x": canvas_x, "y": canvas_y,
                                                          "unit": "schematic_native", "method": "matched_by_pin_number"}
                        pin_rows.append(item)
                component["pins"] = pin_rows
                component["symbol_reference"] = {"part_id": symbol["part_id"],
                    "library_document_uuid": symbol["document_uuid"]} if symbol else None
                component["footprint_reference"] = {"library_document_uuid": footprint["document_uuid"],
                    "name": footprint.get("name")} if footprint else None
                schematic_components.append(component)
            elif row["type"] == "WIRE":
                net = _number(_attrs(segment_rows).get(row["id"], {}).get("NET")).strip() or None
                segments = [r["data"] for r in segment_rows
                            if r["type"] == "LINE" and _number(r["data"].get("lineGroup")) == row["id"]]
                wire = {"document_segment": row["segment"], "id": row["id"], "net": net,
                        "coordinate_system": "schematic_native", "unit": "schematic_native",
                        "segments": segments}
                schematic_wires.append(wire)
                if net:
                    schematic_net_wires[net].append({"wire_id": row["id"], "segments": segments,
                                                     "document_segment": row["segment"]})

    return {"source": {"path": str(path), "archive": path.name, "epru_path": epru,
                        "coordinate_systems": {
                            "schematic_native": {"unit": "0.254 mm = 10 mil (inferred from A4 width 1170 units)",
                                                  "mm_per_unit": 0.254, "mil_per_unit": 10,
                                                  "meaning": "原理图页/符号库坐标"},
                            "pcb_mil": {"unit": "mil", "mm_per_unit": 0.0254,
                                         "meaning": "PCB 与封装焊盘局部坐标"}}},
            "documents": documents,
            "schematic": {"components": sorted(schematic_components, key=lambda x: x["designator"]),
                          "wires": schematic_wires,
                          "net_labels": schematic_net_labels,
                          "nets": [{"name": name, "wires": wires} for name, wires in sorted(schematic_net_wires.items())],
                          "coordinate_note": "placement 是器件原点；pins[].canvas 是对符号引脚局部坐标执行镜像、旋转、平移后的原理图画布坐标。"},
            "libraries": {"symbols": symbols, "footprints": footprints,
                          "coordinate_note": "symbols.pins.local 使用 schematic_native；footprints.pads.local 使用 pcb_mil。pad_to_canvas 仅表示同编号焊盘映射到对应符号引脚画布位置，不代表把 PCB 几何单位直接换算成原理图单位。"}}


def _point(value: Any) -> tuple[float, float] | None:
    """Normalize a schematic coordinate for endpoint matching."""
    if not isinstance(value, (int, float)):
        return None
    return round(float(value), 6)


def to_partition_netlist(extracted: dict[str, Any]) -> dict[str, Any]:
    """Convert the slim schematic representation to the partitioner's netlist.

    Connectivity is reconstructed in schematic space: wire segments are joined
    by touching endpoints, and a component pin is attached when its transformed
    canvas coordinate touches a wire endpoint.  A wire group without a visible
    NET label receives a stable anonymous name.  PCB pad coordinates are not
    used as topology coordinates.
    """
    schematic = extracted.get("schematic", {})
    source = extracted.get("source", {})
    components: list[dict[str, Any]] = []
    seen: Counter[str] = Counter()
    selected: dict[str, dict[str, Any]] = {}
    for candidate in schematic.get("components", []):
        ref = str(candidate.get("designator", "")).strip()
        if not ref:
            continue
        # Multi-sheet projects can repeat the same SCH_PAGE records byte-for-
        # byte.  Keep one physical component per designator for partitioning.
        old = selected.get(ref)
        if old is None or len(candidate.get("pins", [])) > len(old.get("pins", [])):
            selected[ref] = candidate
    point_to_pins: defaultdict[tuple[float, float], list[dict[str, str]]] = defaultdict(list)
    for row in selected.values():
        ref = str(row.get("designator", "")).strip()
        if not ref:
            continue
        seen[ref] += 1
        cid = ref if seen[ref] == 1 else f"{ref}__dup{seen[ref]}"
        pins = []
        for pin in row.get("pins", []):
            number = str(pin.get("pin_number") or "").strip()
            canvas = pin.get("canvas") or {}
            point = _point(canvas.get("x")), _point(canvas.get("y"))
            if not number or point[0] is None or point[1] is None:
                continue
            endpoint = {"component": cid, "pin": number,
                        "name": str(pin.get("pin_name") or "")}
            point_to_pins[point].append(endpoint)  # type: ignore[arg-type]
            pins.append({"id": number, "name": endpoint["name"], "net": ""})
        kind = {"R": "resistor", "C": "capacitor", "L": "inductor", "D": "diode",
                "Q": "transistor", "U": "ic_module", "J": "connector"}.get(ref[:1].upper(), "other")
        components.append({"id": cid, "ref": ref, "document_segment": row.get("document_segment"),
                           "document_uuid": row.get("document_uuid"),
                           "placement": row.get("placement", {}),
                           "value": str(row.get("value") or row.get("name") or row.get("part_id") or ""),
                           "part": str(row.get("part_id") or ""), "kind": kind, "pins": pins,
                           "footprint": str((row.get("footprint_reference") or {}).get("name") or "")})

    # Union touching wire endpoints into connected wire groups.
    parent: dict[tuple[float, float], tuple[float, float]] = {}
    def find(point: tuple[float, float]) -> tuple[float, float]:
        parent.setdefault(point, point)
        while parent[point] != point:
            parent[point] = parent[parent[point]]
            point = parent[point]
        return point
    def union(a: tuple[float, float], b: tuple[float, float]) -> None:
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[rb] = ra

    wire_rows = []
    for index, wire in enumerate(schematic.get("wires", []), start=1):
        points: list[tuple[float, float]] = []
        for segment in wire.get("segments", []):
            a = (_point(segment.get("startX")), _point(segment.get("startY")))
            b = (_point(segment.get("endX")), _point(segment.get("endY")))
            if a[0] is None or a[1] is None or b[0] is None or b[1] is None:
                continue
            aa, bb = a, b  # type: ignore[assignment]
            points.extend((aa, bb)); union(aa, bb)
        wire_rows.append((index, wire, points))
    groups: defaultdict[tuple[float, float], list[tuple[int, dict[str, Any], list[tuple[float, float]]]]] = defaultdict(list)
    for item in wire_rows:
        index, wire, points = item
        if points:
            groups[find(points[0])].append(item)

    labels_by_anchor: defaultdict[tuple[float, float], set[str]] = defaultdict(set)
    for label in schematic.get("net_labels", []):
        anchor = label.get("anchor") or {}
        point = (_point(anchor.get("x")), _point(anchor.get("y")))
        name = str(label.get("name") or "").strip()
        if point[0] is not None and point[1] is not None and name:
            labels_by_anchor[point].add(name)  # type: ignore[index]

    net_endpoints: defaultdict[str, dict[tuple[str, str], dict[str, str]]] = defaultdict(dict)
    for index, (root, rows) in enumerate(groups.items(), start=1):
        points = {point for _, _, row_points in rows for point in row_points}
        label_names = sorted({name for point in points for name in labels_by_anchor.get(point, set())})
        wire_names = sorted({str(w.get("net") or "").strip() for _, w, _ in rows if str(w.get("net") or "").strip()})
        names = label_names or wire_names
        net_name = names[0] if names else f"$WIRE_{index}"
        endpoints = [dict(pin) for point in points for pin in point_to_pins.get(point, [])]
        unique: dict[tuple[str, str], dict[str, str]] = {(p["component"], p["pin"]): p for p in endpoints}
        if unique:
            net_endpoints[net_name].update(unique)
            for pin in unique.values():
                for component in components:
                    if component["id"] == pin["component"]:
                        for item in component["pins"]:
                            if item["id"] == pin["pin"]:
                                item["net"] = net_name
    nets = [{"id": name, "pins": list(endpoints.values())}
            for name, endpoints in sorted(net_endpoints.items())]
    # Preserve isolated labelled wires as named nets even when no pin touches them.
    return {"schema": "device-function-netlist-v1", "name": Path(str(source.get("archive") or "project")).stem,
            "source_format": "easyeda-pro-epro2-slim", "source": source,
            "components": components, "nets": nets}


def main() -> int:
    parser = argparse.ArgumentParser(description="精简提取 EasyEDA Pro .epro2：source/documents/schematic/libraries")
    parser.add_argument("input", type=Path)
    parser.add_argument("--out", type=Path, default=None)
    args = parser.parse_args()
    output = args.out or args.input.with_suffix(".slim.extracted.json")
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(extract_epro2_slim(args.input), ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
