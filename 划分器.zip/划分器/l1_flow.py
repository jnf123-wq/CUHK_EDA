#!/usr/bin/env python3
"""L1 flow: algorithmic partitioning followed by DeepSeek small-device completion.

The deterministic partitioner is deliberately run before the second model call.
Before the second call, the flow rechecks small components assigned by the
algorithm against their L1 anchor and moves same-page members farther than
4 inches into the unresolved candidate pool. The model receives unresolved
components and these requeued members only when an existing anchor is on the
same schematic page within 4 inches. It cannot move other assigned components
or create a new domain; the flow computes and sends the candidate-to-anchor
distance table before the model call, and candidates without a nearby anchor
stay unresolved.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import http.client
import json
import os
import re
import sys
import time
from collections import Counter
from pathlib import Path
from typing import Any, Mapping
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from epro2_extractors import load_extractor


ROOT = Path(__file__).resolve().parent
DEFAULT_ALGORITHM_DIR = ROOT / "划分器算法部分"
PROMPT_DIR = ROOT / "prompts"
epro2_extract_slim = load_extractor("L1")
SCHEMATIC_COMPLETION_RADIUS_INCH = 4.0
SCHEMATIC_INCHES_PER_NATIVE_UNIT = 0.01


def _schematic_xy_inches(placement: Mapping[str, Any]) -> tuple[float, float] | None:
    """Convert the extractor's raw schematic-native placement to inches."""
    x, y = placement.get("x"), placement.get("y")
    try:
        # EasyEDA Pro schematic-native coordinates are 10 mil (0.01 inch) per unit.
        return (float(x) * SCHEMATIC_INCHES_PER_NATIVE_UNIT,
                float(y) * SCHEMATIC_INCHES_PER_NATIVE_UNIT)
    except (TypeError, ValueError):
        return None


def _schematic_distance_inch(candidate: Mapping[str, Any] | None,
                             anchor: Mapping[str, Any] | None) -> float | None:
    if (not candidate or not anchor or candidate.get("document_segment") is None or
            anchor.get("document_segment") is None or
            candidate.get("document_segment") != anchor.get("document_segment")):
        return None
    try:
        dx = float(candidate["x"]) - float(anchor["x"])
        dy = float(candidate["y"]) - float(anchor["y"])
    except (KeyError, TypeError, ValueError):
        return None
    return (dx * dx + dy * dy) ** 0.5

if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except (AttributeError, OSError):
        pass


def _json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, indent=2)


def save_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(_json(value) + "\n", encoding="utf-8")


def _component_kind(component: Mapping[str, Any]) -> str:
    value = str(component.get("kind", component.get("type", ""))).strip().lower()
    if value:
        aliases = {"ic": "ic_module", "controller": "controller", "chip": "ic_module"}
        return aliases.get(value, value)
    ref = str(component.get("id", component.get("ref", ""))).upper()
    return {"R": "resistor", "C": "capacitor", "L": "inductor", "D": "diode",
            "Q": "transistor", "U": "ic_module", "J": "connector"}.get(ref[:1], "other")


def _component_id(component: Mapping[str, Any]) -> str:
    value = component.get("id", component.get("ref", component.get("designator")))
    if value is None or not str(value).strip():
        raise ValueError("每个器件必须有非空 id/ref/designator")
    return str(value).strip()


def _to_topology(netlist: Mapping[str, Any], *, source: Mapping[str, Any]) -> dict[str, Any]:
    components = []
    for item in netlist.get("components", []):
        cid = str(item["id"])
        components.append({"designator": cid, "kind": _component_kind(item),
                           "name": str(item.get("value", item.get("name", item.get("part", "")))),
                           "value": str(item.get("value", "")), "part": str(item.get("part", "")),
                           "pins": item.get("pins", [])})
    nets: dict[str, list[dict[str, str]]] = {}
    for net in netlist.get("nets", []):
        name = str(net["id"])
        nets[name] = [{"c": str(pin["component"]), "pin": str(pin.get("pin", "")),
                       "name": str(pin.get("name", ""))} for pin in net.get("pins", [])]
    return {"schema": "moduplace-topology-v1", "source": dict(source),
            "components": components, "nets": nets}


def load_inputs(path: Path, *, extracted_out: Path | None = None) -> tuple[dict[str, Any], dict[str, Any]]:
    if path.suffix.lower() == ".epro2":
        extracted = epro2_extract_slim.extract_epro2_slim(path)
    elif path.suffix.lower() == ".json":
        extracted = json.loads(path.read_text(encoding="utf-8-sig"))
        if not isinstance(extracted, Mapping) or not isinstance(extracted.get("schematic"), Mapping):
            raise ValueError("L1 流程仅接受 .epro2 工程或 L1 提取器生成的 extracted JSON")
    else:
        raise ValueError("L1 专用流程只接受 .epro2 工程或 L1 提取器生成的 extracted JSON")
    if extracted_out is not None:
        save_json(extracted_out, extracted)
    netlist = epro2_extract_slim.to_partition_netlist(extracted)
    if not netlist.get("components"):
        raise ValueError(".epro2 工程中没有可划分的原理图器件；请确认工程包含原理图页面和器件")
    topology = _to_topology(netlist, source={"format": "easyeda-pro-epro2-slim", "path": str(path.resolve())})
    return netlist, topology


def _read_key_file(path: Path | None) -> dict[str, str]:
    if not path:
        return {}
    text = path.read_text(encoding="utf-8-sig")
    result: dict[str, str] = {}
    aliases = {"模型名": "model", "模型": "model", "model_name": "model", "model": "model",
               "base url": "base_url", "base_url": "base_url", "url": "base_url", "接口地址": "base_url",
               "api": "api_key", "api key": "api_key", "api_key": "api_key", "apikey": "api_key",
               "key": "api_key", "token": "api_key", "deepseek_api_key": "deepseek_api_key"}
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        normalized = line.replace("：", ":")
        if "=" in normalized:
            key, value = normalized.split("=", 1)
        elif ":" in normalized:
            key, value = normalized.split(":", 1)
        else:
            continue
        key = key.strip().lower()
        value = value.split("#", 1)[0].strip().strip("'\"")
        mapped = aliases.get(key)
        if mapped and value:
            result[mapped] = value
    if "base_url" not in result:
        match = re.search(r"https?://[^\s'\"]+", text)
        if match:
            result["base_url"] = match.group(0).rstrip("，,。")
    if "model" not in result:
        match = re.search(r"(?:模型名|模型|model(?:_name)?)\s*[:：=]\s*([^\s,，]+)", text, re.I)
        if match:
            result["model"] = match.group(1).strip()
    if "api_key" not in result:
        match = re.search(r"(?:API(?:\s*Key)?|api_key|apikey)\s*[:：=]\s*([^\s]+)", text, re.I)
        if match:
            result["api_key"] = match.group(1).strip().strip("'\"")
    if not result and text.strip() and "=" not in text and ":" not in text:
        result["api_key"] = text.strip()
    return result


class DeepSeekClient:
    def __init__(self, api_key: str, *, base_url: str, model: str, timeout: int = 180,
                 retries: int = 3, temperature: float = 0.0, provider: str = "DeepSeek"):
        if not api_key:
            raise ValueError(f"未找到 {provider} API key")
        self.api_key, self.base_url, self.model = api_key, base_url.rstrip("/"), model
        self.timeout, self.retries, self.temperature, self.provider = timeout, retries, temperature, provider

    @staticmethod
    def _decode(content: Any) -> dict[str, Any]:
        if isinstance(content, list):
            content = "".join(str(x.get("text", "")) for x in content if isinstance(x, Mapping))
        text = str(content).strip()
        text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text, flags=re.I | re.S).strip()
        result = json.loads(text)
        if not isinstance(result, dict):
            raise ValueError("DeepSeek 返回的根对象必须是 JSON object")
        return result

    def ask(self, system: str, data: Mapping[str, Any]) -> dict[str, Any]:
        user_text = json.dumps(data, ensure_ascii=False)
        body = json.dumps({"model": self.model, "temperature": self.temperature,
                           "response_format": {"type": "json_object"},
                           "messages": [{"role": "system", "content": system},
                                        {"role": "user", "content": user_text}]},
                          ensure_ascii=False).encode("utf-8")
        last: Exception | None = None
        for attempt in range(self.retries):
            request = Request(self.base_url + "/chat/completions", data=body, method="POST",
                               headers={"Authorization": "Bearer " + self.api_key,
                                        "Content-Type": "application/json"})
            try:
                with urlopen(request, timeout=self.timeout) as response:
                    payload = json.loads(response.read().decode("utf-8"))
                content = payload["choices"][0]["message"]["content"]
                return self._decode(content)
            except HTTPError as exc:
                detail = exc.read().decode("utf-8", errors="replace")
                compact = re.sub(r"<[^>]+>", " ", detail)
                compact = re.sub(r"\s+", " ", compact).strip()[:500]
                retry_after = exc.headers.get("Retry-After", "")
                if exc.code == 429:
                    last = RuntimeError(
                        f"HTTP 429 请求被 {self.provider} 或中间网关限流/拦截"
                        + (f"（Retry-After={retry_after}s）" if retry_after else "")
                        + (f"：{compact}" if compact else "")
                    )
                    if attempt + 1 < self.retries:
                        try:
                            delay = min(30.0, max(1.0, float(retry_after))) if retry_after else min(8.0, 1.5 ** attempt)
                        except ValueError:
                            delay = min(8.0, 1.5 ** attempt)
                        time.sleep(delay)
                        continue
                else:
                    last = RuntimeError(f"HTTP {exc.code}: {compact or detail[:500]}")
                if exc.code in {400, 401, 403}:
                    break
            except (http.client.HTTPException, URLError, TimeoutError, ConnectionError,
                    KeyError, IndexError, json.JSONDecodeError, ValueError) as exc:
                # Some gateways close a chunked response before sending the
                # terminating chunk. urllib raises IncompleteRead/HTTPException
                # while reading the body, not HTTPError, so treat it as a
                # transient transport failure and retry the same request.
                last = RuntimeError(f"HTTP 响应传输中断（第 {attempt + 1}/{self.retries} 次尝试）：{exc}")
            if attempt + 1 < self.retries:
                time.sleep(0.7 * (attempt + 1))
        if isinstance(last, RuntimeError) and "HTTP 429" in str(last):
            raise RuntimeError(
                f"{last}。请检查 {self.provider} 账户余额/限额、API key 权限和请求频率；"
                "若返回页面标题为 Request Blocked，请更换网络出口或在 --base-url 中使用可访问的兼容代理。"
            ) from last
        raise RuntimeError(f"{self.provider} 请求失败：{last}") from last


def _is_major(component: Mapping[str, Any]) -> bool:
    kind = _component_kind(component).lower()
    ref = str(component.get("id", "")).upper()
    return kind in {"ic_module", "mcu", "power_module", "driver", "processor", "fpga", "controller"} or ref.startswith(("U", "IC"))


def _is_connector(component: Mapping[str, Any]) -> bool:
    """Recognize ordinary connectors and FPC-class parts as connectors."""
    kind = _component_kind(component).lower()
    ref = str(component.get("id", component.get("ref", ""))).strip().upper()
    identity = " ".join(str(component.get(key, "")) for key in
                         ("value", "part", "footprint", "name", "description", "comment")).upper()
    return (kind in {"connector", "connectors", "socket", "header", "terminal_block"} or
            ref.startswith(("J", "CN", "FPC")) or "CONN" in identity or "CONNECTOR" in identity or
            kind.startswith("fpc") or "FPC" in identity)


def _is_mechanical_support(component: Mapping[str, Any]) -> bool:
    """Identify mechanical mounting and support hardware from type and BOM fields."""
    kind = _component_kind(component).lower()
    if kind in {"mechanical", "hardware", "fastener", "mounting_hole", "spacer", "standoff", "support"}:
        return True
    identity = " ".join(str(component.get(key, "")) for key in
                         ("value", "part", "footprint", "name", "description", "comment")).casefold()
    footprint = str(component.get("footprint", ""))
    # Hardware footprints are often named only by their thread size (for
    # example, M3 or M2.5) rather than by an explicit "nut" or "screw" label.
    if re.search(r"(?<![A-Z0-9])M\d(?:\.\d+)?(?![A-Z0-9])", footprint, flags=re.IGNORECASE):
        return True
    markers = (
        "nut", "screw", "bolt", "washer", "spacer", "standoff", "stand-off",
        "fastener", "mounting hole", "mounting_hole", "mount hole", "support post",
        "support pillar", "rivet", "螺母", "螺钉", "螺丝", "螺栓", "垫圈", "垫片",
        "隔离柱", "支撑柱", "固定柱", "螺柱", "铆钉", "安装孔", "固定孔",
    )
    return any(marker in identity for marker in markers)


def _split_special_components_into_singleton_domains(result: Mapping[str, Any],
                                                      component_rows: list[Mapping[str, Any]]) -> dict[str, Any]:
    """Give every connector and mechanical support part its own L1 domain."""
    connector_ids = sorted({str(c["id"]) for c in component_rows if _is_connector(c)})
    mechanical_ids = sorted({str(c["id"]) for c in component_rows
                             if _is_mechanical_support(c) and not _is_connector(c)})
    special_ids = set(connector_ids) | set(mechanical_ids)
    normalized = dict(result)
    partition = dict(result.get("partition", {}))
    source_domains = partition.get("l1_domains") or partition.get("domains") or []
    domains: list[dict[str, Any]] = []
    used_ids = {str(d.get("id", "")) for d in source_domains if isinstance(d, Mapping)}
    numeric_ids = [int(match.group(1)) for domain_id in used_ids
                   if (match := re.fullmatch(r"L1-(\d+)", domain_id, flags=re.IGNORECASE))]
    next_generic_id = max(numeric_ids, default=0) + 1
    for raw in source_domains:
        if not isinstance(raw, Mapping):
            continue
        domain = dict(raw)
        members = sorted({str(ref) for ref in raw.get("members", []) if str(ref) not in special_ids})
        domain["members"] = members
        if str(domain.get("anchor", "")) in special_ids:
            former_anchor = str(domain.get("anchor"))
            domain["anchor"] = None
            prior_reason = str(domain.get("assignment_reason", "")).strip()
            category = "连接器" if former_anchor in connector_ids else "机械固定/支撑器件"
            note = f"原 anchor {former_anchor} 为{category}，已单独拆分；其余成员保留为未归属候选。"
            domain["assignment_reason"] = (prior_reason + "；" + note).strip("；")
        if members or domain.get("anchor"):
            domains.append(domain)

    for component_id in sorted(special_ids):
        is_connector = component_id in connector_ids
        cluster_kind = "connector_singleton" if is_connector else "mechanical_singleton"
        cluster_type = "connector" if is_connector else "mechanical_support"
        label = "单连接器簇" if is_connector else "单机械固定/支撑器件簇"
        reason = ("连接器单独成簇：每个连接器对应一个 L1 簇。" if is_connector else
                  "机械固定/支撑器件单独成簇：每个器件对应一个 L1 簇。")
        domain_id = f"L1-{next_generic_id:04d}"
        while domain_id in used_ids:
            next_generic_id += 1
            domain_id = f"L1-{next_generic_id:04d}"
        next_generic_id += 1
        used_ids.add(domain_id)
        domains.append({"id": domain_id, "level": "L1", "anchor": component_id,
                        "members": [component_id], "cluster_kind": cluster_kind,
                        "cluster_type": cluster_type, "function_label": label,
                        "assignment_reason": reason})

    assignment = {str(ref): str(domain.get("id", ""))
                  for domain in domains for ref in domain.get("members", [])}
    partition["l1_domains"] = domains
    partition["domains"] = domains
    partition["assignment"] = assignment
    normalized["partition"] = partition
    return normalized


def _normalize_algorithm_l1_result(result: Mapping[str, Any]) -> dict[str, Any]:
    """Expose the algorithm's former L2 domains as this flow's current L1."""
    normalized = dict(result)
    source_partition = result.get("partition", {})
    if not isinstance(source_partition, Mapping):
        raise ValueError("算法结果缺少 partition 对象")
    source_domains = (source_partition.get("l2_domains") or source_partition.get("l1_domains")
                      or source_partition.get("domains") or [])
    if not isinstance(source_domains, list):
        raise ValueError("算法结果缺少可用的 L1 域数组")
    id_map: dict[str, str] = {}
    domains: list[dict[str, Any]] = []
    for raw in source_domains:
        if not isinstance(raw, Mapping):
            continue
        domain = dict(raw)
        old_id = str(domain.get("id", ""))
        new_id = re.sub(r"^L2(?=-)", "L1", old_id, flags=re.I)
        if old_id:
            id_map[old_id] = new_id
        if new_id:
            domain["id"] = new_id
        if str(domain.get("level", "")).upper() == "L2":
            domain["level"] = "L1"
        # These links point to the discarded lower-level hierarchy.
        domain.pop("parent_l2_domain", None)
        domain.pop("parent_l2_anchor", None)
        domain.pop("l1_1_domain", None)
        domains.append(domain)
    assignment = source_partition.get("assignment")
    if isinstance(assignment, Mapping):
        assignment = {str(ref): id_map.get(str(domain_id), domain_id)
                      for ref, domain_id in assignment.items()}
    partition = {key: value for key, value in source_partition.items()
                 if key not in {"l2_domains", "l1_clusters", "functional_l1_clusters", "l2_clusters",
                                "functional_l2_clusters", "l1_1_domains", "l1_2_clusters", "clusters",
                                "note", "domains", "l1_domains", "assignment"}}
    partition.update({"mode": "l1", "l1_domains": domains, "domains": domains})
    if assignment is not None:
        partition["assignment"] = assignment
    normalized["partition"] = partition
    return normalized


def _extract_domains(algorithm_result: Mapping[str, Any], component_rows: list[Mapping[str, Any]]) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[str], list[str], list[str]]:
    partition = algorithm_result.get("partition", {})
    # The upstream partitioner still calls this layer `l2_domains`; in this
    # flow that layer is the current L1, because the former L1 layer was removed.
    domains = partition.get("l1_domains") or partition.get("domains") or []
    if not isinstance(domains, list):
        raise ValueError("算法结果缺少 partition.l1_domains 数组")
    refs = {str(c["id"]) for c in component_rows}
    assigned: set[str] = set()
    all_domains: list[dict[str, Any]] = []
    anchored: list[dict[str, Any]] = []
    unresolved_domains: list[dict[str, Any]] = []
    unresolved: list[str] = []
    for raw in domains:
        if not isinstance(raw, Mapping):
            continue
        members = sorted({str(x) for x in raw.get("members", []) if str(x) in refs})
        domain = dict(raw)
        domain["members"] = members
        all_domains.append(domain)
        if raw.get("cluster_kind") in {"connector_singleton", "mechanical_singleton"}:
            assigned.update(members)
            continue
        anchor = raw.get("anchor")
        if anchor:
            anchored.append(domain)
            assigned.update(members)
        else:
            unresolved_domains.append(domain)
            unresolved.extend(members)
    unresolved.extend(sorted(refs - assigned - set(unresolved)))
    # The algorithm normally emits an anchor-null fallback domain. If an
    # older algorithm result omitted it, materialize one so final export still
    # has exactly one row for every input component.
    represented_refs = {ref for domain in all_domains for ref in domain.get("members", [])}
    missing_refs = sorted(refs - represented_refs)
    if missing_refs:
        fallback = {"id": "L1-UNRESOLVED", "level": "L1", "anchor": None,
                    "members": missing_refs,
                    "assignment_reason": "missing_from_algorithm_domain"}
        all_domains.append(fallback)
        unresolved_domains.append(fallback)
        unresolved.extend(missing_refs)
    major_refs = {str(c["id"]) for c in component_rows if _is_major(c)}
    unresolved_small = sorted(set(unresolved) - major_refs)
    # There is no meaningful completion target when the algorithm found no
    # anchored large-device domain. Keep these parts auditable but do not make
    # a model request that can only invent a domain.
    eligible = unresolved_small if anchored else []
    no_target_small = [] if anchored else unresolved_small
    excluded_major = sorted(set(unresolved) & major_refs)
    return all_domains, anchored, eligible, excluded_major, no_target_small


def _requeue_distant_small_members(domains: list[Mapping[str, Any]],
                                   target_domains: list[Mapping[str, Any]],
                                   component_rows: list[Mapping[str, Any]],
                                   placement_by_ref: Mapping[str, Mapping[str, Any]]) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[str], list[dict[str, Any]]]:
    """Move small members farther than the completion radius back to unresolved candidates."""
    component_by_ref = {str(c["id"]): c for c in component_rows}
    records: list[dict[str, Any]] = []
    far_members: set[tuple[str, str]] = set()
    requeued: set[str] = set()
    for domain in target_domains:
        domain_id = str(domain.get("id", ""))
        anchor_id = str(domain.get("anchor", ""))
        anchor_placement = placement_by_ref.get(anchor_id)
        for ref in map(str, domain.get("members", [])):
            if ref == anchor_id:
                continue
            component = component_by_ref.get(ref)
            if not component or _is_major(component) or _is_connector(component):
                continue
            component_placement = placement_by_ref.get(ref)
            same_page = bool(component_placement and anchor_placement and
                             component_placement.get("document_segment") is not None and
                             component_placement.get("document_segment") == anchor_placement.get("document_segment"))
            distance = _schematic_distance_inch(component_placement, anchor_placement)
            too_far = bool(same_page and distance is not None and distance > SCHEMATIC_COMPLETION_RADIUS_INCH)
            records.append({"component_id": ref, "source_l1_id": domain_id,
                            "anchor_component_id": anchor_id,
                            "same_document_segment": same_page,
                            "center_distance_inch": round(distance, 6) if distance is not None else None,
                            "within_4_inch_radius": bool(same_page and distance is not None and
                                                          distance <= SCHEMATIC_COMPLETION_RADIUS_INCH),
                            "requeued_as_candidate": too_far})
            if too_far:
                far_members.add((domain_id, ref))
                requeued.add(ref)

    adjusted_domains = [dict(domain, members=list(domain.get("members", []))) for domain in domains]
    adjusted_by_id = {str(domain.get("id", "")): domain for domain in adjusted_domains}
    for domain_id, ref in far_members:
        domain = adjusted_by_id.get(domain_id)
        if domain:
            domain["members"] = [str(member) for member in domain["members"] if str(member) != ref]

    if requeued:
        holding = next((domain for domain in adjusted_domains
                        if not domain.get("anchor") and domain.get("cluster_kind") not in {"connector_singleton", "mechanical_singleton"}), None)
        if holding is None:
            holding_id = "L1-UNRESOLVED-DISTANCE"
            existing_ids = set(adjusted_by_id)
            suffix = 2
            while holding_id in existing_ids:
                holding_id = f"L1-UNRESOLVED-DISTANCE-{suffix}"
                suffix += 1
            holding = {"id": holding_id, "level": "L1", "anchor": None, "members": [],
                       "assignment_reason": "远离初始 anchor 的小器件，等待补划分。"}
            adjusted_domains.append(holding)
        holding["members"] = sorted(set(map(str, holding.get("members", []))) | requeued)

    adjusted_by_id = {str(domain.get("id", "")): domain for domain in adjusted_domains}
    adjusted_targets = [adjusted_by_id[str(domain.get("id", ""))]
                        for domain in target_domains if str(domain.get("id", "")) in adjusted_by_id]
    return adjusted_domains, adjusted_targets, sorted(requeued), records


def _completion_assignments(result: Mapping[str, Any], eligible: list[str],
                            major_domains: list[Mapping[str, Any]], net_names: set[str],
                            allowed_targets: Mapping[str, set[str]] | None = None) -> list[dict[str, Any]]:
    raw = result.get("assignments", [])
    if not isinstance(raw, list):
        raise ValueError("补划分结果缺少 assignments 数组")
    eligible_set = set(eligible)
    major_ids = {str(domain.get("id", "")) for domain in major_domains if domain.get("anchor")}
    assignments: list[dict[str, Any]] = []
    seen: set[str] = set()
    for item in raw:
        if not isinstance(item, Mapping):
            raise ValueError("补划分 assignment 必须是对象")
        cid = str(item.get("component_id", "")).strip()
        target = str(item.get("target_l1_id", "")).strip()
        if cid not in eligible_set:
            raise ValueError(f"补划分结果包含非候选器件：{cid or '(空)'}")
        if cid in seen:
            raise ValueError(f"补划分结果存在重复器件：{cid}")
        if target not in major_ids:
            raise ValueError(f"补划分目标不是已有带 anchor 的大器件 L1 簇：{target or '(空)'}")
        if allowed_targets is not None and target not in allowed_targets.get(cid, set()):
            raise ValueError(f"{cid} 的目标簇 {target} 不满足同页且器件中心距离不超过 4 inch 的限制")
        evidence = item.get("evidence_nets", [])
        if isinstance(evidence, str):
            evidence = [evidence] if evidence else []
        if not isinstance(evidence, list):
            raise ValueError(f"{cid} 的 evidence_nets 必须是数组")
        unknown_nets = sorted(set(map(str, evidence)) - net_names)
        if unknown_nets:
            raise ValueError(f"{cid} 使用了网表中不存在的网络：{', '.join(unknown_nets)}")
        try:
            confidence = max(0.0, min(1.0, float(item.get("confidence", 0))))
        except (TypeError, ValueError):
            confidence = 0.0
        seen.add(cid)
        assignments.append({"component_id": cid, "l1_id": target,
                            "reason": str(item.get("reason") or "模型根据器件属性、网表连接及允许目标完成归属；未请求逐项文字说明。"),
                            "evidence_nets": sorted(set(map(str, evidence))),
                            "confidence": confidence, "assignment_mode": "llm_small_component_to_major_l1",
                            "source": "deepseek_small_component_major_domain_assignment"})
    missing = sorted(eligible_set - seen)
    if missing:
        raise ValueError("补划分结果未覆盖全部候选器件：" + ", ".join(missing))
    return sorted(assignments, key=lambda row: row["component_id"])


def _write_assignments_csv(path: Path, domains: list[Mapping[str, Any]], completion: list[Mapping[str, Any]]) -> None:
    completion_by_ref = {row["component_id"]: row for row in completion}
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        fields = ["l1_id", "anchor", "cluster_kind", "function_label", "cluster_type", "component_id", "assignment_source", "assignment_reason", "assignment_mode", "evidence_nets", "confidence"]
        writer = csv.DictWriter(handle, fieldnames=fields); writer.writeheader()
        for domain in domains:
            for ref in domain.get("members", []):
                row = completion_by_ref.get(ref)
                is_special_singleton = domain.get("cluster_kind") in {"connector_singleton", "mechanical_singleton"}
                writer.writerow({"l1_id": domain.get("id", ""), "anchor": domain.get("anchor", ""),
                                 "cluster_kind": domain.get("cluster_kind", "major_device_domain"),
                                 "function_label": domain.get("function_label", ""),
                                 "cluster_type": domain.get("cluster_type", ""),
                                 "component_id": ref,
                                 "assignment_source": row["source"] if row else ("singleton_rule" if is_special_singleton else "algorithm_l1"),
                                 "assignment_reason": row["reason"] if row else domain.get("assignment_reason", ""),
                                 "assignment_mode": row.get("assignment_mode", "") if row else (str(domain.get("cluster_kind", "")) if is_special_singleton else "algorithm_l1"),
                                 "evidence_nets": ";".join(row["evidence_nets"]) if row else "",
                                 "confidence": row["confidence"] if row else ""})


def run_flow(args: argparse.Namespace) -> dict[str, Any]:
    flow_started = time.perf_counter()
    llm_call_timings: dict[str, list[float]] = {"small_component_completion": []}

    def ask_timed(stage: str, system: str, request: Mapping[str, Any]) -> dict[str, Any]:
        started = time.perf_counter()
        try:
            return client.ask(system, request)
        finally:
            # Includes network wait, response transfer, internal retries and
            # retry backoff performed inside DeepSeekClient.ask.
            llm_call_timings[stage].append(time.perf_counter() - started)

    temperature = float(getattr(args, "temperature", 0.0))
    input_path = Path(args.netlist).resolve()
    out = Path(args.out).resolve(); out.mkdir(parents=True, exist_ok=True)
    netlist, topology = load_inputs(input_path, extracted_out=out / "epro2_extracted.json")
    digest = hashlib.sha256(json.dumps(netlist, ensure_ascii=False, sort_keys=True).encode()).hexdigest()

    config = _read_key_file(Path(args.api_key_file) if args.api_key_file else None)
    api_key = os.getenv("DEEPSEEK_API_KEY") or config.get("api_key") or config.get("deepseek_api_key") or config.get("key") or config.get("token")
    base_url = args.base_url or os.getenv("DEEPSEEK_BASE_URL") or config.get("base_url") or "https://api.deepseek.com/v1"
    model = args.model or os.getenv("DEEPSEEK_MODEL") or config.get("model") or "deepseek-chat"
    client = None if args.dry_run else DeepSeekClient(api_key, base_url=base_url, model=model,
                                                       timeout=args.timeout, temperature=temperature)
    save_json(out / "normalized_netlist.json", netlist)
    save_json(out / "algorithm_topology.json", topology)
    algorithm_dir = Path(args.algorithm_dir).resolve()
    sys.path.insert(0, str(algorithm_dir))
    try:
        from partitioner.l1_partition import run as algorithm_run, validate_topology
    except ImportError as exc:
        raise RuntimeError(f"无法导入算法目录 {algorithm_dir}：{exc}") from exc
    validate_topology(topology)
    algorithm_started = time.perf_counter()
    algorithm_result = algorithm_run(topology, project_id=netlist.get("name"),
                                     partition_mode="hierarchical", unresolved_llm=False,
                                     learn_soft_constraints=False)
    algorithm_elapsed = time.perf_counter() - algorithm_started
    algorithm_result = _normalize_algorithm_l1_result(algorithm_result)
    flow_algorithm_result = _split_special_components_into_singleton_domains(algorithm_result, netlist["components"])
    flow_algorithm_result["postprocessing"] = {
        "connector_singleton_component_ids": sorted(str(c["id"]) for c in netlist["components"] if _is_connector(c)),
        "mechanical_singleton_component_ids": sorted(str(c["id"]) for c in netlist["components"]
                                                     if _is_mechanical_support(c) and not _is_connector(c))}
    save_json(out / "algorithm_l1_result.json", flow_algorithm_result)
    domains, target_domains, eligible, excluded_major, no_target_small = _extract_domains(flow_algorithm_result, netlist["components"])
    domain_ids = {str(d.get("id")) for d in target_domains}
    all_net_names = {str(n["id"]) for n in netlist["nets"]}
    extracted = json.loads((out / "epro2_extracted.json").read_text(encoding="utf-8"))
    schematic_by_ref: dict[str, Mapping[str, Any]] = {}
    for item in extracted.get("schematic", {}).get("components", []):
        ref = str(item.get("designator", "")).strip()
        if ref:
            previous = schematic_by_ref.get(ref)
            if previous is None or len(item.get("pins", [])) > len(previous.get("pins", [])):
                schematic_by_ref[ref] = item
    initial_eligible = list(eligible)
    component_by_ref = {str(c["id"]): c for c in netlist["components"]}
    members_to_recheck = {str(ref) for domain in target_domains for ref in domain.get("members", [])
                          if str(ref) != str(domain.get("anchor", "")) and
                          str(ref) in component_by_ref and
                          not _is_major(component_by_ref[str(ref)]) and
                          not _is_connector(component_by_ref[str(ref)])}
    relevant_refs = (set(initial_eligible) | members_to_recheck |
                     {str(domain.get("anchor")) for domain in target_domains if domain.get("anchor")})
    placement_by_ref: dict[str, dict[str, Any]] = {}
    for ref in sorted(relevant_refs):
        source_component = schematic_by_ref.get(ref)
        if not source_component:
            continue
        placement = source_component.get("placement") or {}
        xy_inches = _schematic_xy_inches(placement)
        if xy_inches is None:
            continue
        placement_row = {"component_id": ref,
                         "document_segment": source_component.get("document_segment"),
                         "x": xy_inches[0], "y": xy_inches[1],
                         "coordinate_system": "schematic_inches", "unit": "inch"}
        placement_by_ref[ref] = placement_row

    domains, target_domains, distance_requeued, initial_cluster_distance_checks = _requeue_distant_small_members(
        domains, target_domains, netlist["components"], placement_by_ref)
    initial_eligible = sorted(set(initial_eligible) | set(distance_requeued))

    allowed_targets: dict[str, set[str]] = {}
    schematic_distance_checks = []
    for candidate_id in initial_eligible:
        candidate_placement = placement_by_ref.get(candidate_id)
        for domain in target_domains:
            domain_id = str(domain.get("id", ""))
            anchor_id = str(domain.get("anchor", ""))
            anchor_placement = placement_by_ref.get(anchor_id)
            same_page = bool(candidate_placement and anchor_placement and
                             candidate_placement.get("document_segment") is not None and
                             candidate_placement.get("document_segment") == anchor_placement.get("document_segment"))
            distance = _schematic_distance_inch(candidate_placement, anchor_placement)
            within_radius = bool(same_page and distance is not None and
                                 distance <= SCHEMATIC_COMPLETION_RADIUS_INCH)
            schematic_distance_checks.append({"component_id": candidate_id,
                                              "target_l1_id": domain_id,
                                              "anchor_component_id": anchor_id,
                                              "same_document_segment": same_page,
                                              "center_distance_inch": round(distance, 6) if distance is not None else None,
                                              "within_4_inch_radius": within_radius})
            if domain_id and within_radius:
                allowed_targets.setdefault(candidate_id, set()).add(domain_id)

    # Candidates without a same-page anchor within 4 inches remain in their
    # existing unresolved holding domain; the LLM cannot assign them remotely.
    no_nearby_anchor = sorted(set(initial_eligible) - set(allowed_targets))
    eligible = sorted(allowed_targets)
    completion_request = {"task": "small_component_l1_completion", "eligible_component_ids": eligible,
                          "components": [c for c in netlist["components"] if str(c["id"]) in set(eligible)],
                          "schematic_distance_checks": schematic_distance_checks,
                          "initial_cluster_distance_checks": initial_cluster_distance_checks,
                          "network_connectivity": [n for n in netlist["nets"] if any(p["component"] in set(eligible) for p in n["pins"])],
                          "algorithm_l1_result": flow_algorithm_result.get("partition", {}),
                          "algorithm_l1_domains": target_domains,
                          "constraints": {"existing_major_l1_ids": sorted(domain_ids), "preserve_existing_major_domains": True,
                                          "do_not_move_existing_members": True, "require_full_coverage": True,
                                          "assign_every_candidate_to_existing_major_domain": True,
                                          "must_not_create_new_domains": True,
                                          "connector_singleton_component_ids": flow_algorithm_result["postprocessing"]["connector_singleton_component_ids"],
                                          "mechanical_singleton_component_ids": flow_algorithm_result["postprocessing"]["mechanical_singleton_component_ids"],
                                          "schematic_coordinate_unit": "inch",
                                          "schematic_assignment_radius_inch": SCHEMATIC_COMPLETION_RADIUS_INCH,
                                          "allowed_target_l1_ids_by_candidate": {cid: sorted(ids) for cid, ids in sorted(allowed_targets.items())}}}
    # A candidate with exactly one target passing the existing same-page
    # 4-inch gate has no remaining L1 choice for the model to make. Resolve
    # only these forced assignments locally; leave all ambiguous cases to LLM.
    rule_preassigned = []
    llm_eligible = []
    domain_by_id = {str(domain.get("id", "")): domain for domain in target_domains}
    for component_id in eligible:
        targets = allowed_targets.get(component_id, set())
        if len(targets) == 1:
            target_id = next(iter(targets))
            anchor_id = str(domain_by_id[target_id].get("anchor", ""))
            rule_preassigned.append({"component_id": component_id, "l1_id": target_id,
                                     "reason": "唯一通过同页且不超过 4 inch 距离门槛的现有大器件簇；无其他允许目标。",
                                     "evidence_nets": [], "confidence": 1.0,
                                     "assignment_mode": "rule_unique_allowed_target",
                                     "source": "deterministic_single_allowed_l1_target",
                                     "anchor_component_id": anchor_id})
        else:
            llm_eligible.append(component_id)
    completion_request["eligible_component_ids"] = llm_eligible
    completion_request["components"] = [c for c in netlist["components"] if str(c["id"]) in set(llm_eligible)]
    completion_request["schematic_distance_checks"] = [row for row in schematic_distance_checks
                                                        if str(row["component_id"]) in set(llm_eligible)]
    completion_request["initial_cluster_distance_checks"] = [row for row in initial_cluster_distance_checks
                                                              if str(row["component_id"]) in set(llm_eligible)]
    completion_request["network_connectivity"] = [n for n in netlist["nets"]
                                                  if any(str(p["component"]) in set(llm_eligible) for p in n["pins"])]
    completion_request["constraints"]["allowed_target_l1_ids_by_candidate"] = {
        cid: sorted(allowed_targets[cid]) for cid in llm_eligible
    }
    completion_request["rule_preassigned_unique_target_count"] = len(rule_preassigned)
    save_json(out / "small_component_completion_request.json", completion_request)
    if llm_eligible and not args.dry_run:
        completion_system = (PROMPT_DIR / "small_component_completion_system.txt").read_text(encoding="utf-8")
        completion_raw = ask_timed("small_component_completion", completion_system, completion_request)
        try:
            llm_completion = _completion_assignments(completion_raw, llm_eligible, target_domains, all_net_names, allowed_targets)
        except ValueError as first_error:
            repair_request = {**completion_request, "repair_instruction":
                              str(first_error) + "；请修正 clusters，必须覆盖 eligible_component_ids 中的全部器件且每个器件只出现一次，"
                              "必须输出 assignments，覆盖全部候选器件且每个器件只出现一次；target_l1_id 只能是已有带 anchor 的大器件 L1 域。"}
            completion_raw = ask_timed("small_component_completion", completion_system, repair_request)
            llm_completion = _completion_assignments(completion_raw, llm_eligible, target_domains, all_net_names, allowed_targets)
        completion = sorted(rule_preassigned + llm_completion, key=lambda row: row["component_id"])
    else:
        completion_raw = {"status": "dry_run" if args.dry_run else "not_needed"}
        completion = sorted(rule_preassigned, key=lambda row: row["component_id"])

    # Start from every algorithm domain, including anchor-null unresolved
    # domains. A completed move must be removed from its old fallback domain
    # before being added to the selected anchored domain.
    # Move each completed candidate out of its anchor-null holding domain and
    # append it to the selected existing anchored major-device L1 domain.
    completed_refs = {row["component_id"] for row in completion}
    assignments_by_domain: dict[str, list[str]] = {}
    for row in completion:
        assignments_by_domain.setdefault(str(row["l1_id"]), []).append(str(row["component_id"]))
    final_domains = []
    for domain in domains:
        did = str(domain.get("id", ""))
        members = [str(ref) for ref in domain.get("members", [])
                   if str(domain.get("anchor") or "") or str(ref) not in completed_refs]
        members.extend(assignments_by_domain.get(did, []))
        final_domains.append(dict(domain, members=sorted(set(members))))
    expected_refs = {str(c["id"]) for c in netlist["components"]}
    final_refs = [str(ref) for domain in final_domains for ref in domain.get("members", [])]
    missing_refs = sorted(expected_refs - set(final_refs))
    extra_refs = sorted(set(final_refs) - expected_refs)
    duplicate_refs = sorted(ref for ref in set(final_refs) if final_refs.count(ref) > 1)
    if missing_refs or extra_refs or duplicate_refs:
        raise RuntimeError(
            "最终 L1 归属完整性校验失败："
            f"missing={missing_refs[:20]}, extra={extra_refs[:20]}, duplicate={duplicate_refs[:20]}"
        )
    unresolved_after = sorted((set(eligible) - {row["component_id"] for row in completion}) |
                              set(no_target_small) | set(no_nearby_anchor))
    completion_llm_seconds = sum(llm_call_timings["small_component_completion"])
    timing = {
        "unit": "seconds",
        "algorithm_initial_partition_seconds": round(algorithm_elapsed, 6),
        "llm_response_seconds": {
            "small_component_completion": {
                "total": round(completion_llm_seconds, 6),
                "calls": [round(value, 6) for value in llm_call_timings["small_component_completion"]],
            },
            "total": round(completion_llm_seconds, 6),
        },
        "flow_total_seconds": round(time.perf_counter() - flow_started, 6),
    }
    final_result = {"schema": "l1-integrated-flow-v1", "input_sha256": digest,
                    "source": str(input_path), "domains": final_domains,
                    "completion_assignments": completion, "still_unassigned_small_components": unresolved_after,
                    "small_components_without_completion_target": no_target_small,
                    "excluded_unassigned_major_components": excluded_major,
                    "algorithm_result": flow_algorithm_result, "completion_raw_response": completion_raw,
                    "timing": timing}
    final_result["small_components_without_nearby_anchor_within_4in"] = no_nearby_anchor
    final_result["small_components_requeued_by_distance"] = distance_requeued
    final_result["initial_cluster_distance_checks"] = initial_cluster_distance_checks
    save_json(out / "l1_final_result.json", final_result)
    _write_assignments_csv(out / "l1_final_assignments.csv", final_domains, completion)
    manifest = {"schema": "l1-integrated-flow-manifest-v1", "status": "completed", "input": str(input_path),
                "input_sha256": digest, "model": {"provider": "deepseek", "name": model, "base_url": base_url,
                "temperature": temperature, "dry_run": bool(args.dry_run)}, "timing": timing,
                "counts": {"components": len(netlist["components"]),
                "l1_domains": len(final_domains), "algorithm_l1_domains": len(domains),
                "anchored_l1_domains": len(target_domains),
                "connector_singleton_domains": len(flow_algorithm_result.get("postprocessing", {}).get("connector_singleton_component_ids", [])),
                "mechanical_singleton_domains": len(flow_algorithm_result.get("postprocessing", {}).get("mechanical_singleton_component_ids", [])),
                "small_components_requeued_by_distance": len(distance_requeued),
                "eligible_small_components": len(eligible),
                "small_components_without_nearby_anchor_within_4in": len(no_nearby_anchor),
                "rule_preassigned_unique_target": len(rule_preassigned),
                "completion_assignments": len(completion), "still_unassigned_small_components": len(unresolved_after),
                "final_assignment_count": len(final_refs), "final_unique_assignment_count": len(set(final_refs))},
                "artifacts": ["epro2_extracted.json", "normalized_netlist.json", "algorithm_topology.json",
                              "algorithm_l1_result.json", "small_component_completion_request.json",
                              "l1_final_result.json", "l1_final_assignments.csv"]}
    save_json(out / "flow_manifest.json", manifest)
    return manifest


def _round_assignment_map(result: Mapping[str, Any]) -> dict[str, str]:
    mapping: dict[str, str] = {}
    for domain in result.get("domains", []):
        if not isinstance(domain, Mapping):
            continue
        did = str(domain.get("id", ""))
        if domain.get("cluster_kind") == "independent_auxiliary_function_cluster":
            did = "AUX:" + "|".join(sorted(str(ref) for ref in domain.get("members", [])))
        for ref in domain.get("members", []):
            mapping[str(ref)] = did
    return mapping


def run_multi_round(args: argparse.Namespace) -> dict[str, Any]:
    """Run independent flow repetitions and summarize assignment stability."""
    multi_round_started = time.perf_counter()
    root_out = Path(args.out).resolve()
    root_out.mkdir(parents=True, exist_ok=True)
    requested = int(args.rounds)
    temperature = float(getattr(args, "temperature", 0.0))
    width = max(2, len(str(requested)))
    manifests: list[dict[str, Any]] = []
    round_data: list[dict[str, Any]] = []
    errors: list[dict[str, Any]] = []
    for index in range(1, requested + 1):
        round_dir = root_out / f"round_{index:0{width}d}"
        round_args = argparse.Namespace(**vars(args))
        round_args.out = str(round_dir)
        round_args.rounds = 1
        try:
            manifest = run_flow(round_args)
            manifest["round"] = index
            result_path = round_dir / "l1_final_result.json"
            result = json.loads(result_path.read_text(encoding="utf-8"))
            manifests.append(manifest)
            round_data.append({"round": index, "result": result})
        except (OSError, ValueError, RuntimeError, json.JSONDecodeError) as exc:
            errors.append({"round": index, "error_type": type(exc).__name__, "error": str(exc)})

    if not round_data:
        raise RuntimeError(f"所有多轮运行均失败：{errors}")

    rounds = [item["round"] for item in round_data]
    assignment_maps = [_round_assignment_map(item["result"]) for item in round_data]
    component_ids = sorted(set().union(*(mapping.keys() for mapping in assignment_maps)))
    assignment_rows: list[dict[str, Any]] = []
    for cid in component_ids:
        values = [mapping.get(cid, "") for mapping in assignment_maps]
        votes = Counter(value for value in values if value)
        majority = sorted(votes.items(), key=lambda item: (-item[1], item[0]))[0] if votes else ("", 0)
        assignment_rows.append({"component_id": cid, "round_assignments": values,
                                "votes": dict(sorted(votes.items())), "majority_l1_id": majority[0],
                                "agreement": majority[1] / len(values) if values else 0.0,
                                "stable": majority[1] == len(values)})
    assignment_agreements = [float(row["agreement"]) for row in assignment_rows]
    report = {"schema": "l1-multi-round-stability-v1", "requested_rounds": requested,
              "completed_rounds": len(round_data), "rounds": rounds, "errors": errors,
              "temperature": temperature,
              "assignment": {"components": assignment_rows,
                              "mean_agreement": sum(assignment_agreements) / len(assignment_agreements) if assignment_agreements else 0.0,
                              "stable_component_count": sum(1 for row in assignment_rows if row["stable"]),
                              "unstable_component_ids": [row["component_id"] for row in assignment_rows if not row["stable"]]},
              "round_manifests": manifests,
              "timing": {"unit": "seconds",
                         "rounds": [{"round": item["round"], "timing": item.get("timing", {})}
                                    for item in manifests],
                         "flow_total_seconds": round(time.perf_counter() - multi_round_started, 6)}}
    save_json(root_out / "stability_report.json", report)
    with (root_out / "l1_assignment_stability.csv").open("w", encoding="utf-8-sig", newline="") as handle:
        fields = ["component_id"] + [f"round_{number:0{width}d}" for number in rounds] + ["majority_l1_id", "agreement", "stable"]
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in assignment_rows:
            output = {"component_id": row["component_id"], "majority_l1_id": row["majority_l1_id"],
                      "agreement": row["agreement"], "stable": row["stable"]}
            output.update({f"round_{number:0{width}d}": value for number, value in zip(rounds, row["round_assignments"])})
            writer.writerow(output)
    manifest = {"schema": "l1-multi-round-manifest-v1", "status": "completed_with_errors" if errors else "completed",
                "requested_rounds": requested, "completed_rounds": len(round_data), "output": str(root_out),
                "temperature": temperature, "stability_report": str(root_out / "stability_report.json"),
                "round_directories": [str(root_out / f"round_{index:0{width}d}") for index in rounds],
                "timing": report["timing"],
                "errors": errors}
    save_json(root_out / "flow_manifest.json", manifest)
    return manifest


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="L1 综合流程：算法初划分 + DeepSeek 小元件补划分（跳过功能识别）")
    parser.add_argument("netlist", help="EasyEDA Pro 工程文件（仅支持 .epro2）")
    parser.add_argument("--out", default="l1_flow_output", help="输出目录")
    parser.add_argument("--api-key-file", "--deepseek-api-key-file")
    parser.add_argument("--base-url", default=None)
    parser.add_argument("--model", default=None)
    parser.add_argument("--timeout", type=int, default=180)
    parser.add_argument("--temperature", type=float, default=0.0,
                        help="DeepSeek 采样温度；多轮稳定性测试可设为 0.2-0.8")
    parser.add_argument("--rounds", type=int, default=1,
                        help="独立重复运行次数；大于 1 时生成稳定性报告")
    parser.add_argument("--algorithm-dir", default=str(DEFAULT_ALGORITHM_DIR))
    parser.add_argument("--dry-run", action="store_true", help="只生成请求和算法结果，不调用任何模型")
    args = parser.parse_args(argv)
    if Path(args.netlist).suffix.lower() != ".epro2":
        parser.error("输入文件只支持 .epro2 格式")
    if args.rounds < 1:
        parser.error("--rounds 必须是正整数")
    if not 0 <= args.temperature <= 2:
        parser.error("--temperature 必须在 0 到 2 之间")
    try:
        manifest = run_multi_round(args) if args.rounds > 1 else run_flow(args)
    except (OSError, ValueError, RuntimeError, json.JSONDecodeError) as exc:
        error_dir = Path(args.out).resolve()
        try:
            save_json(error_dir / "flow_error.json", {
                "schema": "l1-integrated-flow-error-v1",
                "error_type": type(exc).__name__,
                "error": str(exc),
                "base_url": args.base_url or os.getenv("DEEPSEEK_BASE_URL") or "https://api.deepseek.com/v1",
                "model": args.model or os.getenv("DEEPSEEK_MODEL") or "deepseek-chat",
            })
        except OSError:
            pass
        print(f"error: {exc}", file=sys.stderr)
        return 2
    print(_json(manifest))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

