"""Build voltage features for L1 functional clusters and aggregate into L2 domains.

This is a deterministic L3 voltage-only experiment. It consumes a final L1
assignment JSON and its matching .epro2 project; it does not rerun L0/L1.
"""
from __future__ import annotations
import argparse, csv, json
import re
from collections import defaultdict
from pathlib import Path
from typing import Any, Mapping

from epro2_netlist import extract_input
from voltage_core import component_id, component_nets, ground_coupling_links, is_ground_net, nets_map, parse_voltage


POWER_INPUT_NAMES = {
    "VIN", "VIN1", "VIN2", "PVIN", "AVIN", "DVIN", "HVIN", "VHV", "HV",
    "VCC", "VCC1", "VCC2", "VDD", "VDD1", "VDD2", "VDDIO", "DVDD", "AVDD",
    "VCORE", "VIO", "VBAT", "VBUS", "VSYS", "VSUP", "VSUPPLY", "VPLUS",
    "V+", "VP", "VPP", "VEE", "VNEG", "V-", "VSS", "VSSA", "VSSD",
    "VSSIO", "GND", "AGND", "DGND", "PGND", "GROUND", "SUPPLY", "POWER",
}
POWER_INPUT_TYPES = {"power_in", "power input", "powerinput", "pwr_in", "pwrin"}


def _is_core_chip(component: Mapping[str, Any]) -> bool:
    kind = str(component.get("kind", component.get("type", ""))).lower()
    ref = str(component.get("ref", component.get("id", ""))).upper()
    return kind in {"ic", "ic_module", "integrated_circuit", "microcontroller", "processor"} or ref.startswith("U")


def _is_power_input_pin(pin: Mapping[str, Any]) -> bool:
    name = str(pin.get("name", pin.get("pin_name", ""))).strip().upper()
    normalized = re.sub(r"[^A-Z0-9+\-]", "", name)
    pin_type = str(pin.get("pin_type", pin.get("electrical_type", ""))).strip().lower()
    if pin_type in POWER_INPUT_TYPES or normalized in POWER_INPUT_NAMES:
        return True
    return bool(re.fullmatch(r"(?:P?VIN|AVIN|DVIN|HVIN|VHV|VCC|VDD|VBAT|VBUS|VSYS|VSUP|VCORE|VIO|VPP|VSS|GND|AGND|DGND|PGND)(?:[A-Z0-9+\-]*)", normalized))


def _pin_power_nets(component: Mapping[str, Any], netlist: Mapping[str, Any]) -> list[dict[str, str]]:
    """Return nets attached to pins that look like power inputs."""
    cid = component_id(component)
    pins_by_number = {str(p.get("id", p.get("pin_number", ""))).strip(): p
                      for p in component.get("pins", []) or [] if isinstance(p, Mapping)}
    found: dict[tuple[str, str], dict[str, str]] = {}
    for net_name, endpoints in nets_map(netlist).items():
        for endpoint in endpoints:
            if str(endpoint.get("component", endpoint.get("ref", endpoint.get("c", "")))).strip() != cid:
                continue
            pin_number = str(endpoint.get("pin", endpoint.get("pin_number", ""))).strip()
            merged = {**endpoint, **pins_by_number.get(pin_number, {})}
            if _is_power_input_pin(merged):
                pin_name = str(merged.get("name", merged.get("pin_name", ""))).strip()
                found[(net_name, pin_name)] = {"net": net_name, "pin_name": pin_name}
    for pin in component.get("pins", []) or []:
        if isinstance(pin, Mapping) and _is_power_input_pin(pin):
            net_name = str(pin.get("net", "")).strip()
            if net_name:
                pin_name = str(pin.get("name", pin.get("pin_name", ""))).strip()
                found[(net_name, pin_name)] = {"net": net_name, "pin_name": pin_name}
    return sorted(found.values(), key=lambda row: (row["net"], row["pin_name"]))


def _l1_domains(doc: Mapping[str, Any]) -> list[dict[str, Any]]:
    domains=doc.get("domains")
    if not isinstance(domains,list):
        partition=doc.get("partition",{})
        domains=partition.get("l1_domains") or partition.get("domains") or [] if isinstance(partition,Mapping) else []
    if not isinstance(domains,list): raise ValueError("L1结果中未找到 domains 或 partition.l1_domains 数组")
    out=[]
    for i,row in enumerate(domains):
        if not isinstance(row,Mapping): continue
        cid=str(row.get("id") or row.get("l1_id") or f"L1-{i+1:03d}")
        members=row.get("members",row.get("component_ids",[]))
        if isinstance(members,list): out.append({"l1_cluster_id":cid,"name":str(row.get("name") or row.get("function_label") or cid),"component_ids":sorted(set(map(str,members)))})
    if not out: raise ValueError("L1结果没有有效的簇成员")
    return out


def build_features(netlist: Mapping[str,Any], l1doc: Mapping[str,Any], threshold_v: float=12.0) -> dict[str,Any]:
    components={component_id(c):c for c in netlist.get("components",[]) or []}
    cn=component_nets(netlist); nm=nets_map(netlist); couplers=ground_coupling_links(netlist)
    by_comp=defaultdict(list); domains=_l1_domains(l1doc)
    for domain in domains:
        for cid in domain["component_ids"]:
            if cid in by_comp: raise ValueError(f"器件重复出现在多个L1簇: {cid}")
            by_comp[cid].append(domain["l1_cluster_id"])
    missing=sorted(set(components)-set(by_comp)); extra=sorted(set(by_comp)-set(components))
    if missing or extra: raise ValueError(f"L1覆盖与网表器件不匹配: missing={missing[:10]}, extra={extra[:10]}")

    rail_values={n:parse_voltage(n) for n in nm}
    features=[]
    for domain in domains:
        ids=domain["component_ids"]; nets=sorted({n for cid in ids for n in cn.get(cid,set())})
        candidates=defaultdict(list); grounds=set()
        for net in nets:
            if is_ground_net(net): grounds.add(net)
        core_chips=[components[cid] for cid in ids if _is_core_chip(components[cid])]
        input_power_nets=[]
        for chip in core_chips:
            for evidence in _pin_power_nets(chip, netlist):
                net=evidence["net"]
                input_power_nets.append({"component_id":component_id(chip), **evidence})
                val=rail_values.get(net)
                if val is not None and val>0:
                    candidates[val].append({"type":"chip_power_input_net","component_id":component_id(chip),"pin_name":evidence["pin_name"],"net":net})
        touching=[link for link in couplers if link["net_a"] in nets or link["net_b"] in nets]
        values=sorted(candidates)
        has_low=any(v<=threshold_v for v in values); has_high=any(v>threshold_v for v in values)
        status="mixed_voltage" if has_low and has_high else "resolved_high" if has_high else "resolved_low"
        if not core_chips: decision_reason="no_core_chip_default_low"
        elif not input_power_nets: decision_reason="core_chip_power_input_not_found_default_low"
        elif not values: decision_reason="unquantified_power_net_default_low"
        else: decision_reason="core_chip_power_input_net_voltage"
        features.append({"l1_cluster_id":domain["l1_cluster_id"],"name":domain["name"],"component_ids":ids,
                         "core_chip_ids":sorted(component_id(chip) for chip in core_chips),
                         "input_power_nets":input_power_nets,
                         "voltage_rails":[{"voltage_v":v,"evidence":candidates[v]} for v in values],
                         "ground_refs":sorted(grounds),"ground_links":touching,
                         "mixed_voltage":status=="mixed_voltage","status":status,
                         "decision_reason":decision_reason,
                         "boundary_nets":sorted({row["net"] for row in input_power_nets}) if status=="mixed_voltage" else [],
                         "evidence_nets":sorted({row["net"] for row in input_power_nets}),"confidence":0.9 if values else 0.6})

    grouped={"low_voltage":[],"high_voltage":[]}; uncertain=[]
    for row in features:
        if row["status"]=="resolved_low": grouped["low_voltage"].append(row["l1_cluster_id"])
        elif row["status"]=="resolved_high": grouped["high_voltage"].append(row["l1_cluster_id"])
        else: uncertain.append(row["l1_cluster_id"])
    return {"schema":"l1-voltage-feature-l2-aggregation-v1","threshold_v":threshold_v,
            "source_l1_schema":l1doc.get("schema"),"l1_voltage_features":features,
            "l2_voltage_domains":[{"domain_id":k,"l1_cluster_ids":sorted(v)} for k,v in grouped.items()],
            "unresolved_l1_cluster_ids":sorted(uncertain),
            "policy":"Classify each L1 cluster from core-chip power-input pin net names; unquantified rails and clusters without a core chip default to low voltage. Clusters with numeric input rails on both sides of the threshold remain unresolved.",
            "counts":{"l1_clusters":len(features),"low_l2_clusters":len(grouped['low_voltage']),"high_l2_clusters":len(grouped['high_voltage']),"unresolved_l1_clusters":len(uncertain)}}


def main(argv=None):
    p=argparse.ArgumentParser(description="按L1功能簇提取电压特征并规则聚合L2电压域")
    p.add_argument("project",type=Path,help="输入的 EasyEDA Pro .epro2 工程文件")
    p.add_argument("l1_result",type=Path,help="L1流程输出的l1_final_result.json")
    p.add_argument("--threshold-v",type=float,default=12.0)
    p.add_argument("--out",type=Path,default=Path("output/l1_voltage_l2"))
    a=p.parse_args(argv)
    if a.project.suffix.lower() != ".epro2": p.error("project 输入必须是 .epro2 文件")
    if not a.project.is_file(): p.error(f"找不到 .epro2 工程文件: {a.project}")
    if a.threshold_v<=0: p.error("--threshold-v必须大于0")
    netlist,extracted=extract_input(a.project)
    result=build_features(netlist,json.loads(a.l1_result.read_text(encoding="utf-8-sig")),a.threshold_v)
    a.out.mkdir(parents=True,exist_ok=True)
    (a.out/"epro2_extracted.json").write_text(json.dumps(extracted,ensure_ascii=False,indent=2),encoding="utf-8")
    (a.out/"normalized_netlist.json").write_text(json.dumps(netlist,ensure_ascii=False,indent=2),encoding="utf-8")
    (a.out/"l1_voltage_features_l2.json").write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding="utf-8")
    with (a.out/"l1_voltage_features.csv").open("w",encoding="utf-8-sig",newline="") as f:
        w=csv.DictWriter(f,fieldnames=["l1_cluster_id","name","status","decision_reason","mixed_voltage","confidence","core_chip_ids","input_power_nets","voltage_rails","ground_refs","ground_links","boundary_nets","evidence_nets","component_ids"]); w.writeheader()
        for row in result["l1_voltage_features"]:
            w.writerow({**row,"core_chip_ids":", ".join(row["core_chip_ids"]),"input_power_nets":json.dumps(row["input_power_nets"],ensure_ascii=False),"voltage_rails":json.dumps(row["voltage_rails"],ensure_ascii=False),"ground_refs":", ".join(row["ground_refs"]),"ground_links":json.dumps(row["ground_links"],ensure_ascii=False),"boundary_nets":", ".join(row["boundary_nets"]),"evidence_nets":", ".join(row["evidence_nets"]),"component_ids":", ".join(row["component_ids"])})
    print(json.dumps(result["counts"],ensure_ascii=False))
    return 0

if __name__=="__main__": raise SystemExit(main())
