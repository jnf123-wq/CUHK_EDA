#!/usr/bin/env python3
"""Public entry point for the bottom-up L0 -> L1 -> L2 flow."""

from run_flow_bottom_up import *  # noqa: F401,F403
from run_flow_bottom_up import _is_connector, main


if __name__ == "__main__":
    raise SystemExit(main())
