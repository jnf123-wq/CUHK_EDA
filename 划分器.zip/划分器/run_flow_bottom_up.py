#!/usr/bin/env python3
"""Bottom-up three-level partition flow: L0 -> L1 -> L2.

The functional partition is computed on the complete netlist first.  Every
functional L1 cluster then receives one L0 singleton child per component.  A
voltage classifier is run afterwards and its component evidence is aggregated
at the L1-cluster boundary, so an L1 cluster is always assigned to exactly one
L2 voltage domain and is never split between parents.
"""

from __future__ import annotations

import argparse
import csv
import json
import re
import sys
import time
from collections import Counter
from pathlib import Path
from typing import Any, Mapping

import l1_voltage_aggregate
import l1_flow as l1_experiment
from epro2_extractors import load_extractor
from epro2_board_mapping import board_extracted, board_netlist, map_project_boards


ROOT = Path(__file__).resolve().parent


def save_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def _is_connector(component: Mapping[str, Any]) -> bool:
    ref = str(component.get("id", component.get("ref", component.get("designator", "")))).strip().upper()
    if re.match(r"^(?:J|P|CN|CON|USB)(?:\d|[-_]|$)", ref):
        return True
    kind = str(component.get("kind", component.get("type", ""))).strip().casefold().replace("-", "_")
    if kind in {"connector", "connectors", "conn", "plug", "socket", "header", "terminal_block"}:
        return True
    text = " ".join(str(component.get(key, "")) for key in (
        "kind", "type", "category", "part", "value", "name", "description", "footprint",
        "manufacturer_part", "manufacturerPart", "device_name", "deviceName"))
    return any(token in text.casefold() for token in (
        "connector", "conn-", "conn_", "usb", "type-c", "type c", "usba", "header", "socket",
        "plug", "terminal", "fpc", "fpc类器件", "fpc 类器件", "柔性排线", "柔性电路",
        "插座", "连接器", "端子", "排针", "排母"))


def _subset_netlist(netlist: Mapping[str, Any], component_ids: set[str]) -> dict[str, Any]:
    components = [dict(row) for row in netlist["components"] if str(row["id"]) in component_ids]
    nets = []
    for net in netlist.get("nets", []):
        pins = [dict(pin) for pin in net.get("pins", []) if str(pin.get("component")) in component_ids]
        if pins:
            nets.append({**dict(net), "pins": pins})
    return {**dict(netlist), "components": components, "nets": nets}


def _run_l1(netlist: Mapping[str, Any], args: argparse.Namespace, out: Path,
            l1_extracted: Mapping[str, Any]) -> dict[str, Any]:
    """Run the dedicated short-output, no-function-recognition L1 flow."""
    out.mkdir(parents=True, exist_ok=True)
    extracted_path = out / "l1_board_extracted.json"
    save_json(extracted_path, l1_extracted)
    flow_args = argparse.Namespace(
        netlist=str(extracted_path), out=str(out),
        api_key_file=str(args.api_key_file) if args.api_key_file else None,
        base_url=args.base_url, model=args.model, timeout=args.timeout,
        temperature=args.temperature, dry_run=args.dry_run,
        algorithm_dir=str(args.algorithm_dir.resolve()),
    )
    print(f"  L1：调用 L1 短输出专用流程（{len(netlist['components'])} 个器件；不做 LLM 功能识别）…", flush=True)
    manifest = l1_experiment.run_flow(flow_args)
    final = json.loads((out / "l1_final_result.json").read_text(encoding="utf-8-sig"))
    expected = {str(row["id"]) for row in netlist.get("components", [])}
    clusters = []
    seen: set[str] = set()
    for index, row in enumerate(final.get("domains", []), 1):
        members = sorted(set(map(str, row.get("members", []))))
        unknown = sorted(set(members) - expected)
        if unknown:
            raise RuntimeError(f"L1 专用流程包含未知器件：{unknown}")
        duplicate = seen.intersection(members)
        if duplicate:
            raise RuntimeError(f"L1 专用流程重复分配器件：{sorted(duplicate)}")
        seen.update(members)
        if not members:
            continue
        clusters.append({"id": str(row.get("id") or f"L1-{index:04d}"), "level": "L1",
            "members": members, "source_id": str(row.get("id", "")),
            "anchor": row.get("anchor"), "function": row.get("function_label", row.get("cluster_kind", "")),
            "function_type": row.get("function_label", row.get("cluster_kind", "")),
            "source": row.get("source", "l1_short_output_experiment"),
            "reason": row.get("assignment_reason", ""), "evidence_nets": row.get("evidence_nets", [])})
    if seen != expected:
        raise RuntimeError(f"L1 专用流程覆盖不完整：missing={sorted(expected-seen)}, extra={sorted(seen-expected)}")
    return {"schema": "bottom-up-l1-v2", "clusters": clusters,
            "component_count": len(expected), "all_components_once": True,
            "source_result": final, "manifest": manifest}


def build_l0(netlist: Mapping[str, Any], out: Path | None = None) -> dict[str, Any]:
    """Materialize the bottom layer before any higher-level partitioning."""
    clusters = []
    for index, component in enumerate(sorted(netlist.get("components", []), key=lambda row: str(row["id"])), 1):
        component_id = str(component["id"])
        clusters.append({"id": f"L0-{index:05d}", "level": "L0", "component_id": component_id,
                         "members": [component_id], "is_connector": _is_connector(component) or None})
    result = {"schema": "bottom-up-l0-base-v1", "clusters": clusters,
              "component_count": len(clusters), "all_components_once": True}
    if out is not None:
        save_json(out / "base_clusters.json", result)
    return result


def aggregate_voltage_by_l1(l1_result: Mapping[str, Any], netlist: Mapping[str, Any], *, threshold_v: float = 12.0) -> dict[str, Any]:
    """Classify complete L1 clusters from core-chip power-input rails."""
    l1_doc = {"schema": "bottom-up-l1-v1", "domains": [
        {"id": row["id"], "name": row.get("function", row.get("function_type", row["id"])),
         "members": list(row.get("members", []))}
        for row in l1_result.get("clusters", [])]}
    features = l1_voltage_aggregate.build_features(netlist, l1_doc, threshold_v)
    grouped = {"low_voltage": [], "high_voltage": [], "unresolved_voltage": []}
    cluster_assignments = []
    component_assignments = []
    feature_by_id = {row["l1_cluster_id"]: row for row in features["l1_voltage_features"]}
    for cluster in l1_result.get("clusters", []):
        cid = str(cluster["id"])
        feature = feature_by_id[cid]
        status = feature["status"]
        domain = ("high_voltage" if status == "resolved_high" else
                  "unresolved_voltage" if status == "mixed_voltage" else "low_voltage")
        grouped[domain].append(cid)
        cluster_assignments.append({"l1_id": cid, "l2_cluster_id": domain,
            "member_count": len(cluster.get("members", [])), "status": status,
            "decision": feature["decision_reason"], "threshold_v": threshold_v,
            "mixed_voltage": feature["mixed_voltage"]})
        for ref in cluster.get("members", []):
            component_assignments.append({"component_id": str(ref), "cluster_id": domain,
                "confidence": feature["confidence"], "status": status,
                "evidence_nets": feature["evidence_nets"]})
    labels = {"low_voltage": "低压域", "high_voltage": "高压域", "unresolved_voltage": "未决电压边界"}
    clusters = [{"cluster_id": key, "cluster_name": labels[key], "l1_cluster_ids": ids,
                 "component_ids": sorted(str(ref) for row in l1_result.get("clusters", [])
                    if str(row["id"]) in ids for ref in row.get("members", []))}
                for key, ids in grouped.items() if ids or key != "unresolved_voltage"]
    return {"schema": "bottom-up-l2-l1-voltage-rules-v1", "clusters": clusters,
        "cluster_assignments": cluster_assignments, "component_assignments": component_assignments,
        "l1_voltage_features": features["l1_voltage_features"],
        "unresolved_l1_cluster_ids": features["unresolved_l1_cluster_ids"],
        "threshold_v": threshold_v, "policy": features["policy"]}


def _component_owner_check(hierarchy: Mapping[str, Any], expected: set[str]) -> None:
    owners = hierarchy.get("assignments", [])
    refs = [str(row["component_id"]) for row in owners]
    counts = Counter(refs)
    duplicate = sorted(ref for ref, count in counts.items() if count != 1)
    if set(refs) != expected or duplicate:
        raise ValueError(f"层级唯一归属校验失败：missing={sorted(expected-set(refs))}, extra={sorted(set(refs)-expected)}, duplicate={duplicate}")


def build_hierarchy(netlist: Mapping[str, Any], l1_result: Mapping[str, Any], l2_result: Mapping[str, Any], *, l0_result: Mapping[str, Any] | None = None, dry_run: bool = False, l1_seconds: float = 0.0, l2_seconds: float = 0.0) -> dict[str, Any]:
    """Materialize L0 children, then nest L1 clusters under L2 voltage parents."""
    components = {str(row["id"]): row for row in netlist.get("components", [])}
    expected = set(components)
    parent_by_l1 = {str(row["l1_id"]): str(row["l2_cluster_id"])
                     for row in l2_result.get("cluster_assignments", [])}
    l2_domains = {str(row["cluster_id"]): {"id": f"L2-{row['cluster_id']}", "level": "L2",
                           "cluster_id": str(row["cluster_id"]), "cluster_name": str(row["cluster_name"]),
                           "l1_clusters": [], "component_ids": []}
                  for row in l2_result.get("clusters", [])}
    assignments: list[dict[str, Any]] = []
    l1_rows: list[dict[str, Any]] = []
    l0_by_component = {str(row["component_id"]): dict(row)
                       for row in (l0_result or {}).get("clusters", [])}
    if not l0_by_component:
        l0_by_component = {str(component_id): {"id": f"L0-{index:05d}", "component_id": str(component_id),
                                               "is_connector": _is_connector(components[str(component_id)]) or None}
                           for index, component_id in enumerate(sorted(expected), 1)}
    seen: set[str] = set()
    for l1 in l1_result.get("clusters", []):
        l1_id = str(l1["id"])
        members = sorted(str(ref) for ref in l1.get("members", []))
        parent_domain = parent_by_l1.get(l1_id)
        if parent_domain not in l2_domains:
            raise ValueError(f"L1 簇 {l1_id} 没有唯一 L2 父域")
        if not members or not set(members) <= expected or seen.intersection(members):
            raise ValueError(f"L1 簇 {l1_id} 成员覆盖或重复错误")
        seen.update(members)
        l0_clusters = []
        for component_id in members:
            l0_id = str(l0_by_component[component_id]["id"])
            connector = _is_connector(components[component_id])
            l0_clusters.append({"id": l0_id, "level": "L0", "component_id": component_id,
                                "members": [component_id], "is_connector": True if connector else None,
                                "parent_l1_id": l1_id})
            assignments.append({"component_id": component_id, "l0_id": l0_id, "l1_id": l1_id,
                                "l2_id": l2_domains[parent_domain]["id"], "is_connector": True if connector else None})
        l1_node = {**dict(l1), "l1_id": l1_id, "parent_l2_id": l2_domains[parent_domain]["id"],
                   "l2_cluster_id": parent_domain, "l0_clusters": l0_clusters,
                   "component_ids": members, "members": members}
        l2_domains[parent_domain]["l1_clusters"].append(l1_node)
        l2_domains[parent_domain]["component_ids"].extend(members)
        l1_rows.append(l1_node)
    if seen != expected:
        raise ValueError(f"L1/L0 全覆盖校验失败：missing={sorted(expected-seen)}")
    for domain in l2_domains.values():
        domain["component_ids"] = sorted(domain["component_ids"])
        domain["l1_cluster_ids"] = [str(row["l1_id"]) for row in domain["l1_clusters"]]
    hierarchy = {
        "schema": "partitioner-hierarchy-l0-l2-v1", "status": "dry_run" if dry_run else "completed",
        "flow_order": ["L0", "L1", "L2"], "levels": ["L0", "L1", "L2"],
        "component_count": len(expected), "l2_domains": list(l2_domains.values()),
        "l1_clusters": l1_rows, "assignments": sorted(assignments, key=lambda row: row["component_id"]),
        "all_components_once": True, "strict_parent_child": True,
        "analysis_times_seconds": {"L0": {"total_seconds": 0.0},
                                    "L1": {"total_seconds": round(l1_seconds, 6)},
                                    "L2": {"total_seconds": round(l2_seconds, 6)}},
        "dry_run_note": "Dry-run 跳过 DeepSeek 小器件补划分；L2 仍按电源输入网名规则计算。" if dry_run else None,
    }
    # Parent coverage is checked at the materialized tree boundary.
    for domain in hierarchy["l2_domains"]:
        children = [ref for child in domain["l1_clusters"] for ref in child["members"]]
        if sorted(children) != sorted(domain["component_ids"]):
            raise ValueError(f"{domain['id']} 父子成员覆盖不一致")
        if len(children) != len(set(children)):
            raise ValueError(f"{domain['id']} 子节点成员重复")
    _component_owner_check(hierarchy, expected)
    return hierarchy


def _write_csv(path: Path, fieldnames: list[str], rows: list[Mapping[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows({key: row.get(key, "") for key in fieldnames} for row in rows)


def write_assignments_csv(path: Path, hierarchy: Mapping[str, Any]) -> None:
    _write_csv(path, ["component_id", "l0_id", "l1_id", "l2_id", "is_connector"], hierarchy["assignments"])


def write_l1_voltage_features_csv(path: Path, l2_result: Mapping[str, Any]) -> None:
    fields = ["l1_cluster_id", "name", "status", "decision_reason", "mixed_voltage", "confidence",
              "core_chip_ids", "input_power_nets", "voltage_rails", "ground_refs", "ground_links",
              "boundary_nets", "evidence_nets", "component_ids"]
    rows = []
    for source in l2_result.get("l1_voltage_features", []):
        row = dict(source)
        for key in ("core_chip_ids", "ground_refs", "boundary_nets", "evidence_nets", "input_power_nets", "voltage_rails", "ground_links", "component_ids"):
            row[key] = json.dumps(row.get(key, []), ensure_ascii=False) if key in {"input_power_nets", "voltage_rails", "ground_links"} else ", ".join(map(str, row.get(key, [])))
        rows.append(row)
    _write_csv(path, fields, rows)


def write_layer_assignments(out: Path, hierarchy: Mapping[str, Any], l2_result: Mapping[str, Any], l1_result: Mapping[str, Any]) -> list[str]:
    expected = {str(row["component_id"]) for row in hierarchy["assignments"]}
    l0_rows = [{**row, "analysis_seconds": hierarchy["analysis_times_seconds"]["L0"]["total_seconds"]}
               for row in hierarchy["assignments"]]
    l1_rows = []
    l2_rows = []
    status_by_l1 = {str(row["l1_id"]): (str(row.get("status", "")), str(row.get("decision", "")))
                    for row in l2_result.get("cluster_assignments", [])}
    for domain in hierarchy["l2_domains"]:
        for child in domain["l1_clusters"]:
            for component_id in child["members"]:
                l1_rows.append({"component_id": component_id, "l0_id": next(item["id"] for item in child["l0_clusters"] if item["component_id"] == component_id),
                                "l1_id": child["l1_id"], "l2_id": domain["id"],
                                "function": child.get("function", ""), "function_type": child.get("function_type", ""),
                                "source": child.get("source", ""), "reason": child.get("reason", ""),
                                "analysis_seconds": hierarchy["analysis_times_seconds"]["L1"]["total_seconds"]})
        for component_id in domain["component_ids"]:
            l2_rows.append({"component_id": component_id, "l2_id": domain["id"],
                            "cluster_id": domain["cluster_id"], "cluster_name": domain["cluster_name"],
                            "status": status_by_l1.get(str(child["l1_id"]), ("", ""))[0],
                            "decision": status_by_l1.get(str(child["l1_id"]), ("", ""))[1],
                            "analysis_seconds": hierarchy["analysis_times_seconds"]["L2"]["total_seconds"]})
    paths = {
        "L0_assignments.csv": (["component_id", "l0_id", "l1_id", "l2_id", "is_connector", "analysis_seconds"], l0_rows),
        "L1_assignments.csv": (["component_id", "l0_id", "l1_id", "l2_id", "function", "function_type", "source", "reason", "analysis_seconds"], l1_rows),
        "L2_assignments.csv": (["component_id", "l2_id", "cluster_id", "cluster_name", "status", "decision", "analysis_seconds"], l2_rows),
    }
    for filename, (fields, rows) in paths.items():
        refs = [str(row["component_id"]) for row in rows]
        if set(refs) != expected or len(refs) != len(set(refs)):
            raise ValueError(f"{filename} 覆盖/唯一性校验失败")
        _write_csv(out / filename, fields, rows)
    return list(paths)


def _l1_pairwise_rand(left: Mapping[str, str], right: Mapping[str, str]) -> float:
    """Label-invariant pairwise agreement (Rand index) for two L1 partitions."""
    ids = sorted(set(left) & set(right))
    n = len(ids)
    if n < 2:
        return 1.0 if set(left) == set(right) else 0.0
    same_left = same_right = both_same = 0
    for i, first in enumerate(ids):
        for second in ids[i + 1:]:
            a = left[first] == left[second]
            b = right[first] == right[second]
            same_left += a
            same_right += b
            both_same += a and b
    total = n * (n - 1) // 2
    both_different = total - same_left - same_right + both_same
    return (both_same + both_different) / total


def _l1_membership_map(hierarchy: Mapping[str, Any]) -> dict[str, str]:
    return {str(component): str(cluster["l1_id"])
            for cluster in hierarchy.get("l1_clusters", [])
            for component in cluster.get("members", [])}


def _assignment_membership_map(hierarchy: Mapping[str, Any], layer: str) -> dict[str, str]:
    return {str(row["component_id"]): str(row[f"{layer}_id"])
            for row in hierarchy.get("assignments", []) if row.get(f"{layer}_id") is not None}


def run_flow(args: argparse.Namespace) -> dict[str, Any]:
    started = time.perf_counter()
    input_path = Path(args.netlist).resolve(); out = Path(args.out).resolve(); out.mkdir(parents=True, exist_ok=True)
    board_l1_extracted_path = getattr(args, "l1_extracted_path", None)
    if input_path.suffix.lower() == ".epro2" and not board_l1_extracted_path:
        # L0/L1 use the L1 experiment's page-aware extractor.
        l1_extractor = load_extractor("L1")
        l1_extracted = l1_extractor.extract_epro2_slim(input_path)
        save_json(out / "epro2_extracted.json", l1_extracted)
        netlist = l1_extractor.to_partition_netlist(l1_extracted)
        # L2 independently extracts global net labels and voltage evidence.
        l2_extractor = load_extractor("L2")
        l2_extracted = l2_extractor.extract_epro2_slim(input_path)
        l2_netlist = l2_extractor.to_partition_netlist(l2_extracted)
        save_json(out / "l2" / "epro2_extracted.json", l2_extracted)
        save_json(out / "l2" / "normalized_netlist.json", l2_netlist)
        l1_boards = map_project_boards(input_path, l1_extracted, l1_extractor)
        l2_boards = map_project_boards(input_path, l2_extracted, l2_extractor)
        l2_by_id = {row["board_id"]: row for row in l2_boards}
        if {row["board_id"] for row in l1_boards} != set(l2_by_id):
            raise ValueError("L1 与 L2 提取器映射出的板卡集合不一致")
        board_runs = []
        requested_rounds = max(1, int(getattr(args, "rounds", 1)))
        for board in l1_boards:
            if board["board_id"] not in l2_by_id:
                raise ValueError(f"L2 提取器缺少板卡 {board['name']}")
            l1_board_netlist = board_netlist(l1_extracted, board, l1_extractor)
            l2_board = l2_by_id[board["board_id"]]
            l2_board_netlist = board_netlist(l2_extracted, l2_board, l2_extractor)
            if {str(c["id"]) for c in l1_board_netlist["components"]} != {str(c["id"]) for c in l2_board_netlist["components"]}:
                raise ValueError(f"板卡 {board['name']} 的 L1/L2 提取器器件 ID 不一致")
            board_slug = re.sub(r"[^0-9A-Za-z._-]+", "_", board["name"]).strip("_")
            repetitions = []
            for round_index in range(1, requested_rounds + 1):
                board_dir = (out / "boards" / board_slug if requested_rounds == 1 else
                             out / f"round_{round_index:02d}" / "boards" / board_slug)
                l1_board_extracted = board_extracted(l1_extracted, board)
                l2_board_extracted = board_extracted(l2_extracted, l2_board)
                l1_extracted_path = board_dir / "l1_board_extracted.json"
                l2_extracted_path = board_dir / "l2" / "l2_board_extracted.json"
                save_json(l1_extracted_path, l1_board_extracted)
                save_json(l2_extracted_path, l2_board_extracted)
                save_json(board_dir / "l2" / "normalized_netlist.json", l2_board_netlist)
                board_args = argparse.Namespace(**vars(args))
                board_args.netlist = str(input_path)
                board_args.out = str(board_dir)
                board_args.rounds = 1
                board_args.l1_extracted_path = str(l1_extracted_path)
                board_args.l2_extracted_path = str(l2_extracted_path)
                board_run = run_flow(board_args)
                hierarchy_path = board_dir / "hierarchy.json"
                hierarchy_data = json.loads(hierarchy_path.read_text(encoding="utf-8-sig"))
                repetitions.append({"round": round_index, "output": str(board_dir),
                                    "run": board_run, "hierarchy": hierarchy_data,
                                    "l1_membership": _l1_membership_map(hierarchy_data)})
            layer_data: dict[str, list[dict[str, str]]] = {}
            for layer in ("l1", "l2"):
                layer_data[layer] = [_assignment_membership_map(item["hierarchy"], layer)
                                     for item in repetitions]
            base_components = set(layer_data["l1"][0])
            for repetition in repetitions:
                for layer in ("l1", "l2"):
                    if set(_assignment_membership_map(repetition["hierarchy"], layer)) != base_components:
                        raise RuntimeError(f"板卡 {board['name']} 第 {repetition['round']} 轮 {layer.upper()} 器件覆盖与首轮不一致")
            layer_stability = {}
            for layer in ("l1", "l2"):
                maps = layer_data[layer]
                scores = [_l1_pairwise_rand(maps[i], maps[j])
                          for i in range(len(maps)) for j in range(i + 1, len(maps))]
                layer_stability[layer.upper()] = {
                    "mean_pairwise_rand_index": sum(scores) / len(scores) if scores else 1.0,
                    "min_pairwise_rand_index": min(scores) if scores else 1.0,
                    "per_round_vs_round_1": [
                        {"round": index + 1,
                         "rand_index": _l1_pairwise_rand(maps[0], membership),
                         "cluster_count": len(set(membership.values()))}
                        for index, membership in enumerate(maps)]}
            stability = {"rounds": requested_rounds,
                         "component_coverage_identical": True,
                         "layers": layer_stability,
                         "metric": "label-invariant pairwise Rand index over device pairs sharing the same layer cluster; 1.0 means identical partition"}
            board_runs.append({"board": board,
                               "output": repetitions[0]["output"],
                               "run": repetitions[0]["run"],
                               "stability": stability,
                               "rounds": [{"round": item["round"], "output": item["output"],
                                           "run": item["run"]} for item in repetitions]})

        all_rows = []
        for item in board_runs:
            board = item["board"]
            hierarchy_path = Path(item["output"]) / "hierarchy.json"
            hierarchy_data = json.loads(hierarchy_path.read_text(encoding="utf-8-sig"))
            for row in hierarchy_data.get("assignments", []):
                all_rows.append({**row, "board_id": board["board_id"], "board_name": board["name"]})
        save_json(out / "board_mapping.json", {"schema": "epro2-board-mapping-v1", "boards": l1_boards})
        save_json(out / "multi_board_hierarchy.json", {"schema": "partitioner-multi-board-hierarchy-v1",
                  "board_count": len(board_runs), "boards": board_runs,
                  "assignments": all_rows, "component_count": len(all_rows),
                  "all_components_once_per_board": True})
        manifest = {"schema": "partitioner-bottom-up-flow-manifest-v1",
                    "status": "dry_run" if args.dry_run else "completed",
                    "flow_order": ["L0", "L1", "L2"], "input": str(input_path),
                    "output": str(out), "dry_run": bool(args.dry_run),
                    "board_count": len(board_runs), "requested_rounds": requested_rounds,
                    "counts": {"boards": len(board_runs),
                               "components": len(all_rows),
                               "l1_clusters": sum(x["run"]["counts"]["l1_clusters"] for x in board_runs),
                               "l2_domains": sum(x["run"]["counts"]["l2_domains"] for x in board_runs)},
                    "board_mapping": "native SCH.board UUID == PCB.board UUID; pages linked by SCH_PAGE.schematic UUID",
                    "l1_method": "integrated_l1_deterministic_partition_plus_small_component_completion_no_function_recognition",
                    "l1_entrypoint": str(Path(l1_experiment.__file__).resolve()),
                    "l2_method": "integrated_l2_core_chip_power_input_voltage_aggregation_rules",
                    "l2_aggregator": str(Path(l1_voltage_aggregate.__file__).resolve()),
                    "epro2_extractors": {"L1": str(l1_extractor.__file__), "L2": str(l2_extractor.__file__)},
                    "artifacts": ["board_mapping.json", "multi_board_hierarchy.json",
                                  *[str(Path(round_item["output"]).relative_to(out) / "hierarchy.json")
                                    for board_item in board_runs for round_item in board_item["rounds"]]]}
        save_json(out / "run.json", manifest)
        print(f"完成多板划分：{len(board_runs)} 块板，{len(all_rows)} 个板级器件归属。", flush=True)
        return manifest
    else:
        l1_extractor = load_extractor("L1")
        l2_extractor = load_extractor("L2")
        if board_l1_extracted_path:
            l1_extracted = json.loads(Path(board_l1_extracted_path).read_text(encoding="utf-8-sig"))
            netlist = l1_extractor.to_partition_netlist(l1_extracted)
        elif input_path.suffix.lower() == ".epro2":
            l1_extracted = l1_extractor.extract_epro2_slim(input_path)
            netlist = l1_extractor.to_partition_netlist(l1_extracted)
        else:
            raise ValueError("当前集成的 L1 专用划分方法要求 .epro2 工程输入")
        l2_extracted_path = getattr(args, "l2_extracted_path", None)
        if l2_extracted_path:
            l2_extracted = json.loads(Path(l2_extracted_path).read_text(encoding="utf-8-sig"))
        else:
            l2_extracted = l2_extractor.extract_epro2_slim(input_path)
        l2_netlist = l2_extractor.to_partition_netlist(l2_extracted)
        if {str(c["id"]) for c in netlist["components"]} != {str(c["id"]) for c in l2_netlist["components"]}:
            raise ValueError("L1 与 L2 提取器器件集合不一致")
    save_json(out / "normalized_netlist.json", netlist)

    l0_result = build_l0(netlist, out / "l0")
    print(f"完成 L0 基础节点：{len(l0_result['clusters'])} 个器件节点。", flush=True)

    l1_started = time.perf_counter()
    l1_result = _run_l1(netlist, args, out / "l1", l1_extracted)
    l1_seconds = time.perf_counter() - l1_started
    print(f"完成 L1 簇划分：{len(l1_result['clusters'])} 簇。", flush=True)

    l2_started = time.perf_counter()
    l2_result = aggregate_voltage_by_l1(l1_result, l2_netlist, threshold_v=args.threshold_v)
    save_json(out / "l2" / "l1_voltage_features_l2.json", l2_result)
    save_json(out / "l2" / "voltage_partition_by_l1.json", l2_result)
    l2_seconds = time.perf_counter() - l2_started
    hierarchy = build_hierarchy(netlist, l1_result, l2_result, l0_result=l0_result, dry_run=args.dry_run,
                                l1_seconds=l1_seconds, l2_seconds=l2_seconds)
    save_json(out / "hierarchy.json", hierarchy)
    write_assignments_csv(out / "hierarchical_assignments.csv", hierarchy)
    layer_csvs = write_layer_assignments(out, hierarchy, l2_result, l1_result)
    artifacts = ["normalized_netlist.json", "l0/base_clusters.json", "l1/l1_final_result.json",
                 "l1/l1_final_assignments.csv", "l2/l1_voltage_features_l2.json",
                 "l2/l1_voltage_features.csv", "hierarchy.json", "hierarchical_assignments.csv", *layer_csvs]
    extraction_sources = None
    if input_path.suffix.lower() == ".epro2":
        artifacts.extend(["epro2_extracted.json", "l2/epro2_extracted.json", "l2/normalized_netlist.json"])
        extraction_sources = {"L1": str(load_extractor("L1").__file__),
                              "L2": str(load_extractor("L2").__file__)}
    manifest = {"schema": "partitioner-bottom-up-flow-manifest-v1",
                "status": "dry_run" if args.dry_run else "completed", "flow_order": ["L0", "L1", "L2"],
                "input": str(input_path), "output": str(out), "threshold_v": args.threshold_v,
                "temperature": args.temperature, "dry_run": bool(args.dry_run),
                "l1_method": "integrated_l1_deterministic_partition_plus_small_component_completion_no_function_recognition",
                "l1_entrypoint": str(Path(l1_experiment.__file__).resolve()),
                "l2_method": "integrated_l2_core_chip_power_input_voltage_aggregation_rules",
                "l2_aggregator": str(Path(l1_voltage_aggregate.__file__).resolve()),
                "epro2_extractors": extraction_sources,
                "strict_parent_child": True, "analysis_times_seconds": hierarchy["analysis_times_seconds"],
                "total_elapsed_seconds": round(time.perf_counter() - started, 6),
                "counts": {"components": hierarchy["component_count"], "l0_clusters": len(hierarchy["assignments"]),
                           "l1_clusters": len(hierarchy["l1_clusters"]), "l2_domains": len(hierarchy["l2_domains"])},
                "artifacts": artifacts}
    save_json(out / "run.json", manifest)
    print(f"完成：L0 {manifest['counts']['l0_clusters']} 个，L1 {manifest['counts']['l1_clusters']} 簇，"
          f"L2 {manifest['counts']['l2_domains']} 电压域（自下而上）。", flush=True)
    return manifest


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="自下而上的三层划分器：L0 单器件 → L1 功能簇 → L2 高低压域")
    parser.add_argument("netlist", help="EasyEDA Pro .epro2 工程（L1/L2 专用流程）")
    parser.add_argument("--out", type=Path, default=ROOT / "output")
    parser.add_argument("--api-key-file", "--deepseek-api-key-file", dest="api_key_file", type=Path)
    parser.add_argument("--base-url"); parser.add_argument("--model")
    parser.add_argument("--threshold-v", type=float, default=12.0)
    parser.add_argument("--temperature", type=float, default=0.0)
    parser.add_argument("--rounds", type=int, default=1,
                        help="每块板独立运行次数；大于 1 时输出 L1/L2 划分稳定性报告")
    parser.add_argument("--timeout", type=int, default=180)
    parser.add_argument("--algorithm-dir", type=Path, default=ROOT / "划分器算法部分")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args(argv)
    if args.threshold_v <= 0 or not 0 <= args.temperature <= 2 or args.timeout <= 0 or args.rounds < 1:
        parser.error("阈值必须大于 0，温度需在 0 到 2 之间，超时和轮数必须为正整数")
    return args


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    try:
        run_flow(args); return 0
    except Exception as exc:
        out = Path(args.out).resolve()
        try:
            save_json(out / "flow_error.json", {"schema": "partitioner-bottom-up-flow-error-v1",
                                                "error_type": type(exc).__name__, "error": str(exc),
                                                "input": str(Path(args.netlist).resolve())})
        except OSError:
            pass
        print(f"运行失败：{exc}", file=sys.stderr, flush=True)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
