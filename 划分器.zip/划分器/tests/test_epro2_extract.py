import json
import tempfile
import unittest
import zipfile
from pathlib import Path

from epro2_extract import _normalize_value_token, _records, extract_epro2


def _record(kind, entity_id, payload, ticket=1):
    header = {"type": kind, "id": entity_id, "ticket": ticket}
    return json.dumps(header, separators=(",", ":")) + "||" + json.dumps(payload) + "|\n"


class Epro2ExtractionTests(unittest.TestCase):
    def test_value_normalization_extracts_units_without_false_positive_part_ids(self):
        self.assertEqual(_normalize_value_token("100nF.1", from_part_id=True), "100nF")
        self.assertEqual(_normalize_value_token("5.1M.1", from_part_id=True), "5.1M")
        self.assertEqual(_normalize_value_token("CGA0603X5R226M100JT.1", from_part_id=True), None)
        self.assertEqual(_normalize_value_token("={ManufacturerPart}"), None)

    def test_records_keep_document_boundaries_and_latest_entity_version(self):
        text = _record("DOCHEAD", "", {"docType": "SCH_PAGE", "uuid": "page-a"})
        text += _record("COMPONENT", "same-id", {"x": 1}, 1)
        text += _record("COMPONENT", "same-id", {"x": 2}, 2)
        text += _record("DOCHEAD", "", {"docType": "PCB", "uuid": "board-a"})
        text += _record("COMPONENT", "same-id", {"x": 3}, 3)
        rows = _records(text)
        self.assertEqual(len(rows), 2)
        self.assertEqual([(row["doc_type"], row["data"]["x"]) for row in rows],
                         [("SCH_PAGE", 2), ("PCB", 3)])

    def test_extract_normalizes_attributes_pad_nets_and_assets(self):
        text = _record("DOCHEAD", "", {"docType": "PCB", "uuid": "board"})
        text += _record("COMPONENT", "cmp1", {"x": 12, "y": 5, "rotation": 90})
        for key, value in (("Designator", "U1"), ("Value", "MCU"), ("Footprint", "LQFP-48")):
            text += _record("ATTR", "attr-" + key,
                            {"parentId": "cmp1", "key": key, "value": value})
        text += _record("PAD_NET", '["PAD_NET","cmp1","7","pad7"]', {"padNet": "VDD"})
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "fixture.epro2"
            with zipfile.ZipFile(path, "w") as archive:
                archive.writestr("project.epru", text)
                archive.writestr("IMAGE/logo.webp", b"not-a-webp-but-indexed")
            assets_dir = Path(temp) / "assets"
            result = extract_epro2(path, asset_dir=assets_dir)
            self.assertTrue(Path(result["assets"][0]["extracted_path"]).is_file())
        self.assertEqual(result["schema"], "easyeda-pro-extraction-v1")
        self.assertEqual(result["pcb"]["components"][0]["designator"], "U1")
        self.assertEqual(result["pcb"]["components"][0]["footprint"], "LQFP-48")
        endpoint = result["pcb"]["nets"][0]["endpoints"][0]
        self.assertEqual((endpoint["component"], endpoint["pin"], endpoint["net"]), ("U1", "7", "VDD"))
        self.assertEqual(result["assets"][0]["archive_path"], "IMAGE/logo.webp")

    def test_component_value_has_normalized_value_and_provenance(self):
        text = _record("DOCHEAD", "", {"docType": "SCH_PAGE", "uuid": "page"})
        text += _record("COMPONENT", "c1", {"partId": "100nF.1", "x": 0, "y": 0})
        text += _record("ATTR", "a1", {"parentId": "c1", "key": "Designator", "value": "C1"})
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "fixture.epro2"
            with zipfile.ZipFile(path, "w") as archive:
                archive.writestr("project.epru", text)
            component = extract_epro2(path)["schematic"]["components"][0]
        self.assertIsNone(component["value"])
        self.assertEqual(component["value_normalized"], "100nF")
        self.assertEqual(component["value_source"], "part_id")
        self.assertEqual(component["value_confidence"], 0.8)


if __name__ == "__main__":
    unittest.main()
