import csv
import tempfile
import unittest
from pathlib import Path

from run_flow import (_is_connector, aggregate_voltage_by_l1, build_hierarchy,
                      write_assignments_csv, write_layer_assignments)
from l1_flow import _is_connector as _is_l1_connector


class BottomUpHierarchyTests(unittest.TestCase):
    def setUp(self):
        self.netlist = {"components": [
            {"id": "U1", "kind": "ic", "pins": [{"id": "1", "name": "VIN"}]},
            {"id": "U2", "kind": "ic", "pins": [{"id": "1", "name": "VIN"}, {"id": "2", "name": "VCC"}]},
            {"id": "C1", "kind": "capacitor"},
            {"id": "R1", "kind": "resistor"}, {"id": "J1", "kind": "connector"},
        ], "nets": [
            {"id": "3V3", "pins": [{"component": "U1", "pin": "1", "name": "VIN"}]},
            {"id": "3V3_B", "pins": [{"component": "U2", "pin": "1", "name": "VIN"}]},
            {"id": "24V", "pins": [{"component": "U2", "pin": "2", "name": "VCC"}]},
        ]}
        self.l1 = {"clusters": [
            {"id": "L1-0001", "members": ["U1", "C1"], "function": "power_stage"},
            {"id": "L1-0002", "members": ["U2", "R1", "J1"], "function": "interface"},
        ]}

    def test_l2_uses_chip_power_inputs_and_keeps_mixed_boundary_unresolved(self):
        l2 = aggregate_voltage_by_l1(self.l1, self.netlist)
        by_l1 = {row["l1_id"]: row["l2_cluster_id"] for row in l2["cluster_assignments"]}
        self.assertEqual(by_l1, {"L1-0001": "low_voltage", "L1-0002": "unresolved_voltage"})
        self.assertEqual(l2["unresolved_l1_cluster_ids"], ["L1-0002"])
        mixed = next(row for row in l2["l1_voltage_features"] if row["l1_cluster_id"] == "L1-0002")
        self.assertTrue(mixed["mixed_voltage"])
        self.assertEqual({row["voltage_v"] for row in mixed["voltage_rails"]}, {3.3, 24.0})

    def test_parent_child_tree_and_csvs_are_unique(self):
        l2 = aggregate_voltage_by_l1(self.l1, self.netlist)
        hierarchy = build_hierarchy(self.netlist, self.l1, l2)
        self.assertEqual(hierarchy["flow_order"], ["L0", "L1", "L2"])
        self.assertTrue(hierarchy["strict_parent_child"])
        self.assertEqual(len(hierarchy["assignments"]), 5)
        self.assertEqual(len(hierarchy["l1_clusters"][0]["l0_clusters"]), 2)
        self.assertEqual({row["cluster_id"] for row in hierarchy["l2_domains"]}, {"low_voltage", "high_voltage", "unresolved_voltage"})
        for domain in hierarchy["l2_domains"]:
            self.assertEqual(
                sorted(domain["component_ids"]),
                sorted(ref for child in domain["l1_clusters"] for ref in child["members"]),
            )
        with tempfile.TemporaryDirectory() as temporary:
            output = Path(temporary)
            write_assignments_csv(output / "hierarchical.csv", hierarchy)
            paths = write_layer_assignments(output, hierarchy, l2, self.l1)
            self.assertEqual(set(paths), {"L0_assignments.csv", "L1_assignments.csv", "L2_assignments.csv"})
            for name in paths:
                with (output / name).open("r", encoding="utf-8-sig", newline="") as handle:
                    rows = list(csv.DictReader(handle))
                self.assertEqual(len(rows), 5, name)
                self.assertEqual({row["component_id"] for row in rows}, {"U1", "U2", "C1", "R1", "J1"})

    def test_connector_detection(self):
        self.assertTrue(_is_connector({"id": "J7", "kind": "other"}))
        self.assertTrue(_is_connector({"id": "CN1", "footprint": "CONN-TH_4P"}))
        self.assertTrue(_is_connector({"id": "FPC1", "value": "FPC类器件"}))
        self.assertTrue(_is_connector({"id": "C7", "description": "柔性排线连接器"}))
        self.assertTrue(_is_l1_connector({"id": "C7", "footprint": "FPC_0.5MM"}))
        self.assertTrue(_is_l1_connector({"id": "C8", "value": "FPC类器件"}))
        self.assertFalse(_is_connector({"id": "C7", "kind": "capacitor"}))


if __name__ == "__main__":
    unittest.main()
