import unittest
from l1_voltage_aggregate import build_features

NET={"components":[
        {"id":"U1","kind":"ic_module","pins":[{"id":"1","name":"VIN","net":"+3V3"}]},
        {"id":"U2","kind":"ic_module","pins":[{"id":"1","name":"VHV","net":"24V"}]},
        {"id":"U3","kind":"ic_module","operating_voltage":"24V","pins":[{"id":"1","name":"VDD","net":"VCC"}]},
        {"id":"U4","kind":"ic_module","pins":[{"id":"1","name":"VIN","net":"3V3"},{"id":"2","name":"VCC","net":"24V"}]},
        {"id":"R0","kind":"resistor","value":"0R","pins":[]},
        {"id":"J1","kind":"connector","pins":[]}],
     "nets":[{"id":"+3V3","pins":[{"component":"U1","pin":"1","name":"VIN"}]},
             {"id":"24V","pins":[{"component":"U2","pin":"1","name":"VHV"}]},
             {"id":"VCC","pins":[{"component":"U3","pin":"1","name":"VDD"}]},
             {"id":"3V3","pins":[{"component":"U4","pin":"1","name":"VIN"}]},
             {"id":"24V_A","pins":[{"component":"U4","pin":"2","name":"VCC"}]},
             {"id":"AGND","pins":[{"component":"R0"}]},{"id":"GND","pins":[{"component":"R0"}]},{"id":"JNET","pins":[{"component":"J1"}]}]}
L1={"schema":"fixture","domains":[{"id":"L1-A","members":["U1","R0"]},{"id":"L1-B","members":["U2"]},{"id":"L1-C","members":["U3"]},{"id":"L1-D","members":["U4"]},{"id":"L1-E","members":["J1"]}]}

class AggregateTests(unittest.TestCase):
    def test_aggregates_l1_clusters_by_explicit_rails_and_preserves_mixed(self):
        result=build_features(NET,L1,12)
        features={r["l1_cluster_id"]:r for r in result["l1_voltage_features"]}
        self.assertEqual(features["L1-A"]["status"],"resolved_low")
        self.assertEqual(features["L1-B"]["status"],"resolved_high")
        self.assertEqual(features["L1-C"]["status"],"resolved_low")
        self.assertEqual(features["L1-C"]["decision_reason"],"unquantified_power_net_default_low")
        self.assertEqual(features["L1-D"]["status"],"mixed_voltage")
        self.assertEqual(features["L1-E"]["status"],"resolved_low")
        self.assertEqual(features["L1-E"]["decision_reason"],"no_core_chip_default_low")
        self.assertEqual(result["unresolved_l1_cluster_ids"],["L1-D"])
        self.assertEqual(features["L1-C"]["voltage_rails"],[])
        self.assertEqual(features["L1-A"]["ground_links"][0]["component_id"],"R0")

    def test_requires_complete_unique_l1_assignment(self):
        bad={"domains":[{"id":"x","members":["U1"]}]}
        with self.assertRaises(ValueError): build_features(NET,bad)

if __name__=="__main__": unittest.main()
