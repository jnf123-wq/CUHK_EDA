import json
import tempfile
import unittest
import zipfile
from pathlib import Path

from epro2_extractors import load_extractor


class StageExtractorTests(unittest.TestCase):
    def test_stage_extractors_are_integrated_inside_the_partitioner(self):
        project_root = Path(__file__).resolve().parents[1]
        for stage in ("L1", "L2"):
            with self.subTest(stage=stage):
                extractor = load_extractor(stage)
                self.assertTrue(Path(extractor.__file__).resolve().is_relative_to(project_root))
                self.assertEqual(Path(extractor.__file__).name, "epro2_extract_slim.py")

    def test_l2_extractor_uses_global_net_labels_while_l1_keeps_page_aware_version(self):
        l1 = load_extractor("L1")
        l2 = load_extractor("L2")
        self.assertNotEqual(l1.__file__, l2.__file__)

        extracted = {
            "source": {"archive": "fixture.epro2"},
            "schematic": {
                "components": [{
                    "designator": "U1", "part_id": "IC", "value": "IC",
                    "placement": {"x": 10, "y": 0},
                    "pins": [{"pin_number": "1", "pin_name": "VIN",
                              "canvas": {"x": 10, "y": 0}}],
                }],
                "wires": [{"id": "w1", "net": None, "segments": [
                    {"startX": 0, "startY": 0, "endX": 10, "endY": 0},
                ]}],
                "net_labels": [{"name": "+32V", "anchor": {"x": 0, "y": 0}}],
            },
        }

        l1_net = l1.to_partition_netlist(extracted)["components"][0]["pins"][0]["net"]
        l2_net = l2.to_partition_netlist(extracted)["components"][0]["pins"][0]["net"]
        self.assertNotEqual(l1_net, "+32V")
        self.assertEqual(l2_net, "+32V")

    def test_both_extractors_keep_matching_component_ids_for_the_same_project(self):
        l1 = load_extractor("L1")
        l2 = load_extractor("L2")

        def record(kind, entity_id, data, ticket=1):
            header = {"type": kind, "id": entity_id, "ticket": ticket}
            return json.dumps(header) + "||" + json.dumps(data) + "|\n"

        epru = record("DOCHEAD", "", {"docType": "SCH_PAGE", "uuid": "page-a"})
        epru += record("COMPONENT", "component-1", {"x": 10, "y": 20, "partId": "R"})
        epru += record("ATTR", "attribute-1", {
            "parentId": "component-1", "key": "Designator", "value": "R1"})
        epru += record("ATTR", "attribute-2", {
            "parentId": "component-1", "key": "Value", "value": "10k"})

        with tempfile.TemporaryDirectory() as temporary:
            project = Path(temporary) / "fixture.epro2"
            with zipfile.ZipFile(project, "w") as archive:
                archive.writestr("project.epru", epru)
            l1_result = l1.to_partition_netlist(l1.extract_epro2_slim(project))
            l2_result = l2.to_partition_netlist(l2.extract_epro2_slim(project))

        self.assertEqual([row["id"] for row in l1_result["components"]], ["R1"])
        self.assertEqual([row["id"] for row in l1_result["components"]],
                         [row["id"] for row in l2_result["components"]])


if __name__ == "__main__":
    unittest.main()
