"""Deterministic voltage evidence extraction for L3 experiments."""
from __future__ import annotations
import re
from collections import defaultdict
from typing import Any, Mapping

CLUSTERS=("low_voltage","high_voltage")
GROUND_NAMES={"GND","PGND","AGND","DGND","CGND","SGND","0V","COM","GROUND"}
PASSIVE_KINDS={"resistor","capacitor","inductor","diode","fuse","thermistor","bead","connector","other"}


def is_ground_net(name: str) -> bool:
    """Recognize explicit ground/reference net labels, not arbitrary nets."""
    text=re.sub(r"[^A-Z0-9]", "", str(name).upper())
    if text in GROUND_NAMES:
        return True
    return bool(re.fullmatch(r"(?:AGND|DGND|PGND|CGND|SGND|GND|GROUND)(?:[0-9]+|[A-Z])?", text)
                or re.fullmatch(r"(?:[+-]?0(?:\.0+)?)V(?:REF)?", text))


def ground_coupling_links(netlist: Mapping[str,Any]) -> list[dict[str,Any]]:
    """Find explicit zero-ohm/ferrite links between two named ground nets.

    This records reference connectivity only. It does not infer the device's
    operating voltage or merge unrelated voltage rails.
    """
    cn=component_nets(netlist)
    links=[]
    for comp in netlist.get("components",[]) or []:
        cid=component_id(comp)
        nets=sorted(cn.get(cid,set()))
        if len(nets)!=2 or not all(is_ground_net(n) for n in nets):
            continue
        ref=str(comp.get("ref",cid)).strip().upper()
        kind=component_kind(comp).lower()
        descriptions=" ".join(str(comp.get(k,"")) for k in ("value","part","name","manufacturer_part","device_name")).strip()
        normalized=descriptions.upper().replace("Ω","R").replace("Ω","R").replace("OHMS","OHM")
        zero_resistor=(bool(re.match(r"^\s*0(?:\.0+)?\s*(?:R|OHM)\b", normalized)) or
                       bool(re.match(r"^\s*0R(?:\.\d+)?(?:\s|$)", normalized)) or
                       bool(re.search(r"-070RL(?:\.|$|[-_])", normalized)))
        zero_resistor=zero_resistor and (kind=="resistor" or ref.startswith("R"))
        bead=(kind in {"bead","ferrite_bead"} or ref.startswith("FB") or
              bool(re.search(r"FERRITE\s*BEAD|磁珠", descriptions, re.IGNORECASE)))
        if zero_resistor or bead:
            links.append({"component_id":cid,"net_a":nets[0],"net_b":nets[1],
                          "link_type":"zero_ohm_resistor" if zero_resistor else "ferrite_bead",
                          "evidence":"explicit_ground_net_labels"})
    return links


def nets_map(netlist: Mapping[str,Any]) -> dict[str,list[dict[str,Any]]]:
    raw=netlist.get("nets",[])
    if isinstance(raw,Mapping):
        raw=[{"id":k,"pins":v} for k,v in raw.items()]
    result={}
    for row in raw or []:
        if not isinstance(row,Mapping): continue
        name=str(row.get("id",row.get("name",""))).strip()
        if not name: continue
        pins=row.get("pins",row.get("components",row.get("endpoints",[])))
        result[name]=[dict(p) if isinstance(p,Mapping) else {"component":str(p)} for p in (pins or [])]
    return result


def component_id(c: Mapping[str,Any])->str:
    return str(c.get("id",c.get("ref",c.get("designator","")))).strip()


def pin_component(pin: Mapping[str,Any])->str:
    return str(pin.get("component") or pin.get("ref") or pin.get("c") or pin.get("designator") or "").strip()


def parse_voltage(value: Any) -> float|None:
    text=str(value or "").strip().upper().replace(" ","")
    if not text: return None
    if text in GROUND_NAMES or text.endswith("_GND") or text.startswith("GND"):
        return 0.0
    m=re.search(r"(?<![A-Z0-9])([+-]?\d+(?:\.\d+)?)V(?:DC|AC)?(?![A-Z0-9])",text)
    if m: return abs(float(m.group(1)))
    m=re.search(r"(?<![A-Z0-9])([+-]?\d+)V(\d+)(?![A-Z0-9])",text)
    if m: return abs(float(f"{m.group(1)}.{m.group(2)}"))
    m=re.search(r"(?<![A-Z0-9])([+-]?\d+(?:\.\d+)?)(?:V|VOLTS?)(?![A-Z0-9])",text)
    if m: return abs(float(m.group(1)))
    return None


def component_nets(netlist: Mapping[str,Any]) -> dict[str,set[str]]:
    out=defaultdict(set)
    for name,pins in nets_map(netlist).items():
        for pin in pins:
            cid=pin_component(pin)
            if cid: out[cid].add(name)
    for c in netlist.get("components",[]) or []:
        cid=component_id(c)
        for pin in c.get("pins",[]) or []:
            if isinstance(pin,Mapping) and pin.get("net"): out[cid].add(str(pin["net"]))
    return dict(out)


def component_kind(c: Mapping[str,Any])->str:
    kind=str(c.get("kind",c.get("type",""))).lower()
    if kind: return kind
    cid=component_id(c).upper()
    return {"R":"resistor","C":"capacitor","L":"inductor","D":"diode","Q":"transistor","U":"ic_module","J":"connector"}.get(cid[:1],"other")


def rail_candidates(net_name: str, pins: list[Mapping[str,Any]])->set[float]:
    values=set()
    for text in [net_name]+[str(p.get("name",p.get("pin_name",""))) for p in pins]:
        v=parse_voltage(text)
        if v is not None: values.add(v)
    return values


def infer_net_voltages(netlist: Mapping[str,Any]) -> tuple[dict[str,set[float]],dict[str,list[str]]]:
    nm=nets_map(netlist)
    values={name:rail_candidates(name,pins) for name,pins in nm.items()}
    for name, value in (netlist.get("net_voltage_overrides", {}) or {}).items():
        try: values.setdefault(str(name), set()).add(float(value))
        except (TypeError, ValueError): pass
    evidence={name:[] for name in values}
    for name,vals in values.items():
        if vals: evidence[name].append("net_or_pin_label")
    comps={component_id(c):c for c in netlist.get("components",[]) or []}
    cn=component_nets(netlist)
    # Safe propagation only through a component that has exactly one known
    # voltage side; a resistor divider or converter with two known sides stays
    # a boundary and does not contaminate either rail.
    for _ in range(max(1,len(comps))):
        changed=False
        for cid,names in cn.items():
            if not names: continue
            known={v for n in names for v in values.get(n,set()) if abs(v)>1e-12}
            known_names=[n for n in names if any(abs(v)>1e-12 for v in values.get(n,set()))]
            if len(known_names)!=1 or len(known)!=1: continue
            value=next(iter(known)); comp=comps.get(cid,{})
            if component_kind(comp) not in PASSIVE_KINDS: continue
            for n in names:
                if not values.get(n):
                    values[n].add(value); evidence[n].append(f"propagated:{cid}"); changed=True
        if not changed: break
    return values,evidence


def extract_evidence(netlist: Mapping[str,Any], threshold_v: float) -> dict[str,dict[str,Any]]:
    nm=nets_map(netlist); nv,ne=infer_net_voltages(netlist); cn=component_nets(netlist)
    comps={component_id(c):c for c in netlist.get("components",[]) or []}
    couplers={row["component_id"]:row for row in ground_coupling_links(netlist)}
    rows={}
    for cid,c in comps.items():
        vals=sorted({v for n in cn.get(cid,set()) for v in nv.get(n,set())})
        # Ground is the reference node, not evidence of a component's operating
        # voltage. Ignore 0 V for component voltage assignment entirely.
        vals=[v for v in vals if abs(v)>1e-12]
        high=[v for v in vals if v>threshold_v]; low=[v for v in vals if v<=threshold_v]
        text=" ".join(str(c.get(k,"")) for k in ("operating_voltage","voltage","name","value","part","manufacturer_part"))
        direct=parse_voltage(c.get("operating_voltage"))
        if direct is None: direct=parse_voltage(c.get("voltage"))
        if not vals and direct is not None: vals=[direct]; (high if direct>threshold_v else low).append(direct)
        if high and not low: cluster="high_voltage"; status="resolved_high"; confidence=.95
        elif low and not high: cluster="low_voltage"; status="resolved_low"; confidence=.95
        elif high and low:
            cluster="high_voltage" if len(high)>len(low) else "low_voltage"; status="boundary"; confidence=.6
        else:
            cluster="low_voltage"; status="unknown"; confidence=.1
        rows[cid]={"component_id":cid,"cluster_id":cluster,"cluster_name":"低压簇" if cluster=="low_voltage" else "高压簇",
                   "operating_voltage_v": max(vals) if vals else None,
                   "evidence_nets": sorted(cn.get(cid,set())),"voltage_candidates_v":vals,
                   "status":status,"confidence":confidence,
                   "ground_coupling":couplers.get(cid),
                   "reason":";".join(item for n in sorted(cn.get(cid,set())) for item in ne.get(n,[])) or ("component_voltage_field" if direct is not None else "no_voltage_evidence")}
    return rows


def normalize_output(rows: Mapping[str,Mapping[str,Any]], source: str, threshold_v: float)->dict[str,Any]:
    ordered=[dict(rows[cid]) for cid in sorted(rows)]
    groups={k:[] for k in CLUSTERS}
    for row in ordered: groups[row["cluster_id"]].append(row["component_id"])
    uncertain=[r["component_id"] for r in ordered if r.get("status") in {"unknown","boundary"}]
    return {"schema":"voltage-domain-experiment-v1","method":source,"threshold_v":threshold_v,
            "clusters":[{"cluster_id":k,"cluster_name":"低压簇" if k=="low_voltage" else "高压簇","component_ids":sorted(groups[k])} for k in CLUSTERS],
            "assignments":ordered,"uncertain_component_ids":sorted(uncertain),
            "ground_coupling_links":[r["ground_coupling"] for r in ordered if r.get("ground_coupling")],
            "quality":{"unknown_count":sum(r.get("status")=="unknown" for r in ordered),"boundary_count":sum(r.get("status")=="boundary" for r in ordered),"evidence_rate":sum(bool(r.get("voltage_candidates_v")) for r in ordered)/len(ordered) if ordered else 0.0}}
