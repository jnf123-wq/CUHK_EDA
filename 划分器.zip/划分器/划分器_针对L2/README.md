# L2 综合划分流程

该目录把两个已有工程串成一条只处理 L2 的流程：

1. 第一次调用 DeepSeek，逐器件识别自身功能，写出 `device_function_annotations.json/csv`。提示词明确禁止输出网络语义和任何分组结论。
2. 使用 `划分器算法部分` 的确定性算法读取同一份原始网表，生成 `algorithm_l2_result.json`。
3. 找出算法 L2 中 `anchor` 为空的、未归入大器件域的小元件，再把它们连同功能文件、算法域结果和真实网络连接交给第二次 DeepSeek。
4. 第二次模型只在这些候选元件内部，依据功能与网络拓扑相似性建立独立辅助簇，例如去耦电容、旁路/滤波电容、RC/RL/LC 滤波、偏置/上拉电阻等。辅助簇与芯片/大器件 L2 域同级，使用 `L2-Sxxx` 编号且 `anchor=null`；不会把小元件强行并入任何芯片簇，也不会修改算法原有成员。最终结果写入 `l2_final_result.json` 和 `l2_final_assignments.csv`。

最终导出会强制校验：输入器件数、最终归属行数和唯一器件数必须一致。CSV 新增 `cluster_kind`、`function_label` 和 `cluster_type` 字段，便于区分大器件域与独立辅助功能簇。

输入支持标准 JSON 网表（`components` 数组、`nets` 数组或网络映射）和 EasyEDA `.enet`。默认算法目录为同一桌面下的 `划分器算法部分`。

## 可视化启动

双击 `启动L2综合划分器.cmd`，或执行 `python gui.py`。界面支持选择文件和目录、Dry-run、启动运行、实时日志，以及打开输出目录。主内容区和日志区都支持鼠标滚轮上下滑动，适合较小屏幕或 Windows 高 DPI 显示。

```powershell
python C:\Users\30943\Desktop\划分器\run_flow.py `
  C:\path\to\netlist.json `
  --api-key-file C:\path\to\deepseek.env `
  --out C:\path\to\l2-flow-output
```

API key 也可以放在 `DEEPSEEK_API_KEY` 环境变量中。配置文件支持 `api_key=...`、`deepseek_api_key=...`、`base_url=...` 和 `model=...`。

如果出现 `HTTP 429` 或网页标题 `Request Blocked`，说明请求被 DeepSeek 账户限额、访问频率或中间网络网关拦截。请先检查账户余额/限额和 API key 权限；如果返回的是网关网页，尝试更换网络出口，或在界面中填写可访问的兼容 API Base URL。程序会读取 `Retry-After` 并退避重试，错误详情同时保存到输出目录的 `flow_error.json`。

先检查输入、算法输出和请求内容而不调用网络时：

```powershell
python C:\Users\30943\Desktop\划分器\run_flow.py input.json --dry-run --out output
```

每次运行会保留两次模型请求的 JSON，方便审计和复现。多轮稳定性报告会按独立辅助簇的完整成员集合比较分簇稳定性。
