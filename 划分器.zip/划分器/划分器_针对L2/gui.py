#!/usr/bin/env python3
"""Tkinter launcher for the integrated L2 flow.

The window intentionally uses a scrollable canvas so the form remains usable
on small laptop screens and with Windows display scaling enabled.
"""

from __future__ import annotations

import json
import os
import queue
import subprocess
import sys
import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk


ROOT = Path(__file__).resolve().parent
FLOW = ROOT / "run_flow.py"


class ScrollableFrame(ttk.Frame):
    def __init__(self, parent, **kwargs):
        super().__init__(parent, **kwargs)
        self.canvas = tk.Canvas(self, highlightthickness=0, background="#f5f7fb")
        self.scrollbar = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.body = ttk.Frame(self.canvas, padding=(18, 16, 18, 24))
        self.window_id = self.canvas.create_window((0, 0), window=self.body, anchor="nw")
        self.canvas.configure(yscrollcommand=self.scrollbar.set)
        self.canvas.grid(row=0, column=0, sticky="nsew")
        self.scrollbar.grid(row=0, column=1, sticky="ns")
        self.rowconfigure(0, weight=1)
        self.columnconfigure(0, weight=1)
        self.body.bind("<Configure>", self._update_scrollregion)
        self.canvas.bind("<Configure>", self._fit_width)
        self.canvas.bind_all("<MouseWheel>", self._mousewheel, add="+")
        self.canvas.bind_all("<Button-4>", lambda event: self.canvas.yview_scroll(-3, "units"), add="+")
        self.canvas.bind_all("<Button-5>", lambda event: self.canvas.yview_scroll(3, "units"), add="+")

    def _update_scrollregion(self, _event=None):
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def _fit_width(self, event):
        self.canvas.itemconfigure(self.window_id, width=event.width)

    def _mousewheel(self, event):
        if event.delta:
            self.canvas.yview_scroll(int(-event.delta / 120), "units")


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("L2 综合划分器")
        self.geometry("940x760")
        self.minsize(720, 520)
        self.configure(background="#f5f7fb")
        self._queue: queue.Queue[tuple[str, str]] = queue.Queue()
        self._running = False
        self._build_style()
        self._build_ui()
        self.after(100, self._drain_queue)

    def _build_style(self):
        style = ttk.Style(self)
        try:
            style.theme_use("vista")
        except tk.TclError:
            pass
        style.configure("Title.TLabel", font=("Microsoft YaHei UI", 20, "bold"), foreground="#19324d")
        style.configure("Subtitle.TLabel", font=("Microsoft YaHei UI", 10), foreground="#5b6b7c")
        style.configure("Section.TLabel", font=("Microsoft YaHei UI", 12, "bold"), foreground="#1f4e79")
        style.configure("Run.TButton", font=("Microsoft YaHei UI", 11, "bold"), padding=(16, 8))
        style.configure("Hint.TLabel", foreground="#687789")

    def _build_ui(self):
        frame = ScrollableFrame(self)
        frame.pack(fill="both", expand=True)
        body = frame.body
        body.columnconfigure(1, weight=1)

        ttk.Label(body, text="L2 综合划分器", style="Title.TLabel").grid(row=0, column=0, columnspan=3, sticky="w")
        ttk.Label(body, text="器件功能识别 → 算法 L2 初划分 → 未归属小元件补划分", style="Subtitle.TLabel").grid(row=1, column=0, columnspan=3, sticky="w", pady=(2, 18))

        self.netlist = tk.StringVar()
        self.key_file = tk.StringVar()
        self.output = tk.StringVar(value=str(ROOT / "output"))
        self.algorithm_dir = tk.StringVar(value=str(ROOT.parent / "划分器算法部分"))
        self.base_url = tk.StringVar(value="https://api.deepseek.com/v1")
        self.model = tk.StringVar(value="deepseek-chat")
        self.timeout = tk.StringVar(value="180")
        self.temperature = tk.StringVar(value="0.0")
        self.rounds = tk.StringVar(value="1")
        self.dry_run = tk.BooleanVar(value=False)

        ttk.Label(body, text="输入与输出", style="Section.TLabel").grid(row=2, column=0, columnspan=3, sticky="w", pady=(0, 8))
        self._path_row(body, 3, "原始网表", self.netlist, self._choose_netlist, "选择 JSON 或 .enet 网表")
        self._path_row(body, 5, "API 配置文件", self.key_file, self._choose_key, "可选；也可使用 DEEPSEEK_API_KEY 环境变量")
        self._path_row(body, 7, "输出目录", self.output, self._choose_output, "保存所有中间文件和最终结果")
        self._path_row(body, 9, "算法目录", self.algorithm_dir, self._choose_algorithm, "通常为桌面的 划分器算法部分")

        ttk.Label(body, text="DeepSeek 设置", style="Section.TLabel").grid(row=11, column=0, columnspan=3, sticky="w", pady=(18, 8))
        self._entry_row(body, 12, "Base URL", self.base_url)
        self._entry_row(body, 13, "模型", self.model)
        self._entry_row(body, 14, "请求超时（秒）", self.timeout)
        self._entry_row(body, 15, "采样温度", self.temperature)
        self._entry_row(body, 16, "独立运行轮数", self.rounds)

        options = ttk.Frame(body)
        options.grid(row=17, column=0, columnspan=3, sticky="ew", pady=(16, 8))
        ttk.Checkbutton(options, text="Dry-run（不调用 DeepSeek，只生成请求和算法结果）", variable=self.dry_run).pack(side="left")
        ttk.Label(options, text="温度为 0 时更偏确定性；多轮建议 0.2–0.8。", style="Hint.TLabel").pack(side="left", padx=(16, 0))

        ttk.Label(body, text="运行日志", style="Section.TLabel").grid(row=18, column=0, columnspan=3, sticky="w", pady=(18, 8))
        log_frame = ttk.Frame(body)
        log_frame.grid(row=19, column=0, columnspan=3, sticky="nsew")
        body.rowconfigure(19, weight=1)
        self.log = tk.Text(log_frame, height=13, wrap="word", state="disabled", background="#101820", foreground="#d6e8f5", insertbackground="white", relief="flat", padx=10, pady=10)
        log_scroll = ttk.Scrollbar(log_frame, orient="vertical", command=self.log.yview)
        self.log.configure(yscrollcommand=log_scroll.set)
        self.log.grid(row=0, column=0, sticky="nsew")
        log_scroll.grid(row=0, column=1, sticky="ns")
        log_frame.rowconfigure(0, weight=1)
        log_frame.columnconfigure(0, weight=1)

        buttons = ttk.Frame(body)
        buttons.grid(row=20, column=0, columnspan=3, sticky="ew", pady=(16, 10))
        self.run_button = ttk.Button(buttons, text="开始运行", style="Run.TButton", command=self._start)
        self.run_button.pack(side="left")
        ttk.Button(buttons, text="打开输出目录", command=self._open_output).pack(side="left", padx=(10, 0))
        self.status = ttk.Label(buttons, text="等待输入", style="Hint.TLabel")
        self.status.pack(side="right")

        ttk.Label(body, text="输出包括：器件功能识别文件、算法 L2 结果、补划分请求/结果、最终 L2 CSV 和 flow_manifest.json。多轮运行时还会生成 stability_report.json 和稳定性 CSV。", style="Hint.TLabel", wraplength=820).grid(row=21, column=0, columnspan=3, sticky="w")

    def _path_row(self, parent, row, label, variable, command, hint):
        ttk.Label(parent, text=label, width=14).grid(row=row, column=0, sticky="w", pady=5)
        ttk.Entry(parent, textvariable=variable).grid(row=row, column=1, sticky="ew", pady=5, padx=(0, 8))
        ttk.Button(parent, text="浏览…", command=command).grid(row=row, column=2, pady=5)
        ttk.Label(parent, text=hint, style="Hint.TLabel").grid(row=row + 1, column=1, columnspan=2, sticky="w", pady=(0, 2))

    def _entry_row(self, parent, row, label, variable):
        ttk.Label(parent, text=label, width=14).grid(row=row, column=0, sticky="w", pady=5)
        ttk.Entry(parent, textvariable=variable).grid(row=row, column=1, columnspan=2, sticky="ew", pady=5)

    def _choose_netlist(self):
        path = filedialog.askopenfilename(title="选择原始网表", filetypes=[("网表", "*.json *.enet"), ("所有文件", "*.*")])
        if path:
            self.netlist.set(path)

    def _choose_key(self):
        path = filedialog.askopenfilename(title="选择 DeepSeek 配置文件", filetypes=[("配置文件", "*.env *.txt *.py"), ("所有文件", "*.*")])
        if path:
            self.key_file.set(path)

    def _choose_output(self):
        path = filedialog.askdirectory(title="选择输出目录")
        if path:
            self.output.set(path)

    def _choose_algorithm(self):
        path = filedialog.askdirectory(title="选择算法目录")
        if path:
            self.algorithm_dir.set(path)

    def _write_log(self, text):
        self.log.configure(state="normal")
        self.log.insert("end", text)
        self.log.see("end")
        self.log.configure(state="disabled")

    def _start(self):
        if self._running:
            return
        netlist = Path(self.netlist.get().strip())
        if not netlist.is_file():
            messagebox.showerror("缺少输入", "请选择有效的 JSON 或 .enet 原始网表。")
            return
        try:
            timeout = int(self.timeout.get().strip())
            if timeout <= 0:
                raise ValueError
        except ValueError:
            messagebox.showerror("参数错误", "请求超时必须是正整数。")
            return
        try:
            temperature = float(self.temperature.get().strip())
            rounds = int(self.rounds.get().strip())
            if not 0 <= temperature <= 2 or rounds < 1:
                raise ValueError
        except ValueError:
            messagebox.showerror("参数错误", "采样温度必须在 0 到 2 之间，独立运行轮数必须是正整数。")
            return
        output = Path(self.output.get().strip() or ROOT / "output")
        command = [sys.executable, str(FLOW), str(netlist), "--out", str(output),
                   "--algorithm-dir", self.algorithm_dir.get().strip(),
                   "--base-url", self.base_url.get().strip(), "--model", self.model.get().strip(),
                   "--timeout", str(timeout), "--temperature", str(temperature), "--rounds", str(rounds)]
        if self.key_file.get().strip():
            command.extend(["--api-key-file", self.key_file.get().strip()])
        if self.dry_run.get():
            command.append("--dry-run")
        self._running = True
        self.run_button.configure(state="disabled")
        self.status.configure(text="运行中…")
        self._write_log("\n$ " + subprocess.list2cmdline(command) + "\n\n")
        threading.Thread(target=self._run_process, args=(command,), daemon=True).start()

    def _run_process(self, command):
        try:
            process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace", bufsize=1)
            assert process.stdout is not None
            for line in process.stdout:
                self._queue.put(("log", line))
            code = process.wait()
            self._queue.put(("done", str(code)))
        except Exception as exc:
            self._queue.put(("error", str(exc)))

    def _drain_queue(self):
        try:
            while True:
                kind, value = self._queue.get_nowait()
                if kind == "log":
                    self._write_log(value)
                elif kind == "done":
                    self._running = False
                    self.run_button.configure(state="normal")
                    ok = value == "0"
                    self.status.configure(text="完成" if ok else f"失败（退出码 {value}）")
                    self._write_log(f"\n流程结束，退出码：{value}\n")
                    if ok:
                        messagebox.showinfo("运行完成", f"结果已写入：\n{Path(self.output.get()).resolve()}")
                else:
                    self._running = False
                    self.run_button.configure(state="normal")
                    self.status.configure(text="启动失败")
                    self._write_log("启动失败：" + value + "\n")
                    messagebox.showerror("启动失败", value)
        except queue.Empty:
            pass
        self.after(100, self._drain_queue)

    def _open_output(self):
        path = Path(self.output.get().strip() or ROOT / "output")
        path.mkdir(parents=True, exist_ok=True)
        os.startfile(str(path))


def main():
    app = App()
    app.mainloop()


if __name__ == "__main__":
    main()
