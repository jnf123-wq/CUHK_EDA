#!/usr/bin/env python3
"""L2-only flow: device function recognition, algorithmic L2, then completion.

The deterministic partitioner is deliberately run before the second model call.
The second call receives only components in the algorithm's unresolved
``anchor=null`` L2 domain and may attach them to an existing anchored domain.
It cannot move an already assigned component or create a new domain.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import http.client
import json
import zipfile
import os
import re
import sys
import time
from collections import Counter
from pathlib import Path
from typing import Any, Mapping
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen


ROOT = Path(__file__).resolve().parent
DEFAULT_ALGORITHM_DIR = ROOT.parent / "划分器算法部分"
PROMPT_DIR = ROOT / "prompts"

if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except (AttributeError, OSError):
        pass


def _json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, indent=2)


def save_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(_json(value) + "\n", encoding="utf-8")


def _component_kind(component: Mapping[str, Any]) -> str:
    value = str(component.get("kind", component.get("type", ""))).strip().lower()
    if value:
        aliases = {"ic": "ic_module", "controller": "controller", "chip": "ic_module"}
        return aliases.get(value, value)
    ref = str(component.get("id", component.get("ref", ""))).upper()
    return {"R": "resistor", "C": "capacitor", "L": "inductor", "D": "diode",
            "Q": "transistor", "U": "ic_module", "J": "connector"}.get(ref[:1], "other")


def _component_id(component: Mapping[str, Any]) -> str:
    value = component.get("id", component.get("ref", component.get("designator")))
    if value is None or not str(value).strip():
        raise ValueError("每个器件必须有非空 id/ref/designator")
    return str(value).strip()


def _load_easyeda(path: Path) -> tuple[dict[str, Any], dict[str, Any]]:
    raw = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(raw, Mapping) or not isinstance(raw.get("components"), Mapping):
        raise ValueError(f"不是可识别的 EasyEDA .enet 文件：{path}")
    components: list[dict[str, Any]] = []
    nets: dict[str, list[dict[str, str]]] = {}
    seen: dict[str, int] = {}
    for key, item in raw["components"].items():
        if not isinstance(item, Mapping):
            continue
        props = item.get("props") if isinstance(item.get("props"), Mapping) else {}
        ref = str(props.get("Designator") or key).strip()
        seen[ref] = seen.get(ref, 0) + 1
        cid = ref if seen[ref] == 1 else f"{ref}__dup{seen[ref]}"
        value = str(props.get("Value") or props.get("Name") or props.get("DeviceName") or "")
        pins: list[dict[str, str]] = []
        pinmap = item.get("pinInfoMap") or {}
        pin_items = pinmap.items() if isinstance(pinmap, Mapping) else enumerate(pinmap)
        for pin_key, pin in pin_items:
            if not isinstance(pin, Mapping):
                continue
            number = str(pin.get("number", pin_key))
            name = str(pin.get("name", ""))
            net = str(pin.get("net") or "").strip()
            pins.append({"id": number, "name": name, "net": net})
            if net:
                nets.setdefault(net, []).append({"component": cid, "pin": number, "name": name})
        components.append({"id": cid, "ref": ref, "value": value,
                           "part": str(props.get("Manufacturer Part") or props.get("DeviceName") or props.get("Name") or ""),
                           "kind": _component_kind({"id": ref}), "pins": pins,
                           "footprint": str(props.get("FootprintName") or props.get("Supplier Footprint") or "")})
    if not components:
        raise ValueError(".enet 中没有器件")
    net_rows = [{"id": name, "pins": pins} for name, pins in sorted(nets.items())]
    netlist = {"schema": "device-function-netlist-v1", "name": path.stem,
               "source_format": "easyeda-enet", "components": sorted(components, key=lambda x: x["id"]),
               "nets": net_rows}
    return netlist, _to_topology(netlist, source={"format": "enet", "schematic": str(path)})


def _standard_netlist(path: Path) -> tuple[dict[str, Any], dict[str, Any]]:
    raw = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(raw, Mapping) or not isinstance(raw.get("components"), list):
        raise ValueError("标准 JSON 网表必须包含 components 数组")
    components: list[dict[str, Any]] = []
    ids: set[str] = set()
    for raw_component in raw["components"]:
        if not isinstance(raw_component, Mapping):
            raise ValueError("components 中只能包含对象")
        cid = _component_id(raw_component)
        if cid in ids:
            raise ValueError(f"器件位号重复：{cid}")
        ids.add(cid)
        item = dict(raw_component)
        item["id"] = cid
        item["kind"] = _component_kind(item)
        item.setdefault("value", item.get("name", item.get("part", "")))
        components.append(item)
    nets: list[dict[str, Any]] = []
    raw_nets = raw.get("nets", [])
    if isinstance(raw_nets, Mapping):
        raw_nets = [{"id": name, "pins": endpoints} for name, endpoints in raw_nets.items()]
    if not isinstance(raw_nets, list):
        raise ValueError("nets 必须是数组或网络名到端点数组的对象")
    for raw_net in raw_nets:
        if not isinstance(raw_net, Mapping):
            raise ValueError("nets 中只能包含对象")
        name = str(raw_net.get("id", raw_net.get("name", ""))).strip()
        if not name:
            raise ValueError("每个网络必须有 id/name")
        endpoints = raw_net.get("pins", raw_net.get("components", raw_net.get("endpoints", [])))
        if not isinstance(endpoints, list):
            raise ValueError(f"网络 {name} 的端点必须是数组")
        pins: list[dict[str, str]] = []
        for endpoint in endpoints:
            if isinstance(endpoint, Mapping):
                ref = endpoint.get("component", endpoint.get("ref", endpoint.get("designator", endpoint.get("c"))))
                pin = endpoint.get("pin", endpoint.get("pad", endpoint.get("number", "")))
                pin_name = endpoint.get("name", endpoint.get("pin_name", ""))
            else:
                ref, pin, pin_name = endpoint, "", ""
            if ref is None:
                continue
            ref = str(ref).split(".", 1)[0].split(":", 1)[0]
            if ref not in ids:
                raise ValueError(f"网络 {name} 引用了未知器件：{ref}")
            pins.append({"component": ref, "pin": str(pin or ""), "name": str(pin_name or "")})
        nets.append({"id": name, "pins": pins})
    netlist = {"schema": "device-function-netlist-v1", "name": str(raw.get("name", path.stem)),
               "source_format": "standard-json", "components": sorted(components, key=lambda x: x["id"]),
               "nets": nets}
    return netlist, _to_topology(netlist, source={"format": "standard-json", "path": str(path)})


def _to_topology(netlist: Mapping[str, Any], *, source: Mapping[str, Any]) -> dict[str, Any]:
    components = []
    for item in netlist.get("components", []):
        cid = str(item["id"])
        components.append({"designator": cid, "kind": _component_kind(item),
                           "name": str(item.get("value", item.get("name", item.get("part", "")))),
                           "value": str(item.get("value", "")), "part": str(item.get("part", "")),
                           "pins": item.get("pins", [])})
    nets: dict[str, list[dict[str, str]]] = {}
    for net in netlist.get("nets", []):
        name = str(net["id"])
        nets[name] = [{"c": str(pin["component"]), "pin": str(pin.get("pin", "")),
                       "name": str(pin.get("name", ""))} for pin in net.get("pins", [])]
    return {"schema": "moduplace-topology-v1", "source": dict(source),
            "components": components, "nets": nets}


def load_inputs(path: Path) -> tuple[dict[str, Any], dict[str, Any]]:
    if path.suffix.lower() == ".enet":
        return _load_easyeda(path)
    if path.suffix.lower() == ".epro2":
        return _load_epro2(path)
    return _standard_netlist(path)


def _load_epro2(path: Path) -> tuple[dict[str, Any], dict[str, Any]]:
    """Read EasyEDA Pro's zipped project and normalize the board's component/net records."""
    try:
        with zipfile.ZipFile(path) as archive:
            candidates = [name for name in archive.namelist() if name.lower().endswith(".epru")]
            if not candidates:
                raise ValueError(".epro2 压缩包中没有 .epru 项目数据")
            text = archive.read(candidates[0]).decode("utf-8-sig")
    except (OSError, zipfile.BadZipFile, UnicodeDecodeError) as exc:
        raise ValueError(f"无法读取 EasyEDA Pro .epro2 文件：{exc}") from exc

    # epru is an append-only stream of header||payload| records. Keep the latest
    # record for each entity because later tickets supersede earlier versions.
    records: dict[tuple[str, str], dict[str, Any]] = {}
    for match in re.finditer(r'\{"type":"([A-Z_]+)"[^\n]*?\}\|\|([^|]*)\|', text):
        try:
            header, payload = json.loads(match.group(0).split("||", 1)[0]), json.loads(match.group(2))
        except (ValueError, TypeError):
            continue
        kind, entity_id = header.get("type"), str(header.get("id", ""))
        if kind and isinstance(payload, dict) and entity_id:
            records[(kind, entity_id)] = payload

    attrs: dict[str, dict[str, str]] = {}
    for (kind, entity_id), payload in records.items():
        if kind == "ATTR" and payload.get("parentId"):
            attrs.setdefault(str(payload["parentId"]), {})[str(payload.get("key", ""))] = str(payload.get("value") or "")
    components_by_ref: dict[str, dict[str, Any]] = {}
    entity_ids: dict[str, str] = {}
    for (kind, entity_id), payload in records.items():
        if kind != "COMPONENT":
            continue
        properties = attrs.get(entity_id, {})
        ref = properties.get("Designator", "").strip()
        if not ref or ref.endswith("?"):
            continue
        entity_ids[entity_id] = ref
        part = str(payload.get("partId", ""))
        item = {"id": ref, "ref": ref, "value": properties.get("Name", part),
                "part": part, "kind": _component_kind({"id": ref}), "pins": [], "footprint": ""}
        # Board and linked-library records can repeat the same designator. Keep
        # one component row, preferring the record with actual part metadata.
        if ref not in components_by_ref or (part and not components_by_ref[ref].get("part")):
            components_by_ref[ref] = item
    components = list(components_by_ref.values())
    if not components:
        raise ValueError(".epro2 中未找到带有效 Designator 的 PCB 器件")

    nets: dict[str, list[dict[str, str]]] = {}
    for (kind, entity_id), payload in records.items():
        if kind != "PAD_NET":
            continue
        try:
            _, component_entity, pin, _ = json.loads(entity_id)
        except (ValueError, TypeError):
            continue
        ref = entity_ids.get(str(component_entity))
        net_name = str(payload.get("padNet") or "").strip()
        if ref and net_name:
            nets.setdefault(net_name, []).append({"component": ref, "pin": str(pin), "name": ""})
    netlist = {"schema": "device-function-netlist-v1", "name": path.stem,
               "source_format": "easyeda-pro-epro2", "components": sorted(components, key=lambda x: x["id"]),
               "nets": [{"id": name, "pins": pins} for name, pins in sorted(nets.items())]}
    return netlist, _to_topology(netlist, source={"format": "epro2", "path": str(path)})


def _read_key_file(path: Path | None) -> dict[str, str]:
    if not path:
        return {}
    text = path.read_text(encoding="utf-8-sig")
    result: dict[str, str] = {}
    aliases = {
        "模型名": "model", "模型": "model", "model_name": "model", "model": "model",
        "base url": "base_url", "base_url": "base_url", "url": "base_url", "接口地址": "base_url",
        "api": "api_key", "api key": "api_key", "api_key": "api_key", "apikey": "api_key",
        "key": "api_key", "token": "api_key", "deepseek_api_key": "deepseek_api_key",
    }
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        normalized = line.replace("：", ":")
        if "=" in normalized:
            key, value = normalized.split("=", 1)
        elif ":" in normalized:
            key, value = normalized.split(":", 1)
        else:
            continue
        key = key.strip().lower()
        value = value.split("#", 1)[0].strip().strip("'\"")
        mapped = aliases.get(key)
        if mapped and value:
            result[mapped] = value
    if "base_url" not in result:
        match = re.search(r"https?://[^\s'\"]+", text)
        if match:
            result["base_url"] = match.group(0).rstrip("，,。")
    if "model" not in result:
        match = re.search(r"(?:模型名|模型|model(?:_name)?)\s*[:：=]\s*([^\s,，]+)", text, re.I)
        if match:
            result["model"] = match.group(1).strip()
    if "api_key" not in result:
        match = re.search(r"(?:API(?:\s*Key)?|api_key|apikey)\s*[:：=]\s*([^\s]+)", text, re.I)
        if match:
            result["api_key"] = match.group(1).strip().strip("'\"")
    if not result and text.strip() and "=" not in text and ":" not in text:
        result["api_key"] = text.strip()
    return result


class DeepSeekClient:
    def __init__(self, api_key: str, *, base_url: str, model: str, timeout: int = 180,
                 retries: int = 3, temperature: float = 0.0):
        if not api_key:
            raise ValueError("未找到 DeepSeek API key，请设置 DEEPSEEK_API_KEY 或 --api-key-file")
        self.api_key, self.base_url, self.model = api_key, base_url.rstrip("/"), model
        self.timeout, self.retries, self.temperature = timeout, retries, temperature

    @staticmethod
    def _decode(content: Any) -> dict[str, Any]:
        if isinstance(content, Mapping):
            return dict(content)
        if isinstance(content, list):
            content = "".join(
                str(x.get("text", x.get("content", "")))
                for x in content if isinstance(x, Mapping)
            )
        text = str(content or "").strip()
        if not text:
            raise ValueError("DeepSeek 返回内容为空")
        fenced = re.search(r"```(?:json)?\s*([\s\S]*?)\s*```", text, flags=re.I)
        candidate = fenced.group(1).strip() if fenced else text
        try:
            result = json.loads(candidate)
        except json.JSONDecodeError as first_error:
            # Some compatible gateways/models prepend a short explanation or
            # append a trailing sentence even with response_format=json_object.
            # Decode the first complete JSON object in that response.
            start = candidate.find("{")
            if start < 0:
                raise first_error
            try:
                result, _ = json.JSONDecoder().raw_decode(candidate[start:])
            except json.JSONDecodeError:
                raise first_error
        if not isinstance(result, dict):
            raise ValueError("DeepSeek 返回的根对象必须是 JSON object")
        return result

    def ask(self, system: str, data: Mapping[str, Any]) -> dict[str, Any]:
        disable_thinking = "deepseek" in self.model.lower() and any(
            word in self.model.lower() for word in ("v4", "reason", "pro")
        )
        max_tokens = 16384
        last: Exception | None = None
        for attempt in range(self.retries):
            request_payload = {
                "model": self.model, "temperature": self.temperature, "max_tokens": max_tokens,
                "response_format": {"type": "json_object"},
                "messages": [{"role": "system", "content": system},
                             {"role": "user", "content": json.dumps(data, ensure_ascii=False)}],
            }
            if disable_thinking:
                request_payload["thinking"] = {"type": "disabled"}
            body = json.dumps(request_payload, ensure_ascii=False).encode("utf-8")
            request = Request(self.base_url + "/chat/completions", data=body, method="POST",
                               headers={"Authorization": "Bearer " + self.api_key,
                                        "Content-Type": "application/json"})
            try:
                with urlopen(request, timeout=self.timeout) as response:
                    payload = json.loads(response.read().decode("utf-8-sig"))
                content = payload["choices"][0]["message"]["content"]
                return self._decode(content)
            except HTTPError as exc:
                detail = exc.read().decode("utf-8", errors="replace")
                compact = re.sub(r"<[^>]+>", " ", detail)
                compact = re.sub(r"\s+", " ", compact).strip()[:500]
                retry_after = exc.headers.get("Retry-After", "")
                if exc.code == 429:
                    last = RuntimeError(
                        "HTTP 429 请求被 DeepSeek 或中间网关限流/拦截"
                        + (f"（Retry-After={retry_after}s）" if retry_after else "")
                        + (f"：{compact}" if compact else "")
                    )
                    if attempt + 1 < self.retries:
                        try:
                            delay = min(30.0, max(1.0, float(retry_after))) if retry_after else min(8.0, 1.5 ** attempt)
                        except ValueError:
                            delay = min(8.0, 1.5 ** attempt)
                        time.sleep(delay)
                        continue
                else:
                    last = RuntimeError(f"HTTP {exc.code}: {compact or detail[:500]}")
                if exc.code == 400 and disable_thinking:
                    # Older OpenAI-compatible gateways reject the DeepSeek
                    # thinking switch; retry once with the legacy payload.
                    disable_thinking = False
                    continue
                if exc.code == 400 and max_tokens > 8192:
                    # Older gateways cap the output at 8192 tokens.
                    max_tokens = 8192
                    continue
                if exc.code in {400, 401, 403}:
                    break
            except (http.client.HTTPException, URLError, TimeoutError, ConnectionError,
                    KeyError, IndexError, json.JSONDecodeError, ValueError) as exc:
                # Some gateways close a chunked response before sending the
                # terminating chunk. urllib raises IncompleteRead/HTTPException
                # while reading the body, not HTTPError, so treat it as a
                # transient transport failure and retry the same request.
                last = RuntimeError(f"HTTP 响应传输中断（第 {attempt + 1}/{self.retries} 次尝试）：{exc}")
            if attempt + 1 < self.retries:
                time.sleep(0.7 * (attempt + 1))
        if isinstance(last, RuntimeError) and "HTTP 429" in str(last):
            raise RuntimeError(
                f"{last}。请检查 DeepSeek 账户余额/限额、API key 权限和请求频率；"
                "若返回页面标题为 Request Blocked，请更换网络出口或在 --base-url 中使用可访问的兼容代理。"
            ) from last
        raise RuntimeError(f"DeepSeek 请求失败：{last}") from last


def _ask_with_json_repair(client: DeepSeekClient, system: str,
                          request: Mapping[str, Any]) -> dict[str, Any]:
    """Retry a model response once when the gateway returned malformed JSON."""
    try:
        return client.ask(system, request)
    except RuntimeError as exc:
        message = str(exc)
        if not any(marker in message for marker in ("JSON", "Expecting value", "Extra data", "Unterminated")):
            raise
        repair_request = {
            **dict(request),
            "repair_instruction": (
                "上一轮响应无法解析为 JSON。请只返回一个完整、合法的 JSON object，"
                "不要 Markdown、解释文字、代码围栏或尾随文本；保持每条字段简短，"
                "并完整覆盖请求中的全部器件。"
            ),
        }
        return client.ask(system, repair_request)


def _annotation_rows(result: Mapping[str, Any], components: list[Mapping[str, Any]]) -> list[dict[str, Any]]:
    raw = result.get("annotations", result.get("components", result.get("assignments")))
    if isinstance(raw, Mapping):
        raw = [dict(value, component_id=key) for key, value in raw.items() if isinstance(value, Mapping)]
    if not isinstance(raw, list):
        raise ValueError("器件功能识别结果缺少 annotations 数组")
    known = {str(c["id"]) for c in components}
    rows: dict[str, dict[str, Any]] = {}
    for item in raw:
        if not isinstance(item, Mapping):
            raise ValueError("每条器件功能识别结果必须是对象")
        cid = str(item.get("component_id", item.get("id", item.get("L0_Device", "")))).strip()
        if cid not in known:
            raise ValueError(f"功能识别结果包含未知器件：{cid}")
        if cid in rows:
            raise ValueError(f"功能识别结果重复器件：{cid}")
        category = str(item.get("functional_category", item.get("功能类别", item.get("category", "")))).strip()
        description = str(item.get("function_description", item.get("功能说明", item.get("description", "")))).strip()
        if not category or not description:
            raise ValueError(f"{cid} 缺少功能类别或功能说明")
        try:
            confidence = float(item.get("confidence", item.get("置信度", 0)))
        except (TypeError, ValueError) as exc:
            raise ValueError(f"{cid} 的置信度不是数字") from exc
        if not 0 <= confidence <= 1:
            raise ValueError(f"{cid} 的置信度必须在 0 到 1 之间")
        rows[cid] = {"component_id": cid, "component_name": str(item.get("component_name", item.get("器件名称", ""))),
                     "functional_category": category, "function_description": description,
                     "evidence": str(item.get("evidence", item.get("识别依据", ""))),
                     "confidence": confidence, "status": "recognized"}
    missing = sorted(known - set(rows))
    if missing:
        raise ValueError("功能识别结果遗漏器件：" + ", ".join(missing))
    return [rows[cid] for cid in sorted(rows)]


def _is_major(component: Mapping[str, Any]) -> bool:
    kind = _component_kind(component).lower()
    ref = str(component.get("id", "")).upper()
    return kind in {"ic_module", "mcu", "power_module", "driver", "processor", "fpga", "controller"} or ref.startswith(("U", "IC"))


def _extract_domains(algorithm_result: Mapping[str, Any], component_rows: list[Mapping[str, Any]]) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[str], list[str], list[str]]:
    partition = algorithm_result.get("partition", {})
    domains = partition.get("l2_domains") or partition.get("l1_domains") or partition.get("domains") or []
    if not isinstance(domains, list):
        raise ValueError("算法结果缺少 partition.l2_domains 数组")
    refs = {str(c["id"]) for c in component_rows}
    assigned: set[str] = set()
    all_domains: list[dict[str, Any]] = []
    anchored: list[dict[str, Any]] = []
    unresolved_domains: list[dict[str, Any]] = []
    unresolved: list[str] = []
    for raw in domains:
        if not isinstance(raw, Mapping):
            continue
        members = sorted({str(x) for x in raw.get("members", []) if str(x) in refs})
        domain = dict(raw)
        domain["members"] = members
        all_domains.append(domain)
        anchor = raw.get("anchor")
        if anchor:
            anchored.append(domain)
            assigned.update(members)
        else:
            unresolved_domains.append(domain)
            unresolved.extend(members)
    unresolved.extend(sorted(refs - assigned - set(unresolved)))
    # The algorithm normally emits an anchor-null fallback domain. If an
    # older algorithm result omitted it, materialize one so final export still
    # has exactly one row for every input component.
    represented_refs = {ref for domain in all_domains for ref in domain.get("members", [])}
    missing_refs = sorted(refs - represented_refs)
    if missing_refs:
        fallback = {"id": "L2-UNRESOLVED", "level": "L2", "anchor": None,
                    "members": missing_refs,
                    "assignment_reason": "missing_from_algorithm_domain"}
        all_domains.append(fallback)
        unresolved_domains.append(fallback)
        unresolved.extend(missing_refs)
    major_refs = {str(c["id"]) for c in component_rows if _is_major(c)}
    unresolved_small = sorted(set(unresolved) - major_refs)
    # There is no meaningful completion target when the algorithm found no
    # anchored large-device domain. Keep these parts auditable but do not make
    # a model request that can only invent a domain.
    eligible = unresolved_small if anchored else []
    no_target_small = [] if anchored else unresolved_small
    excluded_major = sorted(set(unresolved) & major_refs)
    return all_domains, anchored, eligible, excluded_major, no_target_small


def _completion_groups(result: Mapping[str, Any], eligible: list[str], net_names: set[str]) -> list[dict[str, Any]]:
    raw = result.get("clusters", [])
    if not isinstance(raw, list):
        raise ValueError("补划分结果缺少 clusters 数组")
    eligible_set = set(eligible)
    groups: list[dict[str, Any]] = []
    seen: set[str] = set()
    for item in raw:
        if not isinstance(item, Mapping):
            continue
        members = item.get("component_ids", item.get("members", []))
        if not isinstance(members, list):
            continue
        listed_ids = [str(cid).strip() for cid in members if str(cid).strip()]
        duplicate_ids = sorted(cid for cid in set(listed_ids) if listed_ids.count(cid) > 1 or cid in seen)
        if duplicate_ids:
            raise ValueError("补划分结果存在重复器件：" + ", ".join(duplicate_ids))
        unknown_ids = sorted(set(listed_ids) - eligible_set)
        if unknown_ids:
            raise ValueError("补划分结果包含非候选器件：" + ", ".join(unknown_ids))
        member_ids = sorted(set(listed_ids))
        if not member_ids:
            continue
        seen.update(member_ids)
        evidence = item.get("evidence_nets", [])
        if isinstance(evidence, str):
            evidence = [evidence]
        try:
            confidence = max(0.0, min(1.0, float(item.get("confidence", 0))))
        except (TypeError, ValueError):
            confidence = 0.0
        groups.append({"component_ids": member_ids,
                       "function_label": str(item.get("function_label", item.get("name", "辅助元件簇"))).strip() or "辅助元件簇",
                       "cluster_type": str(item.get("cluster_type", "other_auxiliary")).strip() or "other_auxiliary",
                       "reason": str(item.get("reason", "")),
                       "evidence_nets": sorted({str(x) for x in (evidence or []) if str(x) in net_names}),
                       "confidence": confidence, "source": "deepseek_function_topology_clustering"})
    missing = sorted(eligible_set - seen)
    if missing:
        raise ValueError("补划分结果未覆盖全部候选器件：" + ", ".join(missing))
    # Canonical order makes cluster IDs stable across repeated runs when the
    # model returns the same grouping in a different JSON order.
    groups.sort(key=lambda group: tuple(group["component_ids"]))
    return groups


def _cluster_domains(groups: list[Mapping[str, Any]]) -> list[dict[str, Any]]:
    domains: list[dict[str, Any]] = []
    for index, group in enumerate(groups, 1):
        domains.append({"id": f"L2-S{index:03d}", "level": "L2", "anchor": None,
                        "cluster_kind": "independent_auxiliary_function_cluster",
                        "function_label": group["function_label"], "cluster_type": group["cluster_type"],
                        "members": list(group["component_ids"]), "assignment_reason": group["reason"],
                        "evidence_nets": list(group["evidence_nets"]), "confidence": group["confidence"],
                        "source": group["source"]})
    return domains


def _group_assignments(groups: list[Mapping[str, Any]]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for domain in _cluster_domains(groups):
        for cid in domain["members"]:
            rows.append({"component_id": cid, "l2_id": domain["id"],
                         "reason": domain["assignment_reason"], "evidence_nets": domain["evidence_nets"],
                         "confidence": domain["confidence"], "assignment_mode": domain["cluster_type"],
                         "function_label": domain["function_label"], "source": domain["source"]})
    return rows


def _write_annotations_csv(path: Path, rows: list[Mapping[str, Any]]) -> None:
    fields = ["component_id", "component_name", "functional_category", "function_description", "evidence", "confidence", "status"]
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader(); writer.writerows({key: row.get(key, "") for key in fields} for row in rows)


def _write_assignments_csv(path: Path, domains: list[Mapping[str, Any]], completion: list[Mapping[str, Any]]) -> None:
    completion_by_ref = {row["component_id"]: row for row in completion}
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        fields = ["l2_id", "anchor", "cluster_kind", "function_label", "cluster_type", "component_id", "assignment_source", "assignment_reason", "assignment_mode", "evidence_nets", "confidence"]
        writer = csv.DictWriter(handle, fieldnames=fields); writer.writeheader()
        for domain in domains:
            for ref in domain.get("members", []):
                row = completion_by_ref.get(ref)
                writer.writerow({"l2_id": domain.get("id", ""), "anchor": domain.get("anchor", ""),
                                 "cluster_kind": domain.get("cluster_kind", "major_device_domain"),
                                 "function_label": domain.get("function_label", ""),
                                 "cluster_type": domain.get("cluster_type", ""),
                                 "component_id": ref,
                                 "assignment_source": row["source"] if row else "algorithm_l2",
                                 "assignment_reason": row["reason"] if row else domain.get("assignment_reason", ""),
                                 "assignment_mode": row.get("assignment_mode", "") if row else "algorithm_l2",
                                 "evidence_nets": ";".join(row["evidence_nets"]) if row else "",
                                 "confidence": row["confidence"] if row else ""})


def run_flow(args: argparse.Namespace) -> dict[str, Any]:
    temperature = float(getattr(args, "temperature", 0.0))
    input_path = Path(args.netlist).resolve()
    out = Path(args.out).resolve(); out.mkdir(parents=True, exist_ok=True)
    netlist, topology = load_inputs(input_path)
    save_json(out / "normalized_netlist.json", netlist)
    save_json(out / "algorithm_topology.json", topology)
    digest = hashlib.sha256(json.dumps(netlist, ensure_ascii=False, sort_keys=True).encode()).hexdigest()

    config = _read_key_file(Path(args.api_key_file) if args.api_key_file else None)
    api_key = os.getenv("DEEPSEEK_API_KEY") or config.get("api_key") or config.get("deepseek_api_key") or config.get("key") or config.get("token")
    base_url = args.base_url or os.getenv("DEEPSEEK_BASE_URL") or config.get("base_url") or "https://api.deepseek.com/v1"
    model = args.model or os.getenv("DEEPSEEK_MODEL") or config.get("model") or "deepseek-chat"
    client = None if args.dry_run else DeepSeekClient(api_key, base_url=base_url, model=model,
                                                       timeout=args.timeout, temperature=temperature)

    function_prompt = (PROMPT_DIR / "device_function_system.txt").read_text(encoding="utf-8")
    function_request = {"task": "device_function_recognition", "netlist": netlist,
                        "output_contract": {"annotations": [{"component_id": "", "functional_category": "", "function_description": "", "evidence": "", "confidence": 0.0}]}}
    save_json(out / "device_function_request.json", function_request)
    if args.dry_run:
        annotations = [{"component_id": str(c["id"]), "component_name": str(c.get("value", "")),
                        "functional_category": "待识别", "function_description": "dry-run 未调用模型",
                        "evidence": "", "confidence": 0.0, "status": "not_called"} for c in netlist["components"]]
        function_raw = {"status": "dry_run"}
    else:
        function_raw = _ask_with_json_repair(client, function_prompt, function_request)
        try:
            annotations = _annotation_rows(function_raw, netlist["components"])
        except ValueError as first_error:
            repair_request = {**function_request, "repair_instruction": str(first_error) + "；请严格输出全部器件且每个器件一条记录。"}
            function_raw = _ask_with_json_repair(client, function_prompt, repair_request)
            annotations = _annotation_rows(function_raw, netlist["components"])
    annotation_payload = {"schema": "device-functional-annotations-v1",
                          "input_sha256": digest, "annotations": annotations, "raw_response": function_raw}
    save_json(out / "device_function_annotations.json", annotation_payload)
    # Keep the established artifact name from the standalone function-labeling
    # flow as an alias, so downstream scripts can consume either flow.
    save_json(out / "device_annotations.json", annotation_payload)
    _write_annotations_csv(out / "device_function_annotations.csv", annotations)
    _write_annotations_csv(out / "device_annotations.csv", annotations)

    algorithm_dir = Path(args.algorithm_dir).resolve()
    sys.path.insert(0, str(algorithm_dir))
    try:
        from partitioner.l1_partition import run as algorithm_run, validate_topology
    except ImportError as exc:
        raise RuntimeError(f"无法导入算法目录 {algorithm_dir}：{exc}") from exc
    validate_topology(topology)
    algorithm_result = algorithm_run(topology, project_id=netlist.get("name"),
                                     partition_mode="hierarchical", unresolved_llm=False,
                                     learn_soft_constraints=False)
    save_json(out / "algorithm_l2_result.json", algorithm_result)
    domains, target_domains, eligible, excluded_major, no_target_small = _extract_domains(algorithm_result, netlist["components"])
    domain_ids = {str(d.get("id")) for d in target_domains}
    all_net_names = {str(n["id"]) for n in netlist["nets"]}
    completion_request = {"task": "small_component_l2_completion", "eligible_component_ids": eligible,
                          "components": [c for c in netlist["components"] if str(c["id"]) in set(eligible)],
                          # Keep the complete first-stage function file in the
                          # second request; the eligible subset is repeated so
                          # the model cannot mistake its scope.
                          "function_annotations": annotations,
                          "eligible_function_annotations": [a for a in annotations if a["component_id"] in set(eligible)],
                          "network_connectivity": [n for n in netlist["nets"] if any(p["component"] in set(eligible) for p in n["pins"])],
                          "algorithm_l2_result": algorithm_result.get("partition", {}),
                          "algorithm_l2_domains": target_domains,
                          "constraints": {"existing_major_l2_ids": sorted(domain_ids), "preserve_existing_major_domains": True,
                                          "do_not_move_existing_members": True, "require_full_coverage": True,
                                          "create_independent_auxiliary_clusters": True,
                                          "must_not_assign_to_major_device_domains": True}}
    save_json(out / "small_component_completion_request.json", completion_request)
    if eligible and not args.dry_run:
        completion_system = (PROMPT_DIR / "small_component_completion_system.txt").read_text(encoding="utf-8")
        completion_raw = _ask_with_json_repair(client, completion_system, completion_request)
        try:
            groups = _completion_groups(completion_raw, eligible, all_net_names)
        except ValueError as first_error:
            repair_request = {**completion_request, "repair_instruction":
                              str(first_error) + "；请修正 clusters，必须覆盖 eligible_component_ids 中的全部器件且每个器件只出现一次，"
                              "必须输出 clusters，不得输出大器件域归属或 skipped_component_ids。"}
            completion_raw = _ask_with_json_repair(client, completion_system, repair_request)
            groups = _completion_groups(completion_raw, eligible, all_net_names)
        completion = _group_assignments(groups)
        auxiliary_domains = _cluster_domains(groups)
    else:
        completion_raw = {"status": "dry_run" if args.dry_run else "not_needed"}
        completion = []
        auxiliary_domains = []

    # Start from every algorithm domain, including anchor-null unresolved
    # domains. A completed move must be removed from its old fallback domain
    # before being added to the selected anchored domain.
    # Supplementary function/topology clusters are peer L2 domains. They do
    # not inherit an IC anchor. Remove only eligible parts from the algorithm's
    # anchor-null holding domain; anchored major domains remain untouched.
    completed_refs = {row["component_id"] for row in completion}
    final_domains = [dict(d, members=[ref for ref in d.get("members", [])
                                      if str(d.get("anchor") or "") or str(ref) not in completed_refs])
                     for d in domains] + auxiliary_domains
    expected_refs = {str(c["id"]) for c in netlist["components"]}
    final_refs = [str(ref) for domain in final_domains for ref in domain.get("members", [])]
    missing_refs = sorted(expected_refs - set(final_refs))
    extra_refs = sorted(set(final_refs) - expected_refs)
    duplicate_refs = sorted(ref for ref in set(final_refs) if final_refs.count(ref) > 1)
    if missing_refs or extra_refs or duplicate_refs:
        raise RuntimeError(
            "最终 L2 归属完整性校验失败："
            f"missing={missing_refs[:20]}, extra={extra_refs[:20]}, duplicate={duplicate_refs[:20]}"
        )
    unresolved_after = sorted((set(eligible) - {row["component_id"] for row in completion}) | set(no_target_small))
    final_result = {"schema": "l2-integrated-flow-v1", "input_sha256": digest,
                    "source": str(input_path), "domains": final_domains,
                    "completion_assignments": completion, "still_unassigned_small_components": unresolved_after,
                    "small_components_without_completion_target": no_target_small,
                    "independent_auxiliary_clusters": auxiliary_domains,
                    "excluded_unassigned_major_components": excluded_major,
                    "algorithm_result": algorithm_result, "completion_raw_response": completion_raw}
    save_json(out / "l2_final_result.json", final_result)
    _write_assignments_csv(out / "l2_final_assignments.csv", final_domains, completion)
    manifest = {"schema": "l2-integrated-flow-manifest-v1", "status": "completed", "input": str(input_path),
                "input_sha256": digest, "model": {"provider": "deepseek", "name": model, "base_url": base_url,
                "temperature": temperature, "dry_run": bool(args.dry_run)}, "counts": {"components": len(netlist["components"]),
                "l2_domains": len(final_domains), "algorithm_l2_domains": len(domains),
                "anchored_l2_domains": len(target_domains), "independent_auxiliary_clusters": len(auxiliary_domains),
                "eligible_small_components": len(eligible),
                "completion_assignments": len(completion), "still_unassigned_small_components": len(unresolved_after),
                "final_assignment_count": len(final_refs), "final_unique_assignment_count": len(set(final_refs))},
                "artifacts": ["normalized_netlist.json", "algorithm_topology.json", "device_function_annotations.json",
                              "device_function_annotations.csv", "device_annotations.json", "device_annotations.csv",
                              "algorithm_l2_result.json", "small_component_completion_request.json",
                              "l2_final_result.json", "l2_final_assignments.csv"]}
    save_json(out / "flow_manifest.json", manifest)
    return manifest


def _round_assignment_map(result: Mapping[str, Any]) -> dict[str, str]:
    mapping: dict[str, str] = {}
    for domain in result.get("domains", []):
        if not isinstance(domain, Mapping):
            continue
        did = str(domain.get("id", ""))
        if domain.get("cluster_kind") == "independent_auxiliary_function_cluster":
            did = "AUX:" + "|".join(sorted(str(ref) for ref in domain.get("members", [])))
        for ref in domain.get("members", []):
            mapping[str(ref)] = did
    return mapping


def _round_function_map(result: Mapping[str, Any]) -> dict[str, str]:
    mapping: dict[str, str] = {}
    for row in result.get("annotations", []):
        if isinstance(row, Mapping):
            mapping[str(row.get("component_id", ""))] = str(row.get("functional_category", ""))
    return mapping


def run_multi_round(args: argparse.Namespace) -> dict[str, Any]:
    """Run independent flow repetitions and summarize assignment stability."""
    root_out = Path(args.out).resolve()
    root_out.mkdir(parents=True, exist_ok=True)
    requested = int(args.rounds)
    temperature = float(getattr(args, "temperature", 0.0))
    width = max(2, len(str(requested)))
    manifests: list[dict[str, Any]] = []
    round_data: list[dict[str, Any]] = []
    errors: list[dict[str, Any]] = []
    for index in range(1, requested + 1):
        round_dir = root_out / f"round_{index:0{width}d}"
        round_args = argparse.Namespace(**vars(args))
        round_args.out = str(round_dir)
        round_args.rounds = 1
        try:
            manifest = run_flow(round_args)
            result_path = round_dir / "l2_final_result.json"
            annotation_path = round_dir / "device_function_annotations.json"
            result = json.loads(result_path.read_text(encoding="utf-8"))
            annotation_result = json.loads(annotation_path.read_text(encoding="utf-8"))
            manifests.append(manifest)
            round_data.append({"round": index, "result": result, "annotations": annotation_result})
        except (OSError, ValueError, RuntimeError, json.JSONDecodeError) as exc:
            errors.append({"round": index, "error_type": type(exc).__name__, "error": str(exc)})

    if not round_data:
        raise RuntimeError(f"所有多轮运行均失败：{errors}")

    rounds = [item["round"] for item in round_data]
    assignment_maps = [_round_assignment_map(item["result"]) for item in round_data]
    function_maps = [_round_function_map(item["annotations"]) for item in round_data]
    component_ids = sorted(set().union(*(mapping.keys() for mapping in assignment_maps)))
    assignment_rows: list[dict[str, Any]] = []
    for cid in component_ids:
        values = [mapping.get(cid, "") for mapping in assignment_maps]
        votes = Counter(value for value in values if value)
        majority = sorted(votes.items(), key=lambda item: (-item[1], item[0]))[0] if votes else ("", 0)
        assignment_rows.append({"component_id": cid, "round_assignments": values,
                                "votes": dict(sorted(votes.items())), "majority_l2_id": majority[0],
                                "agreement": majority[1] / len(values) if values else 0.0,
                                "stable": majority[1] == len(values)})
    function_ids = sorted(set().union(*(mapping.keys() for mapping in function_maps)))
    function_rows: list[dict[str, Any]] = []
    for cid in function_ids:
        values = [mapping.get(cid, "") for mapping in function_maps]
        votes = Counter(value for value in values if value)
        majority = sorted(votes.items(), key=lambda item: (-item[1], item[0]))[0] if votes else ("", 0)
        function_rows.append({"component_id": cid, "round_categories": values,
                              "votes": dict(sorted(votes.items())), "majority_category": majority[0],
                              "agreement": majority[1] / len(values) if values else 0.0,
                              "stable": majority[1] == len(values)})

    assignment_agreements = [float(row["agreement"]) for row in assignment_rows]
    function_agreements = [float(row["agreement"]) for row in function_rows]
    report = {"schema": "l2-multi-round-stability-v1", "requested_rounds": requested,
              "completed_rounds": len(round_data), "rounds": rounds, "errors": errors,
              "temperature": temperature,
              "assignment": {"components": assignment_rows,
                              "mean_agreement": sum(assignment_agreements) / len(assignment_agreements) if assignment_agreements else 0.0,
                              "stable_component_count": sum(1 for row in assignment_rows if row["stable"]),
                              "unstable_component_ids": [row["component_id"] for row in assignment_rows if not row["stable"]]},
              "function": {"components": function_rows,
                           "mean_agreement": sum(function_agreements) / len(function_agreements) if function_agreements else 0.0,
                           "stable_component_count": sum(1 for row in function_rows if row["stable"]),
                           "unstable_component_ids": [row["component_id"] for row in function_rows if not row["stable"]]},
              "round_manifests": manifests}
    save_json(root_out / "stability_report.json", report)
    with (root_out / "l2_assignment_stability.csv").open("w", encoding="utf-8-sig", newline="") as handle:
        fields = ["component_id"] + [f"round_{number:0{width}d}" for number in rounds] + ["majority_l2_id", "agreement", "stable"]
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in assignment_rows:
            output = {"component_id": row["component_id"], "majority_l2_id": row["majority_l2_id"],
                      "agreement": row["agreement"], "stable": row["stable"]}
            output.update({f"round_{number:0{width}d}": value for number, value in zip(rounds, row["round_assignments"])})
            writer.writerow(output)
    with (root_out / "function_stability.csv").open("w", encoding="utf-8-sig", newline="") as handle:
        fields = ["component_id"] + [f"round_{number:0{width}d}" for number in rounds] + ["majority_category", "agreement", "stable"]
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in function_rows:
            output = {"component_id": row["component_id"], "majority_category": row["majority_category"],
                      "agreement": row["agreement"], "stable": row["stable"]}
            output.update({f"round_{number:0{width}d}": value for number, value in zip(rounds, row["round_categories"])})
            writer.writerow(output)
    manifest = {"schema": "l2-multi-round-manifest-v1", "status": "completed_with_errors" if errors else "completed",
                "requested_rounds": requested, "completed_rounds": len(round_data), "output": str(root_out),
                "temperature": temperature, "stability_report": str(root_out / "stability_report.json"),
                "round_directories": [str(root_out / f"round_{index:0{width}d}") for index in rounds],
                "errors": errors}
    save_json(root_out / "flow_manifest.json", manifest)
    return manifest


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="L2 综合流程：器件功能识别 + 算法初划分 + 小元件补划分")
    parser.add_argument("netlist", help="标准 JSON 网表或 EasyEDA .enet")
    parser.add_argument("--out", default="l2_flow_output", help="输出目录")
    parser.add_argument("--api-key-file", "--deepseek-api-key-file")
    parser.add_argument("--base-url", default=None)
    parser.add_argument("--model", default=None)
    parser.add_argument("--timeout", type=int, default=180)
    parser.add_argument("--temperature", type=float, default=0.0,
                        help="DeepSeek 采样温度；多轮稳定性测试可设为 0.2-0.8")
    parser.add_argument("--rounds", type=int, default=1,
                        help="独立重复运行次数；大于 1 时生成稳定性报告")
    parser.add_argument("--algorithm-dir", default=str(DEFAULT_ALGORITHM_DIR))
    parser.add_argument("--dry-run", action="store_true", help="只生成请求和算法结果，不调用 DeepSeek")
    args = parser.parse_args(argv)
    if args.rounds < 1:
        parser.error("--rounds 必须是正整数")
    if not 0 <= args.temperature <= 2:
        parser.error("--temperature 必须在 0 到 2 之间")
    try:
        manifest = run_multi_round(args) if args.rounds > 1 else run_flow(args)
    except (OSError, ValueError, RuntimeError, json.JSONDecodeError) as exc:
        error_dir = Path(args.out).resolve()
        try:
            save_json(error_dir / "flow_error.json", {
                "schema": "l2-integrated-flow-error-v1",
                "error_type": type(exc).__name__,
                "error": str(exc),
                "base_url": args.base_url or os.getenv("DEEPSEEK_BASE_URL") or "https://api.deepseek.com/v1",
                "model": args.model or os.getenv("DEEPSEEK_MODEL") or "deepseek-chat",
            })
        except OSError:
            pass
        print(f"error: {exc}", file=sys.stderr)
        return 2
    print(_json(manifest))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
