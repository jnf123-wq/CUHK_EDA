# 划分器 v1.0

本目录把原有 L3、L2、L1 流程串成一个完整层级划分器，并在 L1 下展开 L0 单器件簇：

```text
L3 电压域
└─ L2 功能域
   └─ L1 功能簇
      └─ L0 单器件簇
```

每个 L3 域内部单独运行 L2 和 L1，因此任何 L2/L1 簇都不会跨越高低压域。L2 的器件功能标注会直接供 L1 使用，避免为同一批元件重复调用功能识别。最终会校验每个输入器件恰好出现在一个 L0 簇中。

## 启动

Windows 下双击 `启动划分器.cmd` 打开统一界面，也可以在命令行运行：

```powershell
python run_flow.py C:\path\to\schematic.enet `
  --api-key-file C:\path\to\DeepSeek接口文档.txt `
  --out C:\path\to\partition-output
```

接口文档可使用 `模型名`、`Base URL`、`API` 字段。也可通过环境变量 `DEEPSEEK_API_KEY`、`DEEPSEEK_BASE_URL`、`DEEPSEEK_MODEL` 配置 DeepSeek。

如果有原理图图片，可选填千问配置和图片；千问参与 L2 小元件归簇：

```powershell
python run_flow.py schematic.enet `
  --api-key-file C:\path\to\DeepSeek接口文档.txt `
  --qwen-api-key-file C:\path\to\千问接口文档.txt `
  --schematic C:\path\to\schematic.png `
  --threshold-v 12 --domain-workers 2 --out output
```

不同 L3 电压域之间互不依赖，默认最多并发运行 2 个域，以重叠 DeepSeek/千问的等待时间。接口出现限流或账户并发受限时，可用 `--domain-workers 1` 恢复串行；上限为 4。`run.json` / `hierarchy.json` 中 L2 的 `total_seconds` 仍是各域耗时之和，另有 `wall_clock_seconds` 表示并发后的实际 L2 墙钟时间。

当提供图片且有候选小元件时，千问会覆盖这些器件的最终归属；旧结果显示 DeepSeek 的补簇结果随后被完全覆盖。因此现已跳过这次冗余的 DeepSeek 补簇 API 调用，避免串行等待；没有触发千问时，原 DeepSeek 补簇照常运行。

要定位 L2 的具体耗时，查看总输出目录 `run.json` 中的 `l2_diagnostics_by_l3_domain`：它按 L3 域列出 L2 阶段耗时、各本地阶段时间和逐次模型调用统计。每次调用会记录端到端往返时间、网络尝试数、重试等待、请求/响应字节数及接口返回的 token usage；识图调用还会记录图片字节数。`elapsed_seconds` 是客户端观测到的完整请求时间（含上传、服务端处理、下载），并不等同于服务端纯推理时间。对照阶段/调用耗时即可判断慢在功能识别、补簇、识图还是重试等待。

## Dry-run

```powershell
python run_flow.py schematic.enet --dry-run --out output
```

Dry-run 不访问任何模型。为了贯通本地算法和检查输出结构，它会临时把所有器件放入 L3 `low_voltage` 域，并将每个器件标记为不确定、置信度 0。该层级结果仅用于流程测试，不能作为实际电压域划分。

## 输出

- `hierarchy.json`：完整的嵌套 L3 → L2 → L1 → L0 结构和逐器件归属。
- `hierarchical_assignments.csv`：每个器件对应的 L3、L2、L1、L0 ID，以及 `is_connector` 列。位号为 J 开头的器件，或类型/描述中标明 Connector/连接器的器件记为 `True`，其他元件留空。
- `L3_assignments.csv`、`L2_assignments.csv`、`L1_assignments.csv`、`L0_assignments.csv`：按层级分别导出的逐器件 CSV；每张表包含该层耗时，L0 表也包含连接器标记。
- `hierarchy.json` 和 `run.json`：各层累计耗时（秒）；L2/L1/L0 另按所属 L3 域提供耗时明细。
- `l3/`：L3 请求、模型响应、两电压域分配及审计文件。
- `domains/<L3域>/l2/`：该电压域自己的 L2 请求、算法结果、标注和最终结果。
- `domains/<L3域>/l1/`：该电压域内的 L1 配对分数和分配表。

## 目录

五个原工程作为源码副本保存在同目录下：`划分器_针对L3`、`划分器_针对L2`、`划分器_针对L1`、`划分器算法部分`、`划分器LLM部分`。算法、提示词和知识库运行路径均指向此目录内的副本，可整体移动。
