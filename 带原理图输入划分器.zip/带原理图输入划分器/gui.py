#!/usr/bin/env python3
"""Small Windows-friendly GUI for the unified partitioning flow."""

from __future__ import annotations

import queue
import subprocess
import sys
import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk


ROOT = Path(__file__).resolve().parent
FLOW = ROOT / "run_flow.py"


class App(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title("划分器 v1.0 · L3 → L2 → L1 → L0")
        self.geometry("920x760")
        self.minsize(760, 600)
        self.configure(background="#f4f6fa")
        self.events: queue.Queue[tuple[str, str]] = queue.Queue()
        self.process: subprocess.Popen[str] | None = None
        self.values = {
            "netlist": tk.StringVar(), "deepseek": tk.StringVar(), "qwen": tk.StringVar(),
            "schematic": tk.StringVar(), "out": tk.StringVar(value=str(ROOT / "output")),
            "threshold": tk.StringVar(value="12"), "temperature": tk.StringVar(value="0"),
            "domain_workers": tk.StringVar(value="2"),
            "dry_run": tk.BooleanVar(value=False),
        }
        self._build()
        self.after(120, self._poll)

    def _build(self) -> None:
        body = ttk.Frame(self, padding=20)
        body.pack(fill="both", expand=True)
        ttk.Label(body, text="完整层级划分", font=("Microsoft YaHei UI", 19, "bold")).pack(anchor="w")
        ttk.Label(body, text="L3 电压域 → L2 功能域 → L1 功能簇 → L0 单器件簇",
                  foreground="#536174").pack(anchor="w", pady=(4, 16))

        form = ttk.Frame(body)
        form.pack(fill="x")
        self._file_row(form, 0, "网表 (.enet / .json)", "netlist", self._choose_netlist)
        self._file_row(form, 1, "DeepSeek 接口文档", "deepseek", self._choose_deepseek)
        self._file_row(form, 2, "千问接口文档（可选）", "qwen", self._choose_qwen)
        self._file_row(form, 3, "原理图图片（可选）", "schematic", self._choose_image)
        self._file_row(form, 4, "输出目录", "out", self._choose_output, directory=True)

        settings = ttk.Frame(body)
        settings.pack(fill="x", pady=(14, 8))
        ttk.Label(settings, text="L3 高低压阈值 (V)").grid(row=0, column=0, sticky="w")
        ttk.Entry(settings, textvariable=self.values["threshold"], width=10).grid(row=0, column=1, padx=(8, 24))
        ttk.Label(settings, text="模型温度").grid(row=0, column=2, sticky="w")
        ttk.Entry(settings, textvariable=self.values["temperature"], width=10).grid(row=0, column=3, padx=(8, 24))
        ttk.Checkbutton(settings, text="Dry-run（不调用模型；L3 使用临时占位归属）",
                        variable=self.values["dry_run"]).grid(row=0, column=4, sticky="w")
        ttk.Label(settings, text="并发处理独立 L3 域").grid(row=1, column=0, sticky="w", pady=(8, 0))
        ttk.Spinbox(settings, from_=1, to=4, textvariable=self.values["domain_workers"], width=8).grid(
            row=1, column=1, sticky="w", padx=(8, 24), pady=(8, 0))
        ttk.Label(settings, text="默认 2；接口限流时设为 1", foreground="#536174").grid(
            row=1, column=2, columnspan=3, sticky="w", pady=(8, 0))

        buttons = ttk.Frame(body)
        buttons.pack(fill="x", pady=(6, 12))
        self.run_button = ttk.Button(buttons, text="开始完整划分", command=self._start)
        self.run_button.pack(side="left")
        ttk.Button(buttons, text="打开输出目录", command=self._open_output).pack(side="left", padx=8)
        self.status = ttk.Label(buttons, text="就绪", foreground="#536174")
        self.status.pack(side="right")

        log_frame = ttk.LabelFrame(body, text="运行日志", padding=8)
        log_frame.pack(fill="both", expand=True)
        self.log = tk.Text(log_frame, wrap="word", height=18, state="disabled", font=("Consolas", 10))
        scroll = ttk.Scrollbar(log_frame, orient="vertical", command=self.log.yview)
        self.log.configure(yscrollcommand=scroll.set)
        self.log.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")

    def _file_row(self, parent: ttk.Frame, row: int, label: str, key: str, action, *, directory: bool = False) -> None:
        ttk.Label(parent, text=label, width=23).grid(row=row, column=0, sticky="w", pady=5)
        ttk.Entry(parent, textvariable=self.values[key]).grid(row=row, column=1, sticky="ew", padx=8, pady=5)
        ttk.Button(parent, text="浏览…", command=action, width=10).grid(row=row, column=2, pady=5)
        parent.columnconfigure(1, weight=1)

    def _choose_netlist(self) -> None:
        value = filedialog.askopenfilename(filetypes=[("网表", "*.enet *.json"), ("所有文件", "*.*")])
        if value:
            self.values["netlist"].set(value)

    def _choose_deepseek(self) -> None:
        value = filedialog.askopenfilename(filetypes=[("接口文档", "*.txt *.env *.ini *.conf"), ("所有文件", "*.*")])
        if value:
            self.values["deepseek"].set(value)

    def _choose_qwen(self) -> None:
        value = filedialog.askopenfilename(filetypes=[("接口文档", "*.txt *.env *.ini *.conf"), ("所有文件", "*.*")])
        if value:
            self.values["qwen"].set(value)

    def _choose_image(self) -> None:
        value = filedialog.askopenfilename(filetypes=[("图片", "*.png *.jpg *.jpeg *.bmp *.webp"), ("所有文件", "*.*")])
        if value:
            self.values["schematic"].set(value)

    def _choose_output(self) -> None:
        value = filedialog.askdirectory(mustexist=False)
        if value:
            self.values["out"].set(value)

    def _append(self, value: str) -> None:
        self.log.configure(state="normal")
        self.log.insert("end", value)
        self.log.see("end")
        self.log.configure(state="disabled")

    def _start(self) -> None:
        if self.process is not None:
            return
        netlist = self.values["netlist"].get().strip()
        if not netlist or not Path(netlist).is_file():
            messagebox.showerror("缺少网表", "请选择有效的 .enet 或 JSON 网表。")
            return
        try:
            threshold = float(self.values["threshold"].get())
            temperature = float(self.values["temperature"].get())
            domain_workers = int(self.values["domain_workers"].get())
            if threshold <= 0 or not 0 <= temperature <= 2 or not 1 <= domain_workers <= 4:
                raise ValueError
        except ValueError:
            messagebox.showerror("参数无效", "阈值须大于 0，模型温度须在 0 到 2 之间，并发域数须在 1 到 4 之间。")
            return

        command = [sys.executable, str(FLOW), netlist, "--out", self.values["out"].get().strip(),
                   "--threshold-v", str(threshold), "--temperature", str(temperature),
                   "--domain-workers", str(domain_workers)]
        deepseek = self.values["deepseek"].get().strip()
        qwen = self.values["qwen"].get().strip()
        schematic = self.values["schematic"].get().strip()
        if deepseek:
            command += ["--api-key-file", deepseek]
        if qwen:
            command += ["--qwen-api-key-file", qwen]
        if schematic:
            command += ["--schematic", schematic]
        if self.values["dry_run"].get():
            command.append("--dry-run")

        self.run_button.configure(state="disabled")
        self.status.configure(text="运行中…", foreground="#1368ce")
        self._append("\n$ " + subprocess.list2cmdline(command) + "\n")
        threading.Thread(target=self._worker, args=(command,), daemon=True).start()

    def _worker(self, command: list[str]) -> None:
        try:
            self.process = subprocess.Popen(
                command, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, encoding="utf-8", errors="replace", bufsize=1,
            )
            assert self.process.stdout is not None
            for line in self.process.stdout:
                self.events.put(("log", line))
            code = self.process.wait()
            self.events.put(("done", str(code)))
        except Exception as exc:
            self.events.put(("error", str(exc)))
        finally:
            self.process = None

    def _poll(self) -> None:
        while True:
            try:
                kind, value = self.events.get_nowait()
            except queue.Empty:
                break
            if kind == "log":
                self._append(value)
            elif kind == "done":
                self.run_button.configure(state="normal")
                success = value == "0"
                self.status.configure(text="完成" if success else "失败", foreground="#16834a" if success else "#b42318")
                if success:
                    messagebox.showinfo("划分完成", f"层级结果已保存到：\n{Path(self.values['out'].get()) / 'hierarchy.json'}")
            elif kind == "error":
                self.run_button.configure(state="normal")
                self.status.configure(text="失败", foreground="#b42318")
                messagebox.showerror("启动失败", value)
        self.after(120, self._poll)

    def _open_output(self) -> None:
        path = Path(self.values["out"].get().strip())
        path.mkdir(parents=True, exist_ok=True)
        import os
        os.startfile(path)  # Windows desktop target


if __name__ == "__main__":
    App().mainloop()
