import csv
import tempfile
import unittest
from pathlib import Path

from run_flow import _is_connector, build_hierarchy, write_assignments_csv, write_layer_assignments


class HierarchyTests(unittest.TestCase):
    def setUp(self):
        self.netlist = {"components": [
            {"id": "U1", "kind": "ic"}, {"id": "C1", "kind": "capacitor"},
            {"id": "R1", "kind": "resistor"}, {"id": "J1", "kind": "connector"},
        ]}
        self.l3 = {
            "clusters": [
                {"cluster_id": "low_voltage", "cluster_name": "低压簇", "component_ids": ["U1", "C1"]},
                {"cluster_id": "high_voltage", "cluster_name": "高压簇", "component_ids": ["R1", "J1"]},
            ]
        }
        self.domain_results = {
            "low_voltage": {
                "l2_result": {"domains": [{"id": "domain-a", "anchor": "U1", "members": ["U1", "C1"]}]},
                "l1_result": {"l1_clusters": [{"id": "pair-a", "l2_domain": "domain-a", "members": ["U1", "C1"]}]},
            },
            "high_voltage": {
                "l2_result": {"domains": [{"id": "domain-b", "anchor": "J1", "members": ["R1", "J1"]}]},
                "l1_result": {"l1_clusters": [{"id": "pair-b", "l2_domain": "domain-b", "members": ["R1", "J1"]}]},
            },
        }

    def test_connector_detection_accepts_designator_and_explicit_description(self):
        self.assertTrue(_is_connector({"id": "J7", "kind": "other"}))
        self.assertTrue(_is_connector({"id": "X1", "type": "USB connector"}))
        self.assertTrue(_is_connector({"id": "CN1", "kind": "capacitor", "footprint": "CONN-TH_4P"}))
        self.assertTrue(_is_connector({"id": "USB1", "kind": "ic_module", "footprint": "USB-C-SMD"}))
        self.assertTrue(_is_connector({"id": "U3", "kind": "ic_module", "part": "USBA+TYPE-C",
                                       "footprint": "USB A+TYPE-C一体式插座"}))
        self.assertFalse(_is_connector({"id": "C7", "kind": "capacitor"}))
        self.assertFalse(_is_connector({"id": "H1", "kind": "other", "footprint": "M1.2 mounting hole"}))

    def test_each_component_gets_one_l0_child_in_its_full_path(self):
        result = build_hierarchy(self.netlist, self.l3, self.domain_results)

        self.assertTrue(result["all_components_once"])
        self.assertEqual(len(result["assignments"]), 4)
        self.assertEqual({row["component_id"] for row in result["assignments"]}, {"U1", "C1", "R1", "J1"})
        for domain in result["l3_domains"]:
            for l2 in domain["l2_domains"]:
                for l1 in l2["l1_clusters"]:
                    self.assertEqual(len(l1["l0_clusters"]), len(l1["members"]))
                    for l0 in l1["l0_clusters"]:
                        self.assertEqual(l0["members"], [l0["component_id"]])

        owners = {row["component_id"]: row for row in result["assignments"]}
        self.assertEqual(owners["U1"]["l3_id"], owners["C1"]["l3_id"])
        self.assertNotEqual(owners["U1"]["l3_id"], owners["R1"]["l3_id"])
        self.assertEqual(len({row["l0_id"] for row in result["assignments"]}), 4)
        self.assertIs(owners["J1"]["is_connector"], True)
        self.assertIsNone(owners["C1"]["is_connector"])

    def test_connector_column_is_true_or_blank(self):
        result = build_hierarchy(self.netlist, self.l3, self.domain_results)
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "assignments.csv"
            write_assignments_csv(path, result)
            with path.open("r", encoding="utf-8-sig", newline="") as handle:
                rows = {row["component_id"]: row for row in csv.DictReader(handle)}

        self.assertEqual(rows["J1"]["is_connector"], "True")
        self.assertEqual(rows["C1"]["is_connector"], "")

    def test_each_level_is_saved_as_a_complete_csv(self):
        hierarchy = build_hierarchy(self.netlist, self.l3, self.domain_results)
        l3_result = {"assignments": [
            {"component_id": cid, "cluster_id": cluster_id, "cluster_name": name}
            for cluster_id, name, members in (
                ("low_voltage", "低压簇", ["U1", "C1"]),
                ("high_voltage", "高压簇", ["R1", "J1"]),
            ) for cid in members
        ]}
        with tempfile.TemporaryDirectory() as temporary:
            output = Path(temporary)
            paths = write_layer_assignments(output, hierarchy, l3_result, self.domain_results)

            self.assertEqual(set(paths), {
                "L3_assignments.csv", "L2_assignments.csv", "L1_assignments.csv", "L0_assignments.csv",
            })
            for name in paths:
                with (output / name).open("r", encoding="utf-8-sig", newline="") as handle:
                    rows = list(csv.DictReader(handle))
                self.assertEqual(len(rows), 4, name)
                self.assertEqual({row["component_id"] for row in rows}, {"U1", "C1", "R1", "J1"})
                self.assertIn("analysis_seconds", rows[0])

            with (output / "L0_assignments.csv").open("r", encoding="utf-8-sig", newline="") as handle:
                l0 = {row["component_id"]: row for row in csv.DictReader(handle)}
            self.assertEqual(l0["J1"]["is_connector"], "True")
            self.assertEqual(l0["C1"]["is_connector"], "")

    def test_incomplete_l1_output_is_rejected(self):
        broken = {"low_voltage": self.domain_results["low_voltage"]}
        with self.assertRaisesRegex(ValueError, "L0 全覆盖校验失败"):
            build_hierarchy(self.netlist, self.l3, broken)


if __name__ == "__main__":
    unittest.main()
