import argparse
import json
import threading
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import patch
from urllib.error import URLError

from run_flow import _run_l3_domains, l2_flow, parse_args


class DomainConcurrencyTests(unittest.TestCase):
    def test_independent_l3_domains_can_run_concurrently(self):
        barrier = threading.Barrier(2)

        def fake_domain_flow(netlist, members, cluster_id, args, out):
            barrier.wait(timeout=2)
            return {"cluster_id": cluster_id, "members": members}

        l3_result = {"clusters": [
            {"cluster_id": "low_voltage", "component_ids": ["C1", "U1"]},
            {"cluster_id": "high_voltage", "component_ids": ["C2", "U2"]},
        ]}
        with patch("run_flow._run_l2_l1_for_domain", side_effect=fake_domain_flow):
            results, _elapsed, workers = _run_l3_domains(
                {"components": []}, l3_result, argparse.Namespace(), Path("output"), 2,
            )

        self.assertEqual(workers, 2)
        self.assertEqual(list(results), ["low_voltage", "high_voltage"])
        self.assertEqual(results["low_voltage"]["members"], {"C1", "U1"})
        self.assertEqual(results["high_voltage"]["members"], {"C2", "U2"})

    def test_cli_worker_count_defaults_to_two_and_is_bounded(self):
        self.assertEqual(parse_args(["example.enet"]).domain_workers, 2)
        self.assertEqual(parse_args(["example.enet", "--domain-workers", "1"]).domain_workers, 1)
        with self.assertRaises(SystemExit):
            parse_args(["example.enet", "--domain-workers", "5"])


class CompactCompletionContextTests(unittest.TestCase):
    def test_compact_context_keeps_anchor_members_and_pin_evidence_only(self):
        domains = [{
            "id": "L2-001", "anchor": "U1", "members": ["U1", "R1"],
            "assignment_reason": "recursive_pin_connection",
            "assignments": [{
                "ref": "R1", "score": 0.75, "shared_nets": ["BIAS"],
                "semantics": ["ANALOG"], "assignment_reason": "direct_pin_connection",
                "connection_distance": 1, "connection_path_display": "U1.OUT → R1.1",
                "connection_pin_path": [{"from_component": "U1", "to_component": "R1"}],
            }],
            "children_l1_clusters": [{"id": "L1-001", "members": ["U1", "R1"]}],
        }]

        compact = l2_flow._compact_l2_domain_context(domains)

        self.assertEqual(compact[0]["members"], ["U1", "R1"])
        self.assertEqual(compact[0]["assignments"][0]["connection_path_display"], "U1.OUT → R1.1")
        self.assertNotIn("connection_pin_path", compact[0]["assignments"][0])
        self.assertNotIn("children_l1_clusters", compact[0])

    def test_completion_request_keeps_only_candidate_annotations_and_required_evidence(self):
        request = l2_flow._build_small_component_completion_request(
            netlist={
                "components": [
                    {"id": "C1", "kind": "capacitor", "value": "1uF"},
                    {"id": "U1", "kind": "ic"},
                ],
                "nets": [{"id": "VDD", "pins": [
                    {"component": "C1", "pin": "1"}, {"component": "U1", "pin": "2"},
                ]}],
            },
            eligible=["C1"],
            annotations=[
                {"component_id": "C1", "functional_category": "去耦电容"},
                {"component_id": "U1", "functional_category": "控制器"},
            ],
            target_domains=[{
                "id": "L2-001", "anchor": "U1", "members": ["U1"],
                "assignments": [{"ref": "U1", "shared_nets": ["VDD"]}],
            }],
        )

        self.assertEqual(request["eligible_component_ids"], ["C1"])
        self.assertEqual([row["component_id"] for row in request["function_annotations"]], ["C1"])
        self.assertEqual(request["network_connectivity"][0]["id"], "VDD")
        self.assertEqual(request["algorithm_l2_domains"][0]["anchor"], "U1")
        self.assertNotIn("algorithm_l2_result", request)
        self.assertNotIn("eligible_function_annotations", request)
        self.assertEqual(request["constraints"]["existing_major_l2_ids"], ["L2-001"])


class RedundantCompletionOptimizationTests(unittest.TestCase):
    def test_skip_deepseek_completion_only_when_qwen_will_cover_candidates(self):
        domains = [{"id": "L2-001", "anchor": "U1", "members": ["U1"]}]
        self.assertTrue(l2_flow._qwen_supersedes_completion(
            True, domains, ["C1", "R1"], dry_run=False,
        ))
        self.assertFalse(l2_flow._qwen_supersedes_completion(
            False, domains, ["C1"], dry_run=False,
        ))
        self.assertFalse(l2_flow._qwen_supersedes_completion(
            True, [], ["C1"], dry_run=False,
        ))
        self.assertFalse(l2_flow._qwen_supersedes_completion(
            True, domains, ["C1"], dry_run=True,
        ))

    def test_qwen_full_coverage_makes_completion_result_irrelevant_to_final_domains(self):
        algorithm_domains = [
            {"id": "L2-001", "anchor": "U1", "members": ["U1"]},
            {"id": "L2-unresolved", "anchor": None, "members": ["C1", "R1"]},
        ]
        completion = [
            {"component_id": "C1", "l2_id": "L2-S001"},
            {"component_id": "R1", "l2_id": "L2-S002"},
        ]
        qwen = [
            {"component_id": "C1", "l2_id": "L2-001"},
            {"component_id": "R1", "l2_id": "L2-001"},
        ]
        auxiliary = [
            {"id": "L2-S001", "members": ["C1"]},
            {"id": "L2-S002", "members": ["R1"]},
        ]

        final = l2_flow._merge_final_domains(algorithm_domains, completion, qwen, auxiliary)

        self.assertEqual(final, [{"id": "L2-001", "anchor": "U1", "members": ["C1", "R1", "U1"]},
                                 {"id": "L2-unresolved", "anchor": None, "members": []}])

    def test_without_qwen_deepseek_auxiliary_clusters_remain_in_final_domains(self):
        algorithm_domains = [
            {"id": "L2-001", "anchor": "U1", "members": ["U1"]},
            {"id": "L2-unresolved", "anchor": None, "members": ["C1"]},
        ]
        auxiliary = [{"id": "L2-S001", "anchor": None, "members": ["C1"]}]

        final = l2_flow._merge_final_domains(
            algorithm_domains, [{"component_id": "C1", "l2_id": "L2-S001"}], [], auxiliary,
        )

        self.assertEqual(final[0]["members"], ["U1"])
        self.assertEqual(final[1]["members"], [])
        self.assertEqual(final[2]["members"], ["C1"])

    def test_qwen_path_completes_l2_flow_without_calling_deepseek_completion(self):
        components = [
            {"id": "U1", "kind": "ic_module", "value": "controller", "pins": []},
            {"id": "C1", "kind": "capacitor", "value": "1uF", "pins": []},
        ]
        netlist = {"name": "timing-test", "components": components, "nets": []}
        topology = {"components": [], "nets": {}}
        algorithm_domains = [
            {"id": "L2-001", "anchor": "U1", "members": ["U1"]},
            {"id": "L2-unresolved", "anchor": None, "members": ["C1"]},
        ]
        major_domains = [algorithm_domains[0]]
        call_stages = []

        class FakeClient:
            def __init__(self, api_key, **kwargs):
                self.last_call_stats = {}

        def fake_timed_ask(_client, _system, request, _metrics, stage, **_kwargs):
            call_stages.append(stage)
            if stage == "device_function_recognition":
                return {"annotations": [{
                    "component_id": row["id"], "functional_category": "测试器件",
                    "function_description": "测试", "confidence": 1,
                } for row in components]}
            if stage == "schematic_image_assignment":
                return {"assignments": [{
                    "component_id": cid, "target_l2_id": "L2-001", "confidence": 1,
                } for cid in request["candidate_component_ids"]]}
            raise AssertionError(f"未预期的模型调用：{stage}")

        fake_partition = types.ModuleType("partitioner")
        fake_partition.__path__ = []
        fake_l1_partition = types.ModuleType("partitioner.l1_partition")
        fake_l1_partition.run = lambda *_args, **_kwargs: {"algorithm": "test"}
        fake_l1_partition.validate_topology = lambda _topology: None
        with tempfile.TemporaryDirectory() as temp_dir:
            out = Path(temp_dir) / "l2-output"
            args = argparse.Namespace(
                netlist="test.json", out=str(out), schematic="test.png", api_key_file=None,
                base_url="https://example.invalid", model="test-model", qwen_api_key_file=None,
                qwen_base_url=None, qwen_model="test-qwen", timeout=1, temperature=0,
                dry_run=False, algorithm_dir=temp_dir,
            )
            with patch.object(l2_flow, "load_inputs", return_value=(netlist, topology)), \
                    patch.object(l2_flow, "_image_attachment", return_value={
                        "name": "test.png", "path": "test.png", "bytes": 12,
                        "mime": "image/png", "image_url": "data:image/png;base64,AA==",
                    }), \
                    patch.object(l2_flow, "_read_key_file", return_value={"api_key": "fake-key"}), \
                    patch.object(l2_flow, "DeepSeekClient", FakeClient), \
                    patch.object(l2_flow, "_timed_ask", side_effect=fake_timed_ask), \
                    patch.object(l2_flow, "_extract_domains", return_value=(
                        algorithm_domains, major_domains, ["C1"], [], [],
                    )), \
                    patch.dict("sys.modules", {
                        "partitioner": fake_partition,
                        "partitioner.l1_partition": fake_l1_partition,
                    }):
                manifest = l2_flow.run_flow(args)

            result = json.loads((out / "l2_final_result.json").read_text(encoding="utf-8"))
            self.assertEqual(call_stages, ["device_function_recognition", "schematic_image_assignment"])
            self.assertEqual(result["completion_raw_response"]["status"], "skipped_redundant_qwen_assignment")
            self.assertEqual(result["domains"][0]["members"], ["C1", "U1"])
            self.assertTrue(manifest["counts"]["completion_skipped_redundant_qwen"])


class ModelCallTimingTests(unittest.TestCase):
    def test_client_records_round_trip_retries_sizes_and_usage(self):
        class FakeResponse:
            def __enter__(self):
                return self

            def __exit__(self, *_args):
                return False

            def read(self):
                return json.dumps({
                    "choices": [{"message": {"content": '{"ok": true}'}}],
                    "usage": {"prompt_tokens": 11, "completion_tokens": 3, "total_tokens": 14},
                }).encode("utf-8")

        client = l2_flow.DeepSeekClient(
            "test-key", base_url="https://example.invalid/v1", model="test-model",
            retries=2, provider="test-provider",
        )
        with patch("run_flow.l2_flow.urlopen", side_effect=[URLError("temporary"), FakeResponse()]), \
                patch("run_flow.l2_flow.time.sleep"):
            result = client.ask("system", {"task": "test"})

        self.assertEqual(result, {"ok": True})
        self.assertEqual(client.last_call_stats["network_attempts"], 2)
        self.assertEqual(client.last_call_stats["retry_wait_seconds"], 0.7)
        self.assertEqual(client.last_call_stats["request_bytes_total"],
                         2 * client.last_call_stats["request_bytes_per_attempt"])
        self.assertEqual(client.last_call_stats["usage"]["total_tokens"], 14)

if __name__ == "__main__":
    unittest.main()
