# 器件功能识别标注 Flow

这个副本现在只负责一件事：读取原理图 `.enet` / 标准 JSON 网表，让用户选择 Qwen 或 DeepSeek，对每个器件做功能识别，并输出标注文件。

副本中已经删除候选组、冻结压缩、确定性分区、L3/L2/L1 层级构建和双模型融合等旧算法模块。当前的稳定性报告只比较多轮器件功能标注的一致性，不执行划分。基础划分思路另存于桌面的 [基础划分思路说明.md](C:/Users/30943/Desktop/基础划分思路说明.md)，仅作为后续可选功能的设计记录。

## 输出

每个器件严格输出一条标注，文件为：

```text
device_annotations.csv
device_annotations.json
stability_report.csv       # --rounds > 1 时生成
stability_report.json      # --rounds > 1 时生成
run.json
manifest.json
```

CSV 表头为：

```text
L0_Device,器件名称,功能类别,功能说明,识别依据,置信度,识别状态
```

流程不会输出或计算 L3/L2/L1，不会把器件归入簇，也不会执行 PCB 分区。

## 命令行

使用 Qwen：

```powershell
python -m iterative_partition.run schematic.enet --mode qwen `
  --qwen-api-key-file C:\path\qwen.env --out output\qwen_annotations
```

独立运行多轮并生成稳定性报告：

```powershell
python -m iterative_partition.run schematic.enet --mode qwen `
  --qwen-api-key-file C:\path\qwen.env --rounds 3 --out output\qwen_3rounds
```

多轮结果保存在 `round_01/`、`round_02/` 等目录；最后一轮结果同时保留在输出根目录。稳定性报告按器件统计：功能类别一致率、功能说明完全一致率、置信度均值/标准差，以及完整稳定率。被跳过的 R/L/C 不计入模型稳定性分母，但仍会列在报告中。

使用 DeepSeek：

```powershell
python -m iterative_partition.run schematic.enet --mode deepseek `
  --deepseek-api-key-file C:\path\deepseek.env --out output\deepseek_annotations
```

跳过指定小器件的功能识别（器件仍会写入输出，并标记为“已跳过”）：

```powershell
python -m iterative_partition.run schematic.enet --mode qwen `
  --qwen-api-key-file C:\path\qwen.env --skip-small-devices `
  --skip-device-types R,C --out output\qwen_annotations
```

可选参数：

- `--schematic`：原理图图片/PDF；图片会以视觉输入发送，PDF只保留文件元数据；
- `--reference-sample`：人工标注 CSV，仅作为功能描述粒度参考；
- `--qwen-model`、`--deepseek-model`：覆盖默认模型；
- `--qwen-base-url`、`--deepseek-base-url`：覆盖 API 地址。
- `--skip-small-devices`：启用跳过小器件识别；
- `--skip-device-types R,L,C`：指定跳过的器件类型，可任意组合。

`.enet` 文件先在本地解析为 JSON 网表，再发送给模型；不会把 `.enet` 当作模型可直接读取的文件附件。

## GUI

运行：

```powershell
启动GUI.cmd
```

GUI 中选择一个模型、输入网表和 API 配置文件后，点击“开始识别并生成标注”。界面不再提供分区数量、冻结阈值、最大轮数等算法参数。
“独立运行轮数”填 `1` 时只运行一轮；填大于 `1` 的整数时会保存每轮结果并生成 `stability_report.csv/json`。

## 校验规则

- 模型必须覆盖网表中的全部器件；
- 每个器件位号只能出现一次；
- 不允许输出网表不存在的器件；
- 功能类别和功能说明不能为空；
- 置信度必须为 0 到 1；
- 校验失败时自动带错误信息重试一次，仍失败则运行失败并写入 `run.json`。
