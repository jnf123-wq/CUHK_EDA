"""LLM-only per-device functional annotation workflow."""

__all__ = []
