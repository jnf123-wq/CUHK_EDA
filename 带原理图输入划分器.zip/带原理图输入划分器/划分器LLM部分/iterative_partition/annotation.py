"""LLM-only per-device functional recognition; deliberately performs no partitioning."""

from __future__ import annotations

import csv
import json
import re
import statistics
from collections import Counter
from pathlib import Path
from typing import Any, Mapping

from .api_client import _JSONClient, _file_attachment
from .io import load_engineering_inputs, save_json


FIELDS = ["L0_Device", "器件名称", "功能类别", "功能说明", "识别依据", "置信度", "识别状态"]
STABILITY_FIELDS = [
    "L0_Device", "识别状态", "功能类别一致率", "功能说明完全一致率",
    "类别是否稳定", "说明是否稳定", "置信度均值", "置信度标准差",
    "各轮功能类别", "各轮功能说明",
]


def component_small_type(component_id: str, component: Mapping[str, Any] | None = None) -> str | None:
    """Return a selectable passive type for common schematic designators.

    C/L-prefixed designators are used by some tools as CVC/CL/CSC or L1.
    An L-prefixed LED is excluded from the inductor category by its part text.
    """
    cid = str(component_id).strip().upper()
    first = cid[:1]
    if first not in {"R", "L", "C"}:
        return None
    if first == "L" and not re.match(r"^L\d", cid):
        return None
    if first == "L" and component:
        details = " ".join(str(component.get(key, "")) for key in ("value", "part", "name", "kind")).upper()
        if re.search(r"\bLED\b|LIGHT[ -]?EMITTING|DIODE", details):
            return None
    return first


def split_skipped_components(netlist: Mapping[str, Any], skip_types: set[str]) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    analyzable: list[dict[str, Any]] = []
    skipped: list[dict[str, Any]] = []
    for component in netlist.get("components", []):
        item = dict(component)
        kind = component_small_type(str(item.get("id", "")), item)
        if kind in skip_types:
            skipped.append(item)
        else:
            analyzable.append(item)
    return analyzable, skipped


def _prompt(netlist: Mapping[str, Any], schematic: Mapping[str, Any] | None,
            sample_text: str | None, skipped_ids: list[str]) -> dict[str, Any]:
    return {
        "task": "仅识别每个电子器件自身的功能并生成标注，不做任何层级划分、聚类、分组或分区。",
        "input": {
            "netlist_json": {"name": netlist.get("name"), "components": netlist.get("components", []),
                             "nets": netlist.get("nets", [])},
            "optional_schematic": schematic or {"provided": False},
            "optional_reference_sample": sample_text or "",
            "skipped_component_ids": skipped_ids,
        },
        "output_schema": {"annotations": [{
            "component_id": "网表中的器件位号", "component_name": "型号/名称",
            "functional_category": "器件功能类别", "function_description": "器件用途及关键参数",
            "evidence": "根据器件属性、引脚网络或原理图得出的依据；不确定时说明",
            "confidence": 0.0,
        }]},
        "rules": [
            "每个未跳过器件必须且只能输出一条标注，component_id 必须与网表 id 完全一致，不可改写、遗漏或虚构。",
            "skipped_component_ids 中的器件不要输出任何标注；它们只是网表上下文。",
            "只描述单个器件的功能识别，不得把多个器件合成一个标注，不得输出 L3/L2/L1、簇、分区、归属或分组结果。",
            "优先依据 components 中的 id、value、part、footprint、pins，以及 nets 中的连接关系；不要臆造网表中不存在的参数。",
            "功能类别使用简明、可比较的类别名称；功能说明写该器件自身用途。",
            "evidence 应说明实际依据；证据不足时明确写‘信息不足/推测’，并降低 confidence。confidence 为 0 到 1 的数值。",
            "输出有效 JSON，不要 Markdown 或额外解释。",
        ],
    }


def normalize_annotations(result: Mapping[str, Any], known: set[str]) -> list[dict[str, Any]]:
    raw = result.get("annotations", result.get("components", result.get("assignments")))
    if isinstance(raw, Mapping):
        raw = [dict(value, component_id=key) for key, value in raw.items() if isinstance(value, Mapping)]
    if not isinstance(raw, list):
        raise ValueError("模型输出缺少 annotations 数组")
    records: dict[str, dict[str, Any]] = {}
    for item in raw:
        if not isinstance(item, Mapping):
            raise ValueError("器件标注必须为对象")
        cid = str(item.get("component_id", item.get("id", item.get("L0_Device", "")))).strip()
        if cid not in known:
            raise ValueError(f"模型输出了未知器件位号：{cid or '(空)'}")
        if cid in records:
            raise ValueError(f"模型重复标注器件：{cid}")
        category = str(item.get("functional_category", item.get("功能类别", ""))).strip()
        description = str(item.get("function_description", item.get("功能说明", item.get("description", "")))).strip()
        if not category or not description:
            raise ValueError(f"{cid} 缺少功能类别或功能说明")
        try:
            confidence = float(item.get("confidence", item.get("置信度", 0)))
        except (TypeError, ValueError) as exc:
            raise ValueError(f"{cid} 的置信度不是数字") from exc
        if not 0 <= confidence <= 1:
            raise ValueError(f"{cid} 的置信度必须在 0 到 1 之间")
        records[cid] = {
            "L0_Device": cid,
            "器件名称": str(item.get("component_name", item.get("器件名称", ""))).strip(),
            "功能类别": category,
            "功能说明": description,
            "识别依据": str(item.get("evidence", item.get("识别依据", ""))).strip(),
            "置信度": confidence,
            "识别状态": "已识别",
        }
    missing = sorted(known - records.keys())
    if missing:
        raise ValueError(f"模型遗漏器件：{', '.join(missing[:20])}")
    return [records[cid] for cid in sorted(records)]


def _skipped_annotations(skipped_components: list[dict[str, Any]]) -> list[dict[str, Any]]:
    result = []
    for component in skipped_components:
        cid = str(component["id"])
        kind = component_small_type(cid, component) or "小器件"
        result.append({
            "L0_Device": cid,
            "器件名称": str(component.get("part") or component.get("value") or ""),
            "功能类别": "已跳过识别",
            "功能说明": f"按用户设置跳过 {kind} 类小器件功能识别",
            "识别依据": f"器件位号属于已选择跳过的 {kind} 类别",
            "置信度": 0.0,
            "识别状态": "已跳过",
        })
    return result


def _write_annotation_files(out: Path, annotations: list[dict[str, Any]], skipped_components: list[dict[str, Any]]) -> None:
    out.mkdir(parents=True, exist_ok=True)
    with (out / "device_annotations.csv").open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(annotations)
    save_json(out / "device_annotations.json", {
        "schema": "device-functional-annotations-v1",
        "annotations": annotations,
        "skipped_component_ids": [str(item["id"]) for item in skipped_components],
    })


def _mode(values: list[str]) -> str:
    counts = Counter(values)
    return sorted(counts, key=lambda value: (-counts[value], value))[0] if counts else ""


def build_stability_report(round_annotations: list[list[dict[str, Any]]]) -> dict[str, Any]:
    """Compare repeated model annotations without merging or changing them."""

    if not round_annotations:
        raise ValueError("至少需要一轮标注结果才能生成稳定性报告")
    by_round = [{str(row["L0_Device"]): row for row in rows} for rows in round_annotations]
    component_ids = sorted({cid for rows in by_round for cid in rows})
    devices = []
    for cid in component_ids:
        rows = [rows[cid] for rows in by_round if cid in rows]
        categories = [str(row.get("功能类别", "")) for row in rows]
        descriptions = [str(row.get("功能说明", "")) for row in rows]
        statuses = [str(row.get("识别状态", "")) for row in rows]
        confidences = [float(row.get("置信度", 0.0)) for row in rows]
        category_agreement = max(Counter(categories).values()) / len(categories) if categories else 0.0
        description_agreement = max(Counter(descriptions).values()) / len(descriptions) if descriptions else 0.0
        recognized = all(status != "已跳过" for status in statuses)
        devices.append({
            "L0_Device": cid,
            "识别状态": _mode(statuses),
            "功能类别一致率": round(category_agreement, 6),
            "功能说明完全一致率": round(description_agreement, 6),
            "类别是否稳定": len(set(categories)) <= 1,
            "说明是否稳定": len(set(descriptions)) <= 1,
            "是否纳入模型稳定性统计": recognized,
            "置信度均值": round(statistics.fmean(confidences), 6) if confidences else 0.0,
            "置信度标准差": round(statistics.pstdev(confidences), 6) if len(confidences) > 1 else 0.0,
            "各轮功能类别": categories,
            "各轮功能说明": descriptions,
        })
    recognized_devices = [item for item in devices if item["是否纳入模型稳定性统计"]]
    category_rate = statistics.fmean(item["功能类别一致率"] for item in recognized_devices) if recognized_devices else 1.0
    description_rate = statistics.fmean(item["功能说明完全一致率"] for item in recognized_devices) if recognized_devices else 1.0
    stable_devices = [item for item in recognized_devices if item["类别是否稳定"] and item["说明是否稳定"]]
    return {
        "schema": "device-annotation-stability-v1",
        "round_count": len(round_annotations),
        "component_count": len(component_ids),
        "recognized_component_count": len(recognized_devices),
        "skipped_component_count": len(devices) - len(recognized_devices),
        "category_stability_rate": round(category_rate, 6),
        "description_exact_stability_rate": round(description_rate, 6),
        "fully_stable_rate": round(len(stable_devices) / len(recognized_devices), 6) if recognized_devices else 1.0,
        "stable_component_count": len(stable_devices),
        "unstable_component_ids": [item["L0_Device"] for item in recognized_devices if item not in stable_devices],
        "per_device": devices,
    }


def _write_stability_files(out: Path, report: dict[str, Any]) -> None:
    save_json(out / "stability_report.json", report)
    with (out / "stability_report.csv").open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=STABILITY_FIELDS)
        writer.writeheader()
        for item in report["per_device"]:
            row = {key: item.get(key, "") for key in STABILITY_FIELDS}
            row["各轮功能类别"] = " | ".join(item.get("各轮功能类别", []))
            row["各轮功能说明"] = " | ".join(item.get("各轮功能说明", []))
            writer.writerow(row)


def _run_annotation_once(netlist: Mapping[str, Any], out: Path, *, model: str,
                         client: _JSONClient, attachment: Mapping[str, Any] | None,
                         sample: str | None, skip_small_devices: bool,
                         selected_types: set[str]) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    analyzable, skipped_components = split_skipped_components(netlist, selected_types if skip_small_devices else set())
    analysis_netlist = dict(netlist)
    analysis_netlist["components"] = analyzable
    prompt = _prompt(analysis_netlist, attachment, sample, [str(item["id"]) for item in skipped_components])
    prompt["repair_instruction"] = ""
    last_error = ""
    annotations: list[dict[str, Any]] = []
    known = {str(item["id"]) for item in analyzable}
    if known:
        for attempt in range(1, 3):
            if last_error:
                prompt["repair_instruction"] = f"上次结果未通过完整性校验：{last_error}。请输出全部未跳过器件的完整标注 JSON。"
            raw_result = client.ask(
                "你是谨慎的电子硬件器件功能识别工程师。只识别单个器件功能，禁止生成任何划分或聚类。输出有效 JSON。",
                prompt, image_url=(attachment or {}).get("image_url"))
            try:
                annotations = normalize_annotations(raw_result, known)
                break
            except ValueError as exc:
                last_error = str(exc)
                if attempt == 2:
                    raise ValueError(f"模型器件标注连续两次未通过校验：{last_error}") from exc
    annotations.extend(_skipped_annotations(skipped_components))
    annotations.sort(key=lambda item: item["L0_Device"])
    _write_annotation_files(out, annotations, skipped_components)
    manifest = {
        "schema": "device-annotation-run-v1", "status": "completed",
        "input": {"name": netlist.get("name"), "source_format": netlist.get("source_format"),
                  "component_count": len(netlist.get("components", [])), "net_count": len(netlist.get("nets", []))},
        "provider": {"mode": model, "name": model, "model": client.model},
        "annotation_count": len(annotations), "recognized_count": len(analyzable),
        "skipped_count": len(skipped_components), "skip_small_devices": bool(skip_small_devices),
        "skipped_component_types": sorted(selected_types if skip_small_devices else set()),
        "hierarchical_partitioning": False,
        "artifacts": ["device_annotations.csv", "device_annotations.json"],
        "schematic_visual_optional": bool(attachment),
    }
    save_json(out / "run.json", manifest)
    save_json(out / "manifest.json", manifest)
    return manifest, annotations


def run_annotation(netlist_path: str | Path, out_dir: str | Path, *, model: str,
                   client: _JSONClient, schematic_path: str | None = None,
                   reference_sample_path: str | None = None,
                   skip_small_devices: bool = False,
                   skip_types: set[str] | None = None, rounds: int = 1) -> dict[str, Any]:
    if rounds < 1:
        raise ValueError("rounds 必须是大于等于 1 的整数")
    netlist = load_engineering_inputs(netlist_path)
    selected_types = {str(value).strip().upper() for value in (skip_types or set()) if str(value).strip().upper() in {"R", "L", "C"}}
    attachment = _file_attachment(schematic_path)
    sample = Path(reference_sample_path).read_text(encoding="utf-8-sig")[:100000] if reference_sample_path else None
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    round_annotations: list[list[dict[str, Any]]] = []
    round_manifests: list[dict[str, Any]] = []
    for index in range(1, rounds + 1):
        round_dir = out if rounds == 1 else out / f"round_{index:02d}"
        manifest, annotations = _run_annotation_once(
            netlist, round_dir, model=model, client=client, attachment=attachment, sample=sample,
            skip_small_devices=skip_small_devices, selected_types=selected_types,
        )
        round_manifests.append(manifest)
        round_annotations.append(annotations)
    if rounds == 1:
        return round_manifests[0]

    # Keep the last round at the output root for compatibility, while retaining
    # every independent round under round_XX/ for auditability.
    skipped_components = split_skipped_components(netlist, selected_types if skip_small_devices else set())[1]
    _write_annotation_files(out, round_annotations[-1], skipped_components)
    stability = build_stability_report(round_annotations)
    _write_stability_files(out, stability)
    manifest = {
        **round_manifests[-1],
        "schema": "device-annotation-multi-run-v1",
        "round_count": rounds,
        "rounds": [{"round": index, "directory": f"round_{index:02d}"} for index in range(1, rounds + 1)],
        "stability": {
            "category_stability_rate": stability["category_stability_rate"],
            "description_exact_stability_rate": stability["description_exact_stability_rate"],
            "fully_stable_rate": stability["fully_stable_rate"],
        },
        "artifacts": ["device_annotations.csv", "device_annotations.json", "stability_report.csv",
                      "stability_report.json"] + [f"round_{index:02d}" for index in range(1, rounds + 1)],
    }
    save_json(out / "run.json", manifest)
    save_json(out / "manifest.json", manifest)
    return manifest
