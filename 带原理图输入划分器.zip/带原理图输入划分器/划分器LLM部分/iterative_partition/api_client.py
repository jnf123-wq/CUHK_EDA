"""Minimal OpenAI-compatible client and configuration helpers for annotation only."""

from __future__ import annotations

import ast
import base64
import json
import mimetypes
import os
from pathlib import Path
from typing import Any, Mapping
from urllib.request import Request, urlopen


def read_api_config_file(path: str | Path) -> dict[str, str]:
    source = Path(path)
    text = source.read_text(encoding="utf-8-sig")
    result: dict[str, str] = {}
    names = {"api_key", "apikey", "key", "token", "qwen_api_key", "deepseek_api_key", "base_url", "model"}
    try:
        tree = ast.parse(text, filename=str(source))
    except SyntaxError:
        tree = None
    if tree is not None:
        for node in ast.walk(tree):
            if isinstance(node, (ast.Assign, ast.AnnAssign)):
                targets = node.targets if isinstance(node, ast.Assign) else [node.target]
                if isinstance(node.value, ast.Constant) and isinstance(node.value.value, str):
                    for target in targets:
                        if isinstance(target, ast.Name) and target.id.lower() in names:
                            result[target.id.lower()] = node.value.value.strip()
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip().lower()
        if key not in names:
            continue
        value = value.split("#", 1)[0].strip().rstrip(",").strip().strip("'\"")
        if value and not value.startswith(("os.getenv", "getenv(", "os.environ")):
            result.setdefault(key, value)
    if not result and text.strip() and "\n" not in text.strip() and "=" not in text.strip():
        result["api_key"] = text.strip()
    return result


def _file_attachment(path: str | Path | None) -> dict[str, Any] | None:
    if not path:
        return None
    source = Path(path)
    if not source.is_file():
        raise ValueError(f"schematic file does not exist: {source}")
    record: dict[str, Any] = {"name": source.name, "suffix": source.suffix.lower(), "bytes": source.stat().st_size}
    mime, _ = mimetypes.guess_type(source.name)
    if mime and mime.startswith("image/") and source.stat().st_size <= 8 * 1024 * 1024:
        record["image_url"] = f"data:{mime};base64,{base64.b64encode(source.read_bytes()).decode('ascii')}"
    return record


def _response_json(payload: Mapping[str, Any]) -> dict[str, Any]:
    try:
        content = payload["choices"][0]["message"]["content"]
        if isinstance(content, list):
            content = "".join(str(item.get("text", "")) for item in content if isinstance(item, Mapping))
        result = json.loads(str(content))
    except (KeyError, IndexError, TypeError, json.JSONDecodeError) as exc:
        raise RuntimeError("model response did not contain a valid JSON object") from exc
    if not isinstance(result, dict):
        raise RuntimeError("model response root must be a JSON object")
    return result


class _JSONClient:
    def __init__(self, *, base_url: str, model: str, api_key: str, timeout: int | None = None):
        self.base_url, self.model, self.api_key, self.timeout = base_url.rstrip("/"), model, api_key, timeout

    def ask(self, system: str, prompt: Mapping[str, Any], *, image_url: str | None = None) -> dict[str, Any]:
        text = json.dumps(prompt, ensure_ascii=False)
        content: Any = text
        if image_url:
            content = [{"type": "text", "text": text}, {"type": "image_url", "image_url": {"url": image_url}}]
        body = json.dumps({"model": self.model, "temperature": 0, "response_format": {"type": "json_object"},
                           "messages": [{"role": "system", "content": system}, {"role": "user", "content": content}]},
                          ensure_ascii=False).encode("utf-8")
        request = Request(f"{self.base_url}/chat/completions", data=body, method="POST",
                          headers={"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"})
        try:
            with urlopen(request, timeout=self.timeout) as response:
                return _response_json(json.loads(response.read().decode("utf-8")))
        except Exception as exc:
            raise RuntimeError(f"{self.model} request failed: {exc}") from exc


def resolve_api_config(path: str | None, *, env_key: str, env_base: str, env_model: str,
                       explicit_base: str | None, explicit_model: str | None,
                       default_base: str, default_model: str) -> tuple[str, str, str]:
    file_config = read_api_config_file(path) if path else {}
    key = os.getenv(env_key) or file_config.get("api_key") or file_config.get("apikey") or file_config.get("key") or file_config.get("token") or file_config.get("qwen_api_key") or file_config.get("deepseek_api_key")
    if not key:
        raise ValueError(f"set {env_key} or pass a config file containing a literal API key")
    return key, explicit_base or os.getenv(env_base) or file_config.get("base_url") or default_base, explicit_model or os.getenv(env_model) or file_config.get("model") or default_model
