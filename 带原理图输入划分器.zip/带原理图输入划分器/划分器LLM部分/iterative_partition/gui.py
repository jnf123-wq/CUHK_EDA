"""Small GUI for LLM-only per-device functional annotation."""

from __future__ import annotations

import json
import queue
import subprocess
import sys
import threading
import webbrowser
from pathlib import Path
from tkinter import filedialog, messagebox, ttk
import tkinter as tk

from .io import load_netlist

ROOT = Path(__file__).resolve().parent.parent


def build_command(values: dict[str, str]) -> list[str]:
    command = [sys.executable, "-X", "utf8", "-m", "iterative_partition.run",
               values["netlist"], "--mode", values["mode"], "--out", values["output"]]
    rounds = str(values.get("rounds", "1")).strip() or "1"
    command.extend(("--rounds", rounds))
    for key, flag in (("schematic", "--schematic"), ("reference_sample", "--reference-sample"),
                      ("qwen_api_key_file", "--qwen-api-key-file"), ("qwen_model", "--qwen-model"),
                      ("qwen_base_url", "--qwen-base-url"), ("deepseek_api_key_file", "--deepseek-api-key-file"),
                      ("deepseek_model", "--deepseek-model"), ("deepseek_base_url", "--deepseek-base-url")):
        if values.get(key, "").strip():
            command.extend((flag, values[key].strip()))
    if str(values.get("skip_small_devices", "")).strip().lower() in {"1", "true", "yes", "on"}:
        command.append("--skip-small-devices")
        command.extend(("--skip-device-types", values.get("skip_types", "").strip()))
    return command


def report_is_current(output: str | Path, netlist: str | Path) -> bool:
    try:
        data = json.loads((Path(output) / "run.json").read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return False
    return (data.get("status") == "completed"
            and data.get("input", {}).get("name") == Path(netlist).stem
            and (Path(output) / "device_annotations.csv").is_file())


def main() -> None:
    app = tk.Tk()
    app.title("器件功能识别标注")
    app.geometry("900x690")
    app.minsize(760, 560)
    # Put the complete form in a canvas so the window remains usable on
    # smaller screens.  Both the scrollbar and the mouse wheel control the
    # same vertical viewport.
    viewport = ttk.Frame(app)
    viewport.pack(fill="both", expand=True)
    canvas = tk.Canvas(viewport, highlightthickness=0, borderwidth=0)
    scrollbar = ttk.Scrollbar(viewport, orient="vertical", command=canvas.yview)
    canvas.configure(yscrollcommand=scrollbar.set)
    scrollbar.pack(side="right", fill="y")
    canvas.pack(side="left", fill="both", expand=True)
    root = ttk.Frame(canvas, padding=16)
    canvas_window = canvas.create_window((0, 0), window=root, anchor="nw")

    def update_scroll_region(_event: tk.Event | None = None) -> None:
        canvas.configure(scrollregion=canvas.bbox("all"))

    def resize_content(event: tk.Event) -> None:
        canvas.itemconfigure(canvas_window, width=event.width)

    root.bind("<Configure>", update_scroll_region)
    canvas.bind("<Configure>", resize_content)

    def scroll_with_wheel(event: tk.Event) -> str:
        delta = getattr(event, "delta", 0)
        if delta:
            # Windows/macOS use delta; keep a minimum one-line movement for
            # high-resolution touchpads.
            steps = -int(delta / 120) if abs(delta) >= 120 else (-1 if delta > 0 else 1)
            canvas.yview_scroll(steps, "units")
        elif getattr(event, "num", None) == 4:
            canvas.yview_scroll(-3, "units")
        elif getattr(event, "num", None) == 5:
            canvas.yview_scroll(3, "units")
        return "break"

    app.bind_all("<MouseWheel>", scroll_with_wheel)
    app.bind_all("<Button-4>", scroll_with_wheel)
    app.bind_all("<Button-5>", scroll_with_wheel)
    ttk.Label(root, text="器件功能识别标注", font=("Microsoft YaHei UI", 18, "bold")).pack(anchor="w")
    ttk.Label(root, text="仅由所选大模型逐器件识别功能并输出标注文件；不进行 L3/L2/L1 划分、聚类或算法分区。",
              wraplength=850).pack(anchor="w", pady=(4, 12))

    values = {key: tk.StringVar() for key in ("netlist", "schematic", "reference_sample", "output",
                                               "rounds",
                                               "qwen_api_key_file", "qwen_base_url", "qwen_model",
                                               "deepseek_api_key_file", "deepseek_base_url", "deepseek_model")}
    values["output"].set(str(ROOT / "output" / "annotations"))
    mode = tk.StringVar(value="qwen")
    form = ttk.LabelFrame(root, text="输入与模型设置", padding=10)
    form.pack(fill="x")
    fields = [
        ("原理图 ENET / JSON（必需）", "netlist", "file", "*.enet *.json"),
        ("原理图图片/PDF（可选）", "schematic", "file", "*.png *.jpg *.jpeg *.bmp *.pdf"),
        ("人工标注样例（可选）", "reference_sample", "file", "*.csv"),
        ("Qwen API 配置文件", "qwen_api_key_file", "file", "*.txt *.env *.py"),
        ("Qwen 模型名（可选）", "qwen_model", "text", ""),
        ("Qwen API 地址（可选）", "qwen_base_url", "text", ""),
        ("DeepSeek API 配置文件", "deepseek_api_key_file", "file", "*.txt *.env *.py"),
        ("DeepSeek 模型名（可选）", "deepseek_model", "text", ""),
        ("DeepSeek API 地址（可选）", "deepseek_base_url", "text", ""),
        ("标注输出目录", "output", "directory", ""),
        ("独立运行轮数", "rounds", "text", ""),
    ]
    values["rounds"].set("1")
    for label, key, kind, pattern in fields:
        row = ttk.Frame(form); row.pack(fill="x", pady=3)
        ttk.Label(row, text=label, width=27).pack(side="left")
        ttk.Entry(row, textvariable=values[key]).pack(side="left", fill="x", expand=True)
        if kind != "text":
            def browse(k=key, t=kind, p=pattern):
                selected = filedialog.askdirectory() if t == "directory" else filedialog.askopenfilename(filetypes=[("支持的文件", p), ("所有文件", "*.*")])
                if selected: values[k].set(selected)
            ttk.Button(row, text="浏览…", command=browse).pack(side="left", padx=(6, 0))

    model_box = ttk.LabelFrame(root, text="选择一个模型（每轮请求一次完整器件标注）", padding=8)
    model_box.pack(fill="x", pady=(10, 0))
    ttk.Radiobutton(model_box, text="千问", value="qwen", variable=mode).pack(side="left", padx=8)
    ttk.Radiobutton(model_box, text="DeepSeek", value="deepseek", variable=mode).pack(side="left", padx=8)

    skip_small_var = tk.BooleanVar(value=False)
    skip_type_vars = {kind: tk.BooleanVar(value=True) for kind in ("R", "L", "C")}
    skip_box = ttk.LabelFrame(root, text="可选：跳过小器件功能识别", padding=8)
    skip_box.pack(fill="x", pady=(10, 0))
    ttk.Checkbutton(skip_box, text="启用跳过", variable=skip_small_var).pack(side="left", padx=(0, 14))
    ttk.Label(skip_box, text="跳过类型：").pack(side="left")
    for kind, label in (("R", "电阻 R"), ("L", "电感 L"), ("C", "电容 C")):
        ttk.Checkbutton(skip_box, text=label, variable=skip_type_vars[kind]).pack(side="left", padx=6)
    ttk.Label(skip_box, text="被跳过器件仍会写入 CSV，但状态标记为“已跳过”。", foreground="#666666").pack(side="left", padx=(12, 0))

    log = tk.Text(root, height=10, wrap="word", state="disabled")
    log.pack(fill="both", expand=True, pady=(10, 5))
    status = tk.StringVar(value="就绪")
    ttk.Label(root, textvariable=status).pack(anchor="w")
    actions = ttk.Frame(root); actions.pack(fill="x", pady=(7, 0))
    running = {"active": False}

    def append(text: str) -> None:
        log.configure(state="normal"); log.insert("end", text); log.see("end"); log.configure(state="disabled")

    def execute() -> None:
        if running["active"]: return
        net_path = Path(values["netlist"].get().strip())
        if not net_path.is_file():
            messagebox.showerror("缺少网表", "请选择有效的原理图 ENET/JSON 文件。"); return
        try:
            load_netlist(net_path)
        except (OSError, ValueError, json.JSONDecodeError) as exc:
            messagebox.showerror("无法读取网表", str(exc)); return
        if not values["output"].get().strip():
            messagebox.showerror("缺少输出位置", "请选择标注输出目录。"); return
        try:
            rounds = int(values["rounds"].get().strip() or "1")
            if rounds < 1:
                raise ValueError
        except ValueError:
            messagebox.showerror("运行轮数无效", "独立运行轮数必须是大于等于 1 的整数。"); return
        key_field = "qwen_api_key_file" if mode.get() == "qwen" else "deepseek_api_key_file"
        if not values[key_field].get().strip():
            messagebox.showerror("缺少 API 配置", f"请选择{('千问' if mode.get() == 'qwen' else 'DeepSeek')} API 配置文件。"); return
        for key, variable in values.items():
            if key not in {"output", "qwen_model", "qwen_base_url", "deepseek_model", "deepseek_base_url"} and variable.get().strip() and key != "netlist" and not Path(variable.get()).is_file():
                messagebox.showerror("文件不存在", variable.get()); return
        args = {key: var.get().strip() for key, var in values.items()}; args["mode"] = mode.get()
        args["skip_small_devices"] = "1" if skip_small_var.get() else ""
        args["skip_types"] = ",".join(kind for kind, variable in skip_type_vars.items() if variable.get())
        if skip_small_var.get() and not args["skip_types"]:
            messagebox.showerror("未选择跳过类型", "已启用跳过功能，请至少勾选一种器件类型：R、电感 L 或电容 C。")
            return
        if not messagebox.askokcancel("模型数据发送提示", "网表（本地解析为 JSON）及可选原理图/样例将发送给所选模型服务进行逐器件功能识别。不会执行任何划分或分区。\n\n确认继续？"):
            return
        command = build_command(args)
        running["active"] = True; start.configure(state="disabled"); status.set("正在请求模型并生成器件标注…")
        append("$ " + subprocess.list2cmdline(command) + "\n")
        def worker() -> None:
            try:
                proc = subprocess.Popen(command, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                        text=True, encoding="utf-8", errors="replace",
                                        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
                assert proc.stdout is not None
                for line in proc.stdout: app.after(0, append, line)
                code = proc.wait()
                app.after(0, finished, code)
            except Exception as exc:
                app.after(0, failed, str(exc))
        threading.Thread(target=worker, daemon=True).start()

    def finished(code: int) -> None:
        running["active"] = False; start.configure(state="normal")
        status.set("器件标注完成" if code == 0 else f"运行失败（退出码 {code}）")
        if code == 0:
            out = Path(values["output"].get())
            append(f"\n标注文件：{out / 'device_annotations.csv'}\n")
            try:
                rounds = int(values["rounds"].get().strip() or "1")
            except ValueError:
                rounds = 1
            if rounds > 1:
                append(f"稳定性报告：{out / 'stability_report.csv'}\n")
                try:
                    report = json.loads((out / "stability_report.json").read_text(encoding="utf-8"))
                    append("稳定性摘要："
                           f"功能类别一致率 {report.get('category_stability_rate', 0):.2%}；"
                           f"功能说明完全一致率 {report.get('description_exact_stability_rate', 0):.2%}；"
                           f"完整稳定率 {report.get('fully_stable_rate', 0):.2%}\n")
                except (OSError, json.JSONDecodeError):
                    pass
    def failed(error: str) -> None:
        running["active"] = False; start.configure(state="normal"); status.set("启动失败"); append(error + "\n")

    start = ttk.Button(actions, text="开始识别并生成标注", command=execute); start.pack(side="left")
    ttk.Button(actions, text="打开输出目录", command=lambda: __import__("os").startfile(values["output"].get()) if Path(values["output"].get()).exists() else None).pack(side="left", padx=8)
    app.mainloop()


if __name__ == "__main__":
    main()
