"""Input/output helpers for the annotation workflow."""

from __future__ import annotations

import json
import csv
import hashlib
from pathlib import Path
from typing import Any, Mapping

from .model import clone_json, validate_netlist


def load_json(path: str | Path) -> Any:
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def _load_easyeda_enet(path: str | Path) -> dict[str, Any]:
    """Convert an EasyEDA pin-level .enet export to the workflow's netlist shape."""

    source = load_json(path)
    raw_components = source.get("components") if isinstance(source, Mapping) else None
    if not isinstance(raw_components, Mapping):
        raise ValueError("支持 EasyEDA .enet 或含 components/nets 数组的标准 JSON 网表")

    from collections import Counter, defaultdict

    refs = Counter()
    for key, item in raw_components.items():
        if isinstance(item, Mapping):
            props = item.get("props", {})
            props = props if isinstance(props, Mapping) else {}
            refs[str(props.get("Designator") or key)] += 1
    components: list[dict[str, Any]] = []
    nets: dict[str, list[dict[str, str]]] = defaultdict(list)
    for key, raw in raw_components.items():
        if not isinstance(raw, Mapping):
            raise ValueError(".enet components 必须是对象")
        props = raw.get("props", {})
        if not isinstance(props, Mapping):
            props = {}
        if "pinInfoMap" not in raw:
            raise ValueError("文件缺少引脚级 pinInfoMap；layout JSON 不能作为完整网表")

        ref = str(props.get("Designator") or key)
        if refs[ref] > 1:
            ref = f"{ref}@{key}"
        pinmap = raw["pinInfoMap"]
        if isinstance(pinmap, Mapping):
            pin_items = pinmap.items()
        elif isinstance(pinmap, list):
            pin_items = enumerate(pinmap)
        else:
            raise ValueError(f"{ref} 的 pinInfoMap 必须是对象或数组")

        pins: list[dict[str, str]] = []
        seen_pin_ids: set[str] = set()
        for pin_key, raw_pin in pin_items:
            if not isinstance(raw_pin, Mapping):
                raise ValueError(f"{ref} 的 pinInfoMap 包含无效引脚")
            pin_id = str(raw_pin.get("number", pin_key))
            if pin_id in seen_pin_ids:
                raise ValueError(f"器件引脚编号重复：{ref}.{pin_id}")
            seen_pin_ids.add(pin_id)
            pin_name = str(raw_pin.get("name", ""))
            net_name = str(raw_pin.get("net") or "")
            pins.append({"id": pin_id, "name": pin_name, "net": net_name})
            if net_name:
                nets[net_name].append({"component": ref, "pin": pin_id})

        components.append({
            "id": ref,
            "value": str(props.get("Value", "")),
            "part": str(props.get("Manufacturer Part") or props.get("DeviceName") or props.get("Name", "")),
            "footprint": str(props.get("FootprintName") or props.get("Supplier Footprint") or props.get("Footprint", "")),
            "pins": pins,
        })

    if not components:
        raise ValueError("网表没有器件")
    components.sort(key=lambda item: item["id"])
    net_rows = [
        {"id": name, "pins": sorted(pins, key=lambda pin: (pin["component"], pin["pin"]))}
        for name, pins in sorted(nets.items())
    ]
    electrical_digest = hashlib.sha256(
        json.dumps({"components": components, "nets": net_rows}, ensure_ascii=False, sort_keys=True).encode("utf-8")
    ).hexdigest()
    return validate_netlist({
        "name": Path(path).stem,
        "source_format": "easyeda-enet",
        "electrical_sha256": electrical_digest,
        "components": components,
        "nets": net_rows,
    })


def load_netlist(path: str | Path) -> dict[str, Any]:
    source = Path(path)
    if source.suffix.lower() == ".enet":
        return _load_easyeda_enet(source)
    raw = load_json(source)
    normalized = validate_netlist(raw)
    if not normalized.get("source_format"):
        source_format = raw.get("format") if isinstance(raw, Mapping) else None
        normalized["source_format"] = str(source_format or "standard-json")
    return normalized


def save_json(path: str | Path, value: Any) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def _load_structured(path: str | Path) -> Any:
    source = Path(path)
    if source.suffix.lower() == ".csv":
        with source.open("r", encoding="utf-8-sig", newline="") as handle:
            return list(csv.DictReader(handle))
    return load_json(source)


def _rows_by_component(value: Any, label: str) -> dict[str, dict[str, Any]]:
    """Normalize common BOM/coordinate exports to component-id keyed rows."""

    if isinstance(value, Mapping):
        rows = value.get("components", value.get("items", value.get("rows", value)))
        if isinstance(rows, Mapping):
            result = {}
            for key, row in rows.items():
                result[str(key)] = dict(row) if isinstance(row, Mapping) else {label: row}
            return result
    elif isinstance(value, list):
        rows = value
    else:
        raise ValueError(f"{label} data must be an object, mapping, or array")
    result: dict[str, dict[str, Any]] = {}
    for row in rows:
        if not isinstance(row, Mapping):
            raise ValueError(f"{label} rows must be objects")
        cid = row.get("id", row.get("ref", row.get("reference", row.get("component"))))
        if cid is None or not str(cid).strip():
            raise ValueError(f"every {label} row needs id/ref/reference/component")
        key = str(cid)
        if key in result:
            raise ValueError(f"duplicate {label} row: {key}")
        result[key] = dict(row)
    return result


def load_engineering_inputs(
    netlist_path: str | Path,
    *,
    bom_path: str | Path | None = None,
    coordinates_path: str | Path | None = None,
    metadata_path: str | Path | None = None,
) -> dict[str, Any]:
    """Load the netlist and optional BOM/coordinate/project metadata together.

    The original electrical topology remains the source of truth.  Optional
    engineering records are copied onto matching components and retained in
    ``engineering_inputs`` for the LLM context and audit trail.
    """

    netlist = load_netlist(netlist_path)
    input_records: dict[str, Any] = {}
    component_records = {str(c["id"]): c for c in netlist.get("components", [])}
    for kind, path in (("bom", bom_path), ("coordinates", coordinates_path)):
        if path is None:
            continue
        raw = _load_structured(path)
        rows = _rows_by_component(raw, kind)
        unknown = sorted(set(rows) - set(component_records))
        if unknown:
            raise ValueError(f"{kind} references unknown components: {unknown}")
        input_records[kind] = rows
        for cid, row in rows.items():
            field = "bom" if kind == "bom" else "coordinates"
            component_records[cid][field] = clone_json(row)
    if metadata_path is not None:
        metadata = _load_structured(metadata_path)
        if not isinstance(metadata, Mapping):
            raise ValueError("project metadata must be an object")
        input_records["metadata"] = clone_json(metadata)
        for key, value in metadata.items():
            if key not in {"components", "nets", "schema"}:
                netlist[key] = clone_json(value)
    netlist["engineering_inputs"] = input_records
    return validate_netlist(netlist)
