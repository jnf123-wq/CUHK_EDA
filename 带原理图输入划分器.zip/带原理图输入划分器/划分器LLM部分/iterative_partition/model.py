"""Small JSON-friendly helpers for validating and normalizing netlists."""

from __future__ import annotations

from copy import deepcopy
from typing import Any, Mapping


def component_id(component: Mapping[str, Any]) -> str:
    value = component.get("id", component.get("ref"))
    if value is None or not str(value).strip():
        raise ValueError("every component needs a non-empty id/ref")
    return str(value)


def clone_json(value: Any) -> Any:
    return deepcopy(value)


def component_map(netlist: Mapping[str, Any]) -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    for raw in netlist.get("components", []):
        if not isinstance(raw, Mapping):
            raise ValueError("components must contain objects")
        item = dict(raw)
        cid = component_id(item)
        if cid in result:
            raise ValueError(f"duplicate component: {cid}")
        item["id"] = cid
        result[cid] = item
    return result


def net_id(net: Mapping[str, Any]) -> str:
    value = net.get("id", net.get("name"))
    if value is None or not str(value).strip():
        raise ValueError("every net needs a non-empty id/name")
    return str(value)


def net_components(net: Mapping[str, Any]) -> list[str]:
    pins = net.get("pins")
    if isinstance(pins, list):
        result = []
        for pin in pins:
            if isinstance(pin, Mapping):
                value = pin.get("component", pin.get("ref"))
            else:
                value = pin
            if value is not None:
                result.append(str(value))
        return list(dict.fromkeys(result))
    members = net.get("components", net.get("endpoints", []))
    if not isinstance(members, list):
        raise ValueError(f"net {net_id(net)} endpoints must be an array")
    result = []
    for value in members:
        if isinstance(value, Mapping):
            value = value.get("component", value.get("ref"))
        if value is not None:
            result.append(str(value).split(".", 1)[0].split(":", 1)[0])
    return list(dict.fromkeys(result))


def validate_netlist(netlist: Mapping[str, Any]) -> dict[str, Any]:
    """Normalize an input netlist while preserving extra source fields."""

    if not isinstance(netlist, Mapping):
        raise ValueError("netlist root must be an object")
    components = component_map(netlist)
    nets: list[dict[str, Any]] = []
    seen_nets: set[str] = set()
    for raw in netlist.get("nets", []):
        if not isinstance(raw, Mapping):
            raise ValueError("nets must contain objects")
        item = dict(raw)
        nid = net_id(item)
        if nid in seen_nets:
            raise ValueError(f"duplicate net: {nid}")
        seen_nets.add(nid)
        refs = net_components(item)
        unknown = sorted(set(refs) - set(components))
        if unknown:
            raise ValueError(f"net {nid} references unknown components: {unknown}")
        if len(refs) < 2:
            # Keep one-terminal nets in the source ledger for auditability.
            item["pins"] = [{"component": ref, "pin": ""} for ref in refs]
        else:
            item["pins"] = [
                dict(pin) if isinstance(pin, Mapping) else {"component": str(pin), "pin": ""}
                for pin in item.get("pins", [])
                if (pin.get("component", pin.get("ref")) if isinstance(pin, Mapping) else pin) is not None
            ]
            if not item["pins"]:
                item["pins"] = [{"component": ref, "pin": ""} for ref in refs]
        for pin in item["pins"]:
            pin["component"] = str(pin.get("component", pin.get("ref")))
        item["id"] = nid
        item["name"] = str(item.get("name", nid))
        item.setdefault("weight", 1.0)
        item.setdefault("critical", False)
        nets.append(item)
    return {
        **{k: clone_json(v) for k, v in netlist.items() if k not in {"components", "nets"}},
        "schema": "llm-iterative-netlist-v1",
        "components": list(components.values()),
        "nets": nets,
    }


