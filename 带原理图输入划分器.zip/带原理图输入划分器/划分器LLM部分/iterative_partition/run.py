"""CLI for model-only per-device functional annotations (no partitioning)."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from .annotation import run_annotation
from .api_client import _JSONClient, resolve_api_config
from .io import save_json


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Use one LLM to label each device function; does not partition")
    parser.add_argument("netlist", help="原理图 EasyEDA .enet 或 components/nets JSON 网表")
    parser.add_argument("--mode", choices=("qwen", "deepseek"), default="qwen", help="选择单个模型做器件功能识别")
    parser.add_argument("--out", default="annotation_run", help="输出目录")
    parser.add_argument("--rounds", type=int, default=1,
                        help="独立调用模型的轮数；大于 1 时额外输出每轮结果和稳定性报告")
    parser.add_argument("--schematic", help="可选原理图图片/PDF")
    parser.add_argument("--reference-sample", help="可选人工标注 CSV，仅供器件功能描述口径参考")
    parser.add_argument("--skip-small-devices", action="store_true",
                        help="跳过指定 R/L/C 小器件的功能识别，但仍在输出中标记这些器件")
    parser.add_argument("--skip-device-types", default="R,L,C",
                        help="配合 --skip-small-devices 使用，逗号分隔，可选 R、L、C；默认 R,L,C")
    parser.add_argument("--qwen-base-url")
    parser.add_argument("--qwen-model")
    parser.add_argument("--qwen-api-key-file")
    parser.add_argument("--deepseek-base-url")
    parser.add_argument("--deepseek-model")
    parser.add_argument("--deepseek-api-key-file")
    args = parser.parse_args(argv)
    out = Path(args.out)
    try:
        if args.mode == "qwen":
            key, base, model = resolve_api_config(
                args.qwen_api_key_file, env_key="QWEN_API_KEY", env_base="QWEN_BASE_URL",
                env_model="QWEN_MODEL", explicit_base=args.qwen_base_url, explicit_model=args.qwen_model,
                default_base="https://dashscope.aliyuncs.com/compatible-mode/v1", default_model="qwen3.8-max")
        else:
            key, base, model = resolve_api_config(
                args.deepseek_api_key_file, env_key="DEEPSEEK_API_KEY", env_base="DEEPSEEK_BASE_URL",
                env_model="DEEPSEEK_MODEL", explicit_base=args.deepseek_base_url, explicit_model=args.deepseek_model,
                default_base="https://api.deepseek.com/v1", default_model="deepseek-chat")
        client = _JSONClient(base_url=base, model=model, api_key=key)
        skip_types = {item.strip().upper() for item in args.skip_device_types.split(",") if item.strip()}
        invalid_types = skip_types - {"R", "L", "C"}
        if invalid_types:
            raise ValueError(f"--skip-device-types 只支持 R、L、C，无法识别：{sorted(invalid_types)}")
        manifest = run_annotation(args.netlist, out, model=args.mode, client=client,
                                  schematic_path=args.schematic, reference_sample_path=args.reference_sample,
                                  skip_small_devices=args.skip_small_devices, skip_types=skip_types,
                                  rounds=args.rounds)
    except (OSError, ValueError, RuntimeError) as exc:
        try:
            save_json(out / "run.json", {"schema": "device-annotation-run-v1", "status": "failed",
                                          "error_type": type(exc).__name__, "error": str(exc)[:2000]})
        except OSError:
            pass
        print(f"error: {exc}", file=sys.stderr)
        return 2
    message = f"器件功能标注完成：{manifest['annotation_count']} 个器件；未执行层级划分。输出：{out.resolve() / 'device_annotations.csv'}"
    if manifest.get("round_count", 1) > 1:
        stability = manifest.get("stability", {})
        message += (f"\n已完成 {manifest['round_count']} 轮独立调用；"
                    f"类别稳定率 {stability.get('category_stability_rate', 0):.2%}，"
                    f"说明完全一致率 {stability.get('description_exact_stability_rate', 0):.2%}，"
                    f"完整稳定率 {stability.get('fully_stable_rate', 0):.2%}。"
                    f"稳定性报告：{out.resolve() / 'stability_report.csv'}")
    print(message)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
