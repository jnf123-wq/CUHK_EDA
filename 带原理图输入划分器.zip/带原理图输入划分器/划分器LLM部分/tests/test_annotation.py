import csv
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from iterative_partition.annotation import build_stability_report, normalize_annotations, run_annotation, split_skipped_components
from iterative_partition.gui import build_command, report_is_current
from iterative_partition.io import load_netlist
from iterative_partition.run import main as run_main


class AnnotationTests(unittest.TestCase):
    def test_multi_round_run_writes_rounds_and_stability_report(self):
        class SequenceClient:
            model = "test-model"

            def __init__(self):
                self.calls = 0

            def ask(self, *args, **kwargs):
                self.calls += 1
                category = "电源控制" if self.calls == 1 else "电源管理"
                return {"annotations": [{
                    "component_id": "U1", "component_name": "IC", "functional_category": category,
                    "function_description": category, "evidence": "pins", "confidence": 0.8,
                }]}

        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            netlist = root / "board.json"
            netlist.write_text(json.dumps({"name": "board", "components": [{"id": "U1"}, {"id": "R1"}], "nets": []}), encoding="utf-8")
            manifest = run_annotation(netlist, root / "out", model="qwen", client=SequenceClient(),
                                      rounds=2, skip_small_devices=True, skip_types={"R"})
            self.assertEqual(manifest["round_count"], 2)
            self.assertTrue((root / "out" / "round_01" / "device_annotations.csv").is_file())
            self.assertTrue((root / "out" / "round_02" / "device_annotations.csv").is_file())
            self.assertTrue((root / "out" / "stability_report.csv").is_file())
            self.assertEqual(manifest["stability"]["category_stability_rate"], 0.5)
            report = json.loads((root / "out" / "stability_report.json").read_text(encoding="utf-8"))
            self.assertEqual(report["unstable_component_ids"], ["U1"])

    def test_stability_report_excludes_skipped_devices_from_model_rate(self):
        report = build_stability_report([
            [{"L0_Device": "U1", "功能类别": "A", "功能说明": "x", "置信度": 0.8, "识别状态": "已识别"},
             {"L0_Device": "R1", "功能类别": "已跳过识别", "功能说明": "跳过", "置信度": 0, "识别状态": "已跳过"}],
            [{"L0_Device": "U1", "功能类别": "A", "功能说明": "x", "置信度": 0.9, "识别状态": "已识别"},
             {"L0_Device": "R1", "功能类别": "已跳过识别", "功能说明": "跳过", "置信度": 0, "识别状态": "已跳过"}],
        ])
        self.assertEqual(report["recognized_component_count"], 1)
        self.assertEqual(report["fully_stable_rate"], 1.0)

    def test_all_selected_small_devices_are_written_without_model_call(self):
        class NoCallClient:
            model = "test-model"

            def ask(self, *args, **kwargs):
                raise AssertionError("模型不应在全部器件跳过时被调用")

        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            netlist = root / "board.json"
            netlist.write_text(json.dumps({
                "name": "board",
                "components": [
                    {"id": "R1", "value": "10k"},
                    {"id": "C1", "value": "100nF"},
                ],
                "nets": [],
            }), encoding="utf-8")
            manifest = run_annotation(netlist, root / "out", model="qwen", client=NoCallClient(),
                                      skip_small_devices=True, skip_types={"R", "C"})
            self.assertEqual(manifest["input"]["component_count"], 2)
            self.assertEqual(manifest["recognized_count"], 0)
            self.assertEqual(manifest["skipped_count"], 2)
            with (root / "out" / "device_annotations.csv").open(encoding="utf-8-sig", newline="") as handle:
                rows = list(csv.DictReader(handle))
            self.assertEqual({row["L0_Device"] for row in rows}, {"R1", "C1"})
            self.assertEqual(sum(row["识别状态"] == "已跳过" for row in rows), 2)

    def test_normalize_annotations_requires_exactly_all_devices(self):
        result = normalize_annotations({"annotations": [
            {"component_id": "A", "functional_category": "电阻", "function_description": "限流", "confidence": 0.8},
            {"component_id": "B", "functional_category": "电容", "function_description": "滤波", "confidence": 0.7},
        ]}, {"A", "B"})
        self.assertEqual([item["L0_Device"] for item in result], ["A", "B"])

    def test_normalize_annotations_rejects_duplicate_and_unknown(self):
        with self.assertRaisesRegex(ValueError, "重复"):
            normalize_annotations({"annotations": [
                {"component_id": "A", "functional_category": "x", "function_description": "y"},
                {"component_id": "A", "functional_category": "x", "function_description": "y"},
            ]}, {"A"})
        with self.assertRaisesRegex(ValueError, "未知"):
            normalize_annotations({"annotations": [{"component_id": "X", "functional_category": "x", "function_description": "y"}]}, {"A"})

    def test_split_skipped_components_supports_composite_designators_and_keeps_led(self):
        analyzable, skipped = split_skipped_components({"components": [
            {"id": "R1"}, {"id": "CL7"}, {"id": "L1", "part": "5uH"},
            {"id": "LED1", "part": "LED green"}, {"id": "U1"},
        ]}, {"R", "L", "C"})
        self.assertEqual({item["id"] for item in skipped}, {"R1", "CL7", "L1"})
        self.assertEqual({item["id"] for item in analyzable}, {"LED1", "U1"})

    def test_gui_command_contains_only_annotation_options(self):
        command = build_command({"netlist": "board.enet", "mode": "deepseek", "output": "out",
                                 "deepseek_api_key_file": "key.txt", "schematic": "sch.png", "rounds": "3"})
        self.assertIn("--mode", command)
        self.assertIn("deepseek", command)
        self.assertEqual(command[command.index("--rounds") + 1], "3")
        self.assertNotIn("--partitions", command)
        self.assertNotIn("--max-rounds", command)

        command = build_command({"netlist": "board.enet", "mode": "qwen", "output": "out",
                                 "skip_small_devices": "1", "skip_types": "R,C"})
        self.assertIn("--skip-small-devices", command)
        self.assertEqual(command[command.index("--skip-device-types") + 1], "R,C")

    def test_failed_annotation_run_marks_manifest_failed(self):
        with tempfile.TemporaryDirectory() as temp:
            input_path = Path(temp) / "broken.json"
            output = Path(temp) / "out"
            input_path.write_text("not-json", encoding="utf-8")
            with patch("sys.stderr"):
                self.assertEqual(run_main([str(input_path), "--mode", "qwen", "--out", str(output), "--qwen-api-key-file", str(input_path)]), 2)
            manifest = json.loads((output / "run.json").read_text(encoding="utf-8"))
            self.assertEqual(manifest["status"], "failed")

    def test_report_is_current_requires_annotation_manifest(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "device_annotations.csv").write_text("x", encoding="utf-8")
            (root / "run.json").write_text(json.dumps({"status": "completed", "input": {"name": "board"}}), encoding="utf-8")
            self.assertTrue(report_is_current(root, "board.enet"))
            self.assertFalse(report_is_current(root, "other.enet"))


if __name__ == "__main__":
    unittest.main()
