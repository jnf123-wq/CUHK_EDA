# 针对已知 L2 的 L1 划分器

这里是从 `C:\Users\30943\Desktop\划分器LLM部分` 和 `C:\Users\30943\Desktop\划分器算法部分` 提取并重组的 L1 实现。输入边界固定为**已经完成的 L2**，流程不会重新推断 L2，也不会跨 L2 域配对。

## 已提取的现有思想和文件

| 来源 | 提取内容 | 在本目录中的落点 |
| --- | --- | --- |
| `划分器LLM部分/iterative_partition/annotation.py` | 逐器件标注、完整覆盖校验、置信度和 JSON 结构 | `llm_function.py` 的 prompt/校验 |
| `划分器LLM部分/iterative_partition/model.py`、`io.py` | 组件/网络输入的兼容形状和基本校验 | `l1_flow.py` 的 `normalize_netlist` |
| `划分器LLM部分/iterative_partition/api_client.py` | OpenAI 兼容接口调用方式 | `llm_function.py` 的 `OpenAIJSONClient` |
| `划分器算法部分/partitioner/l1_partition.py` | L2 大器件域、锚点、拓扑连接证据、唯一归属审计 | `normalize_l2`、`score_pairs`、`select_l1_pairs` |
| `划分器算法部分/当前进度与问题_20261017.md` | L2 是父域，L1 是其子簇；公共电源/地不应造成无关合并 | 本实现的 L2 边界和一跳策略 |

旧 LLM 工程的 README 明确写着“不会输出或计算 L3/L2/L1”。因此本目录没有直接复用它的旧分区代码，而是只复用逐器件功能识别契约，并把新的 L1 算法放在 L2 之后。

## 新流程

1. 读取网表和已有 L2 JSON；每个器件必须且只能属于一个 L2（可用 `--allow-unassigned-l2` 将遗漏器件放入审计用保底域）。
2. LLM 只看器件自身字段（位号、型号、值、封装、类型、引脚属性），输出功能类别、功能说明、置信度。prompt 不发送 `nets`，明确禁止网络语义识别、簇和配对。
3. 对每个 L2 选择其 `anchor`；若 L2 没有 anchor，按器件类型选择一个大器件。只构建 anchor 的**一跳直接邻居集合**，不做二跳或更深递归。
4. 只对同一 L2 内、直接共享网络的两个小器件生成候选对；候选对中至少一个器件应在 anchor 的一跳邻居集合中。网络名称只作为拓扑证据写入审计，不转译为 VIN/VOUT/GND 等语义。
5. 算法拓扑分和 LLM 功能相似分加权汇总。默认 `拓扑 0.6 + 功能 0.4`，超过阈值的候选按分数从高到低贪心选择，器件不得重复使用。
6. 未被选中的器件保留为 L1 单例（anchor 单例和普通未配对单例区分），保证全覆盖和可追溯。

## 输入示例

网表可以采用 LLM 工程的格式，也可以直接选择 EasyEDA 导出的 `.json`/`.enet` 网表。对于 EasyEDA 格式，程序会从 `components` 对象映射读取器件，从每个器件的 `props.Designator` 读取位号，并从 `pinInfoMap` 自动重建网络和引脚关系。\n\n网表可以采用 LLM 工程的格式：

```json
{"components":[{"id":"U1","kind":"ic"},{"id":"C1","kind":"capacitor"}],
 "nets":[{"id":"N1","pins":[{"component":"U1"},{"component":"C1"}]}]}
```

L2 只需包含 `l2_domains`（也兼容 `domains`、`l1_1_domains`、`l2_clusters`）：

```json
{"l2_domains":[{"id":"L2-001","anchor":"U1","members":["U1","C1"]}]}
```

功能标注可直接使用 LLM 工程输出的 `device_annotations.json`。

## 运行

离线使用已有标注：

```powershell
python run_l1.py netlist.json l2.json --annotations device_annotations.json --out output
```

只生成发给模型的功能识别 prompt：

```powershell
python run_l1.py netlist.json l2.json --write-prompt-only --out output
```

需要模型时可使用 `--mode qwen` 或 `--mode deepseek`，并提供 `--api-key-file`（或设置 `OPENAI_API_KEY`）。

输出包括：

- `llm_function_prompt.json`：不含 nets 的功能识别 prompt；
- `function_annotations.json`：标准化的逐器件功能结果；
- `pair_scores.json/csv`：每一对候选的拓扑分、功能分、聚合分和证据；
- `l1_result.json`、`l1_assignments.csv`：最终 L1 簇和器件唯一归属；
- `run.json`：输入计数、完成状态和策略摘要。

## 可视化界面与多轮稳定性

双击 `启动L1_GUI.cmd`（或运行 `python gui.py`）打开界面。主区域带有右侧垂直滚动条和鼠标滚轮支持，窗口缩小时仍可访问所有参数。界面可以选择网表、L2、功能标注文件和输出目录，并选择离线标注、Qwen API 或 DeepSeek API。 选择 Qwen API 或 DeepSeek API 后，直接上传对应的接口文档即可；界面分别提供“千问接口文档”和“DeepSeek 接口文档”两个入口，代码会读取文档中的“模型名”“Base URL”“API”（也兼容常见英文键名），不需要再逐项填写。文档只在本机读取，API key 不会写入界面日志或输出报告。

“独立轮数”设为大于 1 后，每轮都会保存到 `round_01/`、`round_02/` 等目录，并生成 `stability_report.json`。报告包含：

- 器件功能类别稳定性；
- 器件功能说明稳定性；
- 每个器件最终 L1 配对稳定性；
- 各轮 L1 pair 集合的平均 Jaccard 相似度；
- 每个器件各轮的类别、说明和配对明细。

已有多轮标注可以写成：

```json
{"rounds": [
  {"annotations": [...]},
  {"annotations": [...]}
]}
```

然后在 GUI 中选择该文件并设置轮数。若使用 Qwen/DeepSeek 模式，则每轮独立调用一次模型，模型温度固定为低值以便观察剩余不稳定性。

## 重要边界

本实现不把“同 GND/同电源网”当作功能相近证据，不让 LLM 识别网络语义，不从一个 L2 跨到另一个 L2，也不允许二跳递归自动扩大候选范围。它输出的是可审计的 pair-first L1 基线；如果工程规则需要三元功能单元，应在 pair 选择后的独立合并阶段明确增加规则。

