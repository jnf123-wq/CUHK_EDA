"""Tkinter GUI for the known-L2 L1 flow, with vertical scrolling and rounds."""
from __future__ import annotations

import json
import queue
import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk
from tkinter.scrolledtext import ScrolledText

from l1_flow import load_json, normalize_netlist, save_json
from llm_function import OpenAIJSONClient, build_function_prompt, read_model_config, recognize_functions
from multi_round import annotations_rounds_from_file, run_multi_round


class ScrollableFrame(ttk.Frame):
    def __init__(self, parent: tk.Misc, **kwargs):
        super().__init__(parent, **kwargs)
        self.canvas = tk.Canvas(self, highlightthickness=0)
        self.scrollbar = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.body = ttk.Frame(self.canvas, padding=14)
        self.window_id = self.canvas.create_window((0, 0), window=self.body, anchor="nw")
        self.canvas.configure(yscrollcommand=self.scrollbar.set)
        self.canvas.grid(row=0, column=0, sticky="nsew")
        self.scrollbar.grid(row=0, column=1, sticky="ns")
        self.columnconfigure(0, weight=1)
        self.rowconfigure(0, weight=1)
        self.body.bind("<Configure>", self._on_body_configure)
        self.canvas.bind("<Configure>", self._on_canvas_configure)
        self.canvas.bind_all("<MouseWheel>", self._on_mousewheel, add="+")
        self.canvas.bind_all("<Button-4>", lambda event: self.canvas.yview_scroll(-3, "units"), add="+")
        self.canvas.bind_all("<Button-5>", lambda event: self.canvas.yview_scroll(3, "units"), add="+")

    def _on_body_configure(self, _event=None):
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def _on_canvas_configure(self, event):
        self.canvas.itemconfigure(self.window_id, width=event.width)

    def _on_mousewheel(self, event):
        if self.canvas.winfo_exists():
            self.canvas.yview_scroll(int(-event.delta / 120), "units")


class L1Gui:
    def __init__(self, root: tk.Tk):
        self.root = root
        root.title("针对已知 L2 的 L1 划分器")
        root.geometry("980x760")
        root.minsize(760, 560)
        # Bring the window to the foreground when launched through pythonw;
        # otherwise Windows may create it behind the currently focused app.
        root.deiconify()
        root.lift()
        root.attributes("-topmost", True)
        root.after(700, lambda: root.attributes("-topmost", False))
        self.queue: queue.Queue[tuple[str, object]] = queue.Queue()
        self.vars = {name: tk.StringVar() for name in (
            "netlist", "l2", "annotations", "output", "qwen_doc", "deepseek_doc", "rounds", "threshold",
            "topology_weight", "function_weight")}
        self.vars["rounds"].set("1")
        self.vars["threshold"].set("50")
        self.vars["topology_weight"].set("0.6")
        self.vars["function_weight"].set("0.4")
        self.mode = tk.StringVar(value="离线标注文件")
        self.status = tk.StringVar(value="等待运行")
        self._build()
        self.root.after(100, self._poll_queue)

    def _build(self):
        outer = ttk.Frame(self.root)
        outer.pack(fill="both", expand=True)
        frame = ScrollableFrame(outer)
        frame.pack(fill="both", expand=True)
        body = frame.body
        ttk.Label(body, text="已知 L2 → L1 拓扑 + 功能评分", font=("Microsoft YaHei UI", 18, "bold")).grid(row=0, column=0, columnspan=3, sticky="w")
        ttk.Label(body, text="LLM 只识别器件功能；候选只在同一 L2 内生成，并限制为锚点一跳范围。", foreground="#555").grid(row=1, column=0, columnspan=3, sticky="w", pady=(2, 14))

        section = 2
        self._path_row(body, section, "网表 JSON", "netlist", filetypes=[("JSON", "*.json"), ("所有文件", "*.*")]); section += 1
        self._path_row(body, section, "已有 L2 JSON", "l2", filetypes=[("JSON", "*.json"), ("所有文件", "*.*")]); section += 1
        self._path_row(body, section, "已有功能标注（可选）", "annotations", filetypes=[("JSON", "*.json"), ("所有文件", "*.*")]); section += 1
        self._path_row(body, section, "输出目录", "output", directory=True); section += 1

        box = ttk.LabelFrame(body, text="功能识别来源", padding=10)
        box.grid(row=section, column=0, columnspan=3, sticky="ew", pady=(10, 8)); box.columnconfigure(1, weight=1)
        ttk.Label(box, text="运行模式").grid(row=0, column=0, sticky="w")
        mode = ttk.Combobox(box, textvariable=self.mode, values=("离线标注文件", "Qwen API", "DeepSeek API"), state="readonly", width=18)
        mode.grid(row=0, column=1, sticky="w"); mode.bind("<<ComboboxSelected>>", lambda _e: self._update_mode_state())
        self._entry_row(box, 1, "千问接口文档", "qwen_doc", browse=True, filetypes=[("接口文档", "*.txt *.env *.md"), ("所有文件", "*.*")])
        self._entry_row(box, 2, "DeepSeek 接口文档", "deepseek_doc", browse=True, filetypes=[("接口文档", "*.txt *.env *.md"), ("所有文件", "*.*")])
        ttk.Label(box, text="文档需包含模型名、Base URL、API；程序自动读取，不显示密钥。", foreground="#555").grid(row=3, column=1, columnspan=3, sticky="w", pady=(2, 4))
        section += 1

        settings = ttk.LabelFrame(body, text="多轮运行与评分", padding=10)
        settings.grid(row=section, column=0, columnspan=3, sticky="ew", pady=(0, 8)); settings.columnconfigure(1, weight=1); settings.columnconfigure(3, weight=1)
        self._entry_row(settings, 0, "独立轮数（重复识别）", "rounds", width=12)
        self._entry_row(settings, 1, "配对阈值", "threshold", width=12)
        self._entry_row(settings, 2, "拓扑权重", "topology_weight", width=12)
        self._entry_row(settings, 3, "功能权重", "function_weight", width=12)
        section += 1

        actions = ttk.Frame(body)
        actions.grid(row=section, column=0, columnspan=3, sticky="ew", pady=(4, 8)); actions.columnconfigure(2, weight=1)
        self.run_button = ttk.Button(actions, text="开始运行", command=self.start)
        self.run_button.grid(row=0, column=0, padx=(0, 8))
        ttk.Button(actions, text="只生成功能 Prompt", command=self.write_prompt).grid(row=0, column=1, padx=(0, 8))
        ttk.Label(actions, textvariable=self.status).grid(row=0, column=2, sticky="e")

        report_box = ttk.LabelFrame(body, text="运行日志与稳定性报告", padding=8)
        report_box.grid(row=section + 1, column=0, columnspan=3, sticky="nsew")
        self.report = ScrolledText(report_box, height=18, wrap="word", state="disabled")
        self.report.pack(fill="both", expand=True)
        body.columnconfigure(1, weight=1)

        self._update_mode_state()

    def _entry_row(self, parent, row, label, key, *, width=48, browse=False, filetypes=None):
        ttk.Label(parent, text=label).grid(row=row, column=0, sticky="w", padx=(0, 8), pady=3)
        entry = ttk.Entry(parent, textvariable=self.vars[key], width=width)
        entry.grid(row=row, column=1, columnspan=2, sticky="ew", pady=3)
        if browse:
            ttk.Button(parent, text="选择", command=lambda: self._browse_file(key, filetypes or [("所有文件", "*.*")])).grid(row=row, column=3, padx=(8, 0))

    def _path_row(self, parent, row, label, key, *, filetypes=None, directory=False):
        ttk.Label(parent, text=label).grid(row=row, column=0, sticky="w", padx=(0, 8), pady=4)
        ttk.Entry(parent, textvariable=self.vars[key]).grid(row=row, column=1, columnspan=2, sticky="ew", pady=4)
        if directory:
            command = lambda: self._browse_dir(key)
        else:
            command = lambda: self._browse_file(key, filetypes or [("所有文件", "*.*")])
        ttk.Button(parent, text="选择", command=command).grid(row=row, column=3, padx=(8, 0))

    def _browse_file(self, key, filetypes):
        path = filedialog.askopenfilename(filetypes=filetypes)
        if path:
            self.vars[key].set(path)

    def _browse_dir(self, key):
        path = filedialog.askdirectory()
        if path:
            self.vars[key].set(path)

    def _update_mode_state(self):
        if self.mode.get() == "离线标注文件":
            self.status.set("离线模式：需要功能标注 JSON")
        else:
            provider = "千问" if self.mode.get() == "Qwen API" else "DeepSeek"
            self.status.set(f"模型模式：从{provider}接口文档读取配置")

    def _append(self, text):
        self.report.configure(state="normal")
        self.report.insert("end", text + "\n")
        self.report.see("end")
        self.report.configure(state="disabled")

    def _validate_common(self):
        netlist_path, l2_path, out = (Path(self.vars[key].get().strip()) for key in ("netlist", "l2", "output"))
        if not netlist_path.is_file(): raise ValueError("请选择有效的网表 JSON")
        if not l2_path.is_file(): raise ValueError("请选择有效的 L2 JSON")
        if not str(out): raise ValueError("请选择输出目录")
        rounds = int(self.vars["rounds"].get()); threshold = float(self.vars["threshold"].get())
        tw, fw = float(self.vars["topology_weight"].get()), float(self.vars["function_weight"].get())
        if rounds < 1 or threshold < 0 or tw < 0 or fw < 0 or tw + fw <= 0: raise ValueError("轮数和评分参数不合法")
        return netlist_path, l2_path, out, rounds, threshold, tw, fw

    def write_prompt(self):
        try:
            netlist_path, _l2, out, *_ = self._validate_common()
            out.mkdir(parents=True, exist_ok=True)
            save_json(out / "llm_function_prompt.json", build_function_prompt(normalize_netlist(load_json(netlist_path))))
            self._append(f"已生成：{out / 'llm_function_prompt.json'}")
        except Exception as exc:
            messagebox.showerror("参数错误", str(exc))

    def start(self):
        try:
            args = self._validate_common()
            mode = self.mode.get()
            annotation_path = self.vars["annotations"].get().strip()
            if mode == "离线标注文件" and not Path(annotation_path).is_file():
                raise ValueError("离线模式请选择功能标注 JSON")
            model_config = None
            if mode != "离线标注文件":
                doc_key = "qwen_doc" if mode == "Qwen API" else "deepseek_doc"
                doc_path = self.vars[doc_key].get().strip()
                if not doc_path or not Path(doc_path).is_file():
                    provider = "千问" if mode == "Qwen API" else "DeepSeek"
                    raise ValueError(f"请选择{provider}接口文档")
                model_config = read_model_config(doc_path)
        except Exception as exc:
            messagebox.showerror("参数错误", str(exc)); return
        self.run_button.configure(state="disabled"); self.status.set("运行中…")
        threading.Thread(target=self._worker, args=(args, mode, annotation_path, model_config), daemon=True).start()

    def _worker(self, args, mode, annotation_path, model_config=None):
        try:
            netlist_path, l2_path, out, rounds, threshold, tw, fw = args
            netlist, l2 = load_json(netlist_path), load_json(l2_path)
            if mode == "离线标注文件":
                round_values = annotations_rounds_from_file(annotation_path, rounds)
                provider = lambda number: round_values[number - 1]
            else:
                if not model_config:
                    raise ValueError("模型接口配置未读取，请重新选择接口文档")
                client = OpenAIJSONClient(base_url=model_config["base_url"],
                                          model=model_config["model"], api_key=model_config["api_key"])
                normalized = normalize_netlist(netlist)
                provider = lambda _number: recognize_functions(normalized, client)
            payload = run_multi_round(netlist, l2, rounds, provider, out,
                                      config={"pair_threshold": threshold, "topology_weight": tw, "function_weight": fw})
            self.queue.put(("success", payload))
        except Exception as exc:
            self.queue.put(("error", str(exc)))

    def _poll_queue(self):
        try:
            kind, payload = self.queue.get_nowait()
            if kind == "error":
                self.status.set("运行失败"); self._append("错误：" + str(payload)); messagebox.showerror("运行失败", str(payload))
            else:
                report = payload["stability"]
                self.status.set("运行完成")
                self._append(json.dumps({"轮数": report["round_count"], "功能类别稳定性": report["function_category_stability"],
                                         "功能说明稳定性": report["function_description_stability"],
                                         "L1配对稳定性": report["l1_pair_stability"],
                                         "L1配对Jaccard": report["l1_pair_jaccard_mean"]}, ensure_ascii=False, indent=2))
                self._append("详细报告：" + str(Path(self.vars["output"].get()) / "stability_report.json"))
            self.run_button.configure(state="normal")
        except queue.Empty:
            pass
        self.root.after(100, self._poll_queue)


def main():
    root = tk.Tk()
    L1Gui(root)
    root.mainloop()


if __name__ == "__main__":
    main()

