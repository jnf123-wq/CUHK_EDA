"""L1 pairing flow constrained by an existing L2 partition.

The module deliberately separates three kinds of evidence:

* topology evidence is computed locally from direct netlist adjacency;
* function evidence comes from per-device LLM annotations;
* L2 membership is an input boundary and is never inferred here.

No net name is translated into a semantic label and no pair is formed across
two L2 domains.  The anchor traversal is intentionally one hop deep.
"""
from __future__ import annotations

import csv
import json
import re
from collections import defaultdict
from pathlib import Path
from typing import Any, Mapping


SCHEMA = "l1-within-l2-v1"
DEFAULT_CONFIG = {
    "topology_weight": 0.6,
    "function_weight": 0.4,
    "pair_threshold": 50.0,
    "topology_direct": 55.0,
    "topology_shared_net": 15.0,
    "topology_anchor_scope": 15.0,
    "topology_multiple_net": 15.0,
}


def load_json(path: str | Path) -> Any:
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def save_json(path: str | Path, value: Any) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def component_id(component: Mapping[str, Any]) -> str:
    value = component.get("id", component.get("ref", component.get("designator")))
    if value is None or not str(value).strip():
        raise ValueError("每个器件必须有非空 id/ref/designator")
    return str(value).strip()


def normalize_netlist(raw: Mapping[str, Any]) -> dict[str, Any]:
    """Accept the LLM project's JSON netlist and the algorithm project's topology."""
    if not isinstance(raw, Mapping):
        raise ValueError("网表必须是 JSON 对象")
    components: list[dict[str, Any]] = []
    seen: set[str] = set()
    raw_components = raw.get("components", [])
    if isinstance(raw_components, Mapping):
        component_items = raw_components.items()
    elif isinstance(raw_components, list):
        component_items = ((None, item) for item in raw_components)
    else:
        raise ValueError("components 必须是对象数组或对象映射")
    derived_nets: dict[str, list[dict[str, str]]] = defaultdict(list)
    for source_key, raw_item in component_items:
        if not isinstance(raw_item, Mapping):
            raise ValueError("components 中的器件必须是对象")
        # EasyEDA .enet/JSON stores components under internal keys (gge1, ...)
        # and puts the human reference plus all part data in props.
        props = raw_item.get("props", {})
        props = props if isinstance(props, Mapping) else {}
        item = {**dict(raw_item), **{str(k): v for k, v in props.items() if str(k) not in raw_item}}
        if source_key is not None and not any(item.get(key) for key in ("id", "ref", "designator", "Designator")):
            item["id"] = str(source_key)
        if item.get("Designator") and not item.get("designator"):
            item["designator"] = item["Designator"]
        if item.get("DeviceName") and not item.get("kind"):
            item["kind"] = item["DeviceName"]
        cid = component_id(item)
        if cid in seen:
            # Preserve a unique internal reference if a source export contains
            # duplicate designators, while normal exports retain Designator IDs.
            cid = str(source_key or cid)
        if cid in seen:
            raise ValueError(f"器件重复：{cid}")
        seen.add(cid)
        row = dict(item)
        row["id"] = cid
        pin_map = raw_item.get("pinInfoMap", item.get("pinInfoMap", {}))
        if isinstance(pin_map, Mapping):
            pins = []
            for pin_key, pin_value in pin_map.items():
                if not isinstance(pin_value, Mapping):
                    continue
                pin_id = str(pin_value.get("number", pin_key))
                pin_name = str(pin_value.get("name", ""))
                net_name = str(pin_value.get("net", "") or "").strip()
                pins.append({"id": pin_id, "number": pin_id, "name": pin_name, "net": net_name})
                if net_name:
                    derived_nets[net_name].append({"component": cid, "pin": pin_id})
            if pins:
                row["pins"] = pins
        components.append(row)
    if not components:
        raise ValueError("网表没有器件")
    nets: dict[str, list[dict[str, str]]] = {}
    raw_nets = raw.get("nets")
    if raw_nets is None:
        raw_nets = derived_nets
    if isinstance(raw_nets, Mapping):
        iterator = raw_nets.items()
        for name, endpoints in iterator:
            rows = endpoints if isinstance(endpoints, list) else []
            normalized = []
            for endpoint in rows:
                if not isinstance(endpoint, Mapping):
                    continue
                ref = endpoint.get("c", endpoint.get("component", endpoint.get("ref")))
                if ref is None:
                    continue
                normalized.append({"component": str(ref), "pin": str(endpoint.get("pin", endpoint.get("name", "")))})
            nets[str(name)] = normalized
    elif isinstance(raw_nets, list):
        for item in raw_nets:
            if not isinstance(item, Mapping):
                raise ValueError("nets 必须是对象数组或对象映射")
            name = str(item.get("id", item.get("name", ""))).strip()
            if not name:
                raise ValueError("每个网络必须有 id/name")
            endpoints = item.get("pins", item.get("endpoints", item.get("components", [])))
            normalized = []
            for endpoint in endpoints if isinstance(endpoints, list) else []:
                if isinstance(endpoint, Mapping):
                    ref = endpoint.get("component", endpoint.get("c", endpoint.get("ref")))
                    pin = endpoint.get("pin", endpoint.get("name", ""))
                else:
                    ref, pin = endpoint, ""
                if ref is not None:
                    normalized.append({"component": str(ref), "pin": str(pin)})
            nets[name] = normalized
    else:
        raise ValueError("nets 必须是对象映射或对象数组")
    unknown = sorted({ep["component"] for rows in nets.values() for ep in rows} - seen)
    if unknown:
        raise ValueError(f"网络引用了未知器件：{unknown}")
    return {**{k: v for k, v in raw.items() if k not in {"components", "nets"}},
            "schema": "l1-netlist-v1", "components": components, "nets": nets}


def _unwrap_l2(raw: Any) -> list[Mapping[str, Any]]:
    if isinstance(raw, list):
        return [x for x in raw if isinstance(x, Mapping)]
    if not isinstance(raw, Mapping):
        raise ValueError("L2 文件必须是对象或数组")
    for key in ("l2_domains", "domains", "l1_1_domains", "l2_clusters"):
        value = raw.get(key)
        if isinstance(value, list):
            return [x for x in value if isinstance(x, Mapping)]
    for key in ("result", "hierarchy"):
        if isinstance(raw.get(key), Mapping):
            return _unwrap_l2(raw[key])
    raise ValueError("L2 文件缺少 l2_domains/domains/l1_1_domains/l2_clusters")


def normalize_l2(raw: Any, refs: set[str], *, allow_unassigned: bool = False) -> list[dict[str, Any]]:
    domains = []
    owners: dict[str, str] = {}
    for index, source in enumerate(_unwrap_l2(raw), 1):
        members = source.get("members", source.get("components", []))
        if not isinstance(members, list):
            raise ValueError(f"L2 域 {index} 的 members 必须是数组")
        members = sorted({str(x) for x in members if str(x).strip()})
        unknown = sorted(set(members) - refs)
        if unknown:
            raise ValueError(f"L2 域引用未知器件：{unknown}")
        domain_id = str(source.get("id", f"L2-{index:03d}"))
        duplicate = sorted(set(members) & set(owners))
        if duplicate:
            raise ValueError(f"器件被多个 L2 域占用：{duplicate}")
        anchor = source.get("anchor")
        anchor = str(anchor) if anchor is not None and str(anchor) in members else None
        row = {"id": domain_id, "anchor": anchor, "members": members,
               "source": dict(source)}
        domains.append(row)
        owners.update({ref: domain_id for ref in members})
    missing = sorted(refs - set(owners))
    if missing and not allow_unassigned:
        raise ValueError(f"L2 未覆盖器件：{missing}；请先完成 L2，或使用 --allow-unassigned")
    if missing:
        domains.append({"id": f"L2-{len(domains)+1:03d}", "anchor": None,
                        "members": missing, "source": {"assignment_reason": "unassigned_input"}})
    if not domains:
        raise ValueError("L2 没有有效域")
    return domains


def normalize_annotations(raw: Any, refs: set[str], *, allow_missing: bool = False) -> dict[str, dict[str, Any]]:
    """Normalize the current LLM project's device_annotations.json shape.

    Only function fields are retained.  Network semantics, candidate clusters,
    and related-component suggestions are intentionally ignored.
    """
    if isinstance(raw, Mapping):
        rows = raw.get("annotations", raw.get("components", raw.get("assignments", [])))
    else:
        rows = raw
    if isinstance(rows, Mapping):
        rows = [dict(value, component_id=key) for key, value in rows.items() if isinstance(value, Mapping)]
    if not isinstance(rows, list):
        raise ValueError("功能标注必须包含 annotations 数组")
    result: dict[str, dict[str, Any]] = {}
    for item in rows:
        if not isinstance(item, Mapping):
            raise ValueError("功能标注条目必须是对象")
        cid = str(item.get("component_id", item.get("id", item.get("ref", item.get("L0_Device", ""))))).strip()
        if cid not in refs:
            raise ValueError(f"功能标注包含未知器件：{cid or '(空)'}")
        if cid in result:
            raise ValueError(f"功能标注重复：{cid}")
        category = item.get("functional_category", item.get("功能类别", item.get("standard_function")))
        if category is None:
            tags = item.get("function_tags", item.get("roles", item.get("role", [])))
            category = tags[0] if isinstance(tags, list) and tags else tags
        category = str(category or "未知功能").strip() or "未知功能"
        description = str(item.get("function_description", item.get("功能说明", item.get("description", "")))).strip()
        result[cid] = {"component_id": cid, "functional_category": category,
                       "function_description": description,
                       "confidence": float(item.get("confidence", item.get("置信度", 0.0)) or 0.0),
                       "evidence": str(item.get("evidence", item.get("识别依据", ""))).strip(),
                       "status": str(item.get("识别状态", "已识别"))}
    missing = sorted(refs - set(result))
    if missing and not allow_missing:
        raise ValueError(f"功能标注遗漏器件：{missing}")
    for cid in missing:
        result[cid] = {"component_id": cid, "functional_category": "未知功能",
                       "function_description": "未提供 LLM 功能标注", "confidence": 0.0,
                       "evidence": "missing_annotation", "status": "未标注"}
    return result


def _component_nets(netlist: Mapping[str, Any]) -> dict[str, set[str]]:
    result: dict[str, set[str]] = defaultdict(set)
    for name, endpoints in netlist.get("nets", {}).items():
        for endpoint in endpoints:
            result[str(endpoint["component"])].add(str(name))
    return result


def _adjacency(netlist: Mapping[str, Any]) -> dict[tuple[str, str], list[str]]:
    by_pair: dict[tuple[str, str], list[str]] = defaultdict(list)
    for name, endpoints in netlist.get("nets", {}).items():
        refs = sorted({str(ep["component"]) for ep in endpoints})
        for index, left in enumerate(refs):
            for right in refs[index + 1:]:
                by_pair[(left, right)].append(str(name))
    return by_pair


def _tokens(value: Any) -> set[str]:
    text = str(value or "").lower()
    # Chinese characters are retained individually; Latin words/numbers stay as tokens.
    return set(re.findall(r"[a-z0-9_]+|[\u4e00-\u9fff]", text))


def function_score(left: Mapping[str, Any], right: Mapping[str, Any]) -> tuple[float, dict[str, Any]]:
    lc, rc = str(left.get("functional_category", "未知功能")), str(right.get("functional_category", "未知功能"))
    ld, rd = left.get("function_description", ""), right.get("function_description", "")
    category_exact = lc == rc and lc not in {"未知功能", "已跳过识别"}
    category_tokens = _tokens(lc) & _tokens(rc)
    category_union = _tokens(lc) | _tokens(rc)
    desc_tokens = _tokens(ld) & _tokens(rd)
    desc_union = _tokens(ld) | _tokens(rd)
    category_similarity = len(category_tokens) / len(category_union) if category_union else 0.0
    description_similarity = len(desc_tokens) / len(desc_union) if desc_union else 0.0
    score = 70.0 * (1.0 if category_exact else category_similarity) + 30.0 * description_similarity
    if lc in {"未知功能", "已跳过识别"} or rc in {"未知功能", "已跳过识别"}:
        score *= 0.35
    evidence = {"left_category": lc, "right_category": rc,
                "category_exact": category_exact,
                "category_similarity": round(category_similarity, 6),
                "description_similarity": round(description_similarity, 6),
                "left_confidence": float(left.get("confidence", 0.0) or 0.0),
                "right_confidence": float(right.get("confidence", 0.0) or 0.0)}
    return round(max(0.0, min(100.0, score)), 6), evidence


def topology_score(shared_nets: list[str], *, anchor_scoped: bool, config: Mapping[str, Any]) -> tuple[float, dict[str, Any]]:
    direct = float(config.get("topology_direct", DEFAULT_CONFIG["topology_direct"]))
    per_net = float(config.get("topology_shared_net", DEFAULT_CONFIG["topology_shared_net"]))
    multiple = float(config.get("topology_multiple_net", DEFAULT_CONFIG["topology_multiple_net"]))
    scope = float(config.get("topology_anchor_scope", DEFAULT_CONFIG["topology_anchor_scope"])) if anchor_scoped else 0.0
    score = direct + min(1, len(shared_nets)) * per_net + (multiple if len(shared_nets) > 1 else 0.0) + scope
    return round(min(100.0, score), 6), {"direct_connection": True, "shared_nets": list(shared_nets),
                                       "shared_net_count": len(shared_nets), "anchor_scoped": anchor_scoped,
                                       "semantic_inference": False}


def _major_like(component: Mapping[str, Any]) -> bool:
    text = " ".join(str(component.get(key, "")) for key in ("kind", "role", "part", "value", "functional_group")).lower()
    return str(component.get("id", "")).upper().startswith(("U", "IC", "MCU")) or any(
        token in text for token in ("ic", "controller", "processor", "fpga", "module", "driver"))


def score_pairs(netlist: Mapping[str, Any], domains: list[Mapping[str, Any]], annotations: Mapping[str, Mapping[str, Any]],
                config: Mapping[str, Any] | None = None) -> list[dict[str, Any]]:
    cfg = {**DEFAULT_CONFIG, **(config or {})}
    components = {str(item["id"]): item for item in netlist["components"]}
    comp_nets = _component_nets(netlist)
    adjacency = _adjacency(netlist)
    rows: list[dict[str, Any]] = []
    for domain in domains:
        members = [str(ref) for ref in domain.get("members", [])]
        anchor = str(domain.get("anchor")) if domain.get("anchor") in members else None
        if anchor is None:
            major = sorted(ref for ref in members if _major_like(components.get(ref, {})))
            anchor = major[0] if major else None
        small = [ref for ref in members if ref != anchor and not (_major_like(components.get(ref, {})) and anchor is not None)]
        frontier = set()
        if anchor:
            frontier = {ref for ref in members if ref != anchor and tuple(sorted((anchor, ref))) in adjacency}
        for index, left in enumerate(sorted(small)):
            for right in sorted(small)[index + 1:]:
                shared = adjacency.get(tuple(sorted((left, right))), [])
                if not shared:
                    continue
                # One-level anchor analysis: at least one member must be in the
                # anchor's direct frontier. There is no second-hop expansion.
                anchor_scoped = not anchor or left in frontier or right in frontier
                if anchor and not anchor_scoped:
                    continue
                topo, topo_ev = topology_score(shared, anchor_scoped=anchor_scoped, config=cfg)
                func, func_ev = function_score(annotations[left], annotations[right])
                aggregate = float(cfg["topology_weight"]) * topo + float(cfg["function_weight"]) * func
                rows.append({"l2_domain": str(domain["id"]), "anchor": anchor,
                             "a": left, "b": right, "topology_score": topo,
                             "function_score": func, "aggregate_score": round(aggregate, 6),
                             "topology_evidence": topo_ev, "function_evidence": func_ev,
                             "decision": "candidate" if aggregate >= float(cfg["pair_threshold"]) else "below_threshold"})
    return sorted(rows, key=lambda row: (-row["aggregate_score"], row["l2_domain"], row["a"], row["b"]))


def select_l1_pairs(netlist: Mapping[str, Any], domains: list[Mapping[str, Any]], pair_scores: list[dict[str, Any]],
                    config: Mapping[str, Any] | None = None) -> dict[str, Any]:
    cfg = {**DEFAULT_CONFIG, **(config or {})}
    components = {str(item["id"]): item for item in netlist["components"]}
    selected: list[dict[str, Any]] = []
    used: set[str] = set()
    for row in pair_scores:
        if row["decision"] != "candidate" or row["a"] in used or row["b"] in used:
            row["decision"] = "rejected_overlap_or_threshold" if row["decision"] == "candidate" else row["decision"]
            continue
        members = [row["a"], row["b"]]
        selected.append({"id": f"L1-{len(selected)+1:03d}", "level": "L1",
                         "l2_domain": row["l2_domain"], "anchor": row.get("anchor"),
                         "members": members, "source": "topology_plus_llm_function",
                         "aggregate_score": row["aggregate_score"],
                         "topology_score": row["topology_score"], "function_score": row["function_score"],
                         "pair_score_id": f"P-{len(selected)+1:03d}"})
        used.update(members)
    clusters = list(selected)
    for domain in domains:
        for ref in domain["members"]:
            if ref in used:
                continue
            is_anchor = ref == domain.get("anchor")
            clusters.append({"id": f"L1-{len(clusters)+1:03d}", "level": "L1",
                             "l2_domain": domain["id"], "anchor": ref if is_anchor else domain.get("anchor"),
                             "members": [ref], "source": "anchor_singleton" if is_anchor else "unpaired_singleton",
                             "aggregate_score": 0.0, "topology_score": 0.0, "function_score": 0.0})
            used.add(ref)
    expected = {str(item["id"]) for item in netlist["components"]}
    final_refs = [ref for cluster in clusters for ref in cluster["members"]]
    result = {"schema": SCHEMA, "config": cfg, "l2_domains": domains,
              "l1_clusters": clusters, "pair_scores": pair_scores,
              "assignment": {ref: next(cluster["id"] for cluster in clusters if ref in cluster["members"]) for ref in expected},
              "all_components_once": len(final_refs) == len(set(final_refs)) == len(expected) and set(final_refs) == expected,
              "policy": {"l2_is_input_boundary": True, "llm_identifies_function_only": True,
                         "network_semantics_inferred": False, "anchor_recursion_depth": 1,
                         "pairs_only_when_directly_connected": True}}
    return result


def run_flow(netlist: Mapping[str, Any], l2: Any, annotations: Any, *, config: Mapping[str, Any] | None = None,
             allow_unassigned_l2: bool = False, allow_missing_annotations: bool = False) -> dict[str, Any]:
    normalized = normalize_netlist(netlist)
    refs = {str(item["id"]) for item in normalized["components"]}
    domains = normalize_l2(l2, refs, allow_unassigned=allow_unassigned_l2)
    function_annotations = normalize_annotations(annotations, refs, allow_missing=allow_missing_annotations)
    scores = score_pairs(normalized, domains, function_annotations, config)
    result = select_l1_pairs(normalized, domains, scores, config)
    result["input"] = {"name": normalized.get("name"), "component_count": len(refs),
                        "net_count": len(normalized.get("nets", {}))}
    result["function_annotations"] = function_annotations
    return result


def write_outputs(result: Mapping[str, Any], out_dir: str | Path) -> None:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    save_json(out / "l1_result.json", result)
    save_json(out / "pair_scores.json", {"schema": "l1-pair-scores-v1", "pairs": result["pair_scores"]})
    with (out / "l1_assignments.csv").open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["L1", "L2", "成员", "来源", "聚合分数", "拓扑分数", "功能分数"])
        writer.writeheader()
        for cluster in result["l1_clusters"]:
            writer.writerow({"L1": cluster["id"], "L2": cluster["l2_domain"], "成员": ",".join(cluster["members"]),
                             "来源": cluster["source"], "聚合分数": cluster["aggregate_score"],
                             "拓扑分数": cluster["topology_score"], "功能分数": cluster["function_score"]})
    with (out / "pair_scores.csv").open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["L2", "锚定器件", "器件A", "器件B", "拓扑分数", "功能分数", "聚合分数", "决策", "共享网络"])
        writer.writeheader()
        for row in result["pair_scores"]:
            writer.writerow({"L2": row["l2_domain"], "锚定器件": row.get("anchor") or "", "器件A": row["a"], "器件B": row["b"],
                             "拓扑分数": row["topology_score"], "功能分数": row["function_score"], "聚合分数": row["aggregate_score"],
                             "决策": row["decision"], "共享网络": ",".join(row["topology_evidence"]["shared_nets"])})
    save_json(out / "run.json", {"schema": "l1-run-v1", "status": "completed", "flow_schema": SCHEMA,
                                  "input": result["input"], "all_components_once": result["all_components_once"],
                                  "artifacts": ["l1_result.json", "pair_scores.json", "l1_assignments.csv", "pair_scores.csv"]})

