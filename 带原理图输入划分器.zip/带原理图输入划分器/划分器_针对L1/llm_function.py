"""Function-only LLM stage extracted from ``划分器LLM部分``.

The old project has a stable per-device annotation contract.  This adapter
keeps that contract while making the L1 constraint explicit: the prompt sends
component-local fields only and forbids net semantics, clustering, and L1/L2
decisions.  The returned annotations can be passed to :func:`run_flow`.
"""
from __future__ import annotations

import json
import os
import re
import urllib.request
from pathlib import Path
from typing import Any, Mapping


def build_function_prompt(netlist: Mapping[str, Any]) -> dict[str, Any]:
    components = []
    for component in netlist.get("components", []):
        row = {key: component.get(key, "") for key in ("id", "ref", "designator", "kind", "value", "part", "name", "footprint", "functional_group") if key in component}
        pins = component.get("pins", [])
        if isinstance(pins, list):
            row["pins"] = [{key: pin.get(key, "") for key in ("id", "number", "name") if key in pin}
                           for pin in pins if isinstance(pin, Mapping)]
        components.append(row)
    return {
        "task": "逐个识别器件自身的功能，为后续 L1 配对提供可比较的功能标签。",
        "input": {"name": netlist.get("name"), "components": components},
        "output_schema": {"annotations": [{
            "component_id": "输入中的器件 id",
            "functional_category": "简短、可比较的功能类别",
            "function_description": "只描述该器件自身用途",
            "evidence": "器件型号、封装、值和本地引脚属性等依据",
            "confidence": 0.0,
        }]},
        "rules": [
            "每个器件恰好输出一条标注，component_id 必须与输入完全一致。",
            "只识别单个器件自身功能；不要输出网络语义、网络类别、网络电压含义或网络名称解释。",
            "不要输出 L1/L2/L3、簇、配对、分组、锚定器件或分区结果。",
            "不要依据器件之间的连接推断功能；输入刻意不包含网络列表，不能补造网络证据。",
            "功能类别应简短、可比较；不确定时写未知功能并降低 confidence。",
            "输出有效 JSON，不要 Markdown 或额外解释。",
        ],
    }


class OpenAIJSONClient:
    """Minimal OpenAI-compatible client; kept optional for offline scoring."""

    def __init__(self, *, base_url: str, model: str, api_key: str, timeout: int = 120):
        self.base_url, self.model, self.api_key, self.timeout = base_url.rstrip("/"), model, api_key, timeout

    def ask(self, prompt: Mapping[str, Any]) -> dict[str, Any]:
        body = {"model": self.model,
                "messages": [{"role": "system", "content": "你是电子器件功能识别工程师，只输出 JSON。"},
                             {"role": "user", "content": json.dumps(prompt, ensure_ascii=False)}],
                "temperature": 0.1, "response_format": {"type": "json_object"}}
        request = urllib.request.Request(self.base_url + "/chat/completions",
            data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
            headers={"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"}, method="POST")
        with urllib.request.urlopen(request, timeout=self.timeout) as response:
            payload = json.loads(response.read().decode("utf-8"))
        content = payload["choices"][0]["message"]["content"]
        if isinstance(content, str):
            content = content.strip()
            if content.startswith("```"):
                content = content.split("\n", 1)[1].rsplit("```", 1)[0]
            return json.loads(content)
        if isinstance(content, Mapping):
            return dict(content)
        raise ValueError("模型没有返回 JSON 对象")


def recognize_functions(netlist: Mapping[str, Any], client: Any) -> dict[str, Any]:
    """Call a compatible client and validate complete per-device coverage."""
    raw = client.ask(build_function_prompt(netlist))
    refs = {str(item.get("id", item.get("ref", item.get("designator")))) for item in netlist.get("components", [])}
    rows = raw.get("annotations", raw.get("components", [])) if isinstance(raw, Mapping) else []
    if not isinstance(rows, list):
        raise ValueError("模型输出缺少 annotations 数组")
    normalized: dict[str, dict[str, Any]] = {}
    for item in rows:
        if not isinstance(item, Mapping):
            raise ValueError("模型标注条目必须是对象")
        cid = str(item.get("component_id", item.get("id", item.get("ref", "")))).strip()
        if cid not in refs or cid in normalized:
            raise ValueError(f"模型输出了未知或重复器件：{cid}")
        category = str(item.get("functional_category", "")).strip()
        description = str(item.get("function_description", "")).strip()
        if not category or not description:
            raise ValueError(f"{cid} 缺少 functional_category/function_description")
        confidence = float(item.get("confidence", 0.0) or 0.0)
        if not 0 <= confidence <= 1:
            raise ValueError(f"{cid} 的 confidence 必须在 0 到 1 之间")
        normalized[cid] = {"component_id": cid, "functional_category": category,
                           "function_description": description,
                           "evidence": str(item.get("evidence", "")).strip(),
                           "confidence": confidence, "识别状态": "已识别"}
    missing = sorted(refs - set(normalized))
    if missing:
        raise ValueError(f"模型遗漏器件：{missing}")
    return {"schema": "l1-function-annotations-v1", "annotations": [normalized[ref] for ref in sorted(refs)],
            "policy": {"function_only": True, "network_semantics": False, "partitioning": False}}


def read_api_key(path: str | Path | None) -> str:
    if path:
        return Path(path).read_text(encoding="utf-8-sig").strip().split("=", 1)[-1].strip().strip('"\'')
    return os.environ.get("OPENAI_API_KEY", "")


def read_model_config(path: str | Path) -> dict[str, str]:
    """Read a model endpoint document without exposing its API key in the UI.

    Supports the Chinese labels used by the supplied documents (模型名、Base
    URL、API) as well as common English/env-style key names.
    """
    source = Path(path)
    text = source.read_text(encoding="utf-8-sig")
    values: dict[str, str] = {}
    aliases = {
        "model": ("模型名", "模型名称", "model", "model_name"),
        "base_url": ("base url", "base_url", "baseurl", "接口地址", "请求地址", "url"),
        "api_key": ("api key", "api_key", "apikey", "api", "密钥", "令牌", "token"),
    }
    for raw_line in text.splitlines():
        line = raw_line.strip().lstrip("\ufeff")
        if not line or line.startswith(("#", "//", ";")):
            continue
        match = re.match(r"^\s*([^:=：]+?)\s*[:：=]\s*(.*?)\s*$", line)
        if not match:
            continue
        label, value = match.group(1).strip().lower(), match.group(2).strip().strip("\"'")
        for key, names in aliases.items():
            if label in {name.lower() for name in names} and value:
                values[key] = value
                break
    missing = [key for key in ("model", "base_url", "api_key") if not values.get(key)]
    if missing:
        display = {"model": "模型名", "base_url": "Base URL", "api_key": "API Key"}
        raise ValueError(f"接口文档 {source.name} 缺少字段：{', '.join(display[key] for key in missing)}")
    values["base_url"] = values["base_url"].rstrip("/")
    return values

