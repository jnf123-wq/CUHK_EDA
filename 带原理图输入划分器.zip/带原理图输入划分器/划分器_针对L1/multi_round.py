"""Run and persist several independent L1 inference rounds."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

from l1_flow import load_json, run_flow, save_json, write_outputs
from stability import build_stability_report


def annotations_rounds_from_file(path: str | Path, rounds: int) -> list[Any]:
    raw = load_json(path)
    if isinstance(raw, Mapping) and isinstance(raw.get("rounds"), list):
        values = list(raw["rounds"])
        if len(values) < rounds:
            raise ValueError(f"标注文件只有 {len(values)} 轮，无法满足 {rounds} 轮")
        return values[:rounds]
    return [raw for _ in range(rounds)]


def run_multi_round(netlist: Mapping[str, Any], l2: Any, rounds: int,
                    annotation_provider: Callable[[int], Any], out_dir: str | Path,
                    *, config: Mapping[str, Any] | None = None,
                    allow_unassigned_l2: bool = False,
                    allow_missing_annotations: bool = False) -> dict[str, Any]:
    if rounds < 1:
        raise ValueError("rounds 必须大于等于 1")
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    results = []
    for number in range(1, rounds + 1):
        annotations = annotation_provider(number)
        result = run_flow(netlist, l2, annotations, config=config,
                          allow_unassigned_l2=allow_unassigned_l2,
                          allow_missing_annotations=allow_missing_annotations)
        round_dir = out / f"round_{number:02d}"
        write_outputs(result, round_dir)
        results.append(result)
    report = build_stability_report(results)
    save_json(out / "stability_report.json", report)
    save_json(out / "multi_round_manifest.json", {
        "schema": "l1-multi-round-v1", "status": "completed", "round_count": rounds,
        "rounds": [{"round": index, "directory": f"round_{index:02d}"} for index in range(1, rounds + 1)],
        "stability": report,
    })
    return {"results": results, "stability": report}

