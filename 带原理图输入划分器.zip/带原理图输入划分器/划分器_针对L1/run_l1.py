"""Run L1 pairing inside already-known L2 domains."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from l1_flow import load_json, run_flow, save_json, write_outputs, normalize_netlist
from llm_function import OpenAIJSONClient, build_function_prompt, read_api_key, recognize_functions
from multi_round import annotations_rounds_from_file, run_multi_round


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="基于已知 L2 的 L1 拓扑+功能配对流程")
    parser.add_argument("netlist", help="标准 JSON 网表或 EasyEDA 转换后的 JSON")
    parser.add_argument("l2", help="已有 L2 结果 JSON")
    parser.add_argument("--annotations", help="已有 device_annotations.json；省略时需要 API 参数")
    parser.add_argument("--out", default="l1_output", help="输出目录")
    parser.add_argument("--mode", choices=("qwen", "deepseek"), help="没有 --annotations 时调用的兼容 API")
    parser.add_argument("--api-key-file")
    parser.add_argument("--base-url", help="兼容 OpenAI API 的 base URL")
    parser.add_argument("--model")
    parser.add_argument("--pair-threshold", type=float, default=50.0)
    parser.add_argument("--topology-weight", type=float, default=0.6)
    parser.add_argument("--function-weight", type=float, default=0.4)
    parser.add_argument("--rounds", type=int, default=1, help="独立运行轮数；大于 1 时生成 stability_report.json")
    parser.add_argument("--allow-unassigned-l2", action="store_true")
    parser.add_argument("--allow-missing-annotations", action="store_true")
    parser.add_argument("--write-prompt-only", action="store_true", help="只生成不含网络的 LLM 功能识别 prompt")
    args = parser.parse_args(argv)
    out = Path(args.out)
    try:
        netlist = normalize_netlist(load_json(args.netlist))
        out.mkdir(parents=True, exist_ok=True)
        prompt = build_function_prompt(netlist)
        save_json(out / "llm_function_prompt.json", prompt)
        if args.write_prompt_only:
            print(f"已生成仅功能识别 prompt：{(out / 'llm_function_prompt.json').resolve()}")
            return 0
        if args.rounds < 1:
            raise ValueError("--rounds 必须大于等于 1")
        if args.annotations and args.rounds > 1:
            round_values = annotations_rounds_from_file(args.annotations, args.rounds)
            provider = lambda number: round_values[number - 1]
            payload = run_multi_round(netlist, load_json(args.l2), args.rounds, provider, out,
                                      config={"pair_threshold": args.pair_threshold,
                                              "topology_weight": args.topology_weight,
                                              "function_weight": args.function_weight})
            print(f"完成 {args.rounds} 轮；L1 配对稳定性 {payload['stability']['l1_pair_stability']:.2%}；输出：{out.resolve()}")
            return 0
        if args.annotations:
            annotations = load_json(args.annotations)
        else:
            if not args.mode:
                raise ValueError("请提供 --annotations，或指定 --mode 及 API 配置")
            key = read_api_key(args.api_key_file)
            if not key:
                raise ValueError("未找到 API key；请使用 --api-key-file 或 OPENAI_API_KEY")
            defaults = {"qwen": ("https://dashscope.aliyuncs.com/compatible-mode/v1", "qwen3.5-plus"),
                        "deepseek": ("https://api.deepseek.com/v1", "deepseek-chat")}
            base, model = defaults[args.mode]
            client = OpenAIJSONClient(base_url=args.base_url or base, model=args.model or model, api_key=key)
            if args.rounds > 1:
                payload = run_multi_round(
                    netlist, load_json(args.l2), args.rounds,
                    lambda _number: recognize_functions(netlist, client), out,
                    config={"pair_threshold": args.pair_threshold,
                            "topology_weight": args.topology_weight,
                            "function_weight": args.function_weight})
                print(f"完成 {args.rounds} 轮模型调用；L1 配对稳定性 {payload['stability']['l1_pair_stability']:.2%}；输出：{out.resolve()}")
                return 0
            annotations = recognize_functions(netlist, client)
            save_json(out / "function_annotations.json", annotations)
        l2 = load_json(args.l2)
        result = run_flow(netlist, l2, annotations,
                          config={"pair_threshold": args.pair_threshold,
                                  "topology_weight": args.topology_weight,
                                  "function_weight": args.function_weight},
                          allow_unassigned_l2=args.allow_unassigned_l2,
                          allow_missing_annotations=args.allow_missing_annotations)
        write_outputs(result, out)
        if not (out / "function_annotations.json").exists():
            save_json(out / "function_annotations.json", {"schema": "l1-function-annotations-v1",
                                                            "annotations": list(result["function_annotations"].values()),
                                                            "policy": {"function_only": True}})
        print(f"L1 完成：{len(result['l1_clusters'])} 个簇；候选对 {len(result['pair_scores'])} 个；输出：{out.resolve()}")
        return 0
    except (OSError, ValueError, KeyError, json.JSONDecodeError) as exc:
        out.mkdir(parents=True, exist_ok=True)
        try:
            save_json(out / "run.json", {"schema": "l1-run-v1", "status": "failed", "error": str(exc)[:2000]})
        except OSError:
            pass
        print(f"error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())

