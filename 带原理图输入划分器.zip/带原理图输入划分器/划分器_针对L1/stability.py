"""Repeated-run stability reports for the L1 flow."""
from __future__ import annotations

import statistics
from collections import Counter, defaultdict
from typing import Any, Mapping, Sequence


def _mode(values: list[str]) -> str:
    counts = Counter(values)
    return sorted(counts, key=lambda value: (-counts[value], value))[0] if counts else ""


def _pair_map(result: Mapping[str, Any]) -> dict[str, frozenset[str] | None]:
    mapping: dict[str, frozenset[str] | None] = {}
    for cluster in result.get("l1_clusters", []):
        members = [str(x) for x in cluster.get("members", [])]
        if len(members) == 2:
            left, right = sorted(members)
            mapping[left] = frozenset((left, right))
            mapping[right] = frozenset((left, right))
        else:
            for ref in members:
                mapping.setdefault(ref, None)
    return mapping


def build_stability_report(results: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    if not results:
        raise ValueError("至少需要一轮结果")
    rounds = len(results)
    annotations = [result.get("function_annotations", {}) for result in results]
    refs = sorted({str(ref) for rows in annotations for ref in rows})
    function_rows = []
    for ref in refs:
        categories = [str(rows.get(ref, {}).get("functional_category", "未知功能")) for rows in annotations]
        descriptions = [str(rows.get(ref, {}).get("function_description", "")) for rows in annotations]
        category_rate = max(Counter(categories).values()) / rounds if categories else 0.0
        description_rate = max(Counter(descriptions).values()) / rounds if descriptions else 0.0
        function_rows.append({"component_id": ref, "categories": categories,
                              "category_mode": _mode(categories), "category_stability": round(category_rate, 6),
                              "descriptions": descriptions, "description_stability": round(description_rate, 6)})

    pair_maps = [_pair_map(result) for result in results]
    pair_rows = []
    for ref in refs:
        pairs = [mapping.get(ref) for mapping in pair_maps]
        labels = ["+".join(sorted(pair)) if pair else "SINGLETON" for pair in pairs]
        agreement = max(Counter(labels).values()) / rounds if labels else 0.0
        pair_rows.append({"component_id": ref, "pairs": labels, "pair_mode": _mode(labels),
                          "pair_stability": round(agreement, 6)})

    pair_sets = [set(frozenset(pair) for pair in (_pair_map(result).values()) if pair) for result in results]
    jaccards = []
    for index, current in enumerate(pair_sets):
        for other in pair_sets[index + 1:]:
            union = current | other
            jaccards.append(len(current & other) / len(union) if union else 1.0)
    category_mean = statistics.fmean(row["category_stability"] for row in function_rows) if function_rows else 1.0
    description_mean = statistics.fmean(row["description_stability"] for row in function_rows) if function_rows else 1.0
    pair_mean = statistics.fmean(row["pair_stability"] for row in pair_rows) if pair_rows else 1.0
    return {
        "schema": "l1-stability-report-v1",
        "round_count": rounds,
        "component_count": len(refs),
        "pair_count_by_round": [len(pairs) for pairs in pair_sets],
        "function_category_stability": round(category_mean, 6),
        "function_description_stability": round(description_mean, 6),
        "l1_pair_stability": round(pair_mean, 6),
        "l1_pair_jaccard_mean": round(statistics.fmean(jaccards), 6) if jaccards else 1.0,
        "per_component_function": function_rows,
        "per_component_pair": pair_rows,
    }

