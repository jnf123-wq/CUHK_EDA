import unittest

from l1_flow import normalize_annotations, normalize_l2, normalize_netlist, run_flow


class L1FlowTests(unittest.TestCase):
    def setUp(self):
        self.netlist = normalize_netlist({
            "components": [
                {"id": "U1", "kind": "ic"},
                {"id": "C1", "kind": "capacitor"},
                {"id": "C2", "kind": "capacitor"},
                {"id": "R1", "kind": "resistor"},
                {"id": "R2", "kind": "resistor"},
                {"id": "U2", "kind": "ic"},
                {"id": "C3", "kind": "capacitor"},
            ],
            "nets": [
                {"id": "N_C", "pins": [{"component": "U1"}, {"component": "C1"}, {"component": "C2"}]},
                {"id": "N_R", "pins": [{"component": "U1"}, {"component": "R1"}, {"component": "R2"}]},
                {"id": "N_CPAIR", "pins": [{"component": "C1"}, {"component": "C2"}]},
                {"id": "N_RPAIR", "pins": [{"component": "R1"}, {"component": "R2"}]},
                {"id": "N_AUX", "pins": [{"component": "U2"}, {"component": "C3"}]},
            ],
        })
        self.l2 = {"l2_domains": [
            {"id": "L2-001", "anchor": "U1", "members": ["U1", "C1", "C2", "R1", "R2"]},
            {"id": "L2-002", "anchor": "U2", "members": ["U2", "C3"]},
        ]}
        self.annotations = {"annotations": [
            {"component_id": "U1", "functional_category": "控制器", "function_description": "控制器"},
            {"component_id": "C1", "functional_category": "输入去耦", "function_description": "输入旁路"},
            {"component_id": "C2", "functional_category": "输入去耦", "function_description": "输入旁路"},
            {"component_id": "R1", "functional_category": "反馈分压", "function_description": "反馈"},
            {"component_id": "R2", "functional_category": "反馈分压", "function_description": "反馈"},
            {"component_id": "U2", "functional_category": "控制器", "function_description": "辅助控制器"},
            {"component_id": "C3", "functional_category": "去耦", "function_description": "辅助去耦"},
        ]}

    def test_pairs_stay_inside_l2_and_cover_once(self):
        result = run_flow(self.netlist, self.l2, self.annotations)
        self.assertTrue(result["all_components_once"])
        pair_sets = [set(row["members"]) for row in result["l1_clusters"] if len(row["members"]) == 2]
        self.assertIn({"C1", "C2"}, pair_sets)
        self.assertIn({"R1", "R2"}, pair_sets)
        for row in result["l1_clusters"]:
            self.assertIn(row["l2_domain"], {"L2-001", "L2-002"})

    def test_missing_l2_is_rejected(self):
        with self.assertRaisesRegex(ValueError, "L2 未覆盖"):
            run_flow(self.netlist, {"l2_domains": [{"members": ["U1"]}]}, self.annotations)

    def test_annotation_does_not_require_or_consume_net_semantics(self):
        annotations = normalize_annotations(self.annotations, {"U1", "C1", "C2", "R1", "R2", "U2", "C3"})
        self.assertNotIn("nets", annotations)
        self.assertEqual(annotations["C1"]["functional_category"], "输入去耦")

    def test_no_second_hop_pair(self):
        netlist = normalize_netlist({
            "components": [{"id": "U1", "kind": "ic"}, {"id": "C1"}, {"id": "R1"}, {"id": "C2"}],
            "nets": [{"id": "A", "pins": [{"component": "U1"}, {"component": "C1"}]},
                      {"id": "B", "pins": [{"component": "C1"}, {"component": "R1"}]},
                      {"id": "C", "pins": [{"component": "R1"}, {"component": "C2"}]}],
        })
        l2 = {"l2_domains": [{"id": "L2-1", "anchor": "U1", "members": ["U1", "C1", "R1", "C2"]}]}
        ann = {"annotations": [{"component_id": ref, "functional_category": "x", "function_description": "x"}
                                for ref in ("U1", "C1", "R1", "C2")]}
        result = run_flow(netlist, l2, ann)
        self.assertFalse(any(set(row["members"]) == {"R1", "C2"} for row in result["l1_clusters"] if len(row["members"]) == 2))

    def test_easyeda_component_mapping_and_pin_info_map(self):
        normalized = normalize_netlist({
            "components": {
                "gge1": {"props": {"Designator": "U1", "DeviceName": "MCU"},
                         "pinInfoMap": {"1": {"number": "1", "name": "VCC", "net": "VCC"}}},
                "gge2": {"props": {"Designator": "C1", "Value": "100nF"},
                         "pinInfoMap": {"1": {"number": "1", "net": "VCC"}}},
            }
        })
        self.assertEqual([row["id"] for row in normalized["components"]], ["U1", "C1"])
        self.assertEqual(normalized["nets"]["VCC"], [
            {"component": "U1", "pin": "1"}, {"component": "C1", "pin": "1"}
        ])


if __name__ == "__main__":
    unittest.main()
