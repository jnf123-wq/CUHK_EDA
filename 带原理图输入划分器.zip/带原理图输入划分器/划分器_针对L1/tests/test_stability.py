import unittest

from stability import build_stability_report


class StabilityTests(unittest.TestCase):
    def test_identical_rounds_are_stable(self):
        result = {"function_annotations": {"A": {"functional_category": "滤波", "function_description": "输入滤波"}},
                  "l1_clusters": [{"members": ["A", "B"]}]}
        report = build_stability_report([result, result])
        self.assertEqual(report["round_count"], 2)
        self.assertEqual(report["function_category_stability"], 1.0)
        self.assertEqual(report["l1_pair_stability"], 1.0)

    def test_changed_partner_reduces_pair_stability(self):
        first = {"function_annotations": {"A": {"functional_category": "x", "function_description": "x"}},
                 "l1_clusters": [{"members": ["A", "B"]}]}
        second = {"function_annotations": {"A": {"functional_category": "x", "function_description": "x"}},
                  "l1_clusters": [{"members": ["A", "C"]}]}
        report = build_stability_report([first, second])
        self.assertEqual(report["l1_pair_stability"], 0.5)
        self.assertEqual(report["l1_pair_jaccard_mean"], 0.0)


if __name__ == "__main__":
    unittest.main()
