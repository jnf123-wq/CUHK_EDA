@echo off
setlocal
cd /d "%~dp0"
where pythonw.exe >nul 2>nul
if errorlevel 1 goto try_python
start "L1 GUI" /b pythonw.exe "%~dp0gui.py"
exit /b 0

:try_python
where python.exe >nul 2>nul
if errorlevel 1 goto no_python
python.exe "%~dp0gui.py"
if errorlevel 1 pause
exit /b %errorlevel%

:no_python
echo Python 3 was not found. Please install Python 3 and add it to PATH.
pause
exit /b 1
