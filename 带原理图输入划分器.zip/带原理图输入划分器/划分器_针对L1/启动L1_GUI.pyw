from pathlib import Path
import traceback
import tkinter.messagebox as messagebox

try:
    from gui import main
    main()
except Exception as exc:
    log_path = Path(__file__).with_name("gui_startup_error.log")
    log_path.write_text(traceback.format_exc(), encoding="utf-8")
    try:
        messagebox.showerror("L1 界面启动失败", f"{exc}\n\n详细错误已写入：\n{log_path}")
    except Exception:
        pass
