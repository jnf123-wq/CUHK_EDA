# L2 综合划分流程

该目录把两个已有工程串成一条只处理 L2 的流程：

1. 第一次调用 DeepSeek，逐器件识别自身功能，写出 `device_function_annotations.json/csv`。
2. 使用 `划分器算法部分` 的确定性算法读取同一份原始网表，生成 `algorithm_l2_result.json`。
3. 找出算法 L2 中 `anchor` 为空、未归入大器件域的小元件。如果不会调用千问，则把这些器件连同功能标注和网表连接交给第二次 DeepSeek，形成独立辅助簇。
4. 如果提供原理图且存在候选器件，千问会把候选器件全部分配到已有大器件 L2 簇；它不能创建新簇或修改大器件原有成员。此时最终归属以千问为准，因此跳过不会被采用的 DeepSeek 补簇调用。最终结果写入 `l2_final_result.json` 和 `l2_final_assignments.csv`。

最终导出会强制校验：输入器件数、最终归属行数和唯一器件数必须一致。CSV 新增 `cluster_kind`、`function_label` 和 `cluster_type` 字段，便于区分大器件域与独立辅助功能簇。

输入支持标准 JSON 网表（`components` 数组、`nets` 数组或网络映射）和 EasyEDA `.enet`。默认算法目录为同一桌面下的 `划分器算法部分`。

## 可视化启动

双击 `启动L2综合划分器.cmd`，或执行 `python gui.py`。界面支持选择文件和目录、Dry-run、启动运行、实时日志，以及打开输出目录。主内容区和日志区都支持鼠标滚轮上下滑动，适合较小屏幕或 Windows 高 DPI 显示。

L2 流程支持同时输入原始 JSON/`.enet` 网表和可选原理图图片：算法先生成确定性 L2 域，DeepSeek 识别器件功能；若提供图片，千问对未锚定小元件进行最终归属，否则 DeepSeek 根据网表拓扑形成独立辅助簇。图片不会改变算法已经锚定的大器件成员，也不会创建新簇。

```powershell
python C:\Users\30943\Desktop\划分器_针对L2\run_flow.py `
  C:\path\to\schematic.json `
  --api-key-file C:\path\to\DS接口文档.txt `
  --schematic C:\path\to\schematic.png `
  --qwen-api-key-file C:\path\to\千问接口文档.txt `
  --out C:\path\to\l2-flow-output
```

界面可直接选择两个接口文档，程序会识别 `模型名`、`Base URL`、`API` 等中英文标签；也支持 `DEEPSEEK_API_KEY` 和 `QWEN_API_KEY` 环境变量。没有填写模型参数时，URL、API 和模型名全部以文档内容为准。

如果出现 `HTTP 429` 或网页标题 `Request Blocked`，说明请求被 DeepSeek 账户限额、访问频率或中间网络网关拦截。请先检查账户余额/限额和 API key 权限；如果返回的是网关网页，尝试更换网络出口，或在界面中填写可访问的兼容 API Base URL。程序会读取 `Retry-After` 并退避重试，错误详情同时保存到输出目录的 `flow_error.json`。

先检查输入、算法输出和请求内容而不调用网络时：

```powershell
python C:\Users\30943\Desktop\划分器_针对L2\run_flow.py input.json --schematic schematic.png --dry-run --out output
```

每次运行会保留 DeepSeek 和（如提供图片）千问的请求/响应 JSON，方便审计和复现。多轮稳定性报告会按独立辅助簇的完整成员集合比较分簇稳定性。

`flow_manifest.json` 的 `timing` 节点记录各阶段耗时，以及每次模型调用的往返秒数、网络尝试数、重试等待、请求/响应字节数和接口返回的 token usage；识图调用额外记录图片字节数。这里的调用耗时是客户端观测到的完整往返时间，不是服务端纯推理时间。
