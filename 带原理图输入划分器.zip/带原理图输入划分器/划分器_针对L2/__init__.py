"""L2 integrated partition flow."""
