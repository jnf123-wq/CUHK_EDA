#!/usr/bin/env python3
"""Tkinter launcher for the L2 algorithm + DeepSeek + optional Qwen image flow."""
from __future__ import annotations
import os
import queue
import subprocess
import sys
import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

ROOT = Path(__file__).resolve().parent
FLOW = ROOT / "run_flow.py"

class ScrollableFrame(ttk.Frame):
    def __init__(self, parent, **kwargs):
        super().__init__(parent, **kwargs)
        self.canvas = tk.Canvas(self, highlightthickness=0, background="#f5f7fb")
        bar = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.body = ttk.Frame(self.canvas, padding=(18, 16, 18, 24))
        self.window_id = self.canvas.create_window((0, 0), window=self.body, anchor="nw")
        self.canvas.configure(yscrollcommand=bar.set)
        self.canvas.grid(row=0, column=0, sticky="nsew")
        bar.grid(row=0, column=1, sticky="ns")
        self.rowconfigure(0, weight=1)
        self.columnconfigure(0, weight=1)
        self.body.bind("<Configure>", lambda _e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<Configure>", lambda e: self.canvas.itemconfigure(self.window_id, width=e.width))
        self.canvas.bind_all("<MouseWheel>", lambda e: self.canvas.yview_scroll(int(-e.delta / 120), "units"), add="+")

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("L2 综合划分器")
        self.geometry("980x820")
        self.minsize(720, 560)
        self.configure(background="#f5f7fb")
        self.events: queue.Queue[tuple[str, str]] = queue.Queue()
        self.running = False
        style = ttk.Style(self)
        try: style.theme_use("vista")
        except tk.TclError: pass
        style.configure("Title.TLabel", font=("Microsoft YaHei UI", 20, "bold"), foreground="#19324d")
        style.configure("Section.TLabel", font=("Microsoft YaHei UI", 12, "bold"), foreground="#1f4e79")
        style.configure("Hint.TLabel", foreground="#687789")
        style.configure("Run.TButton", font=("Microsoft YaHei UI", 11, "bold"), padding=(16, 8))
        self._build()
        self.after(100, self._drain)

    def _build(self):
        frame = ScrollableFrame(self); frame.pack(fill="both", expand=True)
        body = frame.body; body.columnconfigure(1, weight=1)
        ttk.Label(body, text="L2 综合划分器", style="Title.TLabel").grid(row=0, column=0, columnspan=3, sticky="w")
        ttk.Label(body, text="算法 L2 初划分 → DeepSeek 网表分析 → 千问原理图证据 → 小元件补划分", style="Hint.TLabel").grid(row=1, column=0, columnspan=3, sticky="w", pady=(2, 18))
        self.netlist = tk.StringVar(); self.schematic = tk.StringVar(); self.key_file = tk.StringVar(); self.qwen_key_file = tk.StringVar()
        self.output = tk.StringVar(value=str(ROOT / "output")); self.algorithm_dir = tk.StringVar(value=str(ROOT.parent / "划分器算法部分"))
        self.base_url = tk.StringVar(); self.model = tk.StringVar()
        self.qwen_base_url = tk.StringVar(); self.qwen_model = tk.StringVar()
        self.timeout = tk.StringVar(value="180"); self.temperature = tk.StringVar(value="0.0"); self.rounds = tk.StringVar(value="1"); self.dry_run = tk.BooleanVar(value=False)
        ttk.Label(body, text="输入与输出", style="Section.TLabel").grid(row=2, column=0, columnspan=3, sticky="w", pady=(0, 8))
        self._path_row(body, 3, "原始网表", self.netlist, self._choose_netlist, "JSON 或 EasyEDA .enet")
        self._path_row(body, 5, "原理图图片", self.schematic, self._choose_schematic, "可选 PNG/JPG/WebP；提供后由千问分析")
        self._path_row(body, 7, "DeepSeek 接口文档", self.key_file, self._choose_key, "自动读取 URL、API 和模型名")
        self._path_row(body, 9, "千问接口文档", self.qwen_key_file, self._choose_qwen_key, "自动读取 URL、API 和模型名")
        self._path_row(body, 11, "输出目录", self.output, self._choose_output, "保存算法、两模型和最终 L2 结果")
        self._path_row(body, 13, "算法目录", self.algorithm_dir, self._choose_algorithm, "通常为桌面的 划分器算法部分")
        ttk.Label(body, text="运行设置", style="Section.TLabel").grid(row=15, column=0, columnspan=3, sticky="w", pady=(18, 8))
        self._entry_row(body, 16, "请求超时（秒）", self.timeout); self._entry_row(body, 17, "采样温度", self.temperature); self._entry_row(body, 18, "独立运行轮数", self.rounds)
        options = ttk.Frame(body); options.grid(row=19, column=0, columnspan=3, sticky="ew", pady=(16, 8))
        ttk.Checkbutton(options, text="Dry-run（不调用模型，只生成请求和算法结果）", variable=self.dry_run).pack(side="left")
        ttk.Label(options, text="不选图片时仍可只测试原有 L2 流程。", style="Hint.TLabel").pack(side="left", padx=(16, 0))
        ttk.Label(body, text="运行日志", style="Section.TLabel").grid(row=20, column=0, columnspan=3, sticky="w", pady=(18, 8))
        log_frame = ttk.Frame(body); log_frame.grid(row=21, column=0, columnspan=3, sticky="nsew")
        self.log = tk.Text(log_frame, height=13, wrap="word", state="disabled", background="#101820", foreground="#d6e8f5", relief="flat", padx=10, pady=10)
        scroll = ttk.Scrollbar(log_frame, orient="vertical", command=self.log.yview); self.log.configure(yscrollcommand=scroll.set)
        self.log.grid(row=0, column=0, sticky="nsew"); scroll.grid(row=0, column=1, sticky="ns"); log_frame.rowconfigure(0, weight=1); log_frame.columnconfigure(0, weight=1)
        buttons = ttk.Frame(body); buttons.grid(row=22, column=0, columnspan=3, sticky="ew", pady=(16, 10))
        self.run_button = ttk.Button(buttons, text="开始运行", style="Run.TButton", command=self._start); self.run_button.pack(side="left")
        ttk.Button(buttons, text="打开输出目录", command=self._open_output).pack(side="left", padx=(10, 0)); self.status = ttk.Label(buttons, text="等待输入", style="Hint.TLabel"); self.status.pack(side="right")

    def _path_row(self, parent, row, label, variable, command, hint):
        ttk.Label(parent, text=label, width=16).grid(row=row, column=0, sticky="w", pady=5); ttk.Entry(parent, textvariable=variable).grid(row=row, column=1, sticky="ew", pady=5, padx=(0, 8)); ttk.Button(parent, text="浏览…", command=command).grid(row=row, column=2, pady=5); ttk.Label(parent, text=hint, style="Hint.TLabel").grid(row=row + 1, column=1, columnspan=2, sticky="w")

    def _entry_row(self, parent, row, label, variable):
        ttk.Label(parent, text=label, width=16).grid(row=row, column=0, sticky="w", pady=5); ttk.Entry(parent, textvariable=variable).grid(row=row, column=1, columnspan=2, sticky="ew", pady=5)

    def _choose_netlist(self):
        path = filedialog.askopenfilename(title="选择原始网表", filetypes=[("网表", "*.json *.enet"), ("所有文件", "*.*")]); self.netlist.set(path) if path else None
    def _choose_schematic(self):
        path = filedialog.askopenfilename(title="选择原理图图片", filetypes=[("图片", "*.png *.jpg *.jpeg *.webp"), ("所有文件", "*.*")]); self.schematic.set(path) if path else None
    def _choose_key(self):
        path = filedialog.askopenfilename(title="选择 DeepSeek 接口文档", filetypes=[("文档", "*.txt *.env *.md *.py"), ("所有文件", "*.*")]); self.key_file.set(path) if path else None
    def _choose_qwen_key(self):
        path = filedialog.askopenfilename(title="选择千问接口文档", filetypes=[("文档", "*.txt *.env *.md *.py"), ("所有文件", "*.*")]); self.qwen_key_file.set(path) if path else None
    def _choose_output(self):
        path = filedialog.askdirectory(title="选择输出目录"); self.output.set(path) if path else None
    def _choose_algorithm(self):
        path = filedialog.askdirectory(title="选择算法目录"); self.algorithm_dir.set(path) if path else None
    def _write(self, text):
        self.log.configure(state="normal"); self.log.insert("end", text); self.log.see("end"); self.log.configure(state="disabled")

    def _start(self):
        if self.running: return
        netlist = Path(self.netlist.get().strip())
        if not netlist.is_file(): messagebox.showerror("缺少输入", "请选择有效的 JSON 或 .enet 原始网表。"); return
        try:
            timeout = int(self.timeout.get().strip()); rounds = int(self.rounds.get().strip()); temperature = float(self.temperature.get().strip())
            if timeout <= 0 or rounds < 1 or not 0 <= temperature <= 2: raise ValueError
        except ValueError: messagebox.showerror("参数错误", "超时和轮数必须为正整数，温度必须在 0 到 2 之间。"); return
        output = Path(self.output.get().strip() or ROOT / "output")
        command = [sys.executable, "-u", str(FLOW), str(netlist), "--out", str(output), "--algorithm-dir", self.algorithm_dir.get().strip(), "--timeout", str(timeout), "--temperature", str(temperature), "--rounds", str(rounds)]
        if self.schematic.get().strip(): command += ["--schematic", self.schematic.get().strip()]
        if self.key_file.get().strip(): command += ["--api-key-file", self.key_file.get().strip()]
        if self.qwen_key_file.get().strip(): command += ["--qwen-api-key-file", self.qwen_key_file.get().strip()]
        if self.dry_run.get(): command.append("--dry-run")
        self.running = True; self.run_button.configure(state="disabled"); self.status.configure(text="运行中…"); self._write("\n$ " + subprocess.list2cmdline(command) + "\n\n")
        threading.Thread(target=self._run_process, args=(command,), daemon=True).start()

    def _run_process(self, command):
        try:
            env = os.environ.copy(); env["PYTHONIOENCODING"] = "utf-8"; process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace", bufsize=1, env=env); assert process.stdout is not None
            for line in process.stdout: self.events.put(("log", line))
            self.events.put(("done", str(process.wait())))
        except Exception as exc: self.events.put(("error", str(exc)))

    def _drain(self):
        try:
            while True:
                kind, value = self.events.get_nowait()
                if kind == "log": self._write(value)
                elif kind == "done":
                    self.running = False; self.run_button.configure(state="normal"); ok = value == "0"; self.status.configure(text="完成" if ok else f"失败（退出码 {value}）"); self._write(f"\n流程结束，退出码：{value}\n")
                    if ok: messagebox.showinfo("运行完成", f"结果已写入：\n{Path(self.output.get()).resolve()}")
                else:
                    self.running = False; self.run_button.configure(state="normal"); self.status.configure(text="启动失败"); self._write("启动失败：" + value + "\n"); messagebox.showerror("启动失败", value)
        except queue.Empty: pass
        self.after(100, self._drain)

    def _open_output(self):
        path = Path(self.output.get().strip() or ROOT / "output"); path.mkdir(parents=True, exist_ok=True)
        if hasattr(os, "startfile"): os.startfile(str(path))

if __name__ == "__main__":
    App().mainloop()
