#!/usr/bin/env python3
"""L2 flow: algorithmic partitioning, DeepSeek netlist evidence, optional Qwen image evidence, then completion.

The deterministic partitioner is deliberately run before the second model call.
The second call receives only components in the algorithm's unresolved
``anchor=null`` L2 domain and may attach them to an existing anchored domain.
It cannot move an already assigned component or create a new domain.
"""

from __future__ import annotations

import argparse
import base64
import csv
import hashlib
import http.client
import json
import os
import re
import sys
import time
import mimetypes
from collections import Counter
from pathlib import Path
from typing import Any, Mapping
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen


ROOT = Path(__file__).resolve().parent
DEFAULT_ALGORITHM_DIR = ROOT.parent / "划分器算法部分"
DEFAULT_LLM_DIR = ROOT.parent / "划分器LLM部分"
PROMPT_DIR = ROOT / "prompts"

if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except (AttributeError, OSError):
        pass


def _json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, indent=2)


def save_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(_json(value) + "\n", encoding="utf-8")


def _component_kind(component: Mapping[str, Any]) -> str:
    value = str(component.get("kind", component.get("type", ""))).strip().lower()
    if value:
        aliases = {"ic": "ic_module", "controller": "controller", "chip": "ic_module"}
        return aliases.get(value, value)
    ref = str(component.get("id", component.get("ref", ""))).upper()
    return {"R": "resistor", "C": "capacitor", "L": "inductor", "D": "diode",
            "Q": "transistor", "U": "ic_module", "J": "connector"}.get(ref[:1], "other")


def _component_id(component: Mapping[str, Any]) -> str:
    value = component.get("id", component.get("ref", component.get("designator")))
    if value is None or not str(value).strip():
        raise ValueError("每个器件必须有非空 id/ref/designator")
    return str(value).strip()


def _load_easyeda(path: Path) -> tuple[dict[str, Any], dict[str, Any]]:
    raw = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(raw, Mapping) or not isinstance(raw.get("components"), Mapping):
        raise ValueError(f"不是可识别的 EasyEDA .enet 文件：{path}")
    components: list[dict[str, Any]] = []
    nets: dict[str, list[dict[str, str]]] = {}
    seen: dict[str, int] = {}
    for key, item in raw["components"].items():
        if not isinstance(item, Mapping):
            continue
        props = item.get("props") if isinstance(item.get("props"), Mapping) else {}
        ref = str(props.get("Designator") or key).strip()
        seen[ref] = seen.get(ref, 0) + 1
        cid = ref if seen[ref] == 1 else f"{ref}__dup{seen[ref]}"
        value = str(props.get("Value") or props.get("Name") or props.get("DeviceName") or "")
        pins: list[dict[str, str]] = []
        pinmap = item.get("pinInfoMap") or {}
        pin_items = pinmap.items() if isinstance(pinmap, Mapping) else enumerate(pinmap)
        for pin_key, pin in pin_items:
            if not isinstance(pin, Mapping):
                continue
            number = str(pin.get("number", pin_key))
            name = str(pin.get("name", ""))
            net = str(pin.get("net") or "").strip()
            pins.append({"id": number, "name": name, "net": net})
            if net:
                nets.setdefault(net, []).append({"component": cid, "pin": number, "name": name})
        components.append({"id": cid, "ref": ref, "value": value,
                           "part": str(props.get("Manufacturer Part") or props.get("DeviceName") or props.get("Name") or ""),
                           "kind": _component_kind({"id": ref}), "pins": pins,
                           "footprint": str(props.get("FootprintName") or props.get("Supplier Footprint") or "")})
    if not components:
        raise ValueError(".enet 中没有器件")
    net_rows = [{"id": name, "pins": pins} for name, pins in sorted(nets.items())]
    netlist = {"schema": "device-function-netlist-v1", "name": path.stem,
               "source_format": "easyeda-enet", "components": sorted(components, key=lambda x: x["id"]),
               "nets": net_rows}
    return netlist, _to_topology(netlist, source={"format": "enet", "schematic": str(path)})


def _standard_netlist(path: Path) -> tuple[dict[str, Any], dict[str, Any]]:
    raw = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(raw, Mapping) or not isinstance(raw.get("components"), list):
        raise ValueError("标准 JSON 网表必须包含 components 数组")
    components: list[dict[str, Any]] = []
    ids: set[str] = set()
    for raw_component in raw["components"]:
        if not isinstance(raw_component, Mapping):
            raise ValueError("components 中只能包含对象")
        cid = _component_id(raw_component)
        if cid in ids:
            raise ValueError(f"器件位号重复：{cid}")
        ids.add(cid)
        item = dict(raw_component)
        item["id"] = cid
        item["kind"] = _component_kind(item)
        item.setdefault("value", item.get("name", item.get("part", "")))
        components.append(item)
    nets: list[dict[str, Any]] = []
    raw_nets = raw.get("nets", [])
    if isinstance(raw_nets, Mapping):
        raw_nets = [{"id": name, "pins": endpoints} for name, endpoints in raw_nets.items()]
    if not isinstance(raw_nets, list):
        raise ValueError("nets 必须是数组或网络名到端点数组的对象")
    for raw_net in raw_nets:
        if not isinstance(raw_net, Mapping):
            raise ValueError("nets 中只能包含对象")
        name = str(raw_net.get("id", raw_net.get("name", ""))).strip()
        if not name:
            raise ValueError("每个网络必须有 id/name")
        endpoints = raw_net.get("pins", raw_net.get("components", raw_net.get("endpoints", [])))
        if not isinstance(endpoints, list):
            raise ValueError(f"网络 {name} 的端点必须是数组")
        pins: list[dict[str, str]] = []
        for endpoint in endpoints:
            if isinstance(endpoint, Mapping):
                ref = endpoint.get("component", endpoint.get("ref", endpoint.get("designator", endpoint.get("c"))))
                pin = endpoint.get("pin", endpoint.get("pad", endpoint.get("number", "")))
                pin_name = endpoint.get("name", endpoint.get("pin_name", ""))
            else:
                ref, pin, pin_name = endpoint, "", ""
            if ref is None:
                continue
            ref = str(ref).split(".", 1)[0].split(":", 1)[0]
            if ref not in ids:
                raise ValueError(f"网络 {name} 引用了未知器件：{ref}")
            pins.append({"component": ref, "pin": str(pin or ""), "name": str(pin_name or "")})
        nets.append({"id": name, "pins": pins})
    netlist = {"schema": "device-function-netlist-v1", "name": str(raw.get("name", path.stem)),
               "source_format": "standard-json", "components": sorted(components, key=lambda x: x["id"]),
               "nets": nets}
    return netlist, _to_topology(netlist, source={"format": "standard-json", "path": str(path)})


def _to_topology(netlist: Mapping[str, Any], *, source: Mapping[str, Any]) -> dict[str, Any]:
    components = []
    for item in netlist.get("components", []):
        cid = str(item["id"])
        components.append({"designator": cid, "kind": _component_kind(item),
                           "name": str(item.get("value", item.get("name", item.get("part", "")))),
                           "value": str(item.get("value", "")), "part": str(item.get("part", "")),
                           "pins": item.get("pins", [])})
    nets: dict[str, list[dict[str, str]]] = {}
    for net in netlist.get("nets", []):
        name = str(net["id"])
        nets[name] = [{"c": str(pin["component"]), "pin": str(pin.get("pin", "")),
                       "name": str(pin.get("name", ""))} for pin in net.get("pins", [])]
    return {"schema": "moduplace-topology-v1", "source": dict(source),
            "components": components, "nets": nets}


def load_inputs(path: Path) -> tuple[dict[str, Any], dict[str, Any]]:
    if path.suffix.lower() == ".enet":
        return _load_easyeda(path)
    return _standard_netlist(path)


def _read_key_file(path: Path | None) -> dict[str, str]:
    if not path:
        return {}
    text = path.read_text(encoding="utf-8-sig")
    result: dict[str, str] = {}
    aliases = {"模型名": "model", "模型": "model", "model_name": "model", "model": "model",
               "base url": "base_url", "base_url": "base_url", "url": "base_url", "接口地址": "base_url",
               "api": "api_key", "api key": "api_key", "api_key": "api_key", "apikey": "api_key",
               "key": "api_key", "token": "api_key", "deepseek_api_key": "deepseek_api_key", "qwen_api_key": "qwen_api_key"}
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        normalized = line.replace("：", ":")
        if "=" in normalized:
            key, value = normalized.split("=", 1)
        elif ":" in normalized:
            key, value = normalized.split(":", 1)
        else:
            continue
        key = key.strip().lower()
        value = value.split("#", 1)[0].strip().strip("'\"")
        mapped = aliases.get(key)
        if mapped and value:
            result[mapped] = value
    if "base_url" not in result:
        match = re.search(r"https?://[^\s'\"]+", text)
        if match:
            result["base_url"] = match.group(0).rstrip("，,。")
    if "model" not in result:
        match = re.search(r"(?:模型名|模型|model(?:_name)?)\s*[:：=]\s*([^\s,，]+)", text, re.I)
        if match:
            result["model"] = match.group(1).strip()
    if "api_key" not in result:
        match = re.search(r"(?:API(?:\s*Key)?|api_key|apikey)\s*[:：=]\s*([^\s]+)", text, re.I)
        if match:
            result["api_key"] = match.group(1).strip().strip("'\"")
    if not result and text.strip() and "=" not in text and ":" not in text:
        result["api_key"] = text.strip()
    return result


def _image_attachment(path: Path | None) -> dict[str, Any] | None:
    if path is None:
        return None
    if not path.is_file():
        raise ValueError(f"原理图图片不存在：{path}")
    size = path.stat().st_size
    if size > 8 * 1024 * 1024:
        raise ValueError("原理图图片不能超过 8 MB")
    mime, _ = mimetypes.guess_type(path.name)
    if not mime or not mime.startswith("image/"):
        raise ValueError("原理图必须是 PNG/JPG/JPEG/WebP 等图片文件")
    return {"name": path.name, "path": str(path), "bytes": size, "mime": mime,
            "image_url": f"data:{mime};base64,{base64.b64encode(path.read_bytes()).decode('ascii')}"}


class DeepSeekClient:
    def __init__(self, api_key: str, *, base_url: str, model: str, timeout: int = 180,
                 retries: int = 3, temperature: float = 0.0, provider: str = "DeepSeek"):
        if not api_key:
            raise ValueError(f"未找到 {provider} API key")
        self.api_key, self.base_url, self.model = api_key, base_url.rstrip("/"), model
        self.timeout, self.retries, self.temperature, self.provider = timeout, retries, temperature, provider
        self.last_call_stats: dict[str, Any] = {}

    @staticmethod
    def _decode(content: Any) -> dict[str, Any]:
        if isinstance(content, list):
            content = "".join(str(x.get("text", "")) for x in content if isinstance(x, Mapping))
        text = str(content).strip()
        text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text, flags=re.I | re.S).strip()
        result = json.loads(text)
        if not isinstance(result, dict):
            raise ValueError("DeepSeek 返回的根对象必须是 JSON object")
        return result

    def ask(self, system: str, data: Mapping[str, Any], *, image_url: str | None = None) -> dict[str, Any]:
        started = time.perf_counter()
        attempts = 0
        retry_wait_seconds = 0.0
        total_response_bytes = 0
        usage: Any = None
        user_text = json.dumps(data, ensure_ascii=False)
        user_content: Any = user_text
        if image_url:
            user_content = [{"type": "text", "text": user_text},
                            {"type": "image_url", "image_url": {"url": image_url}}]
        body = json.dumps({"model": self.model, "temperature": self.temperature,
                           "response_format": {"type": "json_object"},
                           "messages": [{"role": "system", "content": system},
                                        {"role": "user", "content": user_content}]},
                          ensure_ascii=False).encode("utf-8")
        self.last_call_stats = {}
        last: Exception | None = None
        try:
            for attempt in range(self.retries):
                attempts += 1
                request = Request(self.base_url + "/chat/completions", data=body, method="POST",
                                   headers={"Authorization": "Bearer " + self.api_key,
                                            "Content-Type": "application/json"})
                try:
                    with urlopen(request, timeout=self.timeout) as response:
                        response_body = response.read()
                    total_response_bytes += len(response_body)
                    payload = json.loads(response_body.decode("utf-8"))
                    usage = payload.get("usage")
                    content = payload["choices"][0]["message"]["content"]
                    return self._decode(content)
                except HTTPError as exc:
                    detail_bytes = exc.read()
                    total_response_bytes += len(detail_bytes)
                    detail = detail_bytes.decode("utf-8", errors="replace")
                    compact = re.sub(r"<[^>]+>", " ", detail)
                    compact = re.sub(r"\s+", " ", compact).strip()[:500]
                    retry_after = exc.headers.get("Retry-After", "")
                    if exc.code == 429:
                        last = RuntimeError(
                            f"HTTP 429 请求被 {self.provider} 或中间网关限流/拦截"
                            + (f"（Retry-After={retry_after}s）" if retry_after else "")
                            + (f"：{compact}" if compact else "")
                        )
                        if attempt + 1 < self.retries:
                            try:
                                delay = min(30.0, max(1.0, float(retry_after))) if retry_after else min(8.0, 1.5 ** attempt)
                            except ValueError:
                                delay = min(8.0, 1.5 ** attempt)
                            retry_wait_seconds += delay
                            time.sleep(delay)
                            continue
                    else:
                        last = RuntimeError(f"HTTP {exc.code}: {compact or detail[:500]}")
                    if exc.code in {400, 401, 403}:
                        break
                except (http.client.HTTPException, URLError, TimeoutError, ConnectionError,
                        KeyError, IndexError, json.JSONDecodeError, ValueError) as exc:
                    # Some gateways close a chunked response before sending the
                    # terminating chunk. urllib raises IncompleteRead/HTTPException
                    # while reading the body, not HTTPError, so treat it as a
                    # transient transport failure and retry the same request.
                    last = RuntimeError(f"HTTP 响应传输中断（第 {attempt + 1}/{self.retries} 次尝试）：{exc}")
                if attempt + 1 < self.retries:
                    delay = 0.7 * (attempt + 1)
                    retry_wait_seconds += delay
                    time.sleep(delay)
            if isinstance(last, RuntimeError) and "HTTP 429" in str(last):
                raise RuntimeError(
                    f"{last}。请检查 {self.provider} 账户余额/限额、API key 权限和请求频率；"
                    "若返回页面标题为 Request Blocked，请更换网络出口或在 --base-url 中使用可访问的兼容代理。"
                ) from last
            raise RuntimeError(f"{self.provider} 请求失败：{last}") from last
        finally:
            self.last_call_stats = {
                "provider": self.provider, "model": self.model,
                "elapsed_seconds": round(time.perf_counter() - started, 6),
                "network_attempts": attempts, "retry_wait_seconds": round(retry_wait_seconds, 6),
                "request_bytes_per_attempt": len(body),
                "request_bytes_total": len(body) * attempts,
                "response_bytes_total": total_response_bytes,
                "usage": usage,
            }


def _timed_ask(client: DeepSeekClient, system: str, request: Mapping[str, Any],
               call_metrics: list[dict[str, Any]], stage: str, *, image_url: str | None = None,
               image_bytes: int | None = None) -> dict[str, Any]:
    """Record safe per-call timing/size stats without persisting prompts or credentials."""
    started = time.perf_counter()
    try:
        return client.ask(system, request, image_url=image_url)
    finally:
        stats = dict(client.last_call_stats)
        stats.update({"stage": stage, "elapsed_seconds": round(time.perf_counter() - started, 6)})
        if image_bytes is not None:
            stats["image_bytes"] = image_bytes
        call_metrics.append(stats)


def _annotation_rows(result: Mapping[str, Any], components: list[Mapping[str, Any]]) -> list[dict[str, Any]]:
    raw = result.get("annotations", result.get("components", result.get("assignments")))
    if isinstance(raw, Mapping):
        raw = [dict(value, component_id=key) for key, value in raw.items() if isinstance(value, Mapping)]
    if not isinstance(raw, list):
        raise ValueError("器件功能识别结果缺少 annotations 数组")
    known = {str(c["id"]) for c in components}
    rows: dict[str, dict[str, Any]] = {}
    for item in raw:
        if not isinstance(item, Mapping):
            raise ValueError("每条器件功能识别结果必须是对象")
        cid = str(item.get("component_id", item.get("id", item.get("L0_Device", "")))).strip()
        if cid not in known:
            raise ValueError(f"功能识别结果包含未知器件：{cid}")
        if cid in rows:
            raise ValueError(f"功能识别结果重复器件：{cid}")
        category = str(item.get("functional_category", item.get("功能类别", item.get("category", "")))).strip()
        description = str(item.get("function_description", item.get("功能说明", item.get("description", "")))).strip()
        if not category or not description:
            raise ValueError(f"{cid} 缺少功能类别或功能说明")
        try:
            confidence = float(item.get("confidence", item.get("置信度", 0)))
        except (TypeError, ValueError) as exc:
            raise ValueError(f"{cid} 的置信度不是数字") from exc
        if not 0 <= confidence <= 1:
            raise ValueError(f"{cid} 的置信度必须在 0 到 1 之间")
        rows[cid] = {"component_id": cid, "component_name": str(item.get("component_name", item.get("器件名称", ""))),
                     "functional_category": category, "function_description": description,
                     "evidence": str(item.get("evidence", item.get("识别依据", ""))),
                     "confidence": confidence, "status": "recognized"}
    missing = sorted(known - set(rows))
    if missing:
        raise ValueError("功能识别结果遗漏器件：" + ", ".join(missing))
    return [rows[cid] for cid in sorted(rows)]


def _build_schematic_request(netlist: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "task": "仅根据所附原理图图片，为 L2 器件识别提供可审计的视觉证据和辅助功能/分组提示。",
        "expected_component_ids": [str(c["id"]) for c in netlist.get("components", [])],
        "components": [{"component_id": str(c["id"]), "value": str(c.get("value", "")),
                        "part": str(c.get("part", ""))} for c in netlist.get("components", [])],
        "output_schema": {"annotations": [{
            "component_id": "必须来自 expected_component_ids",
            "functional_category": "图片可见的功能类别；无法判断时填 unknown",
            "function_description": "仅根据图片的简短说明",
            "candidate_group_label": "可选的辅助功能簇名称",
            "candidate_cluster_type": "可选，如 decoupling/filter/bias/other_auxiliary",
            "visible_evidence": "图片中实际可见的位号、网络标注、器件值或电源标注",
            "confidence": 0.0}], "unreadable_component_ids": []},
        "rules": [
            "只报告图片中能读到或可靠识别的器件；不要猜测不可见的网络和数值。",
            "component_id 必须逐字匹配 expected_component_ids；看不清的器件放入 unreadable_component_ids。",
            "这是给 L2 补划分使用的辅助证据，不得直接移动算法已经锚定的大器件域。",
            "输出有效 JSON，不要 Markdown。",
        ],
    }


def _build_qwen_assignment_request(netlist: Mapping[str, Any], candidate_ids: list[str], major_domains: list[Mapping[str, Any]]) -> dict[str, Any]:
    return {
        "task": "只根据所附原理图图片，把算法初划分和 DeepSeek 补划分后仍未进入大器件簇的小元件分配到已有大器件 L2 簇。",
        "candidate_component_ids": candidate_ids,
        "existing_major_l2_domains": [{"l2_id": str(d.get("id")), "anchor": str(d.get("anchor", "")),
                                        "members": list(d.get("members", []))} for d in major_domains],
        "output_schema": {"assignments": [{"component_id": "候选器件位号", "target_l2_id": "已有大器件 l2_id",
                                             "visible_evidence": "图片实际可见的依据", "reason": "归入该大器件簇的理由",
                                             "confidence": 0.0}]},
        "rules": [
            "只输出 candidate_component_ids 中的器件，且每个器件必须恰好一次。",
            "target_l2_id 只能来自 existing_major_l2_domains；不得创建新簇，不得修改大器件成员。",
            "不得使用网表、DeepSeek 理由或不可见信息推断；图片看不清时仍需 best-effort 选择已有大器件簇并降低 confidence。",
            "输出有效 JSON，不要 Markdown。",
        ],
    }


def _qwen_supersedes_completion(schematic_attached: bool, major_domains: list[Mapping[str, Any]],
                                candidate_ids: list[str], *, dry_run: bool) -> bool:
    """Whether a full-coverage Qwen result makes DeepSeek's auxiliary clustering unused."""
    return bool(schematic_attached and major_domains and candidate_ids and not dry_run)


def _validate_qwen_assignments(result: Mapping[str, Any], candidate_ids: list[str], major_domains: list[Mapping[str, Any]]) -> list[dict[str, Any]]:
    raw = result.get("assignments", [])
    if not isinstance(raw, list):
        raise ValueError("千问补划分结果缺少 assignments 数组")
    candidates = set(candidate_ids)
    major_ids = {str(d.get("id")) for d in major_domains}
    rows: list[dict[str, Any]] = []
    seen: set[str] = set()
    for item in raw:
        if not isinstance(item, Mapping):
            raise ValueError("千问补划分 assignment 必须是对象")
        cid = str(item.get("component_id", "")).strip()
        target = str(item.get("target_l2_id", "")).strip()
        if cid not in candidates:
            raise ValueError(f"千问补划分包含非候选器件：{cid}")
        if cid in seen:
            raise ValueError(f"千问补划分重复器件：{cid}")
        if target not in major_ids:
            raise ValueError(f"千问补划分目标不是已有大器件簇：{target}")
        try:
            confidence = max(0.0, min(1.0, float(item.get("confidence", 0))))
        except (TypeError, ValueError):
            confidence = 0.0
        seen.add(cid)
        rows.append({"component_id": cid, "l2_id": target, "reason": str(item.get("reason", "")),
                     "visible_evidence": str(item.get("visible_evidence", "")), "confidence": confidence,
                     "source": "qwen_schematic_assignment", "assignment_mode": "qwen_image_to_major_domain"})
    missing = sorted(candidates - seen)
    if missing:
        raise ValueError("千问补划分遗漏器件：" + ", ".join(missing))
    return sorted(rows, key=lambda row: row["component_id"])


def _merge_final_domains(domains: list[Mapping[str, Any]], completion: list[Mapping[str, Any]],
                         qwen_assignments: list[Mapping[str, Any]],
                         auxiliary_domains: list[Mapping[str, Any]]) -> list[dict[str, Any]]:
    """Apply Qwen's complete candidate map, or use DeepSeek's auxiliary clusters as fallback."""
    qwen_by_ref = {str(row["component_id"]): row for row in qwen_assignments}
    if qwen_by_ref:
        merged = []
        for domain in domains:
            members = [ref for ref in domain.get("members", []) if str(ref) not in qwen_by_ref]
            target_refs = [ref for ref, row in qwen_by_ref.items() if row["l2_id"] == str(domain.get("id"))]
            merged.append(dict(domain, members=sorted(set(members + target_refs))))
        return merged

    completed_refs = {str(row["component_id"]) for row in completion}
    return [dict(domain, members=[ref for ref in domain.get("members", [])
                                  if str(domain.get("anchor") or "") or str(ref) not in completed_refs])
            for domain in domains] + [dict(domain) for domain in auxiliary_domains]


def _visual_rows(result: Mapping[str, Any], components: list[Mapping[str, Any]]) -> dict[str, dict[str, Any]]:
    known = {str(c["id"]) for c in components}
    raw = result.get("annotations", result.get("assignments", []))
    if not isinstance(raw, list):
        raise ValueError("千问原理图结果缺少 annotations 数组")
    rows: dict[str, dict[str, Any]] = {}
    for item in raw:
        if not isinstance(item, Mapping):
            raise ValueError("千问原理图 annotations 必须是对象数组")
        cid = str(item.get("component_id", "")).strip()
        if cid not in known:
            raise ValueError(f"千问原理图结果包含未知器件：{cid or '(空)'}")
        if cid in rows:
            raise ValueError(f"千问原理图结果重复器件：{cid}")
        try:
            confidence = float(item.get("confidence", 0))
        except (TypeError, ValueError) as exc:
            raise ValueError(f"千问原理图结果 {cid} 的 confidence 无效") from exc
        if not 0 <= confidence <= 1:
            raise ValueError(f"千问原理图结果 {cid} 的 confidence 必须在 0 到 1 之间")
        rows[cid] = {"component_id": cid,
                     "functional_category": str(item.get("functional_category", "unknown")).strip() or "unknown",
                     "function_description": str(item.get("function_description", "")).strip(),
                     "candidate_group_label": str(item.get("candidate_group_label", "")).strip(),
                     "candidate_cluster_type": str(item.get("candidate_cluster_type", "")).strip(),
                     "visible_evidence": str(item.get("visible_evidence", "")).strip(),
                     "confidence": confidence}
    unreadable = result.get("unreadable_component_ids", [])
    if not isinstance(unreadable, list) or set(map(str, unreadable)) - known:
        raise ValueError("千问原理图结果的 unreadable_component_ids 无效")
    return rows


def _merge_visual_annotations(annotations: list[dict[str, Any]], visual: Mapping[str, Any] | None) -> list[dict[str, Any]]:
    visual_rows = (visual or {}).get("annotations", {})
    merged: list[dict[str, Any]] = []
    for row in annotations:
        item = dict(row)
        image = visual_rows.get(row["component_id"]) if isinstance(visual_rows, Mapping) else None
        if image:
            item.update({"image_functional_category": image.get("functional_category", ""),
                         "image_function_description": image.get("function_description", ""),
                         "image_group_label": image.get("candidate_group_label", ""),
                         "image_cluster_type": image.get("candidate_cluster_type", ""),
                         "image_evidence": image.get("visible_evidence", ""),
                         "image_confidence": image.get("confidence", 0.0),
                         "evidence": "; ".join(x for x in [item.get("evidence", ""),
                                                               "原理图：" + image.get("visible_evidence", "")] if x)})
        merged.append(item)
    return merged


def _is_major(component: Mapping[str, Any]) -> bool:
    kind = _component_kind(component).lower()
    ref = str(component.get("id", "")).upper()
    return kind in {"ic_module", "mcu", "power_module", "driver", "processor", "fpga", "controller"} or ref.startswith(("U", "IC"))


def _extract_domains(algorithm_result: Mapping[str, Any], component_rows: list[Mapping[str, Any]]) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[str], list[str], list[str]]:
    partition = algorithm_result.get("partition", {})
    domains = partition.get("l2_domains") or partition.get("l1_domains") or partition.get("domains") or []
    if not isinstance(domains, list):
        raise ValueError("算法结果缺少 partition.l2_domains 数组")
    refs = {str(c["id"]) for c in component_rows}
    assigned: set[str] = set()
    all_domains: list[dict[str, Any]] = []
    anchored: list[dict[str, Any]] = []
    unresolved_domains: list[dict[str, Any]] = []
    unresolved: list[str] = []
    for raw in domains:
        if not isinstance(raw, Mapping):
            continue
        members = sorted({str(x) for x in raw.get("members", []) if str(x) in refs})
        domain = dict(raw)
        domain["members"] = members
        all_domains.append(domain)
        anchor = raw.get("anchor")
        if anchor:
            anchored.append(domain)
            assigned.update(members)
        else:
            unresolved_domains.append(domain)
            unresolved.extend(members)
    unresolved.extend(sorted(refs - assigned - set(unresolved)))
    # The algorithm normally emits an anchor-null fallback domain. If an
    # older algorithm result omitted it, materialize one so final export still
    # has exactly one row for every input component.
    represented_refs = {ref for domain in all_domains for ref in domain.get("members", [])}
    missing_refs = sorted(refs - represented_refs)
    if missing_refs:
        fallback = {"id": "L2-UNRESOLVED", "level": "L2", "anchor": None,
                    "members": missing_refs,
                    "assignment_reason": "missing_from_algorithm_domain"}
        all_domains.append(fallback)
        unresolved_domains.append(fallback)
        unresolved.extend(missing_refs)
    major_refs = {str(c["id"]) for c in component_rows if _is_major(c)}
    unresolved_small = sorted(set(unresolved) - major_refs)
    # There is no meaningful completion target when the algorithm found no
    # anchored large-device domain. Keep these parts auditable but do not make
    # a model request that can only invent a domain.
    eligible = unresolved_small if anchored else []
    no_target_small = [] if anchored else unresolved_small
    excluded_major = sorted(set(unresolved) & major_refs)
    return all_domains, anchored, eligible, excluded_major, no_target_small


def _compact_l2_domain_context(domains: list[Mapping[str, Any]]) -> list[dict[str, Any]]:
    """Keep anchor ownership and pin-path evidence without unrelated L1 payloads."""
    compact: list[dict[str, Any]] = []
    assignment_fields = (
        "ref", "score", "shared_nets", "semantics", "assignment_reason",
        "connection_distance", "connection_path_display",
    )
    for domain in domains:
        assignments = []
        for assignment in domain.get("assignments", []):
            if not isinstance(assignment, Mapping):
                continue
            assignments.append({key: assignment[key] for key in assignment_fields if key in assignment})
        row = {
            "id": str(domain.get("id", "")),
            "anchor": str(domain.get("anchor", "")),
            "members": list(domain.get("members", [])),
            "assignment_reason": str(domain.get("assignment_reason", "")),
        }
        if assignments:
            row["assignments"] = assignments
        compact.append(row)
    return compact


def _build_small_component_completion_request(
    netlist: Mapping[str, Any], eligible: list[str], annotations: list[Mapping[str, Any]],
    target_domains: list[Mapping[str, Any]],
) -> dict[str, Any]:
    eligible_ids = set(eligible)
    eligible_annotations = [row for row in annotations if str(row.get("component_id", "")) in eligible_ids]
    relevant_connectivity = [
        net for net in netlist["nets"]
        if any(str(pin.get("component", "")) in eligible_ids for pin in net.get("pins", []))
    ]
    return {
        "task": "small_component_l2_completion",
        "eligible_component_ids": eligible,
        "components": [component for component in netlist["components"]
                       if str(component["id"]) in eligible_ids],
        # The completion prompt only needs annotations for eligible parts; the
        # previous request sent all annotations plus this same subset again.
        "function_annotations": eligible_annotations,
        "network_connectivity": relevant_connectivity,
        # Do not resend the full algorithm result: its partition overlaps these
        # anchor domains and includes unrelated L1 details. Preserve the anchor,
        # complete member list, and concise member pin-path evidence instead.
        "algorithm_l2_domains": _compact_l2_domain_context(target_domains),
        "constraints": {
            "existing_major_l2_ids": sorted(str(domain.get("id", "")) for domain in target_domains),
            "preserve_existing_major_domains": True,
            "do_not_move_existing_members": True,
            "require_full_coverage": True,
            "create_independent_auxiliary_clusters": True,
            "must_not_assign_to_major_device_domains": True,
        },
    }


def _completion_groups(result: Mapping[str, Any], eligible: list[str], net_names: set[str]) -> list[dict[str, Any]]:
    raw = result.get("clusters", [])
    if not isinstance(raw, list):
        raise ValueError("补划分结果缺少 clusters 数组")
    eligible_set = set(eligible)
    groups: list[dict[str, Any]] = []
    seen: set[str] = set()
    for item in raw:
        if not isinstance(item, Mapping):
            continue
        members = item.get("component_ids", item.get("members", []))
        if not isinstance(members, list):
            continue
        listed_ids = [str(cid).strip() for cid in members if str(cid).strip()]
        duplicate_ids = sorted(cid for cid in set(listed_ids) if listed_ids.count(cid) > 1 or cid in seen)
        if duplicate_ids:
            raise ValueError("补划分结果存在重复器件：" + ", ".join(duplicate_ids))
        unknown_ids = sorted(set(listed_ids) - eligible_set)
        if unknown_ids:
            raise ValueError("补划分结果包含非候选器件：" + ", ".join(unknown_ids))
        member_ids = sorted(set(listed_ids))
        if not member_ids:
            continue
        seen.update(member_ids)
        evidence = item.get("evidence_nets", [])
        if isinstance(evidence, str):
            evidence = [evidence]
        try:
            confidence = max(0.0, min(1.0, float(item.get("confidence", 0))))
        except (TypeError, ValueError):
            confidence = 0.0
        groups.append({"component_ids": member_ids,
                       "function_label": str(item.get("function_label", item.get("name", "辅助元件簇"))).strip() or "辅助元件簇",
                       "cluster_type": str(item.get("cluster_type", "other_auxiliary")).strip() or "other_auxiliary",
                       "reason": str(item.get("reason", "")),
                       "evidence_nets": sorted({str(x) for x in (evidence or []) if str(x) in net_names}),
                       "confidence": confidence, "source": "deepseek_function_topology_clustering"})
    missing = sorted(eligible_set - seen)
    if missing:
        raise ValueError("补划分结果未覆盖全部候选器件：" + ", ".join(missing))
    # Canonical order makes cluster IDs stable across repeated runs when the
    # model returns the same grouping in a different JSON order.
    groups.sort(key=lambda group: tuple(group["component_ids"]))
    return groups


def _cluster_domains(groups: list[Mapping[str, Any]]) -> list[dict[str, Any]]:
    domains: list[dict[str, Any]] = []
    for index, group in enumerate(groups, 1):
        domains.append({"id": f"L2-S{index:03d}", "level": "L2", "anchor": None,
                        "cluster_kind": "independent_auxiliary_function_cluster",
                        "function_label": group["function_label"], "cluster_type": group["cluster_type"],
                        "members": list(group["component_ids"]), "assignment_reason": group["reason"],
                        "evidence_nets": list(group["evidence_nets"]), "confidence": group["confidence"],
                        "source": group["source"]})
    return domains


def _group_assignments(groups: list[Mapping[str, Any]]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for domain in _cluster_domains(groups):
        for cid in domain["members"]:
            rows.append({"component_id": cid, "l2_id": domain["id"],
                         "reason": domain["assignment_reason"], "evidence_nets": domain["evidence_nets"],
                         "confidence": domain["confidence"], "assignment_mode": domain["cluster_type"],
                         "function_label": domain["function_label"], "source": domain["source"]})
    return rows


def _write_annotations_csv(path: Path, rows: list[Mapping[str, Any]]) -> None:
    fields = ["component_id", "component_name", "functional_category", "function_description", "evidence", "confidence", "status"]
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader(); writer.writerows({key: row.get(key, "") for key in fields} for row in rows)


def _write_assignments_csv(path: Path, domains: list[Mapping[str, Any]], completion: list[Mapping[str, Any]],
                           qwen_assignments: list[Mapping[str, Any]] | None = None) -> None:
    completion_by_ref = {row["component_id"]: row for row in completion}
    qwen_by_ref = {row["component_id"]: row for row in (qwen_assignments or [])}
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        fields = ["l2_id", "anchor", "cluster_kind", "function_label", "cluster_type", "component_id", "assignment_source", "assignment_reason", "assignment_mode", "evidence_nets", "confidence"]
        writer = csv.DictWriter(handle, fieldnames=fields); writer.writeheader()
        for domain in domains:
            for ref in domain.get("members", []):
                row = completion_by_ref.get(ref)
                qwen_row = qwen_by_ref.get(ref)
                writer.writerow({"l2_id": domain.get("id", ""), "anchor": domain.get("anchor", ""),
                                 "cluster_kind": domain.get("cluster_kind", "major_device_domain"),
                                 "function_label": domain.get("function_label", ""),
                                 "cluster_type": domain.get("cluster_type", ""),
                                 "component_id": ref,
                                 "assignment_source": qwen_row["source"] if qwen_row else (row["source"] if row else "algorithm_l2"),
                                 "assignment_reason": qwen_row["reason"] if qwen_row else (row["reason"] if row else domain.get("assignment_reason", "")),
                                 "assignment_mode": qwen_row.get("assignment_mode", "") if qwen_row else (row.get("assignment_mode", "") if row else "algorithm_l2"),
                                 "evidence_nets": qwen_row.get("visible_evidence", "") if qwen_row else (";".join(row["evidence_nets"]) if row else ""),
                                 "confidence": qwen_row["confidence"] if qwen_row else (row["confidence"] if row else "")})


def run_flow(args: argparse.Namespace) -> dict[str, Any]:
    flow_started = time.perf_counter()
    phase_times: dict[str, float] = {}
    call_metrics: list[dict[str, Any]] = []
    temperature = float(getattr(args, "temperature", 0.0))
    input_path = Path(args.netlist).resolve()
    out = Path(args.out).resolve(); out.mkdir(parents=True, exist_ok=True)
    netlist, topology = load_inputs(input_path)
    schematic_path = Path(args.schematic).resolve() if getattr(args, "schematic", None) else None
    schematic = _image_attachment(schematic_path)
    save_json(out / "normalized_netlist.json", netlist)
    save_json(out / "algorithm_topology.json", topology)
    if schematic:
        save_json(out / "schematic.json", {key: value for key, value in schematic.items() if key != "image_url"})
    digest = hashlib.sha256(json.dumps(netlist, ensure_ascii=False, sort_keys=True).encode()).hexdigest()

    config = _read_key_file(Path(args.api_key_file) if args.api_key_file else None)
    api_key = os.getenv("DEEPSEEK_API_KEY") or config.get("api_key") or config.get("deepseek_api_key") or config.get("key") or config.get("token")
    base_url = args.base_url or os.getenv("DEEPSEEK_BASE_URL") or config.get("base_url") or "https://api.deepseek.com/v1"
    model = args.model or os.getenv("DEEPSEEK_MODEL") or config.get("model") or "deepseek-chat"
    client = None if args.dry_run else DeepSeekClient(api_key, base_url=base_url, model=model,
                                                       timeout=args.timeout, temperature=temperature)
    qwen_model = None

    function_prompt = (PROMPT_DIR / "device_function_system.txt").read_text(encoding="utf-8")
    function_request = {"task": "device_function_recognition", "netlist": netlist,
                        "output_contract": {"annotations": [{"component_id": "", "functional_category": "", "function_description": "", "evidence": "", "confidence": 0.0}]}}
    save_json(out / "device_function_request.json", function_request)
    phase_started = time.perf_counter()
    if args.dry_run:
        annotations = [{"component_id": str(c["id"]), "component_name": str(c.get("value", "")),
                        "functional_category": "待识别", "function_description": "dry-run 未调用模型",
                        "evidence": "", "confidence": 0.0, "status": "not_called"} for c in netlist["components"]]
        function_raw = {"status": "dry_run"}
    else:
        function_raw = _timed_ask(client, function_prompt, function_request, call_metrics,
                                  "device_function_recognition")
        try:
            annotations = _annotation_rows(function_raw, netlist["components"])
        except ValueError as first_error:
            repair_request = {**function_request, "repair_instruction": str(first_error) + "；请严格输出全部器件且每个器件一条记录。"}
            function_raw = _timed_ask(client, function_prompt, repair_request, call_metrics,
                                      "device_function_recognition_repair")
            annotations = _annotation_rows(function_raw, netlist["components"])
    annotation_payload = {"schema": "device-functional-annotations-v1",
                          "input_sha256": digest, "annotations": annotations, "raw_response": function_raw}
    save_json(out / "device_function_annotations.json", annotation_payload)
    # Keep the established artifact name from the standalone function-labeling
    # flow as an alias, so downstream scripts can consume either flow.
    save_json(out / "device_annotations.json", annotation_payload)
    _write_annotations_csv(out / "device_function_annotations.csv", annotations)
    _write_annotations_csv(out / "device_annotations.csv", annotations)
    phase_times["device_function_recognition_and_save"] = round(time.perf_counter() - phase_started, 6)

    phase_started = time.perf_counter()
    algorithm_dir = Path(args.algorithm_dir).resolve()
    sys.path.insert(0, str(algorithm_dir))
    try:
        from partitioner.l1_partition import run as algorithm_run, validate_topology
    except ImportError as exc:
        raise RuntimeError(f"无法导入算法目录 {algorithm_dir}：{exc}") from exc
    validate_topology(topology)
    algorithm_result = algorithm_run(topology, project_id=netlist.get("name"),
                                     partition_mode="hierarchical", unresolved_llm=False,
                                     learn_soft_constraints=False)
    save_json(out / "algorithm_l2_result.json", algorithm_result)
    domains, target_domains, eligible, excluded_major, no_target_small = _extract_domains(algorithm_result, netlist["components"])
    all_net_names = {str(n["id"]) for n in netlist["nets"]}
    completion_request = _build_small_component_completion_request(
        netlist, eligible, annotations, target_domains,
    )
    save_json(out / "small_component_completion_request.json", completion_request)
    phase_times["local_algorithm_and_completion_request_build"] = round(time.perf_counter() - phase_started, 6)
    anchored_members = {str(ref) for domain in target_domains for ref in domain.get("members", [])}
    qwen_candidates = sorted((set(eligible) | set(no_target_small)) - anchored_members)
    qwen_supersedes_completion = _qwen_supersedes_completion(
        bool(schematic), target_domains, qwen_candidates, dry_run=args.dry_run,
    )
    phase_started = time.perf_counter()
    if eligible and not args.dry_run and not qwen_supersedes_completion:
        completion_system = (PROMPT_DIR / "small_component_completion_system.txt").read_text(encoding="utf-8")
        completion_raw = _timed_ask(client, completion_system, completion_request, call_metrics,
                                    "small_component_completion")
        try:
            groups = _completion_groups(completion_raw, eligible, all_net_names)
        except ValueError as first_error:
            repair_request = {**completion_request, "repair_instruction":
                              str(first_error) + "；请修正 clusters，必须覆盖 eligible_component_ids 中的全部器件且每个器件只出现一次，"
                              "必须输出 clusters，不得输出大器件域归属或 skipped_component_ids。"}
            completion_raw = _timed_ask(client, completion_system, repair_request, call_metrics,
                                        "small_component_completion_repair")
            groups = _completion_groups(completion_raw, eligible, all_net_names)
        completion = _group_assignments(groups)
        auxiliary_domains = _cluster_domains(groups)
    else:
        if args.dry_run:
            completion_status = "dry_run"
        elif qwen_supersedes_completion:
            completion_status = "skipped_redundant_qwen_assignment"
        else:
            completion_status = "not_needed"
        completion_raw = {"status": completion_status}
        completion = []
        auxiliary_domains = []

    phase_times["small_component_completion"] = round(time.perf_counter() - phase_started, 6)
    phase_started = time.perf_counter()
    qwen_model = None
    qwen_assignments: list[dict[str, Any]] = []
    qwen_raw: dict[str, Any] = {"status": "not_provided"}
    qwen_request: dict[str, Any] | None = None
    # Qwen is deliberately called last. It only sees parts that are still
    # outside anchored major-device domains after the algorithm and DeepSeek
    # completion, and it can only place them into an existing major domain.
    if schematic and target_domains and qwen_candidates:
        qwen_config = _read_key_file(Path(args.qwen_api_key_file) if getattr(args, "qwen_api_key_file", None) else None)
        qwen_model = getattr(args, "qwen_model", None) or os.getenv("QWEN_MODEL") or qwen_config.get("model") or "qwen3.8-flash"
        qwen_request = _build_qwen_assignment_request(netlist, qwen_candidates, target_domains)
        save_json(out / "qwen_assignment_request.json", qwen_request)
        if args.dry_run:
            qwen_raw = {"status": "dry_run"}
        else:
            qwen_key = os.getenv("QWEN_API_KEY") or qwen_config.get("qwen_api_key") or qwen_config.get("api_key") or qwen_config.get("key") or qwen_config.get("token")
            qwen_base = getattr(args, "qwen_base_url", None) or os.getenv("QWEN_BASE_URL") or qwen_config.get("base_url") or "https://maas.qianwenaiapi.com/compatible-mode/v1"
            qwen_client = DeepSeekClient(qwen_key, base_url=qwen_base, model=qwen_model,
                                         timeout=args.timeout, temperature=temperature, provider="千问")
            qwen_raw = _timed_ask(
                qwen_client, "你是谨慎的原理图 L2 归簇工程师，只输出可解析 JSON。",
                qwen_request, call_metrics, "schematic_image_assignment",
                image_url=schematic["image_url"], image_bytes=schematic["bytes"],
            )
            try:
                qwen_assignments = _validate_qwen_assignments(qwen_raw, qwen_candidates, target_domains)
            except ValueError as first_error:
                repair_request = {**qwen_request, "repair_instruction": str(first_error) + "；请严格覆盖全部候选器件，每个器件一次，目标只能是已有大器件 l2_id。"}
                qwen_raw = _timed_ask(
                    qwen_client, "你是谨慎的原理图 L2 归簇工程师，只输出可解析 JSON。",
                    repair_request, call_metrics, "schematic_image_assignment_repair",
                    image_url=schematic["image_url"], image_bytes=schematic["bytes"],
                )
                qwen_assignments = _validate_qwen_assignments(qwen_raw, qwen_candidates, target_domains)
        save_json(out / "qwen_assignment_response.json", qwen_raw)

    phase_times["schematic_image_assignment"] = round(time.perf_counter() - phase_started, 6)
    phase_started = time.perf_counter()
    # Qwen's validated result covers every candidate and replaces the DeepSeek
    # completion path; without Qwen, use DeepSeek's independent auxiliary clusters.
    final_domains = _merge_final_domains(domains, completion, qwen_assignments, auxiliary_domains)
    expected_refs = {str(c["id"]) for c in netlist["components"]}
    final_refs = [str(ref) for domain in final_domains for ref in domain.get("members", [])]
    missing_refs = sorted(expected_refs - set(final_refs))
    extra_refs = sorted(set(final_refs) - expected_refs)
    duplicate_refs = sorted(ref for ref in set(final_refs) if final_refs.count(ref) > 1)
    if missing_refs or extra_refs or duplicate_refs:
        raise RuntimeError(
            "最终 L2 归属完整性校验失败："
            f"missing={missing_refs[:20]}, extra={extra_refs[:20]}, duplicate={duplicate_refs[:20]}"
        )
    qwen_by_ref = {row["component_id"]: row for row in qwen_assignments}
    unresolved_after = sorted((set(qwen_candidates) - set(qwen_by_ref)) if qwen_assignments else
                              ((set(eligible) - {row["component_id"] for row in completion}) | set(no_target_small)))
    visual_payload = {"schema": "qwen-l2-major-domain-assignment-v1", "candidate_component_ids": qwen_candidates,
                      "assignments": qwen_assignments, "raw_response": qwen_raw} if schematic else {"status": "not_provided"}
    final_result = {"schema": "l2-integrated-flow-v1", "input_sha256": digest,
                    "source": str(input_path), "domains": final_domains,
                    "completion_assignments": completion, "still_unassigned_small_components": unresolved_after,
                    "small_components_without_completion_target": no_target_small,
                    "independent_auxiliary_clusters": auxiliary_domains,
                    "excluded_unassigned_major_components": excluded_major,
                    "schematic_evidence": visual_payload,
                    "qwen_assignments": qwen_assignments,
                    "algorithm_result": algorithm_result, "completion_raw_response": completion_raw}
    save_json(out / "l2_final_result.json", final_result)
    _write_assignments_csv(out / "l2_final_assignments.csv", final_domains, completion, qwen_assignments)
    phase_times["finalize_and_write_outputs"] = round(time.perf_counter() - phase_started, 6)
    call_stage_seconds: Counter[str] = Counter()
    for call in call_metrics:
        call_stage_seconds[str(call.get("stage", "unknown"))] += float(call.get("elapsed_seconds", 0.0))
    manifest = {"schema": "l2-integrated-flow-manifest-v1", "status": "completed", "input": str(input_path),
                "input_sha256": digest, "model": {"provider": "deepseek", "name": model, "base_url": base_url,
                "temperature": temperature, "dry_run": bool(args.dry_run)}, "counts": {"components": len(netlist["components"]),
                "l2_domains": len(final_domains), "algorithm_l2_domains": len(domains),
                "anchored_l2_domains": len(target_domains), "independent_auxiliary_clusters": len(auxiliary_domains),
                "eligible_small_components": len(eligible),
                "completion_assignments": len(completion), "still_unassigned_small_components": len(unresolved_after),
                "completion_skipped_redundant_qwen": qwen_supersedes_completion,
                "final_assignment_count": len(final_refs), "final_unique_assignment_count": len(set(final_refs))},
                "schematic": str(schematic_path) if schematic_path else None,
                "qwen_model": qwen_model,
                "timing": {
                    "total_seconds": round(time.perf_counter() - flow_started, 6),
                    "phases_seconds": phase_times,
                    "model_call_seconds_by_stage": {stage: round(seconds, 6)
                                                     for stage, seconds in sorted(call_stage_seconds.items())},
                    "model_calls": call_metrics,
                },
                "artifacts": ["normalized_netlist.json", "algorithm_topology.json", "device_function_annotations.json",
                              "device_function_annotations.csv", "device_annotations.json", "device_annotations.csv",
                              "algorithm_l2_result.json", "small_component_completion_request.json",
                              "l2_final_result.json", "l2_final_assignments.csv"] + (["schematic.json", "qwen_assignment_request.json",
                              "qwen_assignment_response.json"] if schematic and qwen_request else [])}
    save_json(out / "flow_manifest.json", manifest)
    return manifest


def _round_assignment_map(result: Mapping[str, Any]) -> dict[str, str]:
    mapping: dict[str, str] = {}
    for domain in result.get("domains", []):
        if not isinstance(domain, Mapping):
            continue
        did = str(domain.get("id", ""))
        if domain.get("cluster_kind") == "independent_auxiliary_function_cluster":
            did = "AUX:" + "|".join(sorted(str(ref) for ref in domain.get("members", [])))
        for ref in domain.get("members", []):
            mapping[str(ref)] = did
    return mapping


def _round_function_map(result: Mapping[str, Any]) -> dict[str, str]:
    mapping: dict[str, str] = {}
    for row in result.get("annotations", []):
        if isinstance(row, Mapping):
            mapping[str(row.get("component_id", ""))] = str(row.get("functional_category", ""))
    return mapping


def run_multi_round(args: argparse.Namespace) -> dict[str, Any]:
    """Run independent flow repetitions and summarize assignment stability."""
    root_out = Path(args.out).resolve()
    root_out.mkdir(parents=True, exist_ok=True)
    requested = int(args.rounds)
    temperature = float(getattr(args, "temperature", 0.0))
    width = max(2, len(str(requested)))
    manifests: list[dict[str, Any]] = []
    round_data: list[dict[str, Any]] = []
    errors: list[dict[str, Any]] = []
    for index in range(1, requested + 1):
        round_dir = root_out / f"round_{index:0{width}d}"
        round_args = argparse.Namespace(**vars(args))
        round_args.out = str(round_dir)
        round_args.rounds = 1
        try:
            manifest = run_flow(round_args)
            result_path = round_dir / "l2_final_result.json"
            annotation_path = round_dir / "device_function_annotations.json"
            result = json.loads(result_path.read_text(encoding="utf-8"))
            annotation_result = json.loads(annotation_path.read_text(encoding="utf-8"))
            manifests.append(manifest)
            round_data.append({"round": index, "result": result, "annotations": annotation_result})
        except (OSError, ValueError, RuntimeError, json.JSONDecodeError) as exc:
            errors.append({"round": index, "error_type": type(exc).__name__, "error": str(exc)})

    if not round_data:
        raise RuntimeError(f"所有多轮运行均失败：{errors}")

    rounds = [item["round"] for item in round_data]
    assignment_maps = [_round_assignment_map(item["result"]) for item in round_data]
    function_maps = [_round_function_map(item["annotations"]) for item in round_data]
    component_ids = sorted(set().union(*(mapping.keys() for mapping in assignment_maps)))
    assignment_rows: list[dict[str, Any]] = []
    for cid in component_ids:
        values = [mapping.get(cid, "") for mapping in assignment_maps]
        votes = Counter(value for value in values if value)
        majority = sorted(votes.items(), key=lambda item: (-item[1], item[0]))[0] if votes else ("", 0)
        assignment_rows.append({"component_id": cid, "round_assignments": values,
                                "votes": dict(sorted(votes.items())), "majority_l2_id": majority[0],
                                "agreement": majority[1] / len(values) if values else 0.0,
                                "stable": majority[1] == len(values)})
    function_ids = sorted(set().union(*(mapping.keys() for mapping in function_maps)))
    function_rows: list[dict[str, Any]] = []
    for cid in function_ids:
        values = [mapping.get(cid, "") for mapping in function_maps]
        votes = Counter(value for value in values if value)
        majority = sorted(votes.items(), key=lambda item: (-item[1], item[0]))[0] if votes else ("", 0)
        function_rows.append({"component_id": cid, "round_categories": values,
                              "votes": dict(sorted(votes.items())), "majority_category": majority[0],
                              "agreement": majority[1] / len(values) if values else 0.0,
                              "stable": majority[1] == len(values)})

    assignment_agreements = [float(row["agreement"]) for row in assignment_rows]
    function_agreements = [float(row["agreement"]) for row in function_rows]
    report = {"schema": "l2-multi-round-stability-v1", "requested_rounds": requested,
              "completed_rounds": len(round_data), "rounds": rounds, "errors": errors,
              "temperature": temperature,
              "assignment": {"components": assignment_rows,
                              "mean_agreement": sum(assignment_agreements) / len(assignment_agreements) if assignment_agreements else 0.0,
                              "stable_component_count": sum(1 for row in assignment_rows if row["stable"]),
                              "unstable_component_ids": [row["component_id"] for row in assignment_rows if not row["stable"]]},
              "function": {"components": function_rows,
                           "mean_agreement": sum(function_agreements) / len(function_agreements) if function_agreements else 0.0,
                           "stable_component_count": sum(1 for row in function_rows if row["stable"]),
                           "unstable_component_ids": [row["component_id"] for row in function_rows if not row["stable"]]},
              "round_manifests": manifests}
    save_json(root_out / "stability_report.json", report)
    with (root_out / "l2_assignment_stability.csv").open("w", encoding="utf-8-sig", newline="") as handle:
        fields = ["component_id"] + [f"round_{number:0{width}d}" for number in rounds] + ["majority_l2_id", "agreement", "stable"]
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in assignment_rows:
            output = {"component_id": row["component_id"], "majority_l2_id": row["majority_l2_id"],
                      "agreement": row["agreement"], "stable": row["stable"]}
            output.update({f"round_{number:0{width}d}": value for number, value in zip(rounds, row["round_assignments"])})
            writer.writerow(output)
    with (root_out / "function_stability.csv").open("w", encoding="utf-8-sig", newline="") as handle:
        fields = ["component_id"] + [f"round_{number:0{width}d}" for number in rounds] + ["majority_category", "agreement", "stable"]
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in function_rows:
            output = {"component_id": row["component_id"], "majority_category": row["majority_category"],
                      "agreement": row["agreement"], "stable": row["stable"]}
            output.update({f"round_{number:0{width}d}": value for number, value in zip(rounds, row["round_categories"])})
            writer.writerow(output)
    manifest = {"schema": "l2-multi-round-manifest-v1", "status": "completed_with_errors" if errors else "completed",
                "requested_rounds": requested, "completed_rounds": len(round_data), "output": str(root_out),
                "temperature": temperature, "stability_report": str(root_out / "stability_report.json"),
                "round_directories": [str(root_out / f"round_{index:0{width}d}") for index in rounds],
                "errors": errors}
    save_json(root_out / "flow_manifest.json", manifest)
    return manifest


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="L2 综合流程：算法初划分 + DeepSeek 网表补划分 + 千问原理图到大器件簇归簇")
    parser.add_argument("netlist", help="标准 JSON 网表或 EasyEDA .enet")
    parser.add_argument("--schematic", help="可选原理图图片；交给千问作为 L2 视觉证据")
    parser.add_argument("--out", default="l2_flow_output", help="输出目录")
    parser.add_argument("--api-key-file", "--deepseek-api-key-file")
    parser.add_argument("--base-url", default=None)
    parser.add_argument("--model", default=None)
    parser.add_argument("--qwen-api-key-file", help="千问 API 配置文件；也可设置 QWEN_API_KEY")
    parser.add_argument("--qwen-base-url", default=None)
    parser.add_argument("--qwen-model", default=None)
    parser.add_argument("--timeout", type=int, default=180)
    parser.add_argument("--temperature", type=float, default=0.0,
                        help="DeepSeek 采样温度；多轮稳定性测试可设为 0.2-0.8")
    parser.add_argument("--rounds", type=int, default=1,
                        help="独立重复运行次数；大于 1 时生成稳定性报告")
    parser.add_argument("--algorithm-dir", default=str(DEFAULT_ALGORITHM_DIR))
    parser.add_argument("--dry-run", action="store_true", help="只生成请求和算法结果，不调用任何模型")
    args = parser.parse_args(argv)
    if args.rounds < 1:
        parser.error("--rounds 必须是正整数")
    if not 0 <= args.temperature <= 2:
        parser.error("--temperature 必须在 0 到 2 之间")
    try:
        manifest = run_multi_round(args) if args.rounds > 1 else run_flow(args)
    except (OSError, ValueError, RuntimeError, json.JSONDecodeError) as exc:
        error_dir = Path(args.out).resolve()
        try:
            save_json(error_dir / "flow_error.json", {
                "schema": "l2-integrated-flow-error-v1",
                "error_type": type(exc).__name__,
                "error": str(exc),
                "base_url": args.base_url or os.getenv("DEEPSEEK_BASE_URL") or "https://api.deepseek.com/v1",
                "model": args.model or os.getenv("DEEPSEEK_MODEL") or "deepseek-chat",
            })
        except OSError:
            pass
        print(f"error: {exc}", file=sys.stderr)
        return 2
    print(_json(manifest))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
