# 高低电压域双簇划分器

本目录现在定义一条独立的 L3 电压域划分流程：只将 `.enet`/JSON 网表交给 **DeepSeek**，把每个器件分配到且仅分配到两个簇之一：**低压簇**或**高压簇**。不运行 L1/L2 算法，也不调用千问或其他视觉模型。

## 电压规则

默认阈值为 **12 V**，可通过 `--threshold-v` 修改。绝对工作电压不高于阈值归低压簇，高于阈值归高压簇。模型需参考器件额定/工作电压、引脚、网络和拓扑；网表无法确定电压时仍需做 best-effort 归属、降低置信度并记录不确定位号。跨越两侧的隔离器、变压器、光耦、接口或转换器仍放入两个簇中的一个，并说明其边界属性，不创建第三簇。

这是基于网表证据的分组结果，不替代具体产品标准要求的绝缘距离、耐压或安全认证验证。

## 运行

需要 Python 3.10 或更新版本，无第三方依赖。配置 DeepSeek API key：

```powershell
$env:DEEPSEEK_API_KEY = "你的 API key"
```

或准备配置文件（仅本地保存，不要提交到版本库）：

```text
api_key=你的 API key
```

双击 `启动高低压划分.cmd` 或执行 `python gui.py` 可打开图形界面。界面中的整个参数区域支持右侧垂直滚动条和鼠标滚轮，运行日志也有独立的上下滚动条，适合较小屏幕。选择网表和 DeepSeek 接口文档后，程序自动读取 `模型名`、`Base URL` 和 `API`，不需要逐项填写。

接口文档支持如下格式，也支持英文键名和 `=` 分隔：

```text
模型名：deepseek-v4-pro
Base URL：https://api.deepseek.com
API：你的 API key
```

界面中的“独立分析轮数”用于稳定性评估。例如填 `5`，程序会对同一网表连续调用 DeepSeek 5 次，每轮结果保存到 `round_01/` 至 `round_05/`。这不是参数训练，不会修改 DeepSeek 模型；它用于观察同一输入的多次推理是否给出相同归属。采样温度为 `0` 时更偏确定性；想观察采样变化可设为 `0.2` 到 `0.8`。

运行 `.enet` 或标准 JSON 网表：

```powershell
python C:\Users\30943\Desktop\划分器_针对L3\voltage_partition.py C:\path\to\board.enet `
  --api-key-file C:\path\to\DS接口文档.txt `
  --threshold-v 12 `
  --rounds 5 `
  --temperature 0.5 `
  --out C:\path\to\l3-output
```

可先用 `--dry-run` 检查网表解析并保存模型请求，不访问 DeepSeek。兼容 API 地址和模型名可通过 `--base-url`、`--model` 覆盖。

## 输出

- `voltage_partition.json`：恰有 `low_voltage`、`high_voltage` 两个簇及逐器件归属、证据网络、理由、工作电压估计和置信度。
- `voltage_partition.csv`：逐器件归属表，包含 DeepSeek 的簇判断、证据网络、理由和置信度。
- `input_netlist.json`、`request.json`、`model_response.json`：归一化网表、模型输入和原始响应，便于审计和复现。
- 每个 `round_XX/` 中保存 `deepseek_response.json` 和 `voltage_partition.json`。
- `run.json`：模型、阈值、簇规模与不确定器件摘要。
- `stability_report.json/csv`：多轮有效结果的完整分配一致率、每个器件的簇一致率、稳定器件比例、置信度均值和标准差；`all_rounds_same_assignment` 表示所有有效轮次是否完全相同。

DeepSeek 请求现在只要求返回每个器件的 `component_id`、`cluster_id` 和 `confidence`，不再要求模型重复输出完整簇成员列表；程序会在本地生成两个簇。这样可以避免大型网表因重复位号和长理由触发 `finish_reason=length`。请求同时设置了 8192 的输出上限；若仍遇到截断，程序会记录 `round_XX/error.json`。

对于名称包含 `v4`、`pro` 或 `reason` 的 DeepSeek 模型，程序会自动请求关闭思考输出，避免思考内容占满 8192 个输出 token 而没有留下 JSON；如果兼容网关不接受该参数，会自动退回普通请求。多轮中的每一轮都会独立应用这个处理。

程序会拒绝缺失、重复或网表中不存在的器件位号，拒绝第三种簇 ID，并校验引用网络确实存在于输入网表。

## 提取来源说明

`llm_base/` 中的网表解析和 OpenAI 兼容 API 客户端来自 `划分器LLM部分`。本目录的 `voltage_partition.py` 在此基础上实现仅 DeepSeek 的 L3 网表分析。`history/` 仅保留旧运行文件供结构核对，不参与程序运行；见 `历史代码核对.md`。
