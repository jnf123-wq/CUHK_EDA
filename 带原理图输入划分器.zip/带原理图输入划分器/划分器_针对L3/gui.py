#!/usr/bin/env python3
"""Tkinter GUI for the DeepSeek two-cluster voltage partition flow."""

from __future__ import annotations

import os
import queue
import subprocess
import sys
import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from llm_base.api_client import read_api_config_file


ROOT = Path(__file__).resolve().parent
FLOW = ROOT / "voltage_partition.py"


class ScrollableFrame(ttk.Frame):
    """A frame with mouse-wheel and vertical scrollbar support."""

    def __init__(self, parent: tk.Misc, **kwargs):
        super().__init__(parent, **kwargs)
        self.canvas = tk.Canvas(self, highlightthickness=0, background="#f3f6fa")
        self.scrollbar = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.body = ttk.Frame(self.canvas, padding=(18, 16, 18, 24))
        self.window_id = self.canvas.create_window((0, 0), window=self.body, anchor="nw")
        self.canvas.configure(yscrollcommand=self.scrollbar.set)
        self.canvas.grid(row=0, column=0, sticky="nsew")
        self.scrollbar.grid(row=0, column=1, sticky="ns")
        self.rowconfigure(0, weight=1)
        self.columnconfigure(0, weight=1)
        self.body.bind("<Configure>", lambda _event: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<Configure>", lambda event: self.canvas.itemconfigure(self.window_id, width=event.width))
        self.canvas.bind_all("<MouseWheel>", self._wheel, add="+")
        self.canvas.bind_all("<Button-4>", lambda _event: self.canvas.yview_scroll(-3, "units"), add="+")
        self.canvas.bind_all("<Button-5>", lambda _event: self.canvas.yview_scroll(3, "units"), add="+")

    def _wheel(self, event: tk.Event):
        if event.delta:
            steps = int(event.delta / 120)
            self.canvas.yview_scroll(-steps if steps else (-1 if event.delta > 0 else 1), "units")


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("L3 高低电压域划分器")
        self.geometry("920x720")
        self.minsize(700, 520)
        self.configure(background="#f3f6fa")
        self.events: queue.Queue[tuple[str, str]] = queue.Queue()
        self.running = False
        self._style()
        self._build()
        self.after(100, self._drain_events)

    def _style(self):
        style = ttk.Style(self)
        try:
            style.theme_use("vista")
        except tk.TclError:
            pass
        style.configure("Title.TLabel", font=("Microsoft YaHei UI", 20, "bold"), foreground="#19324d")
        style.configure("Subtitle.TLabel", font=("Microsoft YaHei UI", 10), foreground="#5b6b7c")
        style.configure("Section.TLabel", font=("Microsoft YaHei UI", 12, "bold"), foreground="#1f4e79")
        style.configure("Run.TButton", font=("Microsoft YaHei UI", 11, "bold"), padding=(16, 8))
        style.configure("Hint.TLabel", foreground="#687789")

    def _build(self):
        frame = ScrollableFrame(self)
        frame.pack(fill="both", expand=True)
        body = frame.body
        body.columnconfigure(1, weight=1)

        ttk.Label(body, text="L3 高低电压域划分器", style="Title.TLabel").grid(row=0, column=0, columnspan=3, sticky="w")
        ttk.Label(body, text="DeepSeek 分析网表 → 划分低压簇 / 高压簇", style="Subtitle.TLabel").grid(row=1, column=0, columnspan=3, sticky="w", pady=(2, 18))

        self.netlist = tk.StringVar()
        self.key_file = tk.StringVar()
        self.output = tk.StringVar(value=str(ROOT / "output"))
        self.threshold = tk.StringVar(value="12")
        self.base_url = tk.StringVar(value="https://api.deepseek.com/v1")
        self.model = tk.StringVar(value="deepseek-chat")
        self.rounds = tk.StringVar(value="1")
        self.temperature = tk.StringVar(value="0.0")
        self.dry_run = tk.BooleanVar(value=False)

        ttk.Label(body, text="输入与输出", style="Section.TLabel").grid(row=2, column=0, columnspan=3, sticky="w", pady=(0, 8))
        self._path_row(body, 3, "原始网表", self.netlist, self._choose_netlist, "支持 JSON 和 EasyEDA .enet")
        self._path_row(body, 7, "DeepSeek 接口文档", self.key_file, self._choose_key, "选择包含模型名、Base URL、API 的文本；自动读取")
        self._path_row(body, 9, "输出目录", self.output, self._choose_output, "保存 DeepSeek 划分结果和稳定性报告")

        ttk.Label(body, text="划分设置", style="Section.TLabel").grid(row=13, column=0, columnspan=3, sticky="w", pady=(18, 8))
        self._entry_row(body, 14, "高低压阈值（V）", self.threshold)
        self._entry_row(body, 15, "DeepSeek Base URL", self.base_url)
        self._entry_row(body, 16, "DeepSeek 模型", self.model)
        self._entry_row(body, 17, "独立分析轮数", self.rounds)
        self._entry_row(body, 18, "采样温度", self.temperature)
        options = ttk.Frame(body)
        options.grid(row=21, column=0, columnspan=3, sticky="ew", pady=(12, 4))
        ttk.Checkbutton(options, text="Dry-run（只解析网表，不调用任何模型）", variable=self.dry_run).pack(side="left")
        ttk.Label(options, text="多轮只做独立推理评估，不更新模型参数；结果固定只有两个簇。", style="Hint.TLabel").pack(side="left", padx=(16, 0))

        ttk.Label(body, text="运行日志", style="Section.TLabel").grid(row=22, column=0, columnspan=3, sticky="w", pady=(18, 8))
        log_frame = ttk.Frame(body)
        log_frame.grid(row=23, column=0, columnspan=3, sticky="nsew")
        self.log = tk.Text(log_frame, height=12, wrap="word", state="disabled", background="#101820", foreground="#d6e8f5", insertbackground="white", relief="flat", padx=10, pady=10)
        log_scroll = ttk.Scrollbar(log_frame, orient="vertical", command=self.log.yview)
        self.log.configure(yscrollcommand=log_scroll.set)
        self.log.grid(row=0, column=0, sticky="nsew")
        log_scroll.grid(row=0, column=1, sticky="ns")
        log_frame.rowconfigure(0, weight=1)
        log_frame.columnconfigure(0, weight=1)

        buttons = ttk.Frame(body)
        buttons.grid(row=24, column=0, columnspan=3, sticky="ew", pady=(16, 10))
        self.run_button = ttk.Button(buttons, text="开始划分", style="Run.TButton", command=self._start)
        self.run_button.pack(side="left")
        ttk.Button(buttons, text="打开输出目录", command=self._open_output).pack(side="left", padx=(10, 0))
        self.status = ttk.Label(buttons, text="等待输入", style="Hint.TLabel")
        self.status.pack(side="right")
        ttk.Label(body, text="每轮保存 DeepSeek 网表结果；stability_report.json/csv 汇总归属一致率与置信度波动。", style="Hint.TLabel", wraplength=820).grid(row=25, column=0, columnspan=3, sticky="w")

    def _path_row(self, parent, row, label, variable, command, hint):
        ttk.Label(parent, text=label, width=16).grid(row=row, column=0, sticky="w", pady=5)
        ttk.Entry(parent, textvariable=variable).grid(row=row, column=1, sticky="ew", pady=5, padx=(0, 8))
        ttk.Button(parent, text="浏览…", command=command).grid(row=row, column=2, pady=5)
        ttk.Label(parent, text=hint, style="Hint.TLabel").grid(row=row + 1, column=1, columnspan=2, sticky="w")

    def _entry_row(self, parent, row, label, variable):
        ttk.Label(parent, text=label, width=16).grid(row=row, column=0, sticky="w", pady=5)
        ttk.Entry(parent, textvariable=variable).grid(row=row, column=1, columnspan=2, sticky="ew", pady=5)

    def _choose_netlist(self):
        path = filedialog.askopenfilename(title="选择原始网表", filetypes=[("网表", "*.json *.enet"), ("所有文件", "*.*")])
        if path:
            self.netlist.set(path)

    def _choose_key(self):
        self._choose_interface_doc("DeepSeek", self.key_file, self.base_url, self.model,
                                   "选择 DeepSeek 接口文档")

    def _choose_interface_doc(self, provider, path_var, base_var, model_var, title):
        path = filedialog.askopenfilename(title=title, filetypes=[("接口文档", "*.txt *.env *.conf *.ini *.py"), ("所有文件", "*.*")])
        if not path:
            return
        try:
            config = read_api_config_file(path)
            missing = [name for name in ("api_key", "base_url", "model") if not config.get(name)]
            if missing:
                raise ValueError("缺少字段：" + ", ".join(missing))
        except Exception as exc:
            messagebox.showerror("接口文档无法识别", f"{provider} 文档解析失败：\n{exc}")
            return
        path_var.set(path)
        base_var.set(config["base_url"])
        model_var.set(config["model"])
        self._write_log(f"已读取{provider}接口文档：模型 {config['model']}，Base URL {config['base_url']}（API key 已隐藏）\n")

    def _choose_output(self):
        path = filedialog.askdirectory(title="选择输出目录")
        if path:
            self.output.set(path)

    def _write_log(self, text):
        self.log.configure(state="normal")
        self.log.insert("end", text)
        self.log.see("end")
        self.log.configure(state="disabled")

    def _start(self):
        if self.running:
            return
        netlist = Path(self.netlist.get().strip())
        if not netlist.is_file():
            messagebox.showerror("缺少输入", "请选择有效的 JSON 或 .enet 原始网表。")
            return
        try:
            threshold = float(self.threshold.get().strip())
            if threshold <= 0:
                raise ValueError
        except ValueError:
            messagebox.showerror("参数错误", "高低压阈值必须是大于 0 的数字。")
            return
        try:
            rounds = int(self.rounds.get().strip())
            if rounds < 1:
                raise ValueError
        except ValueError:
            messagebox.showerror("参数错误", "独立分析轮数必须是正整数。")
            return
        try:
            temperature = float(self.temperature.get().strip())
            if not 0 <= temperature <= 2:
                raise ValueError
        except ValueError:
            messagebox.showerror("参数错误", "采样温度必须在 0 到 2 之间。")
            return
        output = Path(self.output.get().strip() or ROOT / "output")
        command = [sys.executable, "-u", str(FLOW), str(netlist), "--out", str(output), "--threshold-v", str(threshold),
                   "--rounds", str(rounds), "--temperature", str(temperature), "--base-url", self.base_url.get().strip(), "--model", self.model.get().strip()]
        if self.key_file.get().strip():
            command.extend(["--api-key-file", self.key_file.get().strip()])
        if self.dry_run.get():
            command.append("--dry-run")
        self.running = True
        self.run_button.configure(state="disabled")
        self.status.configure(text="运行中…")
        self._write_log("\n$ " + subprocess.list2cmdline(command) + "\n\n")
        threading.Thread(target=self._run_process, args=(command,), daemon=True).start()

    def _run_process(self, command):
        try:
            env = os.environ.copy()
            env["PYTHONIOENCODING"] = "utf-8"
            process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace", bufsize=1, env=env)
            assert process.stdout is not None
            for line in process.stdout:
                self.events.put(("log", line))
            self.events.put(("done", str(process.wait())))
        except Exception as exc:
            self.events.put(("error", str(exc)))

    def _drain_events(self):
        try:
            while True:
                kind, value = self.events.get_nowait()
                if kind == "log":
                    self._write_log(value)
                elif kind == "done":
                    self.running = False
                    self.run_button.configure(state="normal")
                    ok = value == "0"
                    self.status.configure(text="完成" if ok else f"失败（退出码 {value}）")
                    self._write_log(f"\n流程结束，退出码：{value}\n")
                    if ok:
                        messagebox.showinfo("运行完成", f"结果已写入：\n{Path(self.output.get()).resolve()}")
                else:
                    self.running = False
                    self.run_button.configure(state="normal")
                    self.status.configure(text="启动失败")
                    self._write_log("启动失败：" + value + "\n")
                    messagebox.showerror("启动失败", value)
        except queue.Empty:
            pass
        self.after(100, self._drain_events)

    def _open_output(self):
        path = Path(self.output.get().strip() or ROOT / "output")
        path.mkdir(parents=True, exist_ok=True)
        if hasattr(os, "startfile"):
            os.startfile(str(path))
        else:
            messagebox.showinfo("输出目录", str(path.resolve()))


if __name__ == "__main__":
    App().mainloop()
