"""Reusable netlist and DeepSeek client helpers extracted from the LLM flow."""
