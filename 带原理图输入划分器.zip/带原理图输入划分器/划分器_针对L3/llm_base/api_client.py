"""Minimal OpenAI-compatible client and configuration helpers for annotation only."""

from __future__ import annotations

import ast
import base64
import json
import mimetypes
import os
import re
from pathlib import Path
from typing import Any, Mapping
from urllib.error import HTTPError
from urllib.request import Request, urlopen


def read_api_config_file(path: str | Path) -> dict[str, str]:
    source = Path(path)
    text = source.read_text(encoding="utf-8-sig")
    result: dict[str, str] = {}
    names = {"api_key", "apikey", "key", "token", "qwen_api_key", "deepseek_api_key", "base_url", "model"}
    try:
        tree = ast.parse(text, filename=str(source))
    except SyntaxError:
        tree = None
    if tree is not None:
        for node in ast.walk(tree):
            if isinstance(node, (ast.Assign, ast.AnnAssign)):
                targets = node.targets if isinstance(node, ast.Assign) else [node.target]
                if isinstance(node.value, ast.Constant) and isinstance(node.value.value, str):
                    for target in targets:
                        if isinstance(target, ast.Name) and target.id.lower() in names:
                            result[target.id.lower()] = node.value.value.strip()
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        match = re.match(r"^\s*(模型名|model|model_name|base\s*url|base_url|api(?:[\s_-]*key)?|apikey|token|key)\s*[:：=]\s*(.*?)\s*$", line, re.IGNORECASE)
        if match:
            label, value = match.group(1).lower().replace(" ", ""), match.group(2)
        elif "=" in line:
            label, value = line.split("=", 1)
            label, value = label.strip().lower(), value.strip()
            if label not in names:
                continue
        else:
            continue
        if label in {"模型名", "model", "model_name"}:
            key = "model"
        elif label in {"baseurl", "base_url"}:
            key = "base_url"
        else:
            key = "api_key"
        value = value.split("#", 1)[0].strip().rstrip(",").strip().strip("'\"")
        if value and not value.startswith(("os.getenv", "getenv(", "os.environ")):
            result.setdefault(key, value)
    if not result and text.strip() and "\n" not in text.strip() and "=" not in text.strip():
        result["api_key"] = text.strip()
    return result


def _file_attachment(path: str | Path | None) -> dict[str, Any] | None:
    if not path:
        return None
    source = Path(path)
    if not source.is_file():
        raise ValueError(f"schematic file does not exist: {source}")
    record: dict[str, Any] = {"name": source.name, "suffix": source.suffix.lower(), "bytes": source.stat().st_size}
    mime, _ = mimetypes.guess_type(source.name)
    if mime and mime.startswith("image/") and source.stat().st_size <= 8 * 1024 * 1024:
        record["image_url"] = f"data:{mime};base64,{base64.b64encode(source.read_bytes()).decode('ascii')}"
    return record


def _response_json(payload: Mapping[str, Any]) -> dict[str, Any]:
    content = None
    message: Mapping[str, Any] = {}
    choice: Mapping[str, Any] = {}
    try:
        choice = payload["choices"][0]
        message = choice["message"]
        content = message.get("content")
        if isinstance(content, list):
            content = "".join(str(item.get("text", item.get("content", ""))) for item in content if isinstance(item, Mapping))
        text = str(content or "").strip()
        if not text:
            raise ValueError("empty assistant content")
        try:
            result = json.loads(text)
        except json.JSONDecodeError:
            # Some OpenAI-compatible gateways ignore json_object mode and wrap
            # an otherwise valid object in prose or a Markdown code fence.
            fenced = re.search(r"```(?:json)?\s*([\s\S]*?)\s*```", text, re.IGNORECASE)
            candidate = fenced.group(1).strip() if fenced else None
            if candidate is None:
                start = text.find("{")
                if start >= 0:
                    try:
                        result, _ = json.JSONDecoder().raw_decode(text[start:])
                    except json.JSONDecodeError:
                        result = None
                else:
                    result = None
            else:
                result = json.loads(candidate)
            if result is None:
                raise ValueError("assistant content is not parseable JSON")
    except (KeyError, IndexError, TypeError, ValueError, json.JSONDecodeError) as exc:
        refusal = message.get("refusal") if isinstance(message, Mapping) else None
        diagnostic_content = content
        if not diagnostic_content and isinstance(message, Mapping):
            diagnostic_content = message.get("reasoning_content") or message.get("reasoning")
        preview = str(diagnostic_content or "")[:1000].replace("\x00", "")
        if len(str(diagnostic_content or "")) > 1000:
            preview += " …[truncated]"
        detail = f"finish_reason={choice.get('finish_reason', 'unknown')}"
        if refusal:
            detail += f"; refusal={str(refusal)[:300]}"
        if preview:
            detail += f"; content_preview={preview!r}"
        if isinstance(payload.get("error"), Mapping):
            detail += f"; api_error={payload['error']}"
        raise RuntimeError(f"model response did not contain a valid JSON object ({detail})") from exc
    if not isinstance(result, dict):
        raise RuntimeError("model response root must be a JSON object")
    return result


class _JSONClient:
    def __init__(self, *, base_url: str, model: str, api_key: str, timeout: int | None = None):
        normalized_base = base_url.strip().rstrip("/")
        if normalized_base.endswith("/chat/completions"):
            normalized_base = normalized_base[:-len("/chat/completions")]
        self.base_url, self.model, self.api_key, self.timeout = normalized_base, model, api_key, timeout

    def ask(self, system: str, prompt: Mapping[str, Any], *, image_url: str | None = None,
            temperature: float = 0.0, max_tokens: int | None = None,
            disable_thinking: bool = False) -> dict[str, Any]:
        text = json.dumps(prompt, ensure_ascii=False)
        content: Any = text
        if image_url:
            content = [{"type": "text", "text": text}, {"type": "image_url", "image_url": {"url": image_url}}]
        request_body = {"model": self.model, "temperature": temperature, "response_format": {"type": "json_object"},
                        "messages": [{"role": "system", "content": system}, {"role": "user", "content": content}]}
        if max_tokens is not None:
            request_body["max_tokens"] = max_tokens
        if disable_thinking:
            # Supported by current DeepSeek-compatible endpoints. The caller
            # retries without this field if a legacy gateway rejects it.
            request_body["thinking"] = {"type": "disabled"}
        body = json.dumps(request_body, ensure_ascii=False).encode("utf-8")
        request = Request(f"{self.base_url}/chat/completions", data=body, method="POST",
                          headers={"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"})
        try:
            with urlopen(request, timeout=self.timeout) as response:
                raw = response.read().decode("utf-8", errors="replace")
                try:
                    payload = json.loads(raw)
                except json.JSONDecodeError as exc:
                    raise RuntimeError(f"API returned non-JSON HTTP response: {raw[:500]!r}") from exc
                if not isinstance(payload, Mapping):
                    raise RuntimeError(f"API response root is not an object: {raw[:500]!r}")
                return _response_json(payload)
        except HTTPError as exc:
            try:
                detail = exc.read().decode("utf-8", errors="replace")[:1000]
            except Exception:
                detail = ""
            raise RuntimeError(f"{self.model} HTTP {exc.code} from {self.base_url}: {detail}") from exc
        except Exception as exc:
            raise RuntimeError(f"{self.model} request failed: {exc}") from exc


def resolve_api_config(path: str | None, *, env_key: str, env_base: str, env_model: str,
                       explicit_base: str | None, explicit_model: str | None,
                       default_base: str, default_model: str) -> tuple[str, str, str]:
    file_config = read_api_config_file(path) if path else {}
    key = os.getenv(env_key) or file_config.get("api_key") or file_config.get("apikey") or file_config.get("key") or file_config.get("token") or file_config.get("qwen_api_key") or file_config.get("deepseek_api_key")
    if not key:
        raise ValueError(f"set {env_key} or pass a config file containing a literal API key")
    return key, explicit_base or os.getenv(env_base) or file_config.get("base_url") or default_base, explicit_model or os.getenv(env_model) or file_config.get("model") or default_model
