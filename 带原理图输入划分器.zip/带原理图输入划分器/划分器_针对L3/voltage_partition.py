"""DeepSeek-only two-cluster voltage-domain partitioning flow for L3."""

from __future__ import annotations

import argparse
import csv
import json
import statistics
import sys
from pathlib import Path
from typing import Any, Mapping

from llm_base.api_client import _JSONClient, resolve_api_config
from llm_base.io import load_netlist, save_json


if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except (AttributeError, OSError):
        pass


CLUSTERS = ("low_voltage", "high_voltage")


def build_prompt(netlist: Mapping[str, Any], threshold_v: float) -> dict[str, Any]:
    return {
        "task": "依据给定的高低电压域分界，直接分析原始网表，将全部器件严格划分为低压簇或高压簇。",
        "standard": {
            "threshold_v": threshold_v,
            "low_voltage": f"工作电压不高于 {threshold_v:g} V 的电压域",
            "high_voltage": f"工作电压高于 {threshold_v:g} V 的电压域",
            "rule": "按器件实际工作/承受的电压及其连接网络判断；不要仅因共地、共电源名或器件类型相同而合并电压域。",
        },
        "netlist": {
            "name": netlist.get("name"),
            "components": netlist.get("components", []),
            "nets": netlist.get("nets", []),
        },
        "output_schema": {
            "assignments": [
                {"component_id": "原始位号", "cluster_id": "low_voltage 或 high_voltage", "confidence": 0.0}
            ],
            "uncertain_component_ids": [],
        },
        "rules": [
            "阈值按直流电压绝对值比较：|V| <= threshold_v 属低压，|V| > threshold_v 属高压；交流额定电压也按给定阈值进行比较并在 reason 中标明判断依据。",
            "所有输入器件必须且只能归入 low_voltage 或 high_voltage；程序会根据 assignments 本地生成两个簇。",
            "优先使用器件 value/part/额定值、引脚名称、网络名称和拓扑；不得只根据位号猜电压，不得编造数值。",
            "跨域器件仍归入一个簇；无法确定时放入 uncertain_component_ids 并降低 confidence。",
            "为避免响应过长，每条 assignment 只输出 component_id、cluster_id、confidence 三个字段；不要输出 clusters、component_ids、reason、evidence_nets 或长解释。",
            "component_id 必须逐字匹配输入器件 id；必须覆盖全部器件且按输入器件逐条输出。",
            "输出有效 JSON，不要 Markdown 或额外解释。",
        ],
    }


def validate_result(result: Mapping[str, Any], netlist: Mapping[str, Any]) -> dict[str, Any]:
    components = {str(c["id"]): c for c in netlist.get("components", [])}
    nets = {str(n.get("id", n.get("name"))) for n in netlist.get("nets", [])}
    raw_assignments = result.get("assignments")
    if not isinstance(raw_assignments, list):
        raise ValueError("模型输出缺少 assignments 数组")
    assignments: dict[str, dict[str, Any]] = {}
    for row in raw_assignments:
        if not isinstance(row, Mapping):
            raise ValueError("每条 assignment 必须是对象")
        cid = str(row.get("component_id", "")).strip()
        if cid not in components:
            raise ValueError(f"模型输出了未知器件：{cid or '(空)'}")
        if cid in assignments:
            raise ValueError(f"模型重复分配器件：{cid}")
        cluster = str(row.get("cluster_id", "")).strip()
        if cluster not in CLUSTERS:
            raise ValueError(f"{cid} 的 cluster_id 必须是 low_voltage 或 high_voltage")
        try:
            confidence = float(row.get("confidence", 0))
        except (TypeError, ValueError) as exc:
            raise ValueError(f"{cid} 的 confidence 不是数字") from exc
        if not 0 <= confidence <= 1:
            raise ValueError(f"{cid} 的 confidence 必须在 0 到 1 之间")
        evidence = row.get("evidence_nets", [])
        if not isinstance(evidence, list):
            raise ValueError(f"{cid} 的 evidence_nets 必须是数组")
        unknown_nets = sorted(set(map(str, evidence)) - nets)
        if unknown_nets:
            raise ValueError(f"{cid} 引用了网表不存在的网络：{unknown_nets}")
        assignments[cid] = {
            "component_id": cid,
            "cluster_id": cluster,
            "cluster_name": "低压簇" if cluster == "low_voltage" else "高压簇",
            "operating_voltage_v": row.get("operating_voltage_v"),
            "evidence_nets": list(map(str, evidence)),
            "reason": str(row.get("reason", "")).strip(),
            "confidence": confidence,
        }
    missing = sorted(set(components) - set(assignments))
    if missing:
        raise ValueError(f"模型遗漏器件：{', '.join(missing)}")
    uncertain = result.get("uncertain_component_ids", [])
    if not isinstance(uncertain, list) or set(map(str, uncertain)) - set(components):
        raise ValueError("uncertain_component_ids 必须是已知器件位号数组")
    groups = {key: [] for key in CLUSTERS}
    for cid, row in assignments.items():
        groups[row["cluster_id"]].append(cid)
    return {
        "schema": "deepseek-two-voltage-cluster-v1",
        "clusters": [
            {"cluster_id": "low_voltage", "cluster_name": "低压簇", "component_ids": sorted(groups["low_voltage"])},
            {"cluster_id": "high_voltage", "cluster_name": "高压簇", "component_ids": sorted(groups["high_voltage"])},
        ],
        "assignments": [assignments[cid] for cid in sorted(assignments)],
        "uncertain_component_ids": sorted(set(map(str, uncertain))),
    }


def write_csv(path: Path, result: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=[
            "component_id", "cluster_id", "cluster_name", "operating_voltage_v",
            "evidence_nets", "reason", "confidence",
        ])
        writer.writeheader()
        for row in result["assignments"]:
            output = {key: (", ".join(row["evidence_nets"]) if key == "evidence_nets" else row.get(key, ""))
                      for key in writer.fieldnames}
            writer.writerow(output)


def build_stability_report(results: list[Mapping[str, Any]], *, threshold_v: float,
                           model: str, netlist: Mapping[str, Any]) -> dict[str, Any]:
    """Compare valid independent rounds without selecting a new assignment."""
    if not results:
        raise ValueError("没有可用于稳定性统计的有效轮次")
    by_round = [{row["component_id"]: row for row in result["assignments"]} for result in results]
    component_ids = sorted(by_round[0])
    device_rows = []
    for cid in component_ids:
        clusters = [round_rows[cid]["cluster_id"] for round_rows in by_round]
        confidences = [float(round_rows[cid]["confidence"]) for round_rows in by_round]
        counts = {cluster: clusters.count(cluster) for cluster in CLUSTERS}
        mode_count = max(counts.values())
        device_rows.append({
            "component_id": cid,
            "cluster_consistency": mode_count / len(clusters),
            "stable": mode_count == len(clusters),
            "majority_cluster_id": max(counts, key=counts.get),
            "cluster_counts": counts,
            "round_clusters": clusters,
            "confidence_mean": statistics.mean(confidences),
            "confidence_stddev": statistics.stdev(confidences) if len(confidences) > 1 else 0.0,
        })
    signatures = [tuple(round_rows[cid]["cluster_id"] for cid in component_ids) for round_rows in by_round]
    complete_matches = sum(signature == signatures[0] for signature in signatures)
    return {
        "schema": "deepseek-voltage-stability-v1",
        "providers": ["DeepSeek"],
        "model": model,
        "threshold_v": threshold_v,
        "round_count": len(results),
        "valid_round_count": len(results),
        "component_count": len(component_ids),
        "complete_assignment_consistency": complete_matches / len(signatures),
        "all_rounds_same_assignment": complete_matches == len(signatures),
        "stable_component_count": sum(row["stable"] for row in device_rows),
        "stable_component_rate": sum(row["stable"] for row in device_rows) / len(device_rows),
        "round_summaries": [
            {"round": index, "cluster_counts": {cluster: len(result["clusters"][i]["component_ids"]) for i, cluster in enumerate(CLUSTERS)},
             "uncertain_component_ids": result["uncertain_component_ids"]}
            for index, result in enumerate(results, 1)
        ],
        "components": device_rows,
        "note": "多轮是独立推理稳定性评估，不会更新或训练 DeepSeek 模型参数。",
    }


def write_stability_csv(path: Path, report: Mapping[str, Any]) -> None:
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["component_id", "stable", "cluster_consistency",
                                                       "majority_cluster_id", "confidence_mean", "confidence_stddev",
                                                       "round_clusters"])
        writer.writeheader()
        for row in report["components"]:
            writer.writerow({key: (" | ".join(row["round_clusters"]) if key == "round_clusters" else row.get(key, ""))
                             for key in writer.fieldnames})


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="仅用 DeepSeek 分析网表，划分高压簇和低压簇")
    parser.add_argument("netlist", type=Path, help="EasyEDA .enet 或标准 JSON 网表")
    parser.add_argument("--api-key-file", help="DeepSeek API 配置文件；也可设置 DEEPSEEK_API_KEY")
    parser.add_argument("--base-url")
    parser.add_argument("--model")
    parser.add_argument("--threshold-v", type=float, default=12.0, help="低/高压分界，默认 12 V")
    parser.add_argument("--rounds", type=int, default=1, help="DeepSeek 独立分析轮数，默认 1")
    parser.add_argument("--temperature", type=float, default=0.0, help="DeepSeek 采样温度，默认 0；多轮稳定性探索可设为 0.2-0.8")
    parser.add_argument("--out", type=Path, default=Path("output/voltage_partition"))
    parser.add_argument("--dry-run", action="store_true", help="仅解析并保存请求，不调用模型")
    args = parser.parse_args(argv)
    if args.threshold_v <= 0 or args.rounds < 1 or not 0 <= args.temperature <= 2:
        parser.error("--threshold-v 必须大于 0，--rounds 必须是正整数，--temperature 必须在 0 到 2 之间")
    netlist = load_netlist(args.netlist)
    prompt = build_prompt(netlist, args.threshold_v)
    args.out.mkdir(parents=True, exist_ok=True)
    # Keep the normalized source alongside requests so the exact electrical
    # evidence used by DeepSeek can be audited or replayed later.
    save_json(args.out / "input_netlist.json", netlist)
    save_json(args.out / "request.json", prompt)
    if args.dry_run:
        print(f"Dry-run 完成：解析 {len(netlist['components'])} 个器件；请求已保存至 {args.out / 'request.json'}")
        return 0
    key, base, model = resolve_api_config(args.api_key_file, env_key="DEEPSEEK_API_KEY", env_base="DEEPSEEK_BASE_URL",
                                          env_model="DEEPSEEK_MODEL", explicit_base=args.base_url,
                                          explicit_model=args.model, default_base="https://api.deepseek.com/v1",
                                          default_model="deepseek-chat")
    client = _JSONClient(base_url=base, model=model, api_key=key)
    disable_deepseek_thinking = "deepseek" in model.lower() and any(token in model.lower() for token in ("v4", "reason", "pro"))
    valid_results: list[dict[str, Any]] = []
    round_errors: list[dict[str, Any]] = []
    last_valid_response: dict[str, Any] | None = None
    for round_index in range(1, args.rounds + 1):
        print(f"开始第 {round_index}/{args.rounds} 轮 DeepSeek 分析…", flush=True)
        try:
            system_prompt = "你是谨慎的电路电压域分析工程师。只按给定阈值输出 JSON。"
            try:
                response = client.ask(system_prompt, prompt, temperature=args.temperature, max_tokens=8192,
                                      disable_thinking=disable_deepseek_thinking)
            except RuntimeError as first_error:
                # Some older OpenAI-compatible gateways reject the thinking
                # option. Retry once without it before changing the prompt.
                if disable_deepseek_thinking and "HTTP 400" in str(first_error):
                    print("当前 API 不接受 thinking 参数，改用兼容模式重试…", flush=True)
                    response = client.ask(system_prompt, prompt, temperature=args.temperature, max_tokens=8192)
                    disable_deepseek_thinking = False
                    first_error = None
                if first_error is None:
                    pass
                elif "model response did not contain a valid JSON object" not in str(first_error):
                    raise
                else:
                    print(f"第 {round_index} 轮响应格式异常，正在要求 DeepSeek 仅返回完整 JSON 并重试一次…", flush=True)
                    response = client.ask(system_prompt + " 必须关闭思考过程，只返回完整、可解析的 JSON object；禁止 Markdown 代码围栏和 JSON 以外文字。",
                                          prompt, temperature=args.temperature, max_tokens=8192,
                                          disable_thinking=disable_deepseek_thinking)
            round_dir = args.out / f"round_{round_index:02d}"
            save_json(round_dir / "deepseek_response.json", response)
            normalized = validate_result(response, netlist)
            last_valid_response = response
            save_json(round_dir / "voltage_partition.json", normalized)
            write_csv(round_dir / "voltage_partition.csv", normalized)
            valid_results.append(normalized)
            print(f"第 {round_index} 轮完成：低压 {len(normalized['clusters'][0]['component_ids'])}，高压 {len(normalized['clusters'][1]['component_ids'])}", flush=True)
        except Exception as exc:
            round_errors.append({"round": round_index, "error": str(exc)})
            save_json(args.out / f"round_{round_index:02d}" / "error.json",
                      {"round": round_index, "error": str(exc)})
            print(f"第 {round_index} 轮失败：{exc}", file=sys.stderr, flush=True)
    if not valid_results:
        save_json(args.out / "run.json", {"status": "failed", "provider": "DeepSeek", "model": model,
                                          "threshold_v": args.threshold_v, "requested_rounds": args.rounds,
                                          "temperature": args.temperature, "failed_rounds": round_errors})
        raise RuntimeError("所有 DeepSeek 轮次均失败")
    normalized = valid_results[-1]
    assert last_valid_response is not None
    save_json(args.out / "model_response.json", last_valid_response)
    save_json(args.out / "voltage_partition.json", normalized)
    write_csv(args.out / "voltage_partition.csv", normalized)
    report = build_stability_report(valid_results, threshold_v=args.threshold_v,
                                    model=f"DeepSeek:{model}", netlist=netlist)
    report["temperature"] = args.temperature
    report["requested_round_count"] = args.rounds
    report["failed_rounds"] = round_errors
    save_json(args.out / "stability_report.json", report)
    write_stability_csv(args.out / "stability_report.csv", report)
    save_json(args.out / "run.json", {"status": "completed", "providers": {"netlist": "DeepSeek"},
                                      "model": model,
                                      "threshold_v": args.threshold_v, "requested_rounds": args.rounds,
                                      "temperature": args.temperature,
                                      "valid_rounds": len(valid_results), "failed_rounds": round_errors,
                                      "component_count": len(netlist["components"]),
                                      "cluster_counts": {row["cluster_id"]: len(row["component_ids"]) for row in normalized["clusters"]},
                                      "uncertain_component_ids": normalized["uncertain_component_ids"],
                                      "all_rounds_same_assignment": report["all_rounds_same_assignment"]})
    print(f"划分完成：低压簇 {len(normalized['clusters'][0]['component_ids'])} 个器件，高压簇 {len(normalized['clusters'][1]['component_ids'])} 个器件。", flush=True)
    print(f"稳定性：{report['stable_component_rate']:.1%} 器件在全部有效轮次保持同一归属；报告：{args.out.resolve() / 'stability_report.json'}", flush=True)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"运行失败：{exc}", file=sys.stderr)
        raise SystemExit(1)
