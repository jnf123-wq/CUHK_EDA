@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
where python >nul 2>nul
if errorlevel 1 goto try_py_launcher
goto run_python

:try_py_launcher
where py >nul 2>nul
if errorlevel 1 goto no_python
goto run_py_launcher

:run_python
python "%~dp0gui.py"
if errorlevel 1 pause
exit /b %errorlevel%

:run_py_launcher
py -3 "%~dp0gui.py"
if errorlevel 1 pause
exit /b %errorlevel%

:no_python
echo Python 3 not found. Please install Python 3.10 or newer and add it to PATH.
pause
exit /b 1
