# Partition 划分器 v0.1

这是一个面向 BUCK/电源原理图的确定性两层功能分区工具包。运行时只使用原理图拓扑、本地角色/网络语义规则和审核通过的硬规则，不调用 LLM、不读取 LLM 标注、不加载历史软先验，也不访问在线数据手册。

## 目录

- `partitioner/`：核心代码；
- `knowledge_base/`：唯一当前规则快照、角色/网络语义字典和软约束记录；
- `docs/`：流程大纲与既有方案；
- `tests/`：核心测试和软证据测试；
- `examples/`：示例输入位置；
- `legacy/`：旧版本材料存档位置。

项目目录可以整体移动到其他位置；代码默认使用项目目录下的 `examples/`
和 `outputs/`，不会依赖某个用户的桌面路径。项目内的 `Partition划分器 GUI.lnk`
快捷方式也随目录保存。

## 运行

单个工程使用原始 schematic `.enet`，PCB `.enet` 只用于补充物理元数据：

```powershell
python -m partitioner.l1_cli <schematic.enet> `
  --pcb-enet <pcb.enet> `
  --output outputs/result.json
```

批量 `.enet` 流程：

```powershell
python -m partitioner.enet_batch --source <source_dir> --output <output_dir>
```

## 图形界面试运行

Windows 下可直接运行：

```powershell
python run_gui.py
```

项目目录中的 `启动Partition划分器_GUI.pyw` 可直接双击启动；同目录的
`Partition划分器 GUI.lnk` 快捷方式也可直接打开，不需要先打开 PowerShell。

也可以使用模块方式：

```powershell
python -m partitioner.gui
```

在界面中选择 schematic `.enet` 或标准化拓扑 JSON，可选填写匹配的 PCB `.enet`，然后点击“开始运行”。运行完成后会在输出 JSON 同目录生成 L1/L2 CSV、规则命中 CSV 和 Markdown 报告；界面中的 L2 表会显示每个大器件根簇及其直接或递归连接的元件。

旧版本留下的 `--deepseek`、`--annotation`、`--api-key-file` 等参数仅为兼容旧脚本而保留，当前会被忽略，不会触发网络请求。

## 结果

每次运行生成 JSON、独立的 L1 和 L2 CSV、规则命中 CSV、软证据 CSV 和 Markdown 总结报告。L1 CSV 是最终细功能簇明细，L2 CSV 是粗功能域成员明细；旧的 `_clusters.csv` 仍作为 L1 兼容文件保留。最终 `partition` 只由本地拓扑候选和审核硬规则决定；未形成多成员簇的器件由算法生成可审计的 singleton。

## 知识库导入

当前运行只读取 `knowledge_base/kb_manifest.json` 指向的单一规则快照；历史案例和旧规则不再作为运行时知识库。

## 算法流程

1. 读取并标准化 schematic `.enet`，可选合并 PCB 元数据；
2. 校验器件、网络和端点完整性；
3. 根据本地网络名、引脚名、器件类型和角色字典推断网络语义与器件角色；
4. 匹配 `approved` 知识库规则和局部拓扑模式；
5. L2 先识别 IC/模块等大器件，每个大器件独立成根簇；
6. 按大器件标号的自然顺序逐个处理，将普通信号网络节点折叠为器件引脚之间的邻接并递归。VCC、3V3、VDD、5V 以及 GND/PGND/AGND 等电源/地网络按保守策略完全排除，不作为直接归属或递归通道；因此 `U1.VHV → VCC → C1.2` 不构成 L2 连接。前序大器件已经占用的器件对后续大器件不可再分配；每次归属记录具体引脚路径及网络证据，便于追溯；
7. 在 L2 域内选择互不重叠的 L1 拓扑候选；
8. 对剩余器件生成可审计 singleton，执行全局唯一归属检查；
9. 导出 JSON、L1/L2 CSV、规则命中和报告。

## 测试

```powershell
python -m unittest discover -s Partition划分器v0.1/tests -v
```
