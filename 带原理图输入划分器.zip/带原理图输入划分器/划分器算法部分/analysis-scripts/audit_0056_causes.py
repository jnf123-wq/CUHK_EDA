"""Audit why 0056 components do not reach L1-2.

This script keeps the DeepSeek annotation and topology fixed while changing
only the knowledge-base inputs.  It also emits one row per component so a high
confidence LLM role can be traced through domains, candidates, and the final
selector.
"""
from __future__ import annotations

import argparse
import csv
import json
import shutil
import sys
from collections import Counter
from pathlib import Path


PROJECT_ID = "0056_199db227_MPPT"
PROJECT_STEM = "0056_199db227_MPPT智能升降压板_PCB_MPPT智能升降压板"


def _json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def _write_json(path: Path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def _copy_manifest(source_manifest: Path, source_rules: Path, source_soft: Path,
                   case_dir: Path, *, use_rules: bool, use_soft: bool) -> Path:
    """Create an isolated manifest so every counterfactual is reproducible."""
    case_dir.mkdir(parents=True, exist_ok=True)
    rules_path = case_dir / "placement_rules.json"
    soft_path = case_dir / "soft_constraints.jsonl"
    if use_rules:
        shutil.copy2(source_rules, rules_path)
    else:
        _write_json(rules_path, {"schema": "partition-placement-rules-v1", "rules": []})
    if use_soft and source_soft.exists():
        shutil.copy2(source_soft, soft_path)
    else:
        soft_path.write_text("", encoding="utf-8")

    manifest = _json(source_manifest)
    manifest["active_rules"] = str(rules_path.resolve())
    manifest["soft_constraints"] = str(soft_path.resolve())
    manifest["dictionaries"] = {
        key: str((source_manifest.parent / value).resolve())
        if not Path(value).is_absolute() else value
        for key, value in manifest.get("dictionaries", {}).items()
    }
    manifest["learning_policy"] = dict(manifest.get("learning_policy", {}),
                                        auto_review_high_confidence=False)
    manifest_path = case_dir / "kb_manifest.json"
    _write_json(manifest_path, manifest)
    return manifest_path


def _strip_relations(annotation: dict) -> dict:
    value = json.loads(json.dumps(annotation))
    value["candidate_clusters"] = []
    value["soft_links"] = []
    value["normalization_warnings"] = []
    return value


def _annotation_counts(annotation: dict) -> dict:
    warnings = annotation.get("normalization_warnings", []) or []
    return {
        "annotation_components": len(annotation.get("components", []) or []),
        "annotation_nets": len(annotation.get("nets", {}) or {}),
        "annotation_candidate_clusters": len(annotation.get("candidate_clusters", []) or []),
        "annotation_soft_links": len(annotation.get("soft_links", []) or []),
        "normalization_warning_count": len(warnings),
        "dropped_candidate_cluster_count": sum(
            1 for row in warnings if row.get("type") == "dropped_candidate_cluster"),
        "dropped_soft_link_count": sum(
            1 for row in warnings if row.get("type") == "dropped_soft_link"),
    }


def _members(rows):
    result = set()
    for row in rows or []:
        if isinstance(row, dict):
            result.update(str(ref) for ref in row.get("members", []) if ref)
    return result


def _counter_text(counter: Counter) -> str:
    return ";".join(f"{key}={value}" for key, value in sorted(counter.items()))


def _run_case(label: str, topology: dict, annotation: dict, manifest: Path,
              output_dir: Path):
    # Import after the project root is placed on sys.path by main().
    from partitioner.l1_partition import run

    result = run(topology, annotation_path=annotation, project_id=PROJECT_ID,
                 knowledge_base_path=manifest, learn_soft_constraints=False,
                 promote_soft_constraints=False)
    case_dir = output_dir / label
    _write_json(case_dir / f"{PROJECT_STEM}_l1.json", result)
    partition = result.get("partition", {})
    quality = result.get("quality", {}) or {}
    reasons = Counter(row.get("reason", "") for row in partition.get("unresolved_components", []))
    candidate_sources = Counter(row.get("source", "") for row in partition.get("decision_trace", []))
    selected_sources = Counter(row.get("source", "") for row in partition.get("selected_candidates", []))
    candidate_decisions = Counter(row.get("decision", "") for row in partition.get("decision_trace", []))
    selected_refs = _members(partition.get("l1_2_clusters", []))
    domain_by_ref = {
        ref: domain.get("id")
        for domain in partition.get("l1_1_domains", [])
        for ref in domain.get("members", [])
    }
    cluster_by_ref = {}
    function_by_ref = {}
    source_by_ref = {}
    for cluster in partition.get("l1_2_clusters", []):
        for ref in cluster.get("members", []):
            cluster_by_ref[ref] = cluster.get("id", "")
            function_by_ref[ref] = cluster.get("function", "")
            source_by_ref[ref] = cluster.get("source", "")
    unresolved_by_ref = {
        row.get("ref"): row for row in partition.get("unresolved_components", [])
    }
    component_rows = []
    for component in topology.get("components", []):
        ref = component.get("designator")
        role = result.get("roles", {}).get(ref, {})
        component_rows.append({
            "case": label,
            "ref": ref,
            "roles": ";".join(role.get("roles", [])),
            "roles_raw": ";".join(role.get("roles_raw", [])),
            "function_tags": ";".join(role.get("function_tags", [])),
            "canonical_function_tags": ";".join(role.get("canonical_function_tags", [])),
            "confidence": role.get("confidence", ""),
            "semantics": ";".join(role.get("semantics", [])),
            "l1_1_domain": domain_by_ref.get(ref, ""),
            "l1_2_cluster": cluster_by_ref.get(ref, ""),
            "l1_2_function": function_by_ref.get(ref, ""),
            "selected_source": source_by_ref.get(ref, ""),
            "clustered": ref in selected_refs,
            "unresolved_reason": unresolved_by_ref.get(ref, {}).get("reason", ""),
            "unresolved_detail": unresolved_by_ref.get(ref, {}).get("detail", ""),
        })
    fieldnames = list(component_rows[0]) if component_rows else []
    with (case_dir / "component_trace.csv").open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(component_rows)

    metrics = {
        "case": label,
        "component_count": len(topology.get("components", [])),
        "net_count": len(topology.get("nets", {})),
        "unknown_net_count": sum(1 for values in result.get("net_semantics", {}).values()
                                  if "UNKNOWN" in values),
        "explicit_semantic_net_count": sum(1 for values in result.get("net_semantics", {}).values()
                                            if set(values) - {"UNKNOWN"}),
        "l1_1_domain_count": len(partition.get("l1_1_domains", [])),
        "anchored_domain_count": sum(
            1 for domain in partition.get("l1_1_domains", [])
            if domain.get("anchor") or domain.get("anchor_ref") or domain.get("anchors")),
        "l1_2_cluster_count": len(partition.get("l1_2_clusters", [])),
        "l1_2_clustered_component_count": len(selected_refs),
        "l1_2_coverage": round(len(selected_refs) / max(1, len(topology.get("components", []))), 6),
        "unresolved_component_count": len(partition.get("unresolved_components", [])),
        "unknown_role_count": sum(1 for row in result.get("roles", {}).values()
                                   if "unknown_component" in row.get("roles", [])),
        "canonical_role_count": sum(1 for row in result.get("roles", {}).values()
                                     if row.get("roles")),
        "candidate_count": len(partition.get("decision_trace", [])),
        "selected_count": len(partition.get("selected_candidates", [])),
        "candidate_source_counts": _counter_text(candidate_sources),
        "selected_source_counts": _counter_text(selected_sources),
        "candidate_decision_counts": _counter_text(candidate_decisions),
        "unresolved_reason_counts": _counter_text(reasons),
        "historical_soft_constraint_count": (result.get("knowledge_base", {}) or {}).get(
            "historical_soft_constraint_count", 0),
        "soft_evidence_pair_count": len(result.get("soft_evidence", []) or []),
        "soft_proposal_count": len(result.get("soft_proposals", []) or []),
        "quality_status": quality.get("status", ""),
    }
    _write_json(case_dir / "metrics.json", metrics)
    return metrics, component_rows


def _write_summary(path: Path, rows):
    if not rows:
        return
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def _write_report(path: Path, *, annotation: dict, rows, control_label: str | None):
    baseline = next(row for row in rows if row["case"] == "current_kb")
    no_soft = next(row for row in rows if row["case"] == "no_historical_soft")
    no_kb = next(row for row in rows if row["case"] == "no_rules_no_soft")
    lines = [
        "# 0056 未进入 L1-2 的原因审计",
        "",
        "## 结论",
        "",
        "本报告固定同一份拓扑和同一份 DeepSeek 器件/网络标注，只切换知识库输入。",
        "因此 L1-2 指标的变化可以归因于知识库，而不是 LLM 输出差异。",
        "",
        f"- 当前标注覆盖：{annotation.get('components', []) and len(annotation['components']) or 0} 个器件，"
        f"{len(annotation.get('nets', {}))} 条网络。",
        f"- 归一化后候选关系：{len(annotation.get('candidate_clusters', []))} 个 candidate_clusters，"
        f"{len(annotation.get('soft_links', []))} 个 soft_links。",
        f"- 归一化警告：{len(annotation.get('normalization_warnings', []))} 条，"
        f"其中丢弃候选簇 {sum(1 for x in annotation.get('normalization_warnings', []) if x.get('type') == 'dropped_candidate_cluster')} 条，"
        f"丢弃软链接 {sum(1 for x in annotation.get('normalization_warnings', []) if x.get('type') == 'dropped_soft_link')} 条。",
        f"- 当前知识库下已选簇全部来自：{baseline['selected_source_counts'] or '无'}。",
        "",
        "## 知识库反事实",
        "",
        "| 情况 | L1-1 域 | L1-2 簇 | L1-2 器件 | 覆盖率 | 候选来源 | 未成簇原因 |",
        "|---|---:|---:|---:|---:|---|---|",
    ]
    for row in rows:
        lines.append(
            f"| {row['case']} | {row['l1_1_domain_count']} | {row['l1_2_cluster_count']} | "
            f"{row['l1_2_clustered_component_count']} | {row['l1_2_coverage']:.3f} | "
            f"{row['candidate_source_counts'] or '-'} | {row['unresolved_reason_counts'] or '-'} |"
        )
    lines.extend([
        "",
        f"去掉历史软约束后，L1-2 器件从 {baseline['l1_2_clustered_component_count']} 变为 "
        f"{no_soft['l1_2_clustered_component_count']}；去掉硬规则和软约束后为 "
        f"{no_kb['l1_2_clustered_component_count']}。",
        "这两个对照用于判断知识库是否是必要条件，但不能把历史软约束当作真实电路证据；如果簇数量下降，说明算法对知识库有依赖，不能说明知识库覆盖正确。",
        "",
        "## 接入层证据",
        "",
        "接入层存在明确损失：模型标注包含关系记录，但当前落盘的规范化结果把这些记录全部变成空列表，并保留了 `fewer_than_two_known_refs` 警告。后续选择器因此看不到 `llm_candidate_cluster` 来源；它只能使用历史 `soft_evidence` 和本地结构候选。",
        "",
        "组件级追踪见各 case 目录的 `component_trace.csv`。其中 `canonical_function_tags` 为空但 `function_tags` 非空的行，是标签已被模型识别、却没有进入标准候选族的直接证据。",
    ])
    if control_label:
        lines.extend([
            "",
            "## 有效关系控制样本",
            "",
            f"使用保存的 `{control_label}` 标注作为格式正确的控制样本。它不是本次实时响应，不能替代实时响应的因果证据；它只验证当前 selector 能消费已正确归一化的候选关系。",
        ])
    lines.extend([
        "",
        "## 判定口径",
        "",
        "- `kb_dependency`：切换规则/历史软约束后，候选来源、L1-2 覆盖或未成簇原因发生变化。",
        "- `integration_loss`：LLM 角色/标签存在，但规范化关系为空、canonical tag 为空，或决策轨迹没有 LLM 候选来源。",
        "- `missing_net_semantics`：器件已有角色，但其网络仍为 UNKNOWN，无法形成拓扑候选。",
        "- `no_anchor_domain`：器件没有进入可识别的 L1-1 锚点域。",
        "- `rejected_overlap`：候选生成了，但互斥选择器因为成员重叠拒绝。",
    ])
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", type=Path,
                        default=Path(__file__).resolve().parents[1])
    parser.add_argument("--output", type=Path,
                        default=None)
    args = parser.parse_args(argv)
    root = args.project_root.resolve()
    output = (args.output or root / "outputs" / "evidence_0056_20261004").resolve()
    output.mkdir(parents=True, exist_ok=True)
    sys.path.insert(0, str(root))

    topology_path = root.parent / "Partition" / "topology_场景2" / f"{PROJECT_STEM}.json"
    annotation_path = root / "outputs" / "live_0056_20261004_1320" / f"{PROJECT_STEM}_annotation.json"
    source_manifest = root / "knowledge_base" / "kb_manifest.json"
    manifest_data = _json(source_manifest)
    source_rules = Path(manifest_data["active_rules"])
    if not source_rules.is_absolute():
        source_rules = source_manifest.parent / source_rules
    source_soft = Path(manifest_data.get("soft_constraints", "soft_constraints.jsonl"))
    if not source_soft.is_absolute():
        source_soft = source_manifest.parent / source_soft
    topology = _json(topology_path)
    annotation = _json(annotation_path)

    cases = [
        ("current_kb", True, True, annotation),
        ("no_historical_soft", True, False, annotation),
        ("no_rules_no_soft", False, False, annotation),
        ("roles_network_only", True, True, _strip_relations(annotation)),
    ]
    rows = []
    all_components = []
    for label, use_rules, use_soft, case_annotation in cases:
        manifest = _copy_manifest(source_manifest, source_rules, source_soft,
                                  output / "counterfactual_kb" / label,
                                  use_rules=use_rules, use_soft=use_soft)
        metrics, component_rows = _run_case(label, topology, case_annotation,
                                             manifest, output / "counterfactual_runs")
        metrics.update(_annotation_counts(case_annotation))
        rows.append(metrics)
        all_components.extend(component_rows)

    # The manually repaired annotation is a positive format control when it is
    # available.  Keep it separate from causal counterfactuals.
    control_label = None
    control_candidates = sorted(
        (root / "outputs" / "manual_0056_199db227_MPPT智能升降压板_PCB_MPPT智能升降压板").glob(
            f"{PROJECT_STEM}_*_annotation.json"),
        key=lambda path: path.stat().st_mtime,
    )
    if control_candidates:
        control_path = control_candidates[-1]
        control_annotation = _json(control_path)
        if control_annotation.get("candidate_clusters") or control_annotation.get("soft_links"):
            control_label = control_path.stem
            manifest = _copy_manifest(source_manifest, source_rules, source_soft,
                                      output / "counterfactual_kb" / "valid_relation_control",
                                      use_rules=True, use_soft=False)
            metrics, component_rows = _run_case("valid_relation_control", topology,
                                                 control_annotation, manifest,
                                                 output / "counterfactual_runs")
            metrics.update(_annotation_counts(control_annotation))
            rows.append(metrics)
            all_components.extend(component_rows)

    _write_summary(output / "counterfactual_summary.csv", rows)
    if all_components:
        _write_summary(output / "component_trace_all_cases.csv", all_components)
    _write_report(output / "audit_0056_causes.md", annotation=annotation,
                  rows=rows, control_label=control_label)
    print(json.dumps({"output": str(output), "cases": [row["case"] for row in rows]},
                     ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
