# Partition 流程总结

更新时间：2026-09-27

## 一、交付位置

完整桌面工具包位于：

`C:\Users\30943\Desktop\Partition流程_已更新`

主要入口：

- `partition_demo\启动Demo.cmd`：双击启动图形界面
- `partition_demo\run.py`：命令行入口
- `partition_demo\README.md`：详细使用说明
- `partition_demo\DELIVERY.md`：交付说明

桌面工具包中的 `partition_demo` 和 `buck_knowledge_base` 必须保持同级目录。知识库中的 TI 原文 TXT 用于启动时校验规则来源。

## 二、整体流程

```text
输入网表
  ↓
网表标准化、器件与引脚连接解析
  ↓
电气连接完整性检查
  ↓
读取并校验知识库规则
  ↓
L0：单器件识别
  ↓
L1：局部功能单元划分
  ↓
L2：基于 L1 的电压域/隔离域聚合
  ↓
层级完整性与连接守恒检查
  ↓
导出分层网表、CSV、统计指标和报告
  ↓
可选置信度检查
```

## 三、三层划分含义

### L0：单器件层

每个器件单独作为一个 primitive，记录器件功能、电压域、隔离域和不确定性。

### L1：功能单元层

根据低扇出非电源网络、反馈、补偿、开关节点、输入旁路等证据，形成局部强耦合功能包。共享 GND 或同属一块板不能单独证明器件应该同簇。

### L2：域组层

默认流程中，L2 接收 L1 功能包作为不可拆分的超级节点，只负责聚合电压域和隔离域。L2 不应重新拆分 L1。

L2 内部使用 L1 超级节点推断，但为了方便和 BOM 对照，导出 CSV 时会把成员展开为原始器件编号。这种展开不代表重新划分。判断层级关系应查看：

- `L2.hierarchy.json`
- `L2.result.json` 中的 `children_l1`
- `L2.assignments.csv` 中的 `children_l1` 列

## 四、LLM 与离线模式

默认使用 LLM：

```powershell
python -X utf8 -m partition_demo.run "网表文件.enet" --config "C:\Users\30943\Desktop\config.yaml" --out "输出目录"
```

不调用 LLM 时使用离线拓扑基线：

```powershell
python -X utf8 -m partition_demo.run "网表文件.enet" --llm-mode off --out "输出目录"
```

离线模式只使用低扇出网络和电源网名启发式，结果用于基线和人工审核，不等同于工程确认。

同时运行有知识库和无知识库对照：

```powershell
--compare
```

如需恢复旧的独立 L0/L1/L2 推断流程：

```powershell
--flat-levels
```

不加 `--flat-levels` 时，默认使用新版 `L1 → L2` 层级流程。

## 五、置信度机制

GUI 和命令行都支持可选置信度机制。

### 1. 模型自报置信度

设置置信度门槛后，模型需要返回 0 到 100 的置信度。低于门槛的响应会自动重试，连续重试仍不满足时，本层运行失败。

命令行示例：

```powershell
--min-confidence 70
```

### 2. 多次采样一致性

对 L1 和 L2 分别进行多次独立采样，并计算划分之间的平均 ARI 一致性。结果保存在：

```text
confidence.json
```

命令行示例：

```powershell
--confidence-samples 3 --confidence-temperature 0.3
```

还可以设置一致性门槛：

```powershell
--min-consistency 0.7
```

模型自报置信度表示模型自己的判断，ARI 表示多次结果的稳定性，两者都不等于工程正确率。置信度采样会增加 API 调用次数，离线模式不能使用此功能。

## 六、输出文件

每次运行的输出目录包括：

- `report.html`：可浏览的总报告
- `report.md`：Markdown 报告
- `run.json`：输入、模式、模型、层级和运行状态
- `metrics.json`：全部层级指标
- `confidence.json`：可选置信度和一致性报告
- `L0/L1/L2.assignments.csv`：器件到簇的映射
- `L0/L1/L2.summary.csv`：每个簇的器件数、域、网络统计
- `L0/L1/L2.netlist.json`：分层网表
- `L0/L1/L2.metrics.json`：每层自动指标
- `L0/L1/L2.result.json`：模型结果、调用信息和修正记录
- `L2.hierarchy.json`：L1 到 L2 的层级映射
- `knowledge/active_rules.jsonl`：本次运行使用的规则快照

## 七、自动统计内容

流程会统计覆盖率、重复或虚构器件、簇数量、簇大小、单例比例、切网数量、连接度、内部网络和边界网络。

如果提供独立人工标注，还可以计算 pair Precision、Recall、F1、ARI、必须同簇召回率和禁止同簇违反率。没有人工标注时，相关正确率显示为 `N/A`，不会伪造准确率。

## 八、知识库和数据边界

运行时使用经过来源校验的公开开关电源资料规则。当前规则主要覆盖输入旁路、反馈、补偿、前馈、电感、开关节点和 TPS54360 专用关系。

旧项目统计、旧案例卡、布局坐标和原分组不会作为当前划分依据直接发送给模型。没有 PCB 坐标和布线数据时，不评价真实布局距离、热、间距和回路面积。

## 九、当前限制

1. L1 功能划分仍需要结合原理图和器件手册人工审核。
2. L2 电压域或隔离域标签不等于安全隔离验证。
3. 大网表会分批处理，批边界可能影响模型结果。
4. 模型自报置信度可能过高，ARI 只能反映稳定性。
5. 桌面包中的 `partition_demo\outputs` 保存了开发验证期历史结果，其中部分来自层级流程改版前。验证当前流程时应新建输出目录，并确认 `run.json` 中为：

   ```json
   "hierarchical": true
   ```

## 十、推荐使用方式

1. 双击 `启动Demo.cmd`。
2. 选择 `.enet` 或标准化 JSON 网表。
3. 选择 API 配置；不使用 LLM 时取消“启用 LLM 划分”。
4. 选择新的输出目录。
5. 根据需要启用模型置信度门槛或多次采样。
6. 点击“开始划分”。
7. 查看 `report.html`、各层 CSV 和 `confidence.json`。
8. 结合原理图、数据手册和人工标注审核结果。

