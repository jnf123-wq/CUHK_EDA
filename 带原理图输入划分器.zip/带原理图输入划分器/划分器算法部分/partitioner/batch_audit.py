"""Audit a nine-project batch without changing its results."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any


REQUIRED_FIELDS = {
    "project", "run_mode", "l1_1_domain_count", "l1_2_cluster_count",
    "valid_cluster_ratio", "unresolved_component_count", "algorithm_stability",
    "quality_status", "deepseek_reviewed_soft_constraints",
    "promoted_hard_rule_count", "promotion_conflict_count",
    "unassigned_component_count", "l1_2_unresolved_component_count",
}


def _load(path: Path) -> list[dict[str, Any]]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, list):
        raise ValueError("batch_summary.json must contain a list")
    return data


def audit_batch(batch_dir: str | Path, expected_projects: int = 9) -> dict[str, Any]:
    root = Path(batch_dir)
    summary_path = root / "batch_summary.json"
    call_path = root / "llm_call_summary.json"
    rows = _load(summary_path)
    findings: list[str] = []
    projects = [str(row.get("project", "")) for row in rows]
    if len(rows) != expected_projects:
        findings.append(f"expected_{expected_projects}_projects_got_{len(rows)}")
    if len(set(projects)) != len(projects):
        findings.append("duplicate_project_rows")
    for index, row in enumerate(rows):
        missing = sorted(REQUIRED_FIELDS - set(row))
        if missing:
            findings.append(f"row_{index}_missing_fields:{','.join(missing)}")
        if row.get("l1_2_cluster_count", 0) < row.get("multi_member_cluster_count", 0):
            findings.append(f"row_{index}_cluster_count_inconsistent")
        if not 0 <= float(row.get("valid_cluster_ratio", 0)) <= 1:
            findings.append(f"row_{index}_invalid_valid_cluster_ratio")
        if not 0 <= float(row.get("singleton_rate", 0)) <= 1:
            findings.append(f"row_{index}_invalid_singleton_rate")
        if row.get("promoted_hard_rule_count", 0) and row.get("deepseek_reviewed_soft_constraints", 0) == 0:
            findings.append(f"row_{index}_promotion_without_review")
        artifact = row.get("json")
        if artifact and not Path(artifact).exists():
            findings.append(f"row_{index}_missing_result_artifact")
        if row.get("run_mode") == "deepseek_live":
            annotation = root / f"{row.get('project')}_annotation.json"
            if not annotation.exists():
                findings.append(f"row_{index}_live_without_annotation")
        if row.get("run_mode") == "deepseek_failed" and row.get("deepseek_reviewed_soft_constraints", 0):
            findings.append(f"row_{index}_failed_with_reviewed_constraints")
        if row.get("run_mode") == "input_failed":
            findings.append(f"row_{index}_input_failed")
        if "partition_error:" in str(row.get("quality_findings", "")):
            findings.append(f"row_{index}_partition_failed")

    call_summary = {}
    if call_path.exists():
        call_summary = json.loads(call_path.read_text(encoding="utf-8"))
        if int(call_summary.get("successful_projects", 0)) > int(call_summary.get("attempted", False)) * expected_projects:
            findings.append("invalid_llm_success_count")
        llm_counts = (int(call_summary.get("successful_projects", 0))
                      + int(call_summary.get("failed_projects", 0))
                      + int(call_summary.get("unavailable_projects", 0)))
        # Offline batches intentionally make no LLM attempts, so their
        # counters remain zero rather than pretending that nine calls ran.
        if call_summary.get("attempted") and llm_counts != len(rows):
            findings.append("llm_project_counts_do_not_match_batch")
    else:
        findings.append("missing_llm_call_summary")

    if call_summary.get("provider") == "deepseek" and call_summary.get("attempted"):
        successful = int(call_summary.get("successful_projects", 0))
        if successful == 0:
            findings.append("deepseek_no_successful_projects")

    # A live batch is only a valid comparison baseline when every project has
    # a real DeepSeek annotation and the generated artifacts are auditable.
    # This prevents legacy directories from being mistaken for a successful
    # run merely because their run_mode was labeled deepseek_live.
    if call_summary.get("provider") == "deepseek" and call_summary.get("attempted"):
        for index, row in enumerate(rows):
            if row.get("run_mode") != "deepseek_live":
                continue
            annotation = root / f"{row.get('project')}_annotation.json"
            if not annotation.exists():
                findings.append(f"row_{index}_live_without_annotation")

    return {
        "batch_dir": str(root),
        "project_count": len(rows),
        "projects": projects,
        "findings": findings,
        "pass": not findings,
        "llm_call_summary": call_summary,
        "metrics": {
            "l1_2_clusters": sum(int(r.get("l1_2_cluster_count", 0)) for r in rows),
            "valid_cluster_ratio_mean": round(sum(float(r.get("valid_cluster_ratio", 0)) for r in rows) / len(rows), 4) if rows else 0,
            "unresolved_components": sum(int(r.get("unresolved_component_count", 0)) for r in rows),
            "l1_2_unresolved_components": sum(int(r.get("l1_2_unresolved_component_count", r.get("unresolved_component_count", 0))) for r in rows),
            "unassigned_components": sum(int(r.get("unassigned_component_count", 0)) for r in rows),
            "quality_status_counts": {status: sum(r.get("quality_status") == status for r in rows) for status in sorted({r.get("quality_status") for r in rows})},
            "promoted_hard_rules": sum(int(r.get("promoted_hard_rule_count", 0)) for r in rows),
            "promotion_conflicts": sum(int(r.get("promotion_conflict_count", 0)) for r in rows),
            "deepseek_live_projects": sum(r.get("run_mode") == "deepseek_live" for r in rows),
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("batch_dir")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = audit_batch(args.batch_dir)
    text = json.dumps(result, ensure_ascii=False, indent=2)
    if args.output:
        args.output.write_text(text + "\n", encoding="utf-8")
    print(text)


if __name__ == "__main__":
    main()
