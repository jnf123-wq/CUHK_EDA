"""Read BOM workbooks and attach traceable datasheet metadata to a topology.

The exporter used by the projects is an ordinary XLSX workbook.  This module
uses the XLSX zip/XML format directly so the flow has no dependency on Excel or
an optional dataframe package.  It is intentionally conservative: a datasheet
URL/path is provenance, not proof of a fact that the model may invent.
"""
from __future__ import annotations

import posixpath
import re
import zipfile
import xml.etree.ElementTree as ET
from pathlib import Path

from .paths import PROJECT_ROOT
from urllib.parse import urlparse


NS = {
    "m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main",
    "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
}

HEADER_ALIASES = {
    "ref": {"designator", "reference", "ref", "位号", "参考标号", "标号", "器件编号", "元件编号"},
    "part": {"manufacturerpart", "mfrpart", "mpn", "型号", "器件型号", "制造商型号", "manufacturerpartnumber"},
    "value": {"value", "值", "参数", "元件值", "物料描述", "description", "lcscpartname", "器件名称"},
    "datasheet": {"datasheet", "datasheeturl", "datasheetlink", "数据手册", "数据手册链接", "规格书", "规格书链接", "手册"},
}


def _norm(value):
    return re.sub(r"[^a-z0-9\u4e00-\u9fff]+", "", str(value or "").strip().lower())


def _column_index(ref):
    letters = re.match(r"([A-Z]+)", str(ref or "").upper())
    if not letters:
        return 0
    value = 0
    for char in letters.group(1):
        value = value * 26 + ord(char) - 64
    return value - 1


def _cell_value(cell, shared):
    kind = cell.attrib.get("t")
    if kind == "inlineStr":
        return "".join(node.text or "" for node in cell.iter("{%s}t" % NS["m"]))
    value = cell.find("m:v", NS)
    text = "" if value is None else value.text or ""
    if kind == "s" and text:
        try:
            return shared[int(text)]
        except (IndexError, ValueError):
            return text
    return text


def _workbook_rows(path):
    """Yield (sheet_name, list-of-row-lists) from an XLSX workbook."""
    with zipfile.ZipFile(path) as archive:
        shared = []
        if "xl/sharedStrings.xml" in archive.namelist():
            root = ET.fromstring(archive.read("xl/sharedStrings.xml"))
            shared = ["".join(t.text or "" for t in item.iter("{%s}t" % NS["m"]))
                      for item in root.findall("m:si", NS)]
        workbook = ET.fromstring(archive.read("xl/workbook.xml"))
        rels = ET.fromstring(archive.read("xl/_rels/workbook.xml.rels"))
        rel_map = {item.attrib.get("Id"): item.attrib.get("Target", "")
                   for item in rels}
        for sheet in workbook.find("m:sheets", NS) or []:
            rel_id = sheet.attrib.get("{%s}id" % NS["r"])
            target = rel_map.get(rel_id, "")
            target = posixpath.normpath(posixpath.join("xl", target)).lstrip("/")
            if target not in archive.namelist():
                continue
            root = ET.fromstring(archive.read(target))
            rows = []
            for row in root.findall(".//m:sheetData/m:row", NS):
                values = {}
                for cell in row.findall("m:c", NS):
                    values[_column_index(cell.attrib.get("r"))] = _cell_value(cell, shared).strip()
                if values:
                    width = max(values) + 1
                    rows.append([values.get(i, "") for i in range(width)])
            yield sheet.attrib.get("name", ""), rows


def _header_map(row):
    result = {}
    for index, value in enumerate(row):
        normalized = _norm(value)
        for field, aliases in HEADER_ALIASES.items():
            if normalized in aliases or any(alias and alias in normalized for alias in aliases):
                result.setdefault(field, index)
    return result


def _split_refs(value):
    text = str(value or "").replace("，", ",").replace("、", ",").replace(";", ",")
    refs = re.findall(r"(?<![A-Za-z0-9])([A-Za-z]{1,6}\d+[A-Za-z]?)", text, flags=re.I)
    return list(dict.fromkeys(ref.upper() for ref in refs))


def _guess_datasheet(values):
    for value in values:
        text = str(value or "").strip()
        if not text:
            continue
        lower = text.lower()
        if lower.startswith(("http://", "https://", "file://")) or lower.endswith((".pdf", ".PDF")):
            return text
    return ""


def _resolve_datasheet(raw, source):
    raw = str(raw or "").strip()
    if not raw:
        return {"raw": "", "url": "", "path": "", "exists": False}
    parsed = urlparse(raw)
    if parsed.scheme in ("http", "https"):
        return {"raw": raw, "url": raw, "path": "", "exists": False}
    candidate = Path(raw.replace("file://", ""))
    if not candidate.is_absolute():
        candidate = source.parent / candidate
    candidate = candidate.resolve()
    return {"raw": raw, "url": "", "path": str(candidate), "exists": candidate.is_file()}


def read_bom(path):
    """Return normalized BOM rows keyed by designator."""
    path = Path(path).resolve()
    records = {}
    for sheet_name, rows in _workbook_rows(path):
        header_index = None
        headers = None
        for index, row in enumerate(rows[:40]):
            candidate = _header_map(row)
            if "ref" in candidate and len(candidate) >= 2:
                header_index, headers = index, candidate
                break
        if header_index is None:
            continue
        for row in rows[header_index + 1:]:
            values = [str(value or "").strip() for value in row]
            raw_refs = values[headers["ref"]] if headers["ref"] < len(values) else ""
            refs = _split_refs(raw_refs)
            if not refs:
                continue
            part = values[headers["part"]] if headers.get("part", len(values)) < len(values) else ""
            value = values[headers["value"]] if headers.get("value", len(values)) < len(values) else ""
            raw_ds = values[headers["datasheet"]] if headers.get("datasheet", len(values)) < len(values) else _guess_datasheet(values)
            ds = _resolve_datasheet(raw_ds, path)
            for ref in refs:
                records[ref] = {
                    "ref": ref,
                    "part": part,
                    "value": value,
                    "datasheet": ds["raw"],
                    "datasheet_url": ds["url"],
                    "datasheet_path": ds["path"],
                    "datasheet_exists": ds["exists"],
                    "bom_sheet": sheet_name,
                    "bom_source": str(path),
                }
    return records


def attach_bom(topology, bom_path):
    """Attach BOM matches to component rows and provenance to ``source``."""
    if not bom_path:
        return topology, {"status": "not_provided", "records": 0, "matched": 0, "path": ""}
    path = Path(bom_path).resolve()
    records = read_bom(path)
    enriched = __import__("copy").deepcopy(topology)
    matched = 0
    for component in enriched.get("components", []):
        record = records.get(component.get("designator"))
        if not record:
            component["bom_match"] = False
            continue
        matched += 1
        component["bom_match"] = True
        component["bom"] = record
        if record.get("part"):
            component["bom_part"] = record["part"]
        if record.get("datasheet"):
            component["datasheet"] = record["datasheet"]
        component["datasheet_url"] = record.get("datasheet_url", "")
        component["datasheet_path"] = record.get("datasheet_path", "")
        component["datasheet_exists"] = record.get("datasheet_exists", False)
    source = enriched.setdefault("source", {})
    source["bom"] = str(path)
    source["bom_records"] = len(records)
    source["bom_matched_components"] = matched
    source["bom_match_rate"] = matched / len(enriched.get("components", [])) if enriched.get("components") else 0.0
    return enriched, {"status": "ok", "records": len(records), "matched": matched,
                      "path": str(path), "match_rate": source["bom_match_rate"]}


def datasheet_trace(topology):
    """Return a report row for each component with BOM/datasheet provenance."""
    rows = []
    source = topology.get("source", {})
    if not isinstance(source, dict):
        source = {}
    for component in topology.get("components", []):
        bom = component.get("bom") or {}
        rows.append({
            "ref": component.get("designator", ""),
            "part": component.get("manufacturer_part") or component.get("bom_part") or component.get("name", ""),
            "bom_match": bool(component.get("bom_match")),
            "bom_source": bom.get("bom_source", source.get("bom", "")),
            "datasheet": component.get("datasheet") or bom.get("datasheet", ""),
            "datasheet_url": component.get("datasheet_url") or bom.get("datasheet_url", ""),
            "datasheet_path": component.get("datasheet_path") or bom.get("datasheet_path", ""),
            "datasheet_exists": bool(component.get("datasheet_exists") or bom.get("datasheet_exists")),
            "datasheet_read_status": (component.get("datasheet_read") or {}).get("status", "not_read"),
            "datasheet_read_error": (component.get("datasheet_read") or {}).get("error", ""),
            "datasheet_pages": (component.get("datasheet_read") or {}).get("pages", 0),
            "datasheet_text_chars": (component.get("datasheet_read") or {}).get("chars", 0),
            "is_major_candidate": str(component.get("kind", "")).lower() in {
                "ic_module", "mcu", "controller", "power_module", "driver", "processor", "fpga"
            } or str(component.get("designator", "")).upper().startswith(("U", "IC")),
        })
    return rows


def major_datasheet_facts(topology):
    """Build compact, provenance-only context for the major-component stage."""
    facts = []
    read_by_ref = {
        str(c.get("designator", "")).upper(): c.get("datasheet_read")
        for c in topology.get("components", []) if c.get("datasheet_read")
    }
    for row in datasheet_trace(topology):
        if not row["is_major_candidate"]:
            continue
        evidence = read_by_ref.get(str(row.get("ref", "")).upper()) or {}
        row = dict(row)
        row["read_status"] = evidence.get("status", "not_read")
        row["read_error"] = evidence.get("error", "")
        row["datasheet_pages"] = evidence.get("pages", 0)
        row["datasheet_text_excerpt"] = evidence.get("text_excerpt", "")
        facts.append(row)
    return facts


def _project_name_from_schematic(path):
    name = Path(path).stem
    name = re.sub(r"^\d+_[0-9a-f]+_", "", name, flags=re.I)
    name = re.split(r"_netlist-sch", name, flags=re.I)[0]
    return name


def _tokens(value):
    return set(re.findall(r"[a-z0-9]+|[\u4e00-\u9fff]{2,}", str(value).lower()))


def find_bom_for_schematic(schematic_path, search_root=None):
    """Find the best matching project BOM without guessing across weak matches."""
    schematic_path = Path(schematic_path).resolve()
    if search_root:
        root = Path(search_root)
    elif schematic_path.parent.name.lower() == "schematic":
        # For an exported project, search its containing export directory.
        # This keeps the default portable while still finding a sibling BOM.
        root = schematic_path.parent.parent.parent
    else:
        root = PROJECT_ROOT / "examples"
    if not root.exists():
        return None
    project = _project_name_from_schematic(schematic_path)
    project_tokens = _tokens(project)
    candidates = []
    for directory in root.iterdir():
        if not directory.is_dir():
            continue
        dir_tokens = _tokens(directory.name)
        score = len(project_tokens & dir_tokens)
        if project and project.lower() in directory.name.lower():
            score += 100
        if score <= 0:
            continue
        for bom in sorted((directory / "assembly").glob("BOM_*.xlsx")):
            candidates.append((score, bom))
    if not candidates:
        return None
    candidates.sort(key=lambda item: (-item[0], len(str(item[1])), str(item[1])))
    best_score, best = candidates[0]
    if best_score < 2 and len(candidates) > 1:
        return None
    return best

