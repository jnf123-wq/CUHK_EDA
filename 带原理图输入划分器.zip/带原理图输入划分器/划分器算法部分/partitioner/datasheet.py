"""Read datasheet sources referenced by a BOM.

The reader is deliberately bounded.  It keeps enough text for a major-device
identification prompt, while recording provenance and failures instead of
pretending that a URL was successfully read.
"""
from __future__ import annotations

import io
import re
import urllib.error
import urllib.request
from html.parser import HTMLParser
from pathlib import Path


DEFAULT_MAX_BYTES = 8 * 1024 * 1024
DEFAULT_MAX_CHARS = 7000


class _HTMLText(HTMLParser):
    def __init__(self):
        super().__init__()
        self.parts = []

    def handle_data(self, data):
        text = re.sub(r"\s+", " ", data or "").strip()
        if text:
            self.parts.append(text)

    def text(self):
        return "\n".join(self.parts)


def _pdf_text(data, max_chars):
    try:
        from pypdf import PdfReader
    except ImportError as exc:
        return {"status": "reader_unavailable", "error": str(exc), "text_excerpt": "", "pages": 0}
    try:
        reader = PdfReader(io.BytesIO(data))
        pages = len(reader.pages)
        chunks = []
        remaining = max_chars
        # The first pages normally contain the part number, pin names and
        # electrical overview.  Add later pages only while the budget remains.
        for page in reader.pages:
            if remaining <= 0:
                break
            text = (page.extract_text() or "").strip()
            if not text:
                continue
            text = re.sub(r"\s+", " ", text)
            chunks.append(text[:remaining])
            remaining = max_chars - sum(len(x) for x in chunks)
        excerpt = "\n".join(chunks)[:max_chars]
        return {"status": "read", "error": "", "text_excerpt": excerpt, "pages": pages}
    except Exception as exc:  # malformed/encrypted PDFs remain auditable
        return {"status": "parse_error", "error": str(exc)[:300], "text_excerpt": "", "pages": 0}


def _html_text(data, max_chars):
    parser = _HTMLText()
    parser.feed(data.decode("utf-8", errors="replace"))
    text = parser.text()
    return {"status": "read_html", "error": "", "text_excerpt": text[:max_chars], "pages": 0}


def read_datasheet(source, *, timeout=30, max_bytes=DEFAULT_MAX_BYTES, max_chars=DEFAULT_MAX_CHARS):
    """Read one local or remote datasheet source and return bounded evidence."""
    source = str(source or "").strip()
    base = {"source": source, "source_type": "", "status": "missing", "error": "",
            "content_type": "", "text_excerpt": "", "pages": 0, "chars": 0}
    if not source:
        return base
    if source.lower().startswith(("http://", "https://")):
        base["source_type"] = "url"
        try:
            request = urllib.request.Request(source, headers={"User-Agent": "Mozilla/5.0 PartitionKB/1.0"})
            with urllib.request.urlopen(request, timeout=timeout) as response:
                data = response.read(max_bytes + 1)
                base["content_type"] = response.headers.get_content_type() or ""
                base["resolved_url"] = response.geturl()
            if len(data) > max_bytes:
                base.update(status="too_large", error=f"response exceeds {max_bytes} bytes")
                return base
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            base.update(status="fetch_error", error=str(exc)[:300])
            return base
    else:
        base["source_type"] = "local"
        path = Path(source).expanduser()
        if not path.is_file():
            base.update(status="missing_local", error="local datasheet path does not exist")
            return base
        try:
            if path.stat().st_size > max_bytes:
                base.update(status="too_large", error=f"file exceeds {max_bytes} bytes")
                return base
            data = path.read_bytes()
            base["content_type"] = "application/pdf" if path.suffix.lower() == ".pdf" else ""
            base["resolved_path"] = str(path.resolve())
        except OSError as exc:
            base.update(status="read_error", error=str(exc)[:300])
            return base

    is_pdf = data[:4] == b"%PDF" or "pdf" in base.get("content_type", "").lower() or source.lower().endswith(".pdf")
    parsed = _pdf_text(data, max_chars) if is_pdf else _html_text(data, max_chars)
    base.update(parsed)
    base["chars"] = len(base.get("text_excerpt", ""))
    return base


def attach_major_datasheets(topology, *, timeout=30, max_chars=DEFAULT_MAX_CHARS):
    """Read only major-component datasheets and attach auditable evidence."""
    major = []
    for component in topology.get("components", []):
        ref = str(component.get("designator", "")).upper()
        kind = str(component.get("kind", "")).lower()
        if not (kind in {"ic_module", "mcu", "controller", "power_module", "driver", "processor", "fpga"}
                or ref.startswith(("U", "IC"))):
            continue
        bom = component.get("bom") or {}
        source = (component.get("datasheet_path") or component.get("datasheet_url")
                  or component.get("datasheet") or bom.get("datasheet_path")
                  or bom.get("datasheet_url") or bom.get("datasheet") or "")
        evidence = read_datasheet(source, timeout=timeout, max_chars=max_chars) if source else {
            "source": "", "source_type": "", "status": "missing", "error": "no datasheet source",
            "content_type": "", "text_excerpt": "", "pages": 0, "chars": 0,
        }
        component["datasheet_read"] = evidence
        major.append({"ref": ref, "part": component.get("manufacturer_part") or component.get("bom_part") or component.get("name", ""),
                      "datasheet": source, "read_status": evidence.get("status"),
                      "read_error": evidence.get("error", ""), "pages": evidence.get("pages", 0),
                      "text_excerpt": evidence.get("text_excerpt", "")})
    topology.setdefault("source", {})["major_datasheet_read_count"] = sum(x.get("read_status") == "read" or x.get("read_status") == "read_html" for x in major)
    topology.setdefault("source", {})["major_datasheet_candidate_count"] = len(major)
    return topology, major


def prepare_major_datasheets(topology, *, schematic_path=None, bom_path=None,
                             bom_root=None, timeout=30,
                             max_chars=DEFAULT_MAX_CHARS):
    """Attach BOM provenance and read major-device datasheets for an online run.

    A URL in a topology is only metadata.  This helper makes the online flow
    explicit: resolve a matching BOM when possible, attach its URLs/parts, and
    then fetch bounded PDF/HTML evidence before the LLM prompt is built.
    Read failures remain attached to each component for reporting.
    """
    try:
        from .bom import attach_bom, find_bom_for_schematic
    except ImportError:
        from bom import attach_bom, find_bom_for_schematic

    source = topology.get("source", {})
    if isinstance(source, str):
        source = {"format": source}
        topology["source"] = source
    elif not isinstance(source, dict):
        source = {}
        topology["source"] = source

    bom_info = {"status": "not_provided", "path": "", "records": 0,
                "matched": 0, "match_rate": 0.0}
    existing_bom = source.get("bom")
    selected_bom = Path(bom_path).resolve() if bom_path else None
    if selected_bom is None and existing_bom:
        selected_bom = Path(existing_bom).resolve()
    if selected_bom is None:
        schematic = schematic_path or source.get("schematic")
        if schematic:
            selected_bom = find_bom_for_schematic(schematic, bom_root)
    if selected_bom:
        if Path(selected_bom).is_file():
            topology, bom_info = attach_bom(topology, selected_bom)
        else:
            bom_info = {"status": "missing", "path": str(selected_bom),
                        "records": 0, "matched": 0, "match_rate": 0.0}
    elif schematic_path or source.get("schematic"):
        bom_info["status"] = "not_found"
    source = topology.setdefault("source", {})
    source["bom_resolution"] = bom_info
    topology, major = attach_major_datasheets(topology, timeout=timeout,
                                               max_chars=max_chars)
    return topology, {"bom": bom_info, "major": major}

