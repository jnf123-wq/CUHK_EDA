"""Call an OpenAI-compatible DeepSeek endpoint for llm-annotation-v1.

The API key is read only from DEEPSEEK_API_KEY (or OPENAI_API_KEY). It is
never written to the project or included in generated annotation files.
"""
from __future__ import annotations

import argparse
import http.client
import json
import os
import re
import time
import urllib.error
import urllib.request
from pathlib import Path

try:
    from .make_llm_annotation_skeleton import build
    from .l1_partition import validate_llm_annotation, net_semantics
    from .major_first_llm import build_major_prompt, build_peripheral_prompt
    from .bom import major_datasheet_facts
except ImportError:
    from make_llm_annotation_skeleton import build
    from l1_partition import validate_llm_annotation, net_semantics
    from major_first_llm import build_major_prompt, build_peripheral_prompt
    from bom import major_datasheet_facts


DEFAULT_BASE_URL = "https://api.deepseek.com"
DEFAULT_MODEL = "deepseek-v4-pro"


class DeepSeekRequestError(RuntimeError):
    """An HTTP error from the DeepSeek endpoint.

    HTTP failures are kept separate from malformed model output so the
    two-stage annotator does not retry an unavailable account or endpoint as
    a different prompt.
    """

    def __init__(self, status_code, detail):
        self.status_code = int(status_code)
        self.detail = str(detail)
        super().__init__(f"DeepSeek HTTP {self.status_code}: {self.detail}")


def _decode_json(content):
    if isinstance(content, list):
        content = "".join(part.get("text", "") for part in content if isinstance(part, dict))
    content = str(content).strip()
    if content.startswith("```"):
        content = content.split("\n", 1)[1].rsplit("```", 1)[0].strip()
    return json.loads(content)


_DESIGNATOR_TOKEN = re.compile(r"(?<![A-Za-z0-9])([A-Za-z]{1,8}\d+[A-Za-z]?)(?![A-Za-z0-9])")
_REF_FIELD_NAMES = {
    "ref", "reference", "designator", "component_ref", "component", "component_id",
    "member_ref", "source_component", "target_component", "from_ref", "to_ref",
}
_RELATION_MEMBER_KEYS = (
    "members", "member_refs", "refs", "related_refs", "components", "component_refs",
    "component_list", "devices", "related_components",
)


def _ref_text(value):
    """Return a compact text representation used for reference matching."""
    return re.sub(r"\s+", " ", str(value or "").strip())


def _member_ref(value, resolver=None):
    """Extract one component reference from a scalar or common model object.

    ``resolver`` is optional for backwards compatibility with callers that only
    need the old scalar behavior.  The annotation normalizer passes a resolver
    so prefixes such as ``component:C1`` and unique part names can be mapped to
    the topology's actual designator.
    """
    if isinstance(value, str):
        text = _ref_text(value)
        if resolver:
            matches = _resolve_member_refs(text, resolver)
            return matches[0] if len(matches) == 1 else ""
        return text
    if isinstance(value, (int, float)):
        return str(value)
    if isinstance(value, dict):
        for key in (*_REF_FIELD_NAMES, "name", "id"):
            candidate = value.get(key)
            if candidate is not None:
                ref = _member_ref(candidate, resolver)
                if ref:
                    return ref
    return ""


def _resolve_member_refs(value, resolver):
    """Resolve one raw relation value to zero or more known designators."""
    if isinstance(value, dict):
        for key in (*_REF_FIELD_NAMES, "name", "id"):
            if key in value and value.get(key) is not None:
                matches = _resolve_member_refs(value.get(key), resolver)
                if matches:
                    return matches
        return []
    if not isinstance(value, (str, int, float)):
        return []
    text = _ref_text(value)
    if not text:
        return []
    exact = resolver["by_ref"].get(text.casefold())
    if exact:
        return [exact]
    # Remove common provenance prefixes before trying exact matching.
    stripped = re.sub(r"^(?:component|component_ref|ref|designator|器件|元件)\s*[:#：]?\s*",
                      "", text, flags=re.IGNORECASE)
    exact = resolver["by_ref"].get(stripped.casefold())
    if exact:
        return [exact]
    tokens = []
    for token in _DESIGNATOR_TOKEN.findall(stripped):
        ref = resolver["by_ref"].get(token.casefold())
        if ref and ref not in tokens:
            tokens.append(ref)
    if tokens:
        return tokens
    compact = re.sub(r"[^a-z0-9]+", "", stripped.casefold())
    aliases = resolver["by_alias"].get(compact, [])
    return list(aliases) if len(aliases) == 1 else []


def _member_values(item):
    """Read relation members from the aliases used by different LLM prompts."""
    for key in _RELATION_MEMBER_KEYS:
        if key not in item or item.get(key) is None:
            continue
        value = item.get(key)
        values = value if isinstance(value, (list, tuple)) else [value]
        if values:
            return values

    # Pair-shaped relations are accepted only as pairs.  In particular, do
    # not treat a lone ``source`` provenance field as a component reference.
    for left, right in (
        ("a", "b"), ("left", "right"), ("from", "to"), ("source", "target"),
        ("source_component", "target_component"), ("from_ref", "to_ref"),
    ):
        if left in item or right in item:
            return [item.get(left), item.get(right)]
    return []


def _normalize_member_records(raw_value, refs, warnings, *, kind, resolver=None):
    """Canonicalize relations while retaining enough data to audit failures."""
    if isinstance(raw_value, list):
        raw_rows = raw_value
    elif isinstance(raw_value, dict):
        raw_rows = [raw_value]
    else:
        raw_rows = []

    normalized = []
    for index, raw in enumerate(raw_rows):
        if not isinstance(raw, dict):
            warnings.append({"type": f"dropped_{kind}", "index": index,
                             "reason": "item_is_not_an_object"})
            continue
        raw_members = _member_values(raw)
        members = []
        unresolved = []
        for value in raw_members:
            matches = (_resolve_member_refs(value, resolver)
                       if resolver else [_member_ref(value)])
            matches = [ref for ref in matches if ref in refs]
            if not matches:
                unresolved.append(value)
            for ref in matches:
                if ref not in members:
                    members.append(ref)
        raw_audit = list(raw_members)
        row = dict(raw)
        row["raw_members"] = raw_audit
        row["resolved_members"] = list(members)
        row["unresolved_members"] = unresolved
        if len(members) < 2:
            warnings.append({"type": f"dropped_{kind}", "index": index,
                             "reason": "fewer_than_two_known_refs",
                             "raw_members": raw_audit,
                             "resolved_members": list(members),
                             "unresolved_members": unresolved})
            continue
        row["members"] = members
        normalized.append(row)
    return normalized


def _normalize_annotation(annotation, topology):
    """Normalize common OpenAI-compatible model schema variations."""
    if not isinstance(annotation, dict):
        raise ValueError("DeepSeek annotation must be a JSON object")
    result = dict(annotation)
    result["schema"] = "llm-annotation-v1"
    refs = {str(c.get("designator", c.get("ref", ""))): c
            for c in topology.get("components", []) if isinstance(c, dict)}
    resolver = {"by_ref": {ref.casefold(): ref for ref in refs}, "by_alias": {}}
    for ref, component in refs.items():
        aliases = [ref, component.get("ref"), component.get("designator"),
                   component.get("name"), component.get("value"), component.get("part_name")]
        for alias in aliases:
            compact = re.sub(r"[^a-z0-9]+", "", str(alias or "").casefold())
            if compact:
                resolver["by_alias"].setdefault(compact, []).append(ref)
    rows = result.get("components")
    if isinstance(rows, list):
        normalized_rows = []
        for raw in rows:
            if not isinstance(raw, dict):
                continue
            row = dict(raw)
            ref = row.get("ref", row.get("designator", row.get("component", row.get("name"))))
            if ref is not None:
                row["ref"] = str(ref)
            if "roles" not in row and "role" in row:
                row["roles"] = row["role"]
            if isinstance(row.get("roles"), str):
                row["roles"] = [row["roles"]]
            row.setdefault("function_tags", [])
            normalized_rows.append(row)
        result["components"] = normalized_rows
    elif isinstance(result.get("components"), dict):
        result["components"] = [dict(value, ref=key) if isinstance(value, dict) else {"ref": key, "roles": []}
                                for key, value in result["components"].items()]
    elif isinstance(result.get("component_roles"), dict):
        result["components"] = [{"ref": ref, "roles": roles if isinstance(roles, list) else [roles],
                                 "function_tags": []}
                                for ref, roles in result["component_roles"].items()]
    else:
        result["components"] = []
    if not isinstance(result.get("nets"), dict):
        result["nets"] = {}
    elif result["nets"] and all(isinstance(value, dict) and
                                 not ({"semantics", "connections"} & set(value))
                                 for value in result["nets"].values()):
        # Some responses use nets as a net-name -> semantics map.
        result["nets"] = {name: {"semantics": value.get("semantics", value.get("tags", []))
                                if isinstance(value, dict) else [], "connections": []}
                          for name, value in result["nets"].items()}
    normalized_nets = {}
    for name, raw in result["nets"].items():
        if name not in topology.get("nets", {}):
            continue
        if isinstance(raw, dict):
            row = dict(raw)
            semantics = row.get("semantics", row.get("tags", []))
            row["semantics"] = [semantics] if isinstance(semantics, str) else semantics
            row.setdefault("connections", [])
            normalized_nets[str(name)] = row
        elif isinstance(raw, list):
            normalized_nets[str(name)] = {"semantics": [], "connections": [
                {"ref": ep.get("ref", ep.get("designator", ep.get("c"))),
                 **({"pin": ep.get("pin", ep.get("pad"))} if ep.get("pin", ep.get("pad")) else {})}
                for ep in raw if isinstance(ep, dict)]}
    # Accept either a net-name map or a list of {name, semantics, ...} rows.
    raw_nets = annotation.get("nets")
    if isinstance(raw_nets, list):
        for net in raw_nets:
            if isinstance(net, dict):
                name = net.get("name", net.get("net"))
                if name in topology.get("nets", {}):
                    normalized_nets[str(name)] = {**net, "semantics": net.get("semantics", net.get("tags", [])),
                                                   "connections": net.get("connections", net.get("endpoints", []))}
    result["nets"] = normalized_nets
    warnings = result.get("normalization_warnings", [])
    if not isinstance(warnings, list):
        warnings = []
    raw_soft_links = result.get("soft_links")
    if raw_soft_links is None:
        raw_soft_links = result.get("links", [])
    raw_candidate_clusters = result.get("candidate_clusters")
    if raw_candidate_clusters is None:
        raw_candidate_clusters = result.get("clusters", [])
    result["soft_links"] = _normalize_member_records(
        raw_soft_links, set(refs), warnings, kind="soft_link", resolver=resolver)
    result["candidate_clusters"] = _normalize_member_records(
        raw_candidate_clusters, set(refs), warnings, kind="candidate_cluster", resolver=resolver)
    result["normalization_warnings"] = warnings
    result.setdefault("datasheet_facts", [])
    # Net semantics are optional in some otherwise complete model responses.
    # Fill only missing rows from the deterministic local semantic dictionary;
    # preserve any semantics explicitly supplied by DeepSeek.
    semantic_fallbacks = []
    try:
        fallback_semantics = net_semantics(topology)
    except Exception:
        fallback_semantics = {}
    # The topology is authoritative for connectivity; preserve model semantics
    # but fill omitted rows so annotation completeness can be checked exactly.
    existing = {}
    for row in result["components"]:
        ref = row.get("ref")
        if ref is None or str(ref) not in refs:
            continue
        ref = str(ref)
        # Merge duplicates conservatively instead of letting the final row erase labels.
        if ref not in existing:
            existing[ref] = row
        else:
            for key in ("roles", "function_tags", "evidence"):
                current = existing[ref].get(key, [])
                incoming = row.get(key, [])
                if isinstance(current, str): current = [current]
                if isinstance(incoming, str): incoming = [incoming]
                existing[ref][key] = list(dict.fromkeys([*current, *incoming]))
    result["components"] = [existing.get(ref, {"ref": ref, "roles": [], "function_tags": []})
                            for ref in refs]
    topology_nets = topology.get("nets", {})
    for name, endpoints in topology_nets.items():
        row = normalized_nets.get(name, {"semantics": [], "connections": []})
        # Connectivity is structural ground truth; LLM endpoint lists are advisory.
        row["connections"] = [
            {"ref": ep.get("c", ep.get("designator", ep.get("ref"))),
             **({"pin": ep.get("name", ep.get("pin", ep.get("pad")))}
                if ep.get("name", ep.get("pin", ep.get("pad"))) else {})}
            for ep in endpoints
            if ep.get("c", ep.get("designator", ep.get("ref")))
        ]
        if isinstance(row.get("semantics"), str):
            row["semantics"] = [row["semantics"]]
        if not isinstance(row.get("semantics"), list):
            row["semantics"] = []
        for ep in row["connections"]:
            ep.pop("ref", None) if ep.get("ref") is None else None
        # The model may omit a net entirely or return it without semantics.
        # Apply deterministic local semantics after materializing every
        # topology net, while preserving any semantics supplied by DeepSeek.
        if not row.get("semantics") and fallback_semantics.get(name):
            row["semantics"] = list(fallback_semantics[name])
            row["semantic_source"] = "local_fallback"
            semantic_fallbacks.append(str(name))
        normalized_nets[name] = row
    result["nets"] = normalized_nets
    if semantic_fallbacks:
        result["semantic_fallbacks"] = list(dict.fromkeys(semantic_fallbacks))
    return result


def _call_model(*, payload, api_key, base_url, timeout):
    request_data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    # A response can be closed after only part of the JSON body has arrived.
    # This is a transport failure, so retry the identical request a small
    # number of times without imposing a generation deadline.
    transient_errors = (http.client.IncompleteRead, http.client.RemoteDisconnected,
                        ConnectionResetError, ConnectionAbortedError, BrokenPipeError)
    for attempt in range(3):
        req = urllib.request.Request(
            base_url.rstrip("/") + "/v1/chat/completions",
            data=request_data,
            headers={"Authorization": "Bearer " + api_key,
                     "Content-Type": "application/json"}, method="POST")
        try:
            # ``None`` deliberately means no client-side request deadline.  This
            # keeps long-running model generations from being interrupted by the
            # partitioner; callers can still pass an integer for diagnostics.
            response_context = (urllib.request.urlopen(req)
                                if timeout is None
                                else urllib.request.urlopen(req, timeout=timeout))
            with response_context as response:
                body = json.loads(response.read().decode("utf-8"))
            break
        except transient_errors as exc:
            if attempt >= 2:
                raise DeepSeekRequestError(
                    0, f"response body truncated or connection closed after 3 attempts: {exc}") from exc
            time.sleep(0.5 * (attempt + 1))
        except TimeoutError as exc:
            raise DeepSeekRequestError(408, f"request timeout after {timeout}s") from exc
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")
            raise DeepSeekRequestError(exc.code, detail[:500]) from exc
        except urllib.error.URLError as exc:
            raise DeepSeekRequestError(0, f"network error: {exc.reason}") from exc
    try:
        return _decode_json(body["choices"][0]["message"]["content"])
    except (KeyError, IndexError, TypeError, json.JSONDecodeError) as exc:
        raise RuntimeError("DeepSeek response did not contain a JSON object") from exc


def _single_stage_annotation(topology, *, api_key, base_url, model, timeout=None):
    prompt = Path(__file__).with_name("llm_annotation_prompt.md").read_text(encoding="utf-8")
    skeleton = build(topology)
    payload = {"model": model, "temperature": 0, "response_format": {"type": "json_object"},
               "messages": [{"role": "system", "content": prompt},
                            {"role": "user", "content": prompt +
                             "\n\n输入标准化拓扑 JSON：\n" + json.dumps(
                                 {"topology": topology, "annotation_skeleton": skeleton},
                                 ensure_ascii=False, indent=2)}]}
    return _call_model(payload=payload, api_key=api_key, base_url=base_url, timeout=timeout)


def request_annotation(topology, *, api_key, base_url=DEFAULT_BASE_URL,
                       model=DEFAULT_MODEL, timeout=None, major_first=True):
    if not api_key:
        raise ValueError("set DEEPSEEK_API_KEY or OPENAI_API_KEY before calling DeepSeek")
    facts = major_datasheet_facts(topology)
    stage = "single_stage"
    major = None
    if major_first:
        major_prompt = build_major_prompt(topology, facts)
        major_payload = {"model": model, "temperature": 0, "response_format": {"type": "json_object"},
                         "messages": [
                             {"role": "system", "content": (
                                 "你是 PCB 原理图大器件识别器。只返回 JSON，不要 Markdown。"
                                 "输出 components 和 datasheet_facts；不要输出布局结论。")},
                             {"role": "user", "content": json.dumps(
                                 {"task": major_prompt, "topology": topology},
                                 ensure_ascii=False, indent=2)}]}
        try:
            major = _call_model(payload=major_payload, api_key=api_key,
                                base_url=base_url, timeout=timeout)
            peripheral_prompt = build_peripheral_prompt(topology, major, facts)
            full_prompt = Path(__file__).with_name("llm_annotation_prompt.md").read_text(encoding="utf-8")
            peripheral_payload = {"model": model, "temperature": 0, "response_format": {"type": "json_object"},
                                  "messages": [
                                      {"role": "system", "content": full_prompt +
                                       "\n这是第二阶段。保留大器件阶段识别结果，并输出完整的全部器件和全部网络。"},
                                      {"role": "user", "content": json.dumps(
                                          {"task": peripheral_prompt, "topology": topology,
                                           "major_annotation": major,
                                           "annotation_skeleton": build(topology)},
                                          ensure_ascii=False, indent=2)}]}
            annotation = _call_model(payload=peripheral_payload, api_key=api_key,
                                     base_url=base_url, timeout=timeout)
            stage = "major_first_two_stage"
        except DeepSeekRequestError:
            # A billing, authentication, rate-limit, or endpoint failure is
            # not repaired by changing the annotation prompt.  Re-raise it so
            # callers record one actionable error instead of issuing another
            # guaranteed-to-fail request.
            raise
        except (RuntimeError, ValueError, json.JSONDecodeError):
            # A malformed partial stage must not silently become a valid claim;
            # retry once with the strict single-stage schema.
            annotation = _single_stage_annotation(topology, api_key=api_key,
                                                  base_url=base_url, model=model,
                                                  timeout=timeout)
            stage = "single_stage_fallback"
    else:
        annotation = _single_stage_annotation(topology, api_key=api_key,
                                              base_url=base_url, model=model,
                                              timeout=timeout)
    annotation = _normalize_annotation(annotation, topology)
    validate_llm_annotation(annotation, topology)
    # Models sometimes echo provenance as a scalar string.  Preserve it as
    # an audit field while canonicalizing ``source`` to the object shape used
    # by downstream batch validation.
    source = annotation.get("source")
    if isinstance(source, dict):
        source = dict(source)
    elif source:
        source = {"model_source": str(source)}
    else:
        source = {}
    source.update({"provider": "deepseek", "model": model,
                   "stage": stage,
                   "datasheet_records": len(facts),
                   "datasheet_refs": [x.get("ref") for x in facts
                                       if x.get("datasheet") or x.get("datasheet_path") or x.get("datasheet_url")]})
    annotation["source"] = source
    if major is not None:
        annotation["major_stage"] = major
    return annotation



def request_unresolved_partition(topology, unresolved_refs, existing_clusters=None, *, api_key,
                                  base_url=DEFAULT_BASE_URL, model=DEFAULT_MODEL, timeout=None):
    """Ask DeepSeek to propose fine clusters only for algorithm-unresolved parts."""
    if not api_key:
        raise ValueError("set DEEPSEEK_API_KEY or OPENAI_API_KEY before calling DeepSeek")
    refs = set(unresolved_refs or [])
    local_components = [c for c in topology.get("components", []) if c.get("designator") in refs]
    local_nets = {}
    for name, endpoints in topology.get("nets", {}).items():
        kept = [ep for ep in endpoints if ep.get("designator", ep.get("c")) in refs]
        if len(kept) >= 2:
            local_nets[name] = kept
    payload_data = {"task": "对算法未形成L1-2细簇的器件进行二次功能划分。只返回能确认的局部功能簇；不要重复已有簇，不要把不同功能合并。每个簇至少包含两个器件。",
                    "unresolved_refs": sorted(refs), "components": local_components,
                    "local_nets": local_nets, "existing_clusters": existing_clusters or []}
    system = "只返回JSON对象：{clusters:[{function,function_type,members,evidence_nets,confidence,reason}]}。members只能使用unresolved_refs中的设计代号。无法确认的器件不要硬塞进簇。"
    payload = {"model": model, "temperature": 0, "response_format": {"type": "json_object"},
               "messages": [{"role": "system", "content": system},
                            {"role": "user", "content": json.dumps(payload_data, ensure_ascii=False)}]}
    result = _call_model(payload=payload, api_key=api_key, base_url=base_url, timeout=timeout)
    if not isinstance(result, dict):
        raise RuntimeError("DeepSeek unresolved partition response must be an object")
    clusters = result.get("clusters", [])
    if not isinstance(clusters, list):
        raise RuntimeError("DeepSeek unresolved partition clusters must be a list")
    clean = []
    for item in clusters:
        if not isinstance(item, dict):
            continue
        members = sorted({str(x) for x in item.get("members", []) if str(x) in refs})
        if len(members) < 2:
            continue
        row = dict(item)
        row["members"] = members
        row["source"] = "llm_unresolved_partition"
        clean.append(row)
    return {"clusters": clean, "source": {"provider": "deepseek", "model": model, "stage": "unresolved_partition"}}

def review_soft_constraints(records, *, api_key, base_url=DEFAULT_BASE_URL,
                            model=DEFAULT_MODEL, timeout=None):
    """Ask DeepSeek to review candidates; returns records with audit fields."""
    if not api_key:
        raise ValueError("set DEEPSEEK_API_KEY or OPENAI_API_KEY before review")
    payload = {"model": model, "temperature": 0, "response_format": {"type": "json_object"},
               "messages": [{"role": "system", "content": (
                   "审核电路软约束。只返回 JSON object: {reviews:[{constraint_id,approved,confidence,reason}]}。"
                   "只有证据充分、跨工程可泛化且无明显反例才 approved=true。" )},
                            {"role": "user", "content": json.dumps({"records": records}, ensure_ascii=False)}]}
    result = _call_model(payload=payload, api_key=api_key, base_url=base_url, timeout=timeout)
    reviews = result.get("reviews", []) if isinstance(result, dict) else []
    by_id = {row.get("constraint_id"): row for row in reviews if isinstance(row, dict)}
    reviewed = []
    for record in records:
        row = dict(record)
        decision = by_id.get(record.get("constraint_id"), {})
        row["review_provider"] = "deepseek"
        if not decision:
            row["review_status"] = "pending_review"
        else:
            row["review_status"] = "deepseek_approved" if decision.get("approved") else "deepseek_rejected"
        try:
            review_confidence = max(0.0, min(1.0, float(decision.get("confidence", 0.0))))
        except (TypeError, ValueError):
            review_confidence = 0.0
        row["review_confidence"] = review_confidence
        row["review_reason"] = decision.get("reason", "未返回审核意见")
        reviewed.append(row)
    return reviewed


def main(argv=None):
    parser = argparse.ArgumentParser(description="Annotate a normalized topology with DeepSeek")
    parser.add_argument("topology", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--model", default=os.getenv("DEEPSEEK_MODEL", DEFAULT_MODEL))
    parser.add_argument("--base-url", default=os.getenv("DEEPSEEK_BASE_URL", DEFAULT_BASE_URL))
    parser.add_argument("--single-stage", action="store_true",
                        help="disable the major-component-first stage")
    args = parser.parse_args(argv)
    topology = json.loads(args.topology.read_text(encoding="utf-8"))
    key = os.getenv("DEEPSEEK_API_KEY") or os.getenv("OPENAI_API_KEY")
    annotation = request_annotation(topology, api_key=key, base_url=args.base_url,
                                    model=args.model, major_first=not args.single_stage)
    args.output.write_text(json.dumps(annotation, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
