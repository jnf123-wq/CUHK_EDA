"""Batch partition schematic/PCB .enet pairs from an export directory.

Only schematic and PCB ``.enet`` files are accepted as topology inputs.  The
PCB file is optional metadata enrichment; electrical connectivity always comes
from the schematic file.
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import re
from pathlib import Path

from .enet_to_topology import convert
from .l1_partition import run
from .paths import DEFAULT_INPUT_ROOT, DEFAULT_OUTPUT_ROOT
from .reporting import quality_metrics, stability_metrics, write_reports


def _cluster_signature(clusters):
    """Return a stable, order-independent signature for L1 clusters."""
    normalized = []
    for cluster in clusters or []:
        members = cluster.get("members", []) if isinstance(cluster, dict) else []
        normalized.append(tuple(sorted(str(member) for member in members)))
    return tuple(sorted(normalized))


def _safe_name(value: str) -> str:
    value = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", value).strip(" .")
    return value[:120] or "unnamed_project"


def _input_error_code(exc: Exception) -> str:
    """Map conversion exceptions to stable batch-audit categories."""
    if isinstance(exc, json.JSONDecodeError):
        return "invalid_enet_json"
    if isinstance(exc, UnicodeDecodeError):
        return "invalid_enet_encoding"
    if "not a supported .enet export" in str(exc):
        return "invalid_enet_schema"
    return "input_conversion_failed"


def _find_pair(project: Path):
    schematic_dir = project / "schematic"
    pcb_dir = project / "pcb"
    schematics = sorted(schematic_dir.glob("*.enet"))
    if not schematics:
        return None
    # A project may contain several schematic sheets; each is a separate
    # electrical input.  Prefer the matching PCB by shared export suffix.
    for schematic in schematics:
        suffix = schematic.stem.rsplit("_", 1)[-1]
        pcbs = sorted(pcb_dir.glob("*.enet"))
        matching = [p for p in pcbs if suffix and suffix in p.stem]
        yield schematic, (matching[0] if matching else (pcbs[0] if len(pcbs) == 1 else None))


def run_batch(source: Path, output: Path, *, api_key: str | None = None,
              model: str = "deepseek-v4-pro", base_url: str = "https://api.deepseek.com",
              use_llm: bool = False, algorithm_repeats: int = 2, llm_repeats: int = 0,
              knowledge_base=None, llm_timeout=None, bom_root=None,
              datasheet_timeout=30):
    """Run every schematic through the deterministic algorithm only.

    The legacy LLM-related keyword arguments are retained so existing scripts
    keep importing successfully.  They are intentionally ignored: this batch
    entry point never reads API keys, fetches datasheets for prompts, or calls
    an annotation/review service.
    """
    source = Path(source).resolve()
    output = Path(output).resolve()
    output.mkdir(parents=True, exist_ok=True)
    manifest = knowledge_base
    projects = []
    input_issues = []
    for project in sorted(p for p in source.iterdir() if p.is_dir()):
        schematic_dir = project / "schematic"
        pcb_dir = project / "pcb"
        schematics = sorted(schematic_dir.glob("*.enet"))
        if not schematics:
            input_issues.append({"project": project.name, "run_mode": "input_failed",
                                 "error": "missing_schematic_enet",
                                 "schematic": "", "pcb": ""})
            continue
        pairs = list(_find_pair(project) or [])
        for schematic, pcb in pairs:
            projects.append((project.name, schematic, pcb))
            if pcb is None and list(pcb_dir.glob("*.enet")):
                input_issues.append({"project": project.name, "run_mode": "input_review",
                                     "error": "no_matching_pcb_enet",
                                     "schematic": str(schematic), "pcb": ""})
    rows = list(input_issues)
    for project_name, schematic, pcb in projects:
        stem = _safe_name(f"{project_name}__{schematic.stem}")
        target = output / stem / f"{stem}_l1.json"
        target.parent.mkdir(parents=True, exist_ok=True)
        record = {"project": project_name, "schematic": str(schematic), "pcb": str(pcb) if pcb else None}
        topology = None
        try:
            topology = convert(schematic, pcb)
            result = run(topology, project_id=stem, knowledge_base_path=manifest,
                         learn_soft_constraints=False, unresolved_llm=False)
            if not isinstance(result, dict) or not isinstance(result.get("partition"), dict):
                raise RuntimeError("partition_result_missing")
            fixed = [result["partition"].get("l1_clusters", result["partition"].get("clusters", []))]
            for _ in range(max(0, algorithm_repeats - 1)):
                repeated = run(topology, project_id=stem, knowledge_base_path=manifest,
                               learn_soft_constraints=False, unresolved_llm=False)
                fixed.append(repeated["partition"].get("l1_clusters", repeated["partition"].get("clusters", [])))
            result["batch_input"] = {"schematic_enet": str(schematic), "pcb_enet": str(pcb) if pcb else None,
                                      "project": project_name, "accepted_input_types": ["schematic.enet", "pcb.enet"]}
            result["llm_call"] = {"provider": None, "attempted": False,
                                   "succeeded": False, "disabled": True}
            reports = write_reports(result, target, fixed_runs=fixed, llm_runs=None)
            quality = quality_metrics(result)
            stability = stability_metrics(result, fixed_runs=fixed, llm_runs=None)
            rows.append({"project": project_name, "schematic": str(schematic), "pcb": str(pcb) if pcb else "",
                         "run_mode": "offline",
                         "component_count": quality["component_count"], "l2_domain_count": quality["l2_domain_count"],
                         "l1_cluster_count": quality["l1_cluster_count"], "multi_member_l1_count": quality["l1_2_cluster_count"],
                         "singleton_fallback_count": quality.get("singleton_fallback_count", 0),
                         "unknown_net_rate": quality["unknown_net_rate"], "unassigned_component_count": quality["unassigned_component_count"],
                         "unknown_net_category_counts": json.dumps(quality.get("unknown_net_category_counts", {}), ensure_ascii=False, sort_keys=True),
                         "all_components_once": quality["all_components_once"], "quality_status": quality["status"],
                         "algorithm_exact_match_rate": stability["algorithm_exact_match_rate"],
                         "algorithm_ari_mean": stability["algorithm_ari_mean"],
                         "llm_exact_match_rate": None,
                         "llm_ari_mean": None,
                         "reference_ari": stability.get("reference_ari"),
                         "reference_ari_status": stability.get("reference_ari_status"),
                         "json": str(target),
                         "report": str(reports["report"]), "l1_csv": str(reports["l1_csv"]),
                         "l2_csv": str(reports["l2_csv"]), "error": ""})
        except Exception as exc:
            input_failed = topology is None
            error_code = _input_error_code(exc) if input_failed else "partition_failed"
            rows.append({"project": project_name, "schematic": str(schematic), "pcb": str(pcb) if pcb else "",
                         "run_mode": "input_failed" if input_failed else "failed",
                         "error": f"{error_code}: {type(exc).__name__}: {str(exc)[:500]}"})
    summary = output / "batch_summary.csv"
    fields = sorted({key for row in rows for key in row}) if rows else ["project", "error"]
    with summary.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore"); writer.writeheader()
        for row in rows:
            writer.writerow({key: row.get(key, "") for key in fields})
    (output / "batch_summary.json").write_text(json.dumps(rows, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return rows


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, default=DEFAULT_INPUT_ROOT,
                        help="输入工程目录（默认：项目目录下的 examples/）")
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT_ROOT,
                        help="输出目录（默认：项目目录下的 outputs/）")
    parser.add_argument("--api-key-file", type=Path, help="deprecated compatibility option; ignored")
    parser.add_argument("--knowledge-base", type=Path)
    parser.add_argument("--offline", action="store_true", help="deprecated compatibility option; algorithm-only is always used")
    parser.add_argument("--model", default="", help="deprecated compatibility option; ignored")
    parser.add_argument("--base-url", default="", help="deprecated compatibility option; ignored")
    parser.add_argument("--algorithm-repeats", type=int, default=2)
    parser.add_argument("--llm-repeats", type=int, default=0,
                        help="deprecated compatibility option; ignored")
    parser.add_argument("--llm-timeout", type=int, default=None,
                        help="optional seconds allowed for each DeepSeek response; omitted means no timeout")
    parser.add_argument("--bom-root", type=Path,
                        help="root directory searched for a matching assembly/BOM_*.xlsx")
    parser.add_argument("--datasheet-timeout", type=int, default=30,
                        help="seconds allowed for each datasheet URL/local source")
    args = parser.parse_args(argv)
    rows = run_batch(args.source, args.output, algorithm_repeats=args.algorithm_repeats,
                     knowledge_base=args.knowledge_base)
    print(json.dumps({"projects": len(rows), "output": str(Path(args.output).resolve()),
                      "run_modes": {mode: sum(row.get("run_mode") == mode for row in rows) for mode in {row.get("run_mode") for row in rows}}}, ensure_ascii=False))


if __name__ == "__main__":
    main()
