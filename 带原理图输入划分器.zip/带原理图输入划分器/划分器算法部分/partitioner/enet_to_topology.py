"""Convert Lichuang/JLC ``.enet`` JSON exports to moduplace-topology-v1.

The schematic export is the authoritative source for electrical connectivity.
An optional PCB export is used only to enrich component metadata (footprint and
coordinates); L1 partition rules deliberately ignore those physical fields.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path


def _load(path: Path):
    data = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(data, dict) or not isinstance(data.get("components"), dict):
        raise ValueError(f"not a supported .enet export: {path}")
    return data


def _props(component):
    return component.get("props") or {}


def _kind(props):
    designator = str(props.get("Designator", "")).upper()
    if designator.startswith("U") or designator.startswith("IC"):
        return "ic_module"
    if designator.startswith("R"):
        return "resistor"
    if designator.startswith("C"):
        return "capacitor"
    if designator.startswith("L"):
        return "inductor"
    if designator.startswith("D"):
        return "diode"
    if designator.startswith("Q"):
        return "transistor"
    if designator.startswith(("J", "P", "CON")):
        return "connector"
    return "other"


def _component_row(raw):
    props = _props(raw)
    ref = str(props.get("Designator", "")).strip()
    if not ref:
        return None
    # Some exports use the literal template "={Manufacturer Part}" in Name;
    # keep the resolved manufacturer part available to role matching.
    name = props.get("Name") or ""
    manufacturer_part = props.get("Manufacturer Part") or ""
    value = props.get("Value") or (manufacturer_part if str(name).startswith("={") else name) or props.get("DeviceName") or ""
    return {
        "designator": ref,
        "kind": _kind(props),
        "name": str(value),
        "value": str(value),
        "manufacturer_part": str(manufacturer_part),
        "datasheet": str(props.get("Datasheet") or ""),
        "datasheet_url": str(props.get("Datasheet") or "") if str(props.get("Datasheet") or "").lower().startswith(("http://", "https://")) else "",
        "datasheet_path": str(props.get("Datasheet") or "") if not str(props.get("Datasheet") or "").lower().startswith(("http://", "https://")) else "",
        "footprint": str(props.get("FootprintName") or props.get("Supplier Footprint") or ""),
        "enet_id": str(props.get("Unique ID", "")),
    }


def _nets(enet, aliases=None):
    aliases = aliases or {}
    nets = {}
    occurrence = {}
    for raw in enet.get("components", {}).values():
        props = _props(raw)
        ref = str(props.get("Designator", "")).strip()
        if not ref:
            continue
        occurrence[ref] = occurrence.get(ref, 0) + 1
        canonical_ref = aliases.get((ref, occurrence[ref]), ref)
        for pin in (raw.get("pinInfoMap") or {}).values():
            net = str(pin.get("net", "")).strip()
            if not net:
                continue
            nets.setdefault(net, []).append({
                "c": canonical_ref,
                "pin": str(pin.get("number", "")),
                "name": str(pin.get("name", "")),
            })
    for endpoints in nets.values():
        endpoints.sort(key=lambda x: (x["c"], x["pin"]))
    return dict(sorted(nets.items()))


def convert(schematic_path: Path, pcb_path: Path | None = None, bom_path: Path | None = None):
    schematic = _load(schematic_path)
    rows = [_component_row(raw) for raw in schematic["components"].values()]
    rows = sorted((row for row in rows if row), key=lambda x: x["designator"])
    # A few exported projects contain repeated schematic references.  Preserve
    # every physical row with a deterministic alias so topology validation does
    # not silently overwrite one component or its pins.
    seen = {}
    aliases = {}
    for row in rows:
        ref = row["designator"]
        count = seen.get(ref, 0) + 1
        seen[ref] = count
        if count > 1:
            alias = f"{ref}__dup{count}"
            aliases[(ref, count)] = alias
            row["original_designator"] = ref
            row["designator"] = alias
    if any(count > 1 for count in seen.values()):
        occurrence = {}
        for raw in schematic["components"].values():
            props = _props(raw)
            ref = str(props.get("Designator", "")).strip()
            if not ref:
                continue
            occurrence[ref] = occurrence.get(ref, 0) + 1
            if occurrence[ref] > 1:
                props["Designator"] = aliases[(ref, occurrence[ref])]
                raw["props"] = props
    by_ref = {row["designator"]: row for row in rows}
    if pcb_path:
        pcb = _load(pcb_path)
        for raw in pcb["components"].values():
            row = _component_row(raw)
            if not row or row["designator"] not in by_ref:
                continue
            # Preserve PCB-only metadata without changing schematic roles.
            props = _props(raw)
            target = by_ref[row["designator"]]
            target["pcb_layer"] = str(props.get("PCB Layer", ""))
            target["pcb_x"] = props.get("X") or props.get("X Location")
            target["pcb_y"] = props.get("Y") or props.get("Y Location")
            target["pcb_angle"] = props.get("Rotation") or props.get("Angle")
    result = {
        "schema": "moduplace-topology-v1",
        "source": {
            "format": "enet",
            "schematic": str(schematic_path),
            "pcb": str(pcb_path) if pcb_path else None,
            "project_id": schematic.get("projectId"),
        },
        "components": rows,
        "nets": _nets(schematic, aliases),
    }
    if bom_path:
        try:
            from .bom import attach_bom
        except ImportError:
            from bom import attach_bom
        result, _ = attach_bom(result, bom_path)
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description="Convert .enet export to normalized topology JSON")
    parser.add_argument("schematic", type=Path)
    parser.add_argument("--pcb", type=Path)
    parser.add_argument("--bom", type=Path,
                        help="optional XLSX BOM used to attach part and datasheet provenance")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    result = convert(args.schematic, args.pcb, args.bom)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
