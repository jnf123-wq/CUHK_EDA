"""Small local Tk GUI for trying the deterministic partitioner.

The GUI is intentionally thin: it loads the selected schematic, calls the
same algorithm-only ``run`` function as the CLI, writes the normal JSON/CSV/
Markdown artifacts, and renders the L2/L1 ownership in a table.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import threading
import traceback
from pathlib import Path

import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from .enet_to_topology import convert
from .l1_partition import run, validate_topology
from .reporting import write_reports


PROJECT_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_OUTPUT = PROJECT_ROOT / "outputs" / "gui_result.json"


def load_input(path: Path, pcb_path: Path | None = None):
    """Load either a schematic .enet or normalized topology JSON."""
    if path.suffix.lower() == ".enet":
        topology = convert(path, pcb_path)
    else:
        if pcb_path:
            raise ValueError("PCB .enet 只能与 schematic .enet 一起使用")
        topology = json.loads(path.read_text(encoding="utf-8-sig"))
    validate_topology(topology)
    return topology


def format_members(members):
    return ", ".join(str(member) for member in members)


class PartitionGUI:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("Partition 划分器 v0.1 — Algorithm-only")
        self.root.geometry("1120x720")
        self.root.minsize(900, 560)

        self.input_var = tk.StringVar()
        self.pcb_var = tk.StringVar()
        self.output_var = tk.StringVar(value=str(DEFAULT_OUTPUT))
        self.mode_var = tk.StringVar(value="hierarchical")
        self.status_var = tk.StringVar(value="请选择 schematic .enet 或拓扑 JSON 文件")
        self.summary_var = tk.StringVar(value="尚未运行")
        self.last_output_dir: Path | None = None

        self._build_style()
        self._build_layout()

    def _build_style(self):
        style = ttk.Style(self.root)
        try:
            style.theme_use("vista")
        except tk.TclError:
            pass
        style.configure("Title.TLabel", font=("Microsoft YaHei UI", 16, "bold"))
        style.configure("Hint.TLabel", foreground="#666666")
        style.configure("Status.TLabel", foreground="#14532d")

    def _build_layout(self):
        outer = ttk.Frame(self.root, padding=16)
        outer.pack(fill="both", expand=True)

        ttk.Label(outer, text="Partition 划分器", style="Title.TLabel").pack(anchor="w")
        ttk.Label(outer, text="纯算法试运行界面：L2 大器件域 + L1 细功能簇；不调用 LLM。",
                  style="Hint.TLabel").pack(anchor="w", pady=(2, 12))

        files = ttk.LabelFrame(outer, text="输入与输出", padding=10)
        files.pack(fill="x")
        self._path_row(files, 0, "输入文件", self.input_var, self._choose_input,
                       "选择 schematic .enet 或 normalized topology JSON")
        self._path_row(files, 1, "PCB 文件（可选）", self.pcb_var, self._choose_pcb,
                       "仅用于补充封装/坐标；必须与 schematic .enet 配套")
        self._path_row(files, 2, "输出 JSON", self.output_var, self._choose_output,
                       "同时生成 L1/L2 CSV、规则命中 CSV 和 Markdown 报告")

        controls = ttk.Frame(outer)
        controls.pack(fill="x", pady=10)
        ttk.Label(controls, text="划分模式").pack(side="left")
        ttk.Combobox(controls, textvariable=self.mode_var, state="readonly", width=16,
                     values=("hierarchical", "conservative")).pack(side="left", padx=(8, 18))
        self.run_button = ttk.Button(controls, text="开始运行", command=self._start_run)
        self.run_button.pack(side="left")
        self.open_button = ttk.Button(controls, text="打开输出目录", command=self._open_output_dir,
                                      state="disabled")
        self.open_button.pack(side="left", padx=8)
        ttk.Label(controls, textvariable=self.status_var, style="Status.TLabel").pack(side="left", padx=12)

        summary = ttk.LabelFrame(outer, text="运行摘要", padding=8)
        summary.pack(fill="x", pady=(0, 10))
        ttk.Label(summary, textvariable=self.summary_var).pack(anchor="w")

        notebook = ttk.Notebook(outer)
        notebook.pack(fill="both", expand=True)
        self.l2_tree = self._make_tree(notebook, "L2 大器件域")
        self.l1_tree = self._make_tree(notebook, "L1 细功能簇")
        self.log_text = tk.Text(notebook, wrap="none", height=8, state="disabled",
                                font=("Consolas", 10))
        notebook.add(self.l2_tree[0], text="L2 大器件域")
        notebook.add(self.l1_tree[0], text="L1 细功能簇")
        notebook.add(self.log_text, text="运行日志")

    @staticmethod
    def _path_row(parent, row, label, variable, command, hint):
        ttk.Label(parent, text=label, width=14).grid(row=row, column=0, sticky="w", pady=4)
        entry = ttk.Entry(parent, textvariable=variable)
        entry.grid(row=row, column=1, sticky="ew", padx=8, pady=4)
        ttk.Button(parent, text="浏览…", command=command, width=9).grid(row=row, column=2, pady=4)
        ttk.Label(parent, text=hint, style="Hint.TLabel").grid(row=row, column=3, sticky="w", padx=10)
        parent.columnconfigure(1, weight=1)

    @staticmethod
    def _make_tree(notebook, title):
        frame = ttk.Frame(notebook, padding=6)
        columns = ("id", "anchor", "members", "children", "reason")
        tree = ttk.Treeview(frame, columns=columns, show="headings")
        headings = {"id": "簇 ID", "anchor": "大器件根", "members": "成员",
                    "children": "包含的 L1 簇", "reason": "归属原因"}
        widths = {"id": 90, "anchor": 100, "members": 420, "children": 180, "reason": 260}
        for column in columns:
            tree.heading(column, text=headings[column])
            tree.column(column, width=widths[column], anchor="w")
        yscroll = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
        xscroll = ttk.Scrollbar(frame, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=yscroll.set, xscrollcommand=xscroll.set)
        tree.grid(row=0, column=0, sticky="nsew")
        yscroll.grid(row=0, column=1, sticky="ns")
        xscroll.grid(row=1, column=0, sticky="ew")
        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)
        return frame, tree

    def _choose_input(self):
        path = filedialog.askopenfilename(
            title="选择输入文件",
            filetypes=[("Schematic/Topology", "*.enet *.json"), ("所有文件", "*.*")],
        )
        if path:
            self.input_var.set(path)
            if Path(path).suffix.lower() != ".enet":
                self.pcb_var.set("")

    def _choose_pcb(self):
        path = filedialog.askopenfilename(
            title="选择 PCB .enet（可选）",
            filetypes=[("PCB .enet", "*.enet"), ("所有文件", "*.*")],
        )
        if path:
            self.pcb_var.set(path)

    def _choose_output(self):
        path = filedialog.asksaveasfilename(
            title="选择输出 JSON",
            defaultextension=".json",
            initialfile="gui_result.json",
            filetypes=[("JSON", "*.json"), ("所有文件", "*.*")],
        )
        if path:
            self.output_var.set(path)

    def _set_log(self, text, append=True):
        self.log_text.configure(state="normal")
        if not append:
            self.log_text.delete("1.0", "end")
        self.log_text.insert("end", text + "\n")
        self.log_text.see("end")
        self.log_text.configure(state="disabled")

    def _start_run(self):
        input_text = self.input_var.get().strip()
        output_text = self.output_var.get().strip()
        if not input_text:
            messagebox.showwarning("缺少输入", "请先选择 schematic .enet 或拓扑 JSON 文件。")
            return
        if not output_text:
            messagebox.showwarning("缺少输出", "请指定输出 JSON 路径。")
            return
        input_path = Path(input_text)
        output_path = Path(output_text)
        pcb_text = self.pcb_var.get().strip()
        pcb_path = Path(pcb_text) if pcb_text else None
        if not input_path.exists():
            messagebox.showerror("输入不存在", str(input_path))
            return
        if pcb_path and not pcb_path.exists():
            messagebox.showerror("PCB 文件不存在", str(pcb_path))
            return
        self.run_button.configure(state="disabled")
        self.open_button.configure(state="disabled")
        self.status_var.set("正在运行算法…")
        self.summary_var.set("处理中，请稍候…")
        self._set_log("开始运行：" + str(input_path), append=False)
        thread = threading.Thread(target=self._run_worker,
                                  args=(input_path, pcb_path, output_path, self.mode_var.get()),
                                  daemon=True)
        thread.start()

    def _run_worker(self, input_path, pcb_path, output_path, mode):
        try:
            topology = load_input(input_path, pcb_path)
            result = run(topology, partition_mode=mode)
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n",
                                   encoding="utf-8")
            reports = write_reports(result, output_path,
                                    fixed_runs=[result.get("partition", {}).get("l1_clusters", [])])
            self.root.after(0, self._run_finished, result, reports, output_path)
        except Exception as exc:  # surface the complete error in the GUI log
            detail = traceback.format_exc()
            self.root.after(0, self._run_failed, f"{exc}\n\n{detail}")

    def _run_finished(self, result, reports, output_path):
        partition = result.get("partition", {})
        components = result.get("component_metadata", [])
        l2_domains = partition.get("l2_domains", [])
        l1_clusters = partition.get("l1_clusters", [])
        self._fill_tree(self.l2_tree[1], l2_domains)
        self._fill_tree(self.l1_tree[1], l1_clusters)
        self.last_output_dir = output_path.parent
        self.open_button.configure(state="normal")
        self.run_button.configure(state="normal")
        self.status_var.set("运行完成（algorithm-only）")
        self.summary_var.set(
            f"器件 {len(components)} 个    L2 域 {len(l2_domains)} 个    "
            f"L1 簇 {len(l1_clusters)} 个    全局唯一归属：{partition.get('all_components_once')}"
        )
        self._set_log("运行完成。")
        self._set_log("JSON：" + str(output_path))
        for key in ("l2_csv", "l1_csv", "report"):
            if reports.get(key):
                self._set_log(key + "：" + str(reports[key]))

    def _run_failed(self, detail):
        self.run_button.configure(state="normal")
        self.status_var.set("运行失败")
        self.summary_var.set("运行失败，请查看运行日志。")
        self._set_log(detail)
        messagebox.showerror("运行失败", detail.split("\n", 1)[0])

    @staticmethod
    def _fill_tree(tree, rows):
        tree.delete(*tree.get_children())
        for row in rows:
            tree.insert("", "end", values=(
                row.get("id", ""), row.get("anchor") or "—",
                format_members(row.get("members", [])),
                ", ".join(row.get("children_l1", [])),
                row.get("assignment_reason") or row.get("reason") or row.get("function", ""),
            ))

    def _open_output_dir(self):
        if not self.last_output_dir:
            return
        path = str(self.last_output_dir)
        try:
            if sys.platform.startswith("win"):
                os.startfile(path)
            elif sys.platform == "darwin":
                subprocess.Popen(["open", path])
            else:
                subprocess.Popen(["xdg-open", path])
        except Exception as exc:
            messagebox.showerror("无法打开目录", str(exc))


def main():
    root = tk.Tk()
    PartitionGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()
