"""Canonical knowledge-base registry and append-only soft constraints."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
import re
from pathlib import Path

try:
    from .taxonomy import as_values, normalize_function, normalize_function_tags, normalize_roles
except ImportError:
    from taxonomy import as_values, normalize_function, normalize_function_tags, normalize_roles


ROOT = Path(__file__).parent
DEFAULT_MANIFEST = ROOT.parent / "knowledge_base" / "kb_manifest.json"


def load_manifest(path=None):
    manifest_path = Path(path) if path else DEFAULT_MANIFEST
    if not manifest_path.exists():
        raise FileNotFoundError(f"knowledge-base manifest not found: {manifest_path}")
    data = json.loads(manifest_path.read_text(encoding="utf-8"))
    if data.get("schema") != "partition-knowledge-base-v1":
        raise ValueError("unsupported knowledge-base manifest schema")
    data["_path"] = str(manifest_path.resolve())
    return data


def _resolve(manifest, value):
    path = Path(value)
    if not path.is_absolute():
        path = Path(manifest["_path"]).parent / path
    return path


def active_rules_path(path=None, manifest_path=None):
    if path:
        return Path(path)
    manifest = load_manifest(manifest_path)
    value = manifest["active_rules"]
    path = Path(value)
    if path.is_absolute():
        return path
    candidate = _resolve(manifest, value)
    if candidate.exists():
        return candidate
    package_candidate = ROOT / value
    return package_candidate if package_candidate.exists() else candidate


def dictionary_path(name, manifest_path=None):
    manifest = load_manifest(manifest_path)
    aliases = {"roles": "roles.json", "net_semantics": "net_semantics.json",
               "function_patterns": "function_patterns.json"}
    key = next((candidate for candidate, filename in aliases.items()
                if name in {candidate, filename}), name)
    value = manifest.get("dictionaries", {}).get(key, manifest.get("dictionaries", {}).get(name, name))
    path = Path(value)
    if path.is_absolute():
        return path
    candidate = _resolve(manifest, value)
    if candidate.exists():
        return candidate
    # A manifest may be copied to a run-specific directory solely to redirect
    # the append-only soft-constraint store. Keep canonical dictionaries
    # resolvable from the package directory in that case.
    package_candidate = ROOT / value
    return package_candidate if package_candidate.exists() else candidate


def soft_constraints_path(manifest_path=None):
    manifest = load_manifest(manifest_path)
    return _resolve(manifest, manifest.get("soft_constraints", "soft_constraints.jsonl"))


def file_sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def provenance(manifest_path=None, rules_path=None):
    manifest = load_manifest(manifest_path)
    selected_rules = active_rules_path(rules_path, manifest_path)
    return {
        "manifest": str(Path(manifest["_path"]).resolve()),
        "manifest_sha256": file_sha256(manifest["_path"]),
        "rules": str(selected_rules.resolve()),
        "rules_sha256": file_sha256(selected_rules),
        "version": manifest.get("version"),
    }


def project_id(topology, explicit=None):
    if explicit:
        return str(explicit)
    source = topology.get("source", {}) if isinstance(topology, dict) else {}
    if not isinstance(source, dict):
        source = {}
    for key in ("project", "name", "schematic"):
        value = source.get(key)
        if value:
            return Path(str(value)).stem
    return "anonymous-project"


def _confidence(value, default=0.0):
    try:
        return max(0.0, min(1.0, float(value)))
    except (TypeError, ValueError):
        return default


def _members(item):
    if not isinstance(item, dict):
        return []
    members = item.get("members")
    if members is None:
        members = [item.get("a"), item.get("b")]
    if not isinstance(members, (list, tuple)):
        return []
    return [str(x) for x in members if x]


def normalize_soft_constraints(annotation, topology, source_project=None):
    """Normalize LLM candidates into reviewable, deduplicable records.

    Besides the original designators, persist a compact role signature for
    each member.  Designators are useful for auditability, while signatures
    let a later project reuse the evidence when its reference names differ.
    """
    if not isinstance(annotation, dict):
        return []
    components = {c.get("designator"): c for c in topology.get("components", [])}
    refs = set(components)
    annotation_components = {
        row.get("ref"): row for row in annotation.get("components", [])
        if isinstance(row, dict) and row.get("ref")
    }

    def signature(ref):
        component = components.get(ref, {})
        row = annotation_components.get(ref, {})
        roles = row.get("roles", row.get("role", component.get("llm_roles", [])))
        raw_roles, canonical_roles = normalize_roles(roles)
        tags = row.get("function_tags", component.get("function_tags", []))
        raw_tags, canonical_tags = normalize_function_tags(tags)
        return {
            "kind": str(component.get("kind", "")),
            "roles": canonical_roles,
            "roles_raw": raw_roles,
            "function_tags": sorted(set(canonical_tags)),
            "function_tags_raw": raw_tags,
        }

    project = source_project or project_id(topology)
    records = []

    def add(item, kind="pair"):
        members = _members(item)
        if len(members) < 2 or any(member not in refs for member in members):
            return
        members = sorted(set(members))
        raw_function = str(item.get("function", item.get("function_type", "")))
        if not raw_function:
            raw_function = str(item.get("cluster_id", item.get("name", "")))
        function_type = normalize_function(raw_function)
        if function_type == "other":
            text = " ".join(str(item.get(key, "")) for key in
                             ("name", "reason", "evidence_source", "cluster_id")).lower()
            function_type = next((label for label, needles in (
                ("input_bypass", ("input_bypass", "input decoupl", "vin")),
                ("output_filter", ("output_filter", "output decoupl", "vout", "vbat")),
                ("feedback", ("feedback", "fb", "sense")),
                ("compensation", ("compensation", "comp", "soft_start")),
            ) if any(needle in text for needle in needles)), "other")
        relation = str(item.get("relation", "prefer_link"))
        if relation not in {"must_link", "prefer_link", "anchor_link", "candidate", "cannot_link"}:
            relation = "prefer_link"
        evidence = item.get("evidence", [])
        if not isinstance(evidence, list):
            evidence = [str(evidence)] if evidence else []
        record = {
            "schema": "partition-placement-rule-v1",
            "rule_id": "",
            "name": str(item.get("name", item.get("reason", "llm_candidate_rule"))),
            "status": "candidate",
            "when": item.get("when", {
                "role_pairs": [[sig.get("roles", [""])[0] if sig.get("roles") else "",
                                sig.get("roles", [""])[0] if sig.get("roles") else ""]
                               for sig in [signature(member) for member in members[:2]]],
                "shared_semantics": list(item.get("shared_semantics", [])),
            }),
            "weight": int(item.get("weight", round(100 * _confidence(item.get("confidence")), 0))),
            "evidence_level": "llm_candidate",
            "source_id": "SRC_LLM_CANDIDATE",
            "source_type": "llm_annotation",
            "counterexamples": list(item.get("counterexamples", [])),
            "schema_legacy": "partition-soft-constraint-v1",
            "constraint_id": "",
            "kind": kind,
            "project_id": project,
            "source_project": project,
            "l1_1_domain": item.get("l1_1_domain", item.get("domain", "")),
            "l1_1_domain_status": ("provided" if item.get("l1_1_domain", item.get("domain"))
                                   else "unresolved"),
            "l1_1_domain_local_id": item.get("l1_1_domain", item.get("domain")) or None,
            "l1_1_domain_key": None,
            "l1_1_domain_project": project,
            "l1_1_domain_source": "current_run" if project else None,
            "raw_function": raw_function,
            "function_type": function_type or "other",
            "evidence_nets": list(as_values(item.get("evidence_nets", item.get("shared_semantics", [])))),
            "review_status": str(item.get("review_status", "candidate")),
            "scope": str(item.get("scope", "project")),
            "relation": relation,
            "members": members,
            "member_signatures": [signature(member) for member in members],
            "confidence": _confidence(item.get("confidence")),
            "evidence": evidence,
            "evidence_source": str(item.get("evidence_source", item.get("source", "llm_realtime"))),
            "reason": str(item.get("reason", "")),
            "source": str(item.get("source", "llm_realtime")),
            "created_at": datetime.now(timezone.utc).isoformat(),
        }
        stable = {key: record[key] for key in
                  ("name", "when", "weight", "kind", "scope", "relation", "members", "member_signatures", "confidence",
                   "evidence", "evidence_source", "reason", "source")}
        record["constraint_id"] = "SC-" + hashlib.sha256(
            json.dumps(stable, ensure_ascii=False, sort_keys=True).encode("utf-8")
        ).hexdigest()[:16]
        records.append(record)

    for key in ("soft_links", "links", "candidate_links"):
        for item in annotation.get(key, []) or []:
            if isinstance(item, dict):
                add(item, "pair")
    for item in annotation.get("candidate_clusters", []) or []:
        if isinstance(item, dict):
            add(item, "cluster")
    return records


def load_soft_constraints(path=None, exclude_project=None):
    path = Path(path) if path else soft_constraints_path()
    if not path.exists():
        return []
    records = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        record = json.loads(line)
        if record.get("schema") not in {"partition-soft-constraint-v1", "partition-placement-rule-v1"}:
            continue
        if record.get("status") == "rejected":
            continue
        if exclude_project and record.get("scope") == "project" and record.get("project_id") == exclude_project:
            continue
        records.append(record)
    return records


REQUIRED_SOFT_FIELDS = (
    "source_project", "l1_1_domain", "function_type", "confidence",
    "evidence_nets", "review_status",
)


def audit_soft_constraint_schema(path=None):
    """Return a non-mutating completeness audit for the append-only store."""
    target = Path(path) if path else soft_constraints_path()
    findings = []
    records = []
    if not target.exists():
        return {"path": str(target.resolve()), "record_count": 0,
                "findings": ["missing_soft_constraint_store"], "pass": False}
    for line_number, line in enumerate(target.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        try:
            record = json.loads(line)
        except json.JSONDecodeError as exc:
            findings.append({"line": line_number, "error": f"invalid_json:{exc.msg}"})
            continue
        records.append(record)
        missing = [field for field in REQUIRED_SOFT_FIELDS
                   if field not in record or record[field] is None or
                   (isinstance(record[field], str) and not record[field].strip())]
        if missing:
            findings.append({"line": line_number, "constraint_id": record.get("constraint_id"),
                             "error": "missing_fields", "fields": missing})
        confidence = record.get("confidence")
        if confidence is not None and not 0 <= _confidence(confidence, -1) <= 1:
            findings.append({"line": line_number, "constraint_id": record.get("constraint_id"),
                             "error": "invalid_confidence"})
        if record.get("review_status") in {"deepseek_approved", "approved"} and not record.get("review_provider"):
            findings.append({"line": line_number, "constraint_id": record.get("constraint_id"),
                             "error": "approved_without_review_provider"})
    return {"path": str(target.resolve()), "record_count": len(records),
            "candidate_count": sum(r.get("status") == "candidate" for r in records),
            "approved_count": sum(r.get("review_status") in {"deepseek_approved", "approved"} for r in records),
            "findings": findings, "pass": not findings}


def summarize_soft_constraints(path=None):
    """Summarize the append-only store for review dashboards and audits."""
    target = Path(path) if path else soft_constraints_path()
    rows = []
    if target.exists():
        rows = [json.loads(line) for line in target.read_text(encoding="utf-8").splitlines() if line.strip()]
    by_function = {}
    by_status = {}
    by_kind = {}
    for row in rows:
        function = str(row.get("function_type") or "other")
        status = str(row.get("review_status") or "candidate")
        kind = str(row.get("kind") or "unknown")
        by_function[function] = by_function.get(function, 0) + 1
        by_status[status] = by_status.get(status, 0) + 1
        by_kind[kind] = by_kind.get(kind, 0) + 1
    return {"total": len(rows), "by_function": dict(sorted(by_function.items())),
            "by_review_status": dict(sorted(by_status.items())),
            "by_kind": dict(sorted(by_kind.items())),
            "promotable_pair_candidates": sum(
                row.get("kind") == "pair" and row.get("review_status") in {"deepseek_approved", "approved"}
                for row in rows)}


def normalize_stored_soft_constraints(path=None):
    """Backfill the current audit fields on legacy JSONL records.

    This is a schema migration only: it preserves candidate status and never
    promotes or rejects a record. Missing values are inferred only from the
    evidence already stored in the record.
    """
    target = Path(path) if path else soft_constraints_path()
    if not target.exists():
        return {"updated": 0, "path": str(target.resolve())}
    rows = []
    updated = 0
    semantic_tokens = ("VIN", "VOUT", "VBAT", "BAT", "FB", "COMP", "BOOT", "SW", "SS", "VCC")
    function_tokens = (
        ("input_bypass", ("input bypass", "input_bypass", "input decoupl", "input_decoupl", "vin")),
        ("output_filter", ("output filter", "output_filter", "output decoupl", "output_decoupl", "vout", "vbat", "battery output")),
        ("feedback", ("feedback", "fb network", "fb resistor", "voltage divider", "sense resistor")),
        ("compensation", ("compensation", "comp network", "soft-start", "soft start")),
        ("bootstrap", ("bootstrap", "boot capacitor")),
        ("switching_loop", ("switching loop", "power stage", "inductor", "switch node")),
    )

    def infer_function(row):
        text = " ".join(str(row.get(key, "")) for key in ("name", "reason", "evidence_source", "evidence")).lower()
        for function, tokens in function_tokens:
            if any(token in text for token in tokens):
                return function
        roles = {str(role).lower() for sig in row.get("member_signatures", []) if isinstance(sig, dict) for role in sig.get("roles", [])}
        tags = {str(tag).lower() for sig in row.get("member_signatures", []) if isinstance(sig, dict) for tag in sig.get("function_tags", [])}
        if any("input_bypass" in role or "input_decoupl" in tag for role in roles for tag in tags):
            return "input_bypass"
        if any("output_filter" in role or "output_filter" in tag for role in roles for tag in tags):
            return "output_filter"
        if any("feedback" in role or "feedback" in tag for role in roles for tag in tags):
            return "feedback"
        if any("compensation" in role or "compensation" in tag for role in roles for tag in tags):
            return "compensation"
        return "other"

    def infer_nets(row):
        nets = set(str(value).upper() for value in row.get("evidence_nets", []) if value)
        evidence = row.get("evidence", [])
        if not isinstance(evidence, list):
            evidence = [evidence]
        for value in evidence:
            upper = str(value).upper()
            nets.update(token for token in semantic_tokens if token in upper)
            nets.update(re.findall(r"\b(?:\+?\d+(?:\.\d+)?V|BAT\+|VIN\d+|VOUT\d+)\b", upper))
        return sorted(nets)
    for line in target.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        row = json.loads(line)
        changed = False
        if not row.get("source_project") and row.get("project_id"):
            row["source_project"] = row["project_id"]
            changed = True
        if not row.get("l1_1_domain") or row.get("l1_1_domain") == "unknown":
            row["l1_1_domain"] = "unknown"
            changed = not row.get("l1_1_domain")
        if row.get("function_type") in (None, "", "other"):
            inferred = infer_function(row)
            if inferred != row.get("function_type"):
                row["function_type"] = inferred
                changed = True
        if not row.get("evidence_nets"):
            row["evidence_nets"] = infer_nets(row)
            changed = True
        if "review_status" not in row:
            row["review_status"] = "candidate"
            changed = True
        if changed:
            updated += 1
        rows.append(row)
    if updated:
        target.write_text("".join(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n" for row in rows), encoding="utf-8")
    return {"updated": updated, "path": str(target.resolve())}


def backfill_l1_1_domains(path=None, historical_results_dir=None):
    """Resolve legacy soft-constraint domains from historical run artifacts.

    Historical domain ids are local to a project.  The stored record keeps the
    local id for readability and adds a project-qualified key plus the exact
    result file used for the resolution.  A record is resolved only when all
    of its members occur in one historical L1-1 domain; missing, cross-domain,
    or unidentifiable history is explicitly marked as ``unresolved``.
    """
    target = Path(path) if path else soft_constraints_path()
    history_root = Path(historical_results_dir) if historical_results_dir else None
    if not target.exists():
        return {"updated": 0, "resolved": 0, "unresolved": 0,
                "ambiguous": 0, "path": str(target.resolve())}
    if history_root is None or not history_root.exists():
        return {"updated": 0, "resolved": 0, "unresolved": 0,
                "ambiguous": 0, "path": str(target.resolve()),
                "reason": "historical_results_dir_missing"}

    def tokens(value):
        return {token for token in re.findall(r"[a-z0-9]+", str(value).lower())
                if token not in {"run", "batch", "live", "llm", "learning",
                                 "source", "final", "hierarchical", "v2", "l1"}
                and not (token.isdigit() and len(token) >= 8)}

    def domains_from(payload):
        if not isinstance(payload, dict):
            return []
        partition = payload.get("partition")
        if not isinstance(partition, dict):
            partition = {}
        values = (partition.get("l1_1_domains") or partition.get("domains") or
                  payload.get("l1_1_domains") or payload.get("domains") or [])
        return [row for row in values if isinstance(row, dict) and row.get("members")]

    history = []
    for result_path in sorted(history_root.rglob("run_*.json")):
        try:
            payload = json.loads(result_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        domains = domains_from(payload)
        if not domains:
            continue
        knowledge = payload.get("knowledge_base", {})
        topology_source = payload.get("topology_source", {})
        project = (knowledge.get("project_id") if isinstance(knowledge, dict) else None)
        project = project or (topology_source.get("project_id")
                              if isinstance(topology_source, dict) else None)
        path_tokens = tokens(result_path.stem)
        project_tokens = tokens(project)
        history.append({"path": result_path, "project": str(project or ""),
                        "path_tokens": path_tokens, "project_tokens": project_tokens,
                        "domains": domains})

    def choose_history(source_project):
        source_tokens = tokens(source_project)
        ranked = []
        for entry in history:
            exact = bool(source_project and source_project == entry["project"])
            overlap = len(source_tokens & entry["path_tokens"])
            project_overlap = len(source_tokens & entry["project_tokens"])
            if exact or overlap or project_overlap:
                ranked.append((1 if exact else 0, overlap + project_overlap,
                               -len(str(entry["path"])), entry))
        if not ranked:
            return None
        ranked.sort(key=lambda value: value[:3], reverse=True)
        best = ranked[0]
        # A weak token match that ties multiple files is not safe to use.
        tied = [row for row in ranked
                if row[:2] == best[:2]]
        return best[3] if len(tied) == 1 else None

    rows = []
    updated = resolved = unresolved = ambiguous = 0
    for line in target.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        row = json.loads(line)
        source_project = str(row.get("source_project") or row.get("project_id") or "")
        current_domain = row.get("l1_1_domain")
        if current_domain and str(current_domain).lower() not in {"unknown", "unresolved"}:
            row.setdefault("l1_1_domain_status", "provided")
            rows.append(row)
            continue
        members = {str(value) for value in row.get("members", []) if value}
        entry = choose_history(source_project)
        matches = []
        if entry and members:
            for domain in entry["domains"]:
                domain_members = {str(value) for value in domain.get("members", []) if value}
                if members.issubset(domain_members):
                    matches.append(domain)
        if len(matches) == 1:
            local_id = str(matches[0].get("id") or "")
            row["l1_1_domain"] = local_id or "unresolved"
            row["l1_1_domain_local_id"] = local_id or None
            row["l1_1_domain_key"] = f"{source_project}::{local_id}" if local_id else None
            row["l1_1_domain_project"] = source_project or None
            row["l1_1_domain_source"] = str(entry["path"].resolve())
            row["l1_1_domain_status"] = "resolved_historical"
            row["l1_1_domain_resolution"] = "member_subset_match"
            resolved += 1
        else:
            if len(matches) > 1:
                ambiguous += 1
                reason = "members_match_multiple_domains"
            elif not entry:
                unresolved += 1
                reason = "historical_project_not_found"
            else:
                unresolved += 1
                reason = "members_not_in_one_historical_domain"
            row["l1_1_domain"] = "unresolved"
            row["l1_1_domain_local_id"] = None
            row["l1_1_domain_key"] = None
            row["l1_1_domain_project"] = source_project or None
            row["l1_1_domain_source"] = str(entry["path"].resolve()) if entry else None
            row["l1_1_domain_status"] = "unresolved"
            row["l1_1_domain_resolution"] = reason
        updated += 1
        rows.append(row)
    if updated:
        target.write_text("".join(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n"
                                     for row in rows), encoding="utf-8")
    return {"updated": updated, "resolved": resolved, "unresolved": unresolved,
            "ambiguous": ambiguous, "path": str(target.resolve()),
            "history_files": len(history)}


def append_soft_constraints(records, path=None):
    """Append only new records; existing evidence is never overwritten."""
    target = Path(path) if path else soft_constraints_path()
    if not records:
        return {"appended": 0, "skipped": 0, "path": str(target.resolve())}
    target.parent.mkdir(parents=True, exist_ok=True)
    existing = {json.loads(line).get("constraint_id") for line in target.read_text(encoding="utf-8").splitlines()
                if line.strip()} if target.exists() else set()
    fresh = [record for record in records if record.get("constraint_id") not in existing]
    if fresh:
        with target.open("a", encoding="utf-8", newline="\n") as handle:
            for record in fresh:
                handle.write(json.dumps(record, ensure_ascii=False, sort_keys=True) + "\n")
    return {"appended": len(fresh), "skipped": len(records) - len(fresh), "path": str(target.resolve())}


def update_soft_constraint_reviews(records, path=None):
    """Persist DeepSeek review fields by constraint_id without losing history."""
    target = Path(path) if path else soft_constraints_path()
    if not target.exists() or not records:
        return {"updated": 0, "path": str(target.resolve())}
    updates = {row.get("constraint_id"): row for row in records if row.get("constraint_id")}
    rows = []
    updated = 0
    for line in target.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        row = json.loads(line)
        replacement = updates.get(row.get("constraint_id"))
        if replacement:
            for key in ("review_provider", "review_status", "review_confidence", "review_reason"):
                if key in replacement:
                    row[key] = replacement[key]
            updated += 1
        rows.append(row)
    target.write_text("".join(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n" for row in rows), encoding="utf-8")
    return {"updated": updated, "path": str(target.resolve())}


def promote_high_confidence(records, rules_path, *, threshold=0.92, provider="deepseek"):
    """Promote only explicitly DeepSeek-reviewed high-confidence candidates.

    Promotion is append-only and conflict-aware: conflicting role/semantic
    rules remain candidates and are reported instead of altering hard rules.
    """
    rules_file = Path(rules_path)
    data = json.loads(rules_file.read_text(encoding="utf-8"))
    rules = data.setdefault("rules", [])
    existing = {rule.get("constraint_id") or rule.get("rule_id") for rule in rules}
    promoted, conflicts = [], []
    for record in records or []:
        if record.get("review_status") not in {"deepseek_approved", "approved"}:
            continue
        if record.get("kind") not in {None, "pair"}:
            continue
        review_confidence = _confidence(record.get("review_confidence", record.get("confidence")))
        if record.get("review_provider") != provider or review_confidence < threshold:
            continue
        cid = record.get("constraint_id")
        if cid in existing:
            continue
        members = record.get("members", [])
        if len(members) < 2:
            continue
        rule = {
            "rule_id": "AUTO-" + str(cid or hashlib.sha256(json.dumps(record, sort_keys=True).encode()).hexdigest()[:12]),
            "constraint_id": cid,
            "name": record.get("name", "deepseek_reviewed_soft_constraint"),
            "status": "approved",
            "when": record.get("when", {}),
            "relation": record.get("relation", "prefer_link"),
            "weight": int(record.get("weight", round(100 * review_confidence))),
            "evidence_level": "deepseek_reviewed",
            "source_type": "deepseek_promotion",
            "reason": record.get("reason", ""),
            "source_project": record.get("source_project", record.get("project_id", "")),
            "l1_1_domain": record.get("l1_1_domain", "unknown"),
            "function_type": record.get("function_type", "other"),
            "evidence_nets": record.get("evidence_nets", []),
            "confidence": review_confidence,
            "review_provider": record.get("review_provider"),
            "review_status": record.get("review_status"),
        }
        candidate_roles = {str(role) for pair in rule.get("when", {}).get("role_pairs", [])
                           if isinstance(pair, list) for role in pair}
        candidate_semantics = set(rule.get("when", {}).get("shared_semantics", []))
        contradictory = []
        for old in rules:
            if old.get("status") != "approved":
                continue
            old_when = old.get("when", {})
            old_roles = {str(role) for pair in old_when.get("role_pairs", [])
                         if isinstance(pair, list) for role in pair}
            old_semantics = set(old_when.get("shared_semantics", []))
            same_scope = bool(candidate_roles & old_roles) and (
                not candidate_semantics or not old_semantics or bool(candidate_semantics & old_semantics))
            same_scope = same_scope and old.get("function_type", rule["function_type"]) == rule["function_type"]
            incompatible = {"must_link", "cannot_link"}
            contradictory_relation = (
                old.get("relation") != rule["relation"] and
                (old.get("relation") in incompatible or rule["relation"] in incompatible)
            )
            if same_scope and contradictory_relation:
                contradictory.append(old.get("rule_id"))
        if contradictory:
            conflicts.append({"constraint_id": cid, "reason": "approved_rule_conflict",
                              "conflicting_rule_ids": contradictory})
            continue
        rules.append(rule); existing.add(cid); promoted.append(rule["rule_id"])
    if promoted:
        rules_file.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return {"promoted": promoted, "conflicts": conflicts, "path": str(rules_file.resolve())}
