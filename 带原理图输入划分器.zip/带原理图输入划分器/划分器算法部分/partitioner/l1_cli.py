"""Run the v1 L1 knowledge base on any normalized topology JSON."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

try:
    from .l1_partition import run, validate_topology
except ImportError:
    from l1_partition import run, validate_topology

try:
    from .reporting import write_reports
except ImportError:
    from reporting import write_reports


def main(argv=None):
    parser = argparse.ArgumentParser(description="Generate auditable L1 functional-cluster candidates")
    parser.add_argument("topology", type=Path,
                        help="moduplace-topology-v1 JSON or schematic .enet export")
    parser.add_argument("--pcb-enet", type=Path,
                        help="optional matching PCB .enet used only to enrich physical metadata")
    parser.add_argument("--output", type=Path)
    parser.add_argument("--overrides", type=Path, help="JSON object mapping ref to explicit role list")
    parser.add_argument("--semantic-overrides", type=Path,
                        help="JSON object mapping net name to explicit semantic list")
    parser.add_argument("--annotation", type=Path,
                        help="deprecated compatibility option; ignored in algorithm-only mode")
    parser.add_argument("--rules", type=Path,
                        help="optional placement rule snapshot; omitted uses the active knowledge-base version")
    parser.add_argument("--knowledge-base", type=Path,
                        help="knowledge-base manifest (default: knowledge_base.json)")
    parser.add_argument("--partition-mode", choices=("hierarchical", "conservative"), default="hierarchical",
                        help="hierarchical two-level selector (default) or legacy conservative hard partition")
    parser.add_argument("--learn-soft-constraints", action="store_true",
                        help="deprecated compatibility option; ignored in algorithm-only mode")
    parser.add_argument("--deepseek-promote", action="store_true",
                        help="deprecated compatibility option; ignored in algorithm-only mode")
    parser.add_argument("--project-id", help="stable project id used for soft-constraint scoping and leakage prevention")
    parser.add_argument("--deepseek", action="store_true",
                        help="deprecated compatibility option; DeepSeek is disabled")
    parser.add_argument("--model", help="deprecated compatibility option; ignored")
    parser.add_argument("--base-url", help="deprecated compatibility option; ignored")
    parser.add_argument("--bom", type=Path,
                        help="XLSX BOM with optional datasheet paths; default auto-matches the project")
    parser.add_argument("--bom-root", type=Path,
                        help="root directory searched for a matching assembly/BOM_*.xlsx")
    parser.add_argument("--single-stage-llm", action="store_true",
                        help="deprecated compatibility option; ignored")
    parser.add_argument("--datasheet-timeout", type=int, default=30,
                        help="seconds allowed for each BOM datasheet source")
    parser.add_argument("--algorithm-repeats", type=int, default=3,
                        help="repeat Partition with the same annotation for deterministic stability")
    parser.add_argument("--reference", type=Path,
                        help="human reference JSON containing {clusters:[{members:[...]}]} for ARI evaluation")
    parser.add_argument("--llm-repeats", type=int, default=0,
                        help="deprecated compatibility option; ignored")
    parser.add_argument("--llm-timeout", type=int, default=None,
                        help="deprecated compatibility option; ignored")
    args = parser.parse_args(argv)
    reference = (json.loads(args.reference.read_text(encoding="utf-8"))
                 if args.reference else None)
    overrides = json.loads(args.overrides.read_text(encoding="utf-8")) if args.overrides else None
    semantic_overrides = (json.loads(args.semantic_overrides.read_text(encoding="utf-8"))
                          if args.semantic_overrides else None)
    # Attach BOM metadata before either annotation or local inference.  A BOM
    # is optional; missing/ambiguous matches are recorded for REVIEW.
    if args.topology.suffix.lower() == ".enet":
        try:
            from .enet_to_topology import convert as convert_enet
        except ImportError:
            from enet_to_topology import convert as convert_enet
        topology_for_run = convert_enet(args.topology, args.pcb_enet, args.bom)
    else:
        if args.pcb_enet:
            parser.error("--pcb-enet is only valid when the input is a schematic .enet")
        topology_for_run = json.loads(args.topology.read_text(encoding="utf-8"))
    bom_info = {"status": "not_provided", "path": "", "records": 0, "matched": 0}
    existing_source = topology_for_run.get("source", {})
    # Older normalized topology exports used a short source label instead of
    # the structured provenance object emitted by enet_to_topology. Normalize
    # that legacy form before reading optional BOM/schematic fields.
    if isinstance(existing_source, str):
        existing_source = {"format": existing_source}
        topology_for_run["source"] = existing_source
    elif not isinstance(existing_source, dict):
        existing_source = {}
        topology_for_run["source"] = existing_source
    # Canonicalize pcb/layout endpoint aliases before datasheet lookup or the
    # DeepSeek prompt.  The later Partition call also validates this contract,
    # but annotation quality must see the same connectivity graph.
    validate_topology(topology_for_run)
    existing_bom = existing_source.get("bom")
    if args.bom or args.bom_root or existing_bom or existing_source.get("schematic"):
        try:
            from .bom import attach_bom, find_bom_for_schematic
        except ImportError:
            from bom import attach_bom, find_bom_for_schematic
        bom_path = args.bom or (Path(existing_bom) if existing_bom else None) or find_bom_for_schematic(
            topology_for_run.get("source", {}).get("schematic", ""), args.bom_root)
        if bom_path:
            # ``enet_to_topology --bom`` may have already attached this exact
            # workbook. Preserve its match counts instead of replacing valid
            # provenance with a failed secondary search result.
            if (existing_bom and Path(bom_path).resolve() == Path(existing_bom).resolve()
                    and existing_source.get("bom_records") is not None):
                bom_info = {
                    "status": "ok",
                    "records": existing_source.get("bom_records", 0),
                    "matched": existing_source.get("bom_matched_components", 0),
                    "path": str(Path(existing_bom).resolve()),
                    "match_rate": existing_source.get("bom_match_rate", 0.0),
                }
            else:
                topology_for_run, bom_info = attach_bom(topology_for_run, bom_path)
        else:
            bom_info["status"] = "not_found"
    if bom_info.get("status") != "not_provided":
        topology_for_run.setdefault("source", {})["bom_resolution"] = bom_info
    # Model annotation and datasheet fetching are deliberately not part of the
    # execution path.  Keep the legacy flags accepted so old scripts fail soft,
    # but never let them alter the deterministic algorithm.
    annotation_path = None
    annotation_output = None
    llm_partition_runs = []
    run_kwargs = {"partition_mode": args.partition_mode, "knowledge_base_path": args.knowledge_base,
                  "learn_soft_constraints": args.learn_soft_constraints, "project_id": args.project_id}
    result = run(topology_for_run, overrides, semantic_overrides, annotation_path, args.rules, **run_kwargs)
    promotion_result = None
    # ``--deepseek-promote`` is retained only as a no-op compatibility flag.
    result.setdefault("input_provenance", {})["bom"] = bom_info
    # Same annotation, repeated algorithm runs isolate deterministic Partition
    # stability from model variability.
    fixed_runs = [result]
    for _ in range(max(0, args.algorithm_repeats - 1)):
        fixed_runs.append(run(topology_for_run, overrides, semantic_overrides, annotation_path, args.rules, **run_kwargs))
    text = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text, encoding="utf-8")
        reports = write_reports(result, args.output,
                                fixed_runs=[x.get("partition", {}).get("l1_clusters", x.get("partition", {}).get("clusters", [])) for x in fixed_runs],
                                llm_runs=llm_partition_runs, reference=reference)
        print("两层功能分区完成。输出文件：")
        print(f"- JSON: {args.output}")
        print("- 模式: algorithm_only（不调用 LLM，不读取 LLM 标注或软先验）")
        print(f"- 簇明细 CSV: {reports['clusters_csv']}")
        print(f"- L1 CSV: {reports['l1_csv']}")
        print(f"- L2 CSV: {reports['l2_csv']}")
        print(f"- 规则命中 CSV: {reports['rule_hits_csv']}")
        print(f"- 数据手册追踪 CSV: {reports['datasheet_trace_csv']}")
        if reports.get("intermediate_csv"):
            print(f"- LLM 中间表示 CSV: {reports['intermediate_csv']}")
        print(f"- 质量/稳定性 CSV: {reports['quality_stability_csv']}")
        print(f"- 总结报告: {reports['report']}")
    else:
        print(text, end="")


if __name__ == "__main__":
    main()
