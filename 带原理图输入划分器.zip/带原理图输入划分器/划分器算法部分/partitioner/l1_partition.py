"""Executable first-pass L1 functional clustering for normalized .enet data.

The model is deliberately conservative: only reviewed hard relations collapse
components.  Other evidence is scored as a preference and the final output
always has exactly one cluster membership per component.
"""
from __future__ import annotations

import json
import re
from pathlib import Path
from collections import defaultdict

try:
    from .taxonomy import (ROLE_ALIASES as TAXONOMY_ROLE_ALIASES,
                           annotation_component_fields, as_values,
                           compatible_tag, normalize_function,
                           normalize_function_tags, normalize_role,
                           normalize_roles, tag_functions)
except ImportError:
    from taxonomy import (ROLE_ALIASES as TAXONOMY_ROLE_ALIASES,
                          annotation_component_fields, as_values,
                          compatible_tag, normalize_function,
                          normalize_function_tags, normalize_role,
                          normalize_roles, tag_functions)

ROOT = Path(__file__).parent

try:
    from .knowledge_base import (active_rules_path, dictionary_path, load_manifest,
                                  load_soft_constraints, normalize_soft_constraints,
                                  append_soft_constraints, project_id as infer_project_id,
                                  update_soft_constraint_reviews, promote_high_confidence,
                                  provenance as knowledge_provenance)
except ImportError:
    from knowledge_base import (active_rules_path, dictionary_path, load_manifest,
                                load_soft_constraints, normalize_soft_constraints,
                                append_soft_constraints, project_id as infer_project_id,
                                provenance as knowledge_provenance)


def validate_topology(topology):
    """Validate the minimal normalized topology contract before inference."""
    if isinstance(topology, dict) and topology.get("schema") == "pcb-topology-v1":
        topology["schema"] = "moduplace-topology-v1"
        for component in topology.get("components", []):
            if "designator" not in component and "ref" in component:
                component["designator"] = component.pop("ref")
    # Layout-derived exports may retain designator/pad endpoint names even
    # after their schema has been upgraded.  Canonicalize them before either
    # LLM annotation or local inference consumes the topology.
    for endpoints in topology.get("nets", {}).values() if isinstance(topology, dict) else []:
        for endpoint in endpoints:
            if "c" not in endpoint:
                ref = endpoint.get("designator", endpoint.get("ref"))
                if ref is not None:
                    endpoint["c"] = ref
            if "name" not in endpoint and "pad" in endpoint:
                endpoint["name"] = endpoint["pad"]
    if not isinstance(topology, dict) or topology.get("schema") != "moduplace-topology-v1":
        raise ValueError("topology schema must be moduplace-topology-v1")
    components = topology.get("components")
    nets = topology.get("nets")
    if not isinstance(components, list) or not isinstance(nets, dict):
        raise ValueError("topology must contain components[] and nets{}")
    refs = [c.get("designator") for c in components if isinstance(c, dict)]
    if any(not ref for ref in refs) or len(set(refs)) != len(refs):
        raise ValueError("components must have unique non-empty designators")
    ref_set = set(refs)
    for net, endpoints in nets.items():
        if not isinstance(endpoints, list):
            raise ValueError(f"net {net!r} endpoints must be a list")
        for endpoint in endpoints:
            if not isinstance(endpoint, dict) or endpoint.get("c") not in ref_set:
                raise ValueError(f"net {net!r} contains an endpoint for an unknown component")
    return True


def validate_llm_annotation(annotation, topology):
    """Validate the separate LLM annotation consumed by Partition."""
    if not isinstance(annotation, dict) or annotation.get("schema") != "llm-annotation-v1":
        raise ValueError("annotation schema must be llm-annotation-v1")
    refs = {c["designator"] for c in topology["components"]}
    rows = annotation.get("components")
    nets = annotation.get("nets")
    if not isinstance(rows, list) or not isinstance(nets, dict):
        raise ValueError("annotation must contain components[] and nets{}")
    seen = set()
    for row in rows:
        ref = row.get("ref") if isinstance(row, dict) else None
        if not ref or ref not in refs or ref in seen:
            raise ValueError(f"annotation component ref is unknown or duplicated: {ref}")
        seen.add(ref)
        if not isinstance(row.get("roles", row.get("role", [])), (list, str)):
            raise ValueError(f"annotation component {ref} roles must be a list or string")
        if not isinstance(row.get("function_tags", []), list):
            raise ValueError(f"annotation component {ref} function_tags must be a list")
        if "phase_id" in row and row["phase_id"] is not None and not isinstance(row["phase_id"], str):
            raise ValueError(f"annotation component {ref} phase_id must be a string or null")
    if seen != refs:
        raise ValueError("annotation must label every topology component exactly once")
    if set(nets) != set(topology["nets"]):
        raise ValueError("annotation nets must cover exactly the topology nets")
    for name, row in nets.items():
        if not isinstance(row, dict) or not isinstance(row.get("semantics", []), list):
            raise ValueError(f"annotation net {name!r} must contain semantics[]")
        if not isinstance(row.get("connections"), list):
            raise ValueError(f"annotation net {name!r} must contain connections[]")
        for endpoint in row.get("connections", []):
            if not isinstance(endpoint, dict) or endpoint.get("ref") not in refs:
                raise ValueError(f"annotation net {name!r} contains an unknown ref")
    for key in ("soft_links", "candidate_clusters", "datasheet_facts"):
        value = annotation.get(key, [])
        if not isinstance(value, list):
            raise ValueError(f"annotation {key} must be a list")
    for index, item in enumerate(annotation.get("soft_links", []) or []):
        if not isinstance(item, dict):
            raise ValueError(f"annotation soft_links[{index}] must be an object")
        members = item.get("members") or [item.get("a"), item.get("b")]
        if not isinstance(members, list) or len([x for x in members if x]) < 2:
            raise ValueError(f"annotation soft_links[{index}] must contain at least two refs")
        if any(ref not in refs for ref in members if ref):
            raise ValueError(f"annotation soft_links[{index}] contains an unknown ref")
    for index, item in enumerate(annotation.get("candidate_clusters", []) or []):
        if not isinstance(item, dict) or not isinstance(item.get("members"), list):
            raise ValueError(f"annotation candidate_clusters[{index}] must contain members[]")
        if len(item["members"]) < 2 or any(ref not in refs for ref in item["members"]):
            raise ValueError(f"annotation candidate_clusters[{index}] contains an unknown or incomplete ref set")
    return True


def annotation_quality(annotation):
    """Return blocking quality findings for an LLM annotation draft."""
    findings = []
    empty_roles = [r["ref"] for r in annotation["components"]
                   if not r.get("roles", r.get("role", []))]
    empty_tags = [r["ref"] for r in annotation["components"]
                  if not r.get("function_tags")]
    empty_semantics = [n for n, r in annotation["nets"].items()
                       if not r.get("semantics")]
    empty_connections = [n for n, r in annotation["nets"].items() if not r.get("connections")]
    if empty_roles:
        findings.append({"type": "missing_roles", "refs": empty_roles})
    if empty_tags:
        findings.append({"type": "missing_function_tags", "refs": empty_tags})
    if empty_semantics:
        findings.append({"type": "missing_net_semantics", "nets": empty_semantics})
    if empty_connections:
        findings.append({"type": "missing_connections", "nets": empty_connections})
    return findings


def annotation_warnings(annotation):
    warnings = []
    unknown_roles = [r["ref"] for r in annotation["components"]
                     if "unknown_component" in (r.get("roles") or r.get("role") or [])]
    unknown_nets = [n for n, r in annotation["nets"].items() if "UNKNOWN" in r.get("semantics", [])]
    if unknown_roles:
        warnings.append({"type": "unclassified_components", "refs": unknown_roles})
    if unknown_nets:
        warnings.append({"type": "unknown_net_semantics", "nets": unknown_nets})
    return warnings


def apply_llm_annotation(topology, annotation):
    validate_llm_annotation(annotation, topology)
    rows = {row["ref"]: row for row in annotation["components"]}
    enriched = json.loads(json.dumps(topology))
    for comp in enriched["components"]:
        row = rows[comp["designator"]]
        roles = row.get("roles", row.get("role", []))
        if isinstance(roles, str):
            roles = [roles]
        normalized_fields = annotation_component_fields(row)
        comp["llm_roles"] = list(roles)
        comp.update(normalized_fields)
        comp["function_tags"] = list(row.get("function_tags", []))
        comp["llm_confidence"] = row.get("confidence")
        comp["llm_evidence"] = row.get("evidence", [])
        comp["phase_id"] = row.get("phase_id")
    # The LLM annotation is the consumed connection graph.  Keep the original
    # topology only as the structural contract and metadata source.
    enriched["nets"] = {
        name: [{"c": ep["ref"], "name": ep.get("pin", ep.get("name", ""))}
               for ep in row["connections"]]
        for name, row in annotation["nets"].items()
    }
    semantics = {name: list(row.get("semantics", ["UNKNOWN"])) for name, row in annotation["nets"].items()}
    evidence = {
        name: [{"semantic": semantic, "source": "llm_annotation",
                "confidence": row.get("confidence"),
                "evidence": row.get("evidence", [])}
               for semantic in semantics[name]]
        for name, row in annotation["nets"].items()
    }
    return enriched, semantics, evidence


def load_json(name, manifest_path=None):
    """Load a dictionary through the active knowledge-base manifest."""
    path = dictionary_path(name, manifest_path)
    return json.loads(path.read_text(encoding="utf-8"))


def load_placement_rules(path=None, manifest_path=None):
    """Load the selected rule snapshot; omitted paths use the active manifest."""
    source = active_rules_path(path, manifest_path)
    return json.loads(source.read_text(encoding="utf-8"))


def load_buck_rule_semantics():
    """Load approved BUCK-specific semantics without changing the base rule schema."""
    path = ROOT / "buck_approved_rule_semantics.json"
    return json.loads(path.read_text(encoding="utf-8")) if path.exists() else {"rules": []}


def net_semantics(topology, overrides=None, manifest_path=None):
    patterns = load_json("net_semantics.json", manifest_path)["patterns"]
    result = {}
    overrides = overrides or {}
    for name, pins in topology["nets"].items():
        if name in overrides:
            result[name] = list(overrides[name])
            continue
        upper = str(name).upper()
        matches = [p["semantic"] for p in patterns if re.search(p["regex"], upper)]
        if not matches:
            pin_text = " ".join(str(p.get("name", "")) for p in pins).upper()
            pin_text += " " + " ".join(str(p.get("pin", "")) for p in pins).upper()
            aliases = [("BST", "BOOT"), ("BOOT", "BOOT"), ("VREG", "VCC"),
                       ("VREF", "VCC"), ("REF", "VCC"), ("FB", "FB"),
                       ("SS", "SS"), ("MODE", "MODE"), ("SW", "SW"),
                       ("VIN", "VIN"), ("VCC", "VCC"), ("PGND", "GND"),
                       ("AGND", "GND"), ("GND", "GND"), ("EN", "EN"),
                       ("VOUT", "VOUT"), ("PGOOD", "PGOOD")]
            matches = [v for needle, v in aliases if needle in pin_text]
        if not matches:
            result[name] = ["UNKNOWN"]
        else:
            # Keep the old list-of-semantic contract for callers while retaining
            # evidence in a parallel field added by `net_semantics_with_evidence`.
            result[name] = sorted(set(matches))
    return result


def net_semantics_with_evidence(topology, overrides=None, manifest_path=None):
    """Return semantic candidates plus their derivation source for review."""
    patterns = load_json("net_semantics.json", manifest_path)["patterns"]
    result = {}
    overrides = overrides or {}
    for name, pins in topology["nets"].items():
        if name in overrides:
            result[name] = [{"semantic": s, "source": "manual_override"} for s in overrides[name]]
            continue
        upper = str(name).upper()
        evidence = [{"semantic": p["semantic"], "source": "name_regex", "pattern": p["regex"]}
                    for p in patterns if re.search(p["regex"], upper)]
        if not evidence:
            pin_text = " ".join(str(p.get("name", "")) for p in pins).upper()
            pin_text += " " + " ".join(str(p.get("pin", "")) for p in pins).upper()
            aliases = [("BST", "BOOT"), ("BOOT", "BOOT"), ("VREG", "VCC"),
                       ("VREF", "VCC"), ("REF", "VCC"), ("FB", "FB"),
                       ("SS", "SS"), ("MODE", "MODE"), ("SW", "SW"),
                       ("VIN", "VIN"), ("VCC", "VCC"), ("PGND", "GND"),
                       ("AGND", "GND"), ("GND", "GND"), ("EN", "EN"),
                       ("VOUT", "VOUT"), ("PGOOD", "PGOOD")]
            evidence = [{"semantic": value, "source": "pin_name", "needle": needle}
                        for needle, value in aliases if needle in pin_text]
        result[name] = evidence or [{"semantic": "UNKNOWN", "source": "fallback"}]
    return result


def classify_unknown_nets(topology, semantic_evidence=None):
    """Classify unresolved nets using only topology and semantic evidence.

    This is diagnostic metadata; it never changes semantic labels or partition
    decisions.  The categories distinguish an opaque autogenerated net from a
    net whose pin evidence was present but inconclusive, and from malformed or
    incomplete connectivity.
    """
    evidence = semantic_evidence or net_semantics_with_evidence(topology)
    component_kinds = {str(row.get("designator")): str(row.get("kind", ""))
                       for row in topology.get("components", []) if isinstance(row, dict)}
    result = {}
    for name, pins in topology.get("nets", {}).items():
        rows = evidence.get(name, []) or []
        semantics = {str(row.get("semantic", "")).upper() for row in rows if isinstance(row, dict)}
        if "UNKNOWN" not in semantics:
            continue
        endpoints = [pin for pin in (pins or []) if isinstance(pin, dict) and pin.get("c")]
        upper = str(name).upper()
        has_pin_evidence = any(str(pin.get("name", "")).strip()
                               and not str(pin.get("name", "")).strip().isdigit()
                               for pin in endpoints)
        autogenerated = bool(re.fullmatch(r"(?:\$?N\d+|NET\d+|N\d+)", upper))
        autogenerated = autogenerated or bool(re.fullmatch(r"\$\d+N\d+", upper))
        if len(endpoints) < 2:
            category = "fragmented_or_missing"
        elif has_pin_evidence:
            category = "pin_evidence_inconclusive"
        elif autogenerated:
            category = "autogenerated_no_evidence"
        else:
            category = "named_no_evidence"
        candidate_semantics = []
        if has_pin_evidence:
            pin_text = " ".join(str(pin.get("name", "")).upper() for pin in endpoints)
            aliases = [("VREG", "VCC"), ("VREF", "VCC"), ("REF", "VCC"),
                       ("FB", "FB"), ("SENSE", "FB"), ("VSENSE", "FB"),
                       ("COMP", "COMP"), ("SS", "SS"), ("SW", "SW"),
                       ("BOOT", "BOOT"), ("BST", "BOOT"), ("EN", "EN"),
                       ("ENABLE", "EN"), ("PGOOD", "PGOOD"), ("PG", "PGOOD")]
            candidate_semantics = sorted({value for needle, value in aliases if needle in pin_text})
        adjacent_kinds = sorted({component_kinds.get(str(pin.get("c")), "")
                                 for pin in endpoints if component_kinds.get(str(pin.get("c")), "")})
        result[name] = {"category": category, "endpoint_count": len(endpoints),
                        "autogenerated_name": autogenerated,
                        "pin_evidence": has_pin_evidence,
                        "candidate_semantics": candidate_semantics,
                        "adjacent_component_kinds": adjacent_kinds}
    return result


# Values accepted in candidate ``evidence_nets``.  Natural-language function
# descriptions belong in ``reason``/``evidence``; keeping them out of this
# field makes reports machine-checkable and prevents them being mistaken for
# topology nets on a later run.
_STANDARD_SEMANTICS = {
    "VIN", "VOUT", "VBAT", "BAT", "GND", "SW", "FB", "VSENSE",
    "COMP", "VCC", "BOOT", "SS", "EN", "MODE", "PGOOD", "PVIN",
}


def _filter_evidence_nets(topology, values):
    """Keep only actual net names or the stable semantic vocabulary."""
    actual = {str(name): str(name) for name in topology.get("nets", {})}
    actual_casefold = {name.casefold(): name for name in actual}
    filtered = []
    for value in as_values(values):
        text = str(value).strip()
        if not text:
            continue
        if text in actual:
            canonical = actual[text]
        elif text.casefold() in actual_casefold:
            canonical = actual_casefold[text.casefold()]
        elif text.upper() in _STANDARD_SEMANTICS:
            canonical = text.upper()
        else:
            continue
        if canonical not in filtered:
            filtered.append(canonical)
    return sorted(filtered)


def _semantic_values(values):
    """Normalize semantic labels while retaining their original spelling only in evidence."""
    result = []
    for value in as_values(values):
        text = str(value).strip()
        if not text:
            continue
        if text.upper() == "UNKNOWN":
            text = "UNKNOWN"
        if text not in result:
            result.append(text)
    return result


def _merge_semantics(topology, annotation_semantics, annotation_evidence,
                     local_semantics, local_evidence, manual_overrides=None):
    """Merge LLM, deterministic and manual net semantics by explicitness.

    An LLM ``UNKNOWN`` is an absence of evidence, so it never erases a local
    name/pin inference.  Explicit labels from both sources are retained; a
    manual override is authoritative for that net.
    """
    annotation_semantics = annotation_semantics or {}
    annotation_evidence = annotation_evidence or {}
    local_semantics = local_semantics or {}
    local_evidence = local_evidence or {}
    manual_overrides = manual_overrides or {}
    merged = {}
    evidence = {}

    def rows_for(source_rows, name, source):
        rows = []
        for row in source_rows.get(name, []) or []:
            if isinstance(row, dict):
                item = dict(row)
                item.setdefault("source", source)
                rows.append(item)
            elif row:
                rows.append({"semantic": str(row), "source": source})
        return rows

    for name in topology.get("nets", {}):
        if name in manual_overrides:
            values = _semantic_values(manual_overrides.get(name)) or ["UNKNOWN"]
            merged[name] = values
            evidence[name] = [{"semantic": value, "source": "manual_override"}
                              for value in values]
            continue
        annotation_values = _semantic_values(annotation_semantics.get(name, []))
        local_values = _semantic_values(local_semantics.get(name, []))
        explicit_annotation = [value for value in annotation_values if value != "UNKNOWN"]
        explicit_local = [value for value in local_values if value != "UNKNOWN"]
        values = list(dict.fromkeys(explicit_annotation + explicit_local))
        if not values:
            values = ["UNKNOWN"]
        merged[name] = values
        rows = rows_for(annotation_evidence, name, "llm_annotation")
        rows.extend(rows_for(local_evidence, name, "local_inference"))
        retained = {value.upper() for value in values}
        filtered_rows = [row for row in rows
                         if str(row.get("semantic", "")).upper() in retained]
        for value in values:
            if not any(str(row.get("semantic", "")).upper() == value.upper()
                       for row in filtered_rows):
                filtered_rows.append({"semantic": value, "source": "merged_fallback"})
        evidence[name] = filtered_rows
    return merged, evidence


def _component_nets(topology):
    out = defaultdict(list)
    for name, endpoints in topology["nets"].items():
        for endpoint in endpoints:
            out[endpoint["c"]].append(name)
    return out


def infer_roles(topology, semantics, overrides=None, use_llm_labels=False, manifest_path=None):
    """Return only roles whose every condition passes; overrides are explicit."""
    definitions = load_json("roles.json", manifest_path)["roles"]
    overrides = overrides or {}
    comp_nets = _component_nets(topology)
    by_ref = {c["designator"]: c for c in topology["components"]}
    rows = {}
    for ref, comp in by_ref.items():
        if ref in overrides:
            rows[ref] = {"roles": list(overrides[ref]),
                         "evidence": ["explicit_override"],
                         "function_tags": list(comp.get("function_tags", [])),
                         "semantics": sorted({s for n in comp_nets[ref] for s in semantics[n]})}
            continue
        if use_llm_labels:
            raw_roles, canonical_roles = normalize_roles(
                comp.get("llm_roles", comp.get("llm_roles_raw", [])))
            raw_tags, canonical_tags = normalize_function_tags(
                comp.get("function_tags", comp.get("function_tags_raw", [])))
            rows[ref] = {"roles": canonical_roles,
                         "roles_raw": raw_roles,
                         "function_tags": sorted(set(raw_tags) | set(canonical_tags)),
                         "canonical_function_tags": canonical_tags,
                         "phase_id": comp.get("phase_id"),
                         "confidence": comp.get("llm_confidence"),
                         "evidence": ["llm_annotation"] + list(comp.get("llm_evidence", [])),
                         "semantics": sorted({s for n in comp_nets[ref] for s in semantics[n]})}
            continue
        sems = {s for n in comp_nets[ref] for s in semantics[n]}
        connected = sems - {"GND", "UNKNOWN"}
        matched = []
        for role in definitions:
            if comp.get("kind") not in role.get("base_types", []):
                continue
            ok = True
            evidence = []
            for cond in role.get("conditions", []):
                typ, values = cond["type"], cond["values"]
                if typ == "has_net_semantics":
                    passed = all(v in sems for v in values)
                elif typ == "connected_to_semantics":
                    passed = any(v in connected for v in values)
                elif typ == "designator_prefix":
                    passed = any(ref.startswith(v) for v in values)
                elif typ == "part_name_any":
                    text = (comp.get("name", "") + " " + comp.get("value", "")).upper()
                    passed = any(v.upper() in text for v in values)
                else:
                    raise ValueError(f"unsupported role predicate: {typ}")
                if not passed:
                    ok = False
                    break
                evidence.append(f"{typ}:{','.join(values)}")
            if ok:
                matched.append((int(role.get("priority", 0)), role["role_id"], evidence))
        matched.sort(reverse=True)
        rows[ref] = {"roles": [x[1] for x in matched],
                     "evidence": [e for x in matched for e in x[2]],
                     "semantics": sorted(sems)}
    return rows


def match_rules(topology, semantics, roles, rules_path=None, manifest_path=None):
    """Evaluate pair rules using actual shared net identities and role evidence."""
    comp_nets = _component_nets(topology)
    rules = [r for r in load_placement_rules(rules_path, manifest_path)["rules"]
             if r.get("status", "candidate") in ("approved", "candidate")]
    hits = []
    refs = sorted(comp_nets)
    phases = {ref: next((c.get("phase_id") for c in topology["components"]
                         if c.get("designator") == ref), None) for ref in refs}
    # Component-level phase annotations are copied by apply_llm_annotation;
    # role override runs may carry them in the role table instead.
    for ref in refs:
        phases[ref] = phases[ref] or roles[ref].get("phase_id")
    for i, left in enumerate(refs):
        for right in refs[i + 1:]:
            shared = set(comp_nets[left]) & set(comp_nets[right])
            shared_sem = {s for n in shared for s in semantics[n]}
            # Normalize domain-specific controller names before applying the
            # reviewed placement rules.
            lr, rr = _canonical_roles(roles, left), _canonical_roles(roles, right)
            for rule in rules:
                when = rule.get("when", {})
                role_pairs = when.get("role_pairs") or [when.get("roles", [])]
                # Accept both the canonical pair form [[role_a, role_b], ...]
                # and the older flat form [role_a, role_b].
                if role_pairs and all(isinstance(value, str) for value in role_pairs):
                    role_pairs = [role_pairs]
                normalized_pairs = []
                for pair in role_pairs:
                    if (isinstance(pair, (list, tuple)) and len(pair) == 2
                            and all(isinstance(side, (list, tuple)) for side in pair)):
                        for left_role in pair[0]:
                            for right_role in pair[1]:
                                normalized_pairs.append([left_role, right_role])
                    elif isinstance(pair, (list, tuple)):
                        normalized_pairs.append(list(pair))
                role_pairs = normalized_pairs
                if not any(len(pair) == 2 and ((pair[0] in lr and pair[1] in rr) or
                                               (pair[1] in lr and pair[0] in rr)) for pair in role_pairs):
                    continue
                required = set(when.get("shared_semantics", []))
                # A semantic can be inferred from pin names, but a rule still
                # needs a physical common net.  For two-pin local motifs it is
                # sufficient that every requested semantic is represented by a
                # shared net; a controller's pin-side semantic may otherwise be
                # absent from the passive's net name.
                if required and not required.issubset(shared_sem):
                    continue
                if not shared:
                    continue
                # A phase annotation is a hard locality guard for phase-scoped
                # rules.  It prevents evidence from crossing multiphase lanes.
                if rule.get("phase_scoped") and phases[left] and phases[right] and phases[left] != phases[right]:
                    continue
                ambiguous_nets = sorted(n for n in shared if len(set(semantics[n]) - {"UNKNOWN"}) > 1)
                def _low_confidence(value):
                    try:
                        return value is not None and float(value) < 0.7
                    except (TypeError, ValueError):
                        return False
                low_confidence = _low_confidence(roles[left].get("confidence")) or \
                                 _low_confidence(roles[right].get("confidence"))
                unknown_role = "unknown_component" in lr or "unknown_component" in rr
                hits.append({"rule_id": rule["rule_id"], "a": left, "b": right,
                             "relation": rule["relation"], "weight": rule.get("weight", 1),
                             "status": rule.get("status", "candidate"),
                             "source_id": rule.get("source_id"),
                             "shared_nets": sorted(shared), "evidence": sorted(shared_sem),
                             "semantic_ambiguity": ambiguous_nets,
                             "review_required": bool(ambiguous_nets or low_confidence or unknown_role),
                             "review_reasons": (["semantic_ambiguity"] if ambiguous_nets else []) +
                                           (["low_role_confidence"] if low_confidence else []) +
                                           (["unknown_component_role"] if unknown_role else []),
                             "reason": rule.get("reason", rule.get("name", ""))})
    # Approved BUCK rules are represented as explainable evidence.  They are
    # deliberately not promoted to must_link unless the base rule snapshot
    # already says so.
    # Extensions are opt-in through the approved BUCK snapshot.  This keeps
    # the historical baseline deterministic and makes the rule version visible
    # in every CLI invocation.
    selected_name = Path(rules_path).name if rules_path else ""
    buck_rules = ({r["rule_id"]: r for r in load_buck_rule_semantics().get("rules", [])
                  if r.get("status") == "approved"}
                  if "buck_approved_with_new_rules" in selected_name else {})
    for rule_id, rule in buck_rules.items():
        if rule_id == "NEW-BUCK-001":
            bypass = [r for r in refs if "input_bypass_capacitor" in roles[r]["roles"]]
            for i, left in enumerate(bypass):
                for right in bypass[i + 1:]:
                    shared = set(comp_nets[left]) & set(comp_nets[right])
                    if shared and any("VIN" in semantics[n] for n in shared):
                        hits.append({"rule_id": rule_id, "a": left, "b": right,
                                     "relation": "must_link", "weight": 88, "status": "approved",
                                     "shared_nets": sorted(shared), "evidence": ["VIN"],
                                     "semantic_ambiguity": [], "review_required": False,
                                     "review_reasons": [], "reason": rule["reason"]})
        elif rule_id == "NEW-BUCK-002":
            for left in refs:
                for right in refs:
                    if left >= right: continue
                    lr, rr = _canonical_roles(roles, left), _canonical_roles(roles, right)
                    if not (("switching_controller" in lr and "power_rectifier_diode" in rr) or
                            ("switching_controller" in rr and "power_rectifier_diode" in lr) or
                            ("power_rectifier_diode" in lr and "power_inductor" in rr) or
                            ("power_rectifier_diode" in rr and "power_inductor" in lr)):
                        continue
                    shared = set(comp_nets[left]) & set(comp_nets[right])
                    if shared and any("SW" in semantics[n] for n in shared):
                        hits.append({"rule_id": rule_id, "a": left, "b": right,
                                     "relation": "anchor_link", "weight": 70, "status": "approved",
                                     "shared_nets": sorted(shared), "evidence": ["SW"],
                                     "semantic_ambiguity": [], "review_required": False,
                                     "review_reasons": [], "reason": rule["reason"]})
    return hits


def match_patterns(topology, semantics, roles, hits=None, manifest_path=None):
    """Build explainable local motifs from executable relation evidence.

    A pattern is a candidate functional motif; it does not imply that all
    motifs sharing an anchor must become one final cluster.
    """
    hits = hits or match_rules(topology, semantics, roles, manifest_path=manifest_path)
    patterns = load_json("function_patterns.json", manifest_path)["patterns"]
    by_pair = defaultdict(list)
    for hit in hits:
        by_pair[frozenset((hit["a"], hit["b"]))].append(hit)
    refs = sorted(roles)
    motifs = []
    for pattern in patterns:
        if pattern.get("pattern_id") == "buck_feedback":
            # The reviewed rules intentionally reject a generic controller-to-
            # feedback-resistor proximity rule (remote sensing is a counterexample).
            # Still expose the feedback-network motif when the actual FB net has
            # a controller endpoint and at least two feedback branch passives.
            feedback_roles = {"feedback_resistor", "feedforward_capacitor",
                              "feedback_capacitor", "compensation_resistor",
                              "compensation_capacitor"}
            comp_nets = _component_nets(topology)
            for anchor in refs:
                if "switching_controller" not in _canonical_roles(roles, anchor):
                    continue
                anchor_fb_nets = [name for name in comp_nets[anchor]
                                  if "FB" in semantics.get(name, [])]
                for net_name in anchor_fb_nets:
                    members = sorted(ref for ref in refs if ref != anchor
                                     and net_name in comp_nets[ref]
                                      and feedback_roles.intersection(_canonical_roles(roles, ref)))
                    if len(members) >= 2:
                        motifs.append({"pattern_id": "buck_feedback",
                                       "function": "feedback_network",
                                       "anchor": anchor, "members": members,
                                       "evidence": [],
                                       "evidence_source": "actual_fb_net_topology",
                                       "anchor_policy": "anchor_excluded"})
            continue
        required = set(pattern.get("required_roles", []))
        anchor_role = pattern.get("anchor_role")
        function = pattern.get("function", pattern["pattern_id"])
        for anchor in refs:
            if anchor_role not in _canonical_roles(roles, anchor):
                continue
            members = {anchor}
            evidence = []
            for other in refs:
                if other == anchor:
                    continue
                pair_hits = by_pair.get(frozenset((anchor, other)), [])
                for hit in pair_hits:
                    if hit["rule_id"] in _pattern_rule_ids(pattern):
                        members.add(other)
                        evidence.append(hit)
            member_roles = {role for ref in members for role in _canonical_roles(roles, ref)}
            # A common rail shared by multiple anchors is infrastructure, not
            # evidence that one controller owns the other's passive.  Require
            # each participating endpoint to have a channel-local net in
            # addition to the common semantic net.
            if anchor_role == "switching_controller" and pattern["pattern_id"] == "buck_input_bypass":
                anchor_vin = {n for n in _component_nets(topology)[anchor] if "VIN" in semantics[n]}
                if any(len([n for n in _component_nets(topology)[m] if "VIN" in semantics[n]]) != 1 for m in members if m != anchor):
                    continue
                if any(sum(1 for ep in topology["nets"][n]
                           if ep["c"] in refs and ep["c"] != anchor
                           and "switching_controller" in _canonical_roles(roles, ep["c"])) > 0
                           for n in anchor_vin):
                    continue
            if required.issubset(member_roles) and len(members) > 1:
                motifs.append({"pattern_id": pattern["pattern_id"], "function": function,
                               "anchor": anchor, "members": sorted(members),
                               "evidence": evidence})
    return motifs


def _pattern_rule_ids(pattern):
    """Map a pattern relation to the rule families it is allowed to use."""
    relation = pattern.get("relation", "")
    if "VIN" in relation:
        return {"R001"}
    if "power_input_path" in relation:
        return {"R014"}
    if "VOUT" in relation:
        return {"R002"}
    if "VBAT" in relation:
        # Battery-rail output filtering is candidate-only and must not reuse
        # the reviewed VOUT hard-link family.
        return {"R016"}
    if "FB" in relation and "feedforward" not in pattern.get("pattern_id", ""):
        # R003 is deliberately rejected in the canonical reviewed snapshot.
        # Feedback motifs are built from the actual FB net below, so a rejected
        # controller-to-resistor rule must not be used as executable evidence.
        return set()
    if "COMP" in relation:
        return {"R004"}
    if "BOOT" in relation:
        return {"R006"}
    if "SW" in relation:
        return {"R007"}
    if "SS" in relation:
        return {"R008"}
    if "EN" in relation:
        return {"R009"}
    if "MODE" in relation:
        return {"R011"}
    if "PGOOD" in relation:
        return {"R012"}
    if "FB" in relation and "feedforward" in pattern.get("pattern_id", ""):
        return {"R013"}
    return set()


class _UF:
    def __init__(self, refs): self.p = {r: r for r in refs}
    def find(self, x):
        while self.p[x] != x:
            self.p[x] = self.p[self.p[x]]; x = self.p[x]
        return x
    def union(self, a, b):
        a, b = self.find(a), self.find(b)
        if a != b: self.p[b] = a


def partition(topology, hits, motifs=None, rules_path=None, manifest_path=None):
    refs = sorted(c["designator"] for c in topology["components"])
    uf = _UF(refs)
    hard = [h for h in hits if h["relation"] == "must_link" and h.get("status", "candidate") == "approved"]
    # Only explicit approved/must_link evidence may collapse components.
    approved = set(r["rule_id"] for r in load_placement_rules(rules_path, manifest_path)["rules"] if r.get("status") == "approved")
    for h in hard:
        if h["rule_id"] in approved: uf.union(h["a"], h["b"])
    groups = defaultdict(list)
    for ref in refs: groups[uf.find(ref)].append(ref)
    clusters = [{"id": f"L1-{i+1:03d}", "members": members} for i, members in enumerate(sorted(groups.values(), key=lambda x: x[0]))]
    return {"clusters": clusters, "assignment": {m: c["id"] for c in clusters for m in c["members"]},
            "all_components_once": sorted(sum((c["members"] for c in clusters), [])) == refs,
            "hard_links_applied": [h for h in hard if h["rule_id"] in approved],
            "motifs": motifs or [],
            "note": "候选 motif 不会自动改变唯一归属；需审核后升级规则或指定成员覆盖"}


def propose_disjoint_clusters(topology, motifs, rules_path=None, manifest_path=None):
    """Produce a reviewable, non-overlapping proposal from motif scores.

    This is advisory only.  Motifs are ranked by evidence weight and accepted
    only when they do not consume a component already assigned to a stronger
    motif.  The result is intentionally separate from ``partition`` so a
    reviewer can compare the proposal with the conservative singleton output.
    """
    weights = {r["rule_id"]: r.get("weight", 1) for r in load_placement_rules(rules_path, manifest_path)["rules"]}
    ranked = sorted(motifs, key=lambda m: (-sum(weights.get(e["rule_id"], 0) for e in m["evidence"]), m["pattern_id"], m["anchor"]))
    used = set(); accepted = []
    for motif in ranked:
        members = set(motif["members"])
        if members & used:
            continue
        accepted.append(motif); used.update(members)
    refs = sorted(c["designator"] for c in topology["components"])
    clusters = [{"id": f"P-{i+1:03d}", "members": m["members"], "function": m["function"], "anchor": m["anchor"],
                 "evidence_rule_ids": sorted({e["rule_id"] for e in m["evidence"]})}
                for i, m in enumerate(accepted)]
    clusters.extend({"id": f"P-{len(clusters)+1:03d}", "members": [ref], "function": "unassigned_component"}
                    for ref in refs if ref not in used)
    return {"clusters": clusters, "accepted_motifs": accepted,
            "all_components_once": sorted(sum((c["members"] for c in clusters), [])) == refs}


_ROLE_ALIASES = {
    # Controller identities are intentionally aliases, not new placement
    # rules.  This lets charger and converter annotations reuse the reviewed
    # controller/peripheral rule families without rewriting their source role.
    "battery_charger_controller": "switching_controller",
    "charger_controller": "switching_controller",
    "power_converter_controller": "switching_controller",
    "buck_controller": "switching_controller",
    "mode_setting_resistor": "mode_resistor",
    "enable_pullup_resistor": "enable_resistor",
    "vcc_decoupling_capacitor": "ic_decoupling_capacitor",
    "feedback_feedforward_capacitor": "feedforward_capacitor",
    "ic_bypass_capacitor": "input_bypass_capacitor",
    "battery_rail_bypass_capacitor": "output_filter_capacitor",
}
_ROLE_ALIASES.update(TAXONOMY_ROLE_ALIASES)


def _canonical_roles(roles, ref):
    raw_values = as_values(roles.get(ref, {}).get("roles", []))
    values = {normalize_role(value) for value in raw_values if str(value).strip()}
    values.update(_ROLE_ALIASES.get(value, value) for value in list(values))
    # A main MCU/controller is a control anchor even when the model did not
    # call it a charger or buck IC.  The previous conditional required a
    # second power-stage tag, which left a correctly labelled MCU in the
    # unanchored catch-all domain and prevented its local peripherals from
    # becoming candidates.
    tags = tag_functions(roles.get(ref, {}).get("canonical_function_tags",
                                             roles.get(ref, {}).get("function_tags", [])))
    if "mcu_controller" in values:
        values.add("switching_controller")
    if "connector" in values and "input_power_path" in tags:
        values.add("input_connector")
    if "power_inductor" in values or "inductor" in values:
        values.add("power_inductor")
    return values


def _component_tags(roles, ref, topology):
    values = set(as_values(roles.get(ref, {}).get("function_tags", [])))
    values.update(as_values(roles.get(ref, {}).get("canonical_function_tags", [])))
    component = next((c for c in topology.get("components", []) if c.get("designator") == ref), {})
    values.update(as_values(component.get("function_tags", [])))
    values.update(as_values(component.get("canonical_function_tags", [])))
    return {str(value).lower() for value in values}


def _is_anchor(roles, ref, topology):
    role_set = _canonical_roles(roles, ref)
    tags = _component_tags(roles, ref, topology)
    # Major modules own their local support topology.  Treat isolated gate
    # drivers and auxiliary regulators as anchors too; otherwise their
    # peripherals are pulled into the MCU domain through shared VCC/GND rails.
    return bool(role_set & {"switching_controller", "mcu_controller", "power_inductor",
                            "input_connector", "gate_driver",
                            "isolated_gate_drive_power", "auxiliary_power_module"}
                or "buck_controller" in tags
                or ("power_stage" in tags and str(ref).upper().startswith(("U", "IC", "L"))))


def _is_major_component(roles, ref, topology):
    """Return whether ``ref`` is an L2 root (IC/module-sized device)."""
    component = next((row for row in topology.get("components", [])
                      if row.get("designator") == ref), {})
    kind = str(component.get("kind", "")).lower()
    role_set = _canonical_roles(roles, ref)
    tags = _component_tags(roles, ref, topology)
    major_kinds = {"ic_module", "mcu", "power_module", "driver", "processor", "fpga", "controller"}
    major_roles = {"switching_controller", "mcu_controller", "battery_charger_controller",
                   "gate_driver", "isolated_gate_drive_power", "auxiliary_power_module"}
    return bool(kind in major_kinds or role_set & major_roles
                or (str(ref).upper().startswith(("U", "IC"))
                    and (component.get("name") or component.get("value")))
                or ("power_stage" in tags and str(ref).upper().startswith(("U", "IC"))))


def _make_recursive_major_domains(topology, semantics, roles):
    """Build L2 roots and recursively absorb uniquely reachable small parts.

    Major roots are processed in deterministic designator order.  A root and
    its already-owned members are expanded completely before the next root is
    started; consequently, an overlap discovered later is retained by the
    earlier root.  This is intentional precedence, not an evidence tie-break.
    Ordinary signal nets may extend a domain through one or more small
    devices. GND and named supply rails are excluded as conservative shared
    infrastructure; they cannot establish ownership or recursion.
    """
    def designator_key(value):
        text = str(value)
        match = re.match(r"^([A-Za-z_]+)(\d+)(.*)$", text)
        if match:
            return (match.group(1).upper(), int(match.group(2)), match.group(3).upper())
        return (text.upper(), -1, "")

    def net_order_key(value):
        is_ground = is_ground_net(value)
        # When several one-hop nets connect the same pin pair, prefer a
        # non-ground edge for the human-readable shortest-path witness.
        return (1 if is_ground else 0, designator_key(value))

    def is_ground_net(value):
        normalized = re.sub(r"[\s_]+", "", str(value).upper())
        semantic_values = {str(item).upper() for item in semantics.get(value, [])}
        ground_names = {"GND", "PGND", "AGND", "DGND", "CGND", "SGND"}
        return normalized in ground_names or "GND" in semantic_values

    def is_supply_net(value):
        normalized = re.sub(r"[\s_]+", "", str(value).upper())
        semantic_values = {str(item).upper() for item in semantics.get(value, [])}
        supply_names = {
            "5V", "+5V", "3V3", "+3V3", "VCC", "+VCC", "VDD", "+VDD",
            "VSS", "-VSS", "VEE", "-VEE", "VBB", "VPP", "+VPP", "VNN", "-VNN",
            "VBUS", "VBAT", "AVCC", "DVCC", "PVCC", "AVDD", "DVDD", "PVDD",
            "AVSS", "DVSS", "PVSS", "CPVDD", "CPVSS",
        }
        return normalized in supply_names or bool(semantic_values.intersection(supply_names))

    refs = sorted((c.get("designator") for c in topology.get("components", [])
                   if c.get("designator")), key=designator_key)
    comp_nets = _component_nets(topology)
    major_refs = [ref for ref in refs if _is_major_component(roles, ref, topology)]
    if not major_refs:
        return [{"id": "D-001", "anchor": None, "members": refs,
                 "assignments": [], "assignment_reason": "no_major_component_detected"}] if refs else []

    direct = {ref: [] for ref in major_refs}
    assigned_refs = set(major_refs)

    # Process one root at a time.  Traverse from each root pin through its net
    # to the pins/components on that net, then repeat from each newly assigned
    # component's pins. Net nodes are contracted out for ordinary signals.
    # Ground and supply rails are excluded as shared infrastructure. Earlier
    # roots own conflicts because later roots treat assigned devices as
    # barriers.
    for anchor in major_refs:
        visited = {anchor}
        frontier = [(anchor, [anchor], [], [])]
        while frontier:
            next_frontier = []
            for current, path_refs, path_nets, pin_path in frontier:
                current_endpoints = []
                for net_name in comp_nets.get(current, []):
                    for endpoint in topology.get("nets", {}).get(net_name, []):
                        if endpoint.get("c") == current:
                            current_endpoints.append((net_name, endpoint))
                current_endpoints.sort(key=lambda item: (
                    net_order_key(item[0]), str(item[1].get("pin", "")),
                    str(item[1].get("name", ""))))
                for net_name, source_pin in current_endpoints:
                    endpoints = topology.get("nets", {}).get(net_name, [])
                    # Conservative policy: neither shared returns nor named
                    # supply rails establish a direct or recursive L2 link.
                    if is_ground_net(net_name) or is_supply_net(net_name):
                        continue
                    values = sorted(set(semantics.get(net_name, [])) - {"UNKNOWN"}) or ["UNKNOWN"]
                    targets = sorted((endpoint for endpoint in endpoints
                                      if endpoint.get("c") and endpoint.get("c") != current),
                                     key=lambda endpoint: (designator_key(endpoint.get("c")),
                                                           str(endpoint.get("pin", "")),
                                                           str(endpoint.get("name", ""))))
                    for target_pin in targets:
                        ref = target_pin.get("c")
                        if ref in major_refs or ref in visited:
                            continue
                        # Earlier roots have precedence.  Do not traverse an
                        # occupied component, otherwise a later root could
                        # bridge through the earlier root's domain.
                        if ref in assigned_refs:
                            continue
                        visited.add(ref)
                        candidate_path = list(path_refs) + [ref]
                        candidate_nets = list(path_nets) + [net_name]
                        candidate_pin_path = list(pin_path) + [{
                            "from_component": current,
                            "from_pin": str(source_pin.get("pin", "")),
                            "from_pin_name": str(source_pin.get("name", "")),
                            "to_component": ref,
                            "to_pin": str(target_pin.get("pin", "")),
                            "to_pin_name": str(target_pin.get("name", "")),
                        }]
                        # Contract each net hyperedge into pin-to-pin
                        # adjacency. Net names remain edge evidence, not path
                        # vertices or contributors to path length.
                        distance = len(candidate_path) - 1
                        def pin_label(component, number, name):
                            label = str(name or "").strip()
                            if not label:
                                label = str(number or "").strip()
                            return f"{component}.{label}" if label else str(component)

                        display_steps = [
                            f"{pin_label(step['from_component'], step['from_pin'], step['from_pin_name'])}"
                            for step in candidate_pin_path
                        ]
                        if candidate_pin_path:
                            last = candidate_pin_path[-1]
                            display_steps.append(pin_label(last["to_component"], last["to_pin"],
                                                           last["to_pin_name"]))
                        direct[anchor].append({
                            "ref": ref,
                            "score": float(1.0 if distance == 1 else round(1.0 / distance, 6)),
                            "shared_nets": sorted(set(candidate_nets)),
                            "semantics": sorted({value for name in candidate_nets
                                                  for value in semantics.get(name, [])}),
                            "assignment_reason": "direct_pin_connection"
                            if distance == 1 else "recursive_pin_connection",
                            "connection_path": candidate_path,
                            "connection_nets": candidate_nets,
                            "connection_distance": distance,
                            "connection_pin_path": candidate_pin_path,
                            "connection_edge_nets": candidate_nets,
                            "connection_path_display": " → ".join(display_steps),
                        })
                        assigned_refs.add(ref)
                        next_frontier.append((ref, candidate_path, candidate_nets,
                                              candidate_pin_path))
            frontier = next_frontier

    domains = []
    for index, anchor in enumerate(major_refs, 1):
        members = sorted({anchor} | {row["ref"] for row in direct[anchor]})
        domains.append({"id": f"D-{index:03d}", "anchor": anchor, "members": members,
                        "assignments": sorted(direct[anchor], key=lambda row: row["ref"]),
                        "assignment_reason": "major_component_plus_recursive_pin_connections"})
    unresolved = sorted(set(refs) - assigned_refs, key=designator_key)
    if unresolved:
        domains.append({"id": f"D-{len(domains)+1:03d}", "anchor": None,
                        "members": unresolved, "assignments": [],
                        "assignment_reason": "no_unique_major_connection"})
    return domains


def _shared_semantics(topology, semantics, left, right):
    comp_nets = _component_nets(topology)
    shared = set(comp_nets.get(left, [])) & set(comp_nets.get(right, []))
    return shared, {semantic for name in shared for semantic in semantics.get(name, [])}


def _refs_for_semantic(topology, semantics, semantic, *, exclude=None):
    exclude = set(exclude or [])
    refs = defaultdict(list)
    for name, endpoints in topology.get("nets", {}).items():
        if semantic not in semantics.get(name, []):
            continue
        for endpoint in endpoints:
            ref = endpoint.get("c")
            if ref and ref not in exclude:
                refs[name].append(ref)
    return refs


def _candidate_score(members, evidence, function, soft_scores):
    """Score a candidate without making any hard-rule decision."""
    score = {"input_bypass_stage": 110, "output_filter_stage": 105,
             "feedback_network": 100, "compensation_network": 92}.get(function, 55)
    rule_weights = {"must_link": 35, "anchor_link": 12, "prefer_link": 8}
    member_set = set(members)
    for hit in evidence:
        if not isinstance(hit, dict):
            continue
        score += rule_weights.get(hit.get("relation"), 0) + min(20, float(hit.get("weight", 0)) / 10)
    for item in soft_scores:
        if item.get("a") in member_set and item.get("b") in member_set:
            score += 20 * float(item.get("confidence", 0))
    score += min(25, max(0, len(members) - 2) * 2)
    return round(score, 4)


def _candidate_priority(candidate):
    """Priority required by the L1-2 selector."""
    if candidate.get("priority") is not None:
        return int(candidate["priority"])
    source = candidate.get("source", "")
    if candidate.get("hard_approved") or source in {"approved_hard_rule", "hard_rule"}:
        return 4
    if source == "topology":
        return 3
    if source == "llm_candidate_cluster":
        return 2
    if source == "soft_evidence":
        return 1
    return 1


def _make_hierarchical_domains(topology, semantics, roles, hits, soft_scores):
    """Build deterministic L2 domains rooted at major devices."""
    # L2 policy: roots are IC/module-sized devices and members are only parts
    # directly present on one of the root's local pin nets.
    return _make_recursive_major_domains(topology, semantics, roles)

    # Legacy semantic-scoring implementation retained below for historical
    # reference; the algorithm-only runtime intentionally does not execute it.
    refs = sorted(c["designator"] for c in topology.get("components", []))
    comp_nets = _component_nets(topology)
    anchors = [ref for ref in refs if _is_anchor(roles, ref, topology)]
    if not anchors:
        return [{"id": "D-001", "anchor": None, "members": refs,
                 "assignment_reason": "no_anchor_detected"}] if refs else []
    phases = {ref: next((c.get("phase_id") for c in topology["components"]
                         if c.get("designator") == ref), None) or roles.get(ref, {}).get("phase_id")
              for ref in refs}
    hit_by_pair = defaultdict(list)
    for hit in hits:
        hit_by_pair[frozenset((hit.get("a"), hit.get("b")))].append(hit)
    soft_by_pair = {frozenset((x.get("a"), x.get("b"))): x for x in soft_scores}
    assigned = defaultdict(list)
    ambiguous = []
    anchor_refs = set(anchors)
    for ref in refs:
        if ref in anchor_refs:
            continue
        scores = []
        for anchor in anchors:
            if phases[ref] and phases[anchor] and phases[ref] != phases[anchor]:
                continue
            shared, shared_sem = _shared_semantics(topology, semantics, ref, anchor)
            # Ground-only/common UNKNOWN rails do not assign a peripheral to a domain.
            local_sem = shared_sem - {"GND", "UNKNOWN"}
            controller_roles = _canonical_roles(roles, anchor)
            feedback_roles = {
                "feedback_resistor", "feedback_capacitor", "feedforward_capacitor",
                "compensation_resistor", "compensation_capacitor",
            }
            fb_pin_nets = {
                name for name in comp_nets.get(anchor, [])
                if any(ep.get("c") == anchor
                       and str(ep.get("pin") or ep.get("name", "")).strip().upper() in {"FB", "VSENSE"}
                       for ep in topology.get("nets", {}).get(name, []))
            } if "switching_controller" in controller_roles else set()
            if fb_pin_nets and feedback_roles.intersection(_canonical_roles(roles, ref)):
                fb_branch_refs = {ep.get("c") for name in fb_pin_nets
                                  for ep in topology.get("nets", {}).get(name, [])}
                fb_branch_nets = set().union(*(set(comp_nets.get(branch_ref, []))
                                               for branch_ref in fb_branch_refs if branch_ref))
                if ref in fb_branch_refs or set(comp_nets.get(ref, [])) & fb_branch_nets:
                    local_sem.add("FB")
                    shared.update(fb_pin_nets)
                if set(comp_nets.get(ref, [])) & fb_branch_nets:
                    local_sem.add("FB")
                    shared.update(fb_pin_nets)
                if ref in fb_branch_refs and set(comp_nets.get(ref, [])) & fb_branch_nets:
                    local_sem.add("VOUT")
                if ref in fb_branch_refs:
                    local_sem.add("FB")
            if not local_sem:
                continue
            # Do not assign a passive to a power inductor merely because it
            # shares VOUT; output capacitors belong to that inductor's stage.
            if "power_inductor" in _canonical_roles(roles, anchor) and not (
                    local_sem & {"SW", "BOOT", "VOUT"}):
                continue
            # A controller owns its pin-local support circuitry, not output
            # rail passives reached indirectly through the shared VIN/VOUT net.
            if "switching_controller" in controller_roles:
                if local_sem & {"VOUT"} and "FB" not in local_sem:
                    continue
                if local_sem & {"VIN"}:
                    connected = [ep.get("c") for name in shared
                                 for ep in topology["nets"].get(name, [])]
                    other_controllers = [x for x in connected if x in anchor_refs and x != anchor
                                         and "switching_controller" in _canonical_roles(roles, x)]
                    if other_controllers:
                        continue
            value = 10.0 * len(local_sem)
            value += sum(float(x.get("weight", 0)) for x in hit_by_pair.get(frozenset((ref, anchor)), []))
            value += 30.0 * float(soft_by_pair.get(frozenset((ref, anchor)), {}).get("confidence", 0))
            scores.append((value, anchor, sorted(shared), sorted(local_sem)))
        if not scores:
            # An UNKNOWN/GND-only net is not a domain relation by itself.  It
            # may be used as a weak tie only when the component has an
            # explicit functional label that is compatible with the anchor;
            # otherwise keep the component in the unresolved domain.
            ref_roles = _canonical_roles(roles, ref)
            ref_tags = _component_tags(roles, ref, topology)

            def unknown_label_matches(anchor):
                anchor_roles = _canonical_roles(roles, anchor)
                if not (ref_roles or ref_tags):
                    return False
                controller_functions = {
                    "input_voltage_sense", "output_voltage_sense",
                    "input_current_sense", "output_current_sense",
                    "adc_filter", "adc_reference", "temperature_sense",
                    "gate_drive_protection", "isolated_gate_drive_power",
                    "auxiliary_power", "controller_decoupling", "uart_debug",
                    "user_input", "fan_control", "feedback", "compensation",
                }
                power_functions = {
                    "power_stage", "switching_loop", "output_power_path",
                    "input_power_path", "input_voltage_sense", "output_voltage_sense",
                    "input_current_sense", "output_current_sense",
                }
                if anchor_roles & {"switching_controller", "mcu_controller"}:
                    return bool(ref_tags & controller_functions or ref_roles & {
                        "feedback_resistor", "compensation_resistor",
                        "compensation_capacitor", "feedforward_capacitor",
                        "gate_resistor", "bootstrap_capacitor",
                    })
                if anchor_roles & {"power_inductor"}:
                    return bool(ref_tags & power_functions or ref_roles & {
                        "power_mosfet", "output_filter_capacitor",
                        "input_bypass_capacitor",
                    })
                if anchor_roles & {"input_connector"}:
                    return bool(ref_tags & {"input_power_path", "input_voltage_sense",
                                           "auxiliary_power"} or ref_roles & {
                                               "input_bypass_capacitor", "tvs_protection"})
                return False

            connected = [anchor for anchor in anchors
                         if (set(comp_nets.get(ref, [])) & set(comp_nets.get(anchor, [])))
                         and unknown_label_matches(anchor)]
            # A component appearing on more than one local unknown net has a
            # bounded topology footprint.  Preserve the legacy unique-anchor
            # assignment for that case while still rejecting a single shared
            # UNKNOWN rail as domain evidence.
            if not connected and len(comp_nets.get(ref, [])) > 1:
                connected = [anchor for anchor in anchors
                             if len(set(comp_nets.get(ref, [])) &
                                    set(comp_nets.get(anchor, []))) >= 1]
            # A validated LLM function label plus a direct evidence net is a
            # bounded domain signal even when that net is still UNKNOWN to the
            # semantic dictionary.  Prefer the unique anchor touching the
            # evidence net; this keeps local sampling/filter networks out of
            # the catch-all unresolved domain.
            if not connected:
                evidence_nets = set()
                row = roles.get(ref, {})
                evidence_nets.update(as_values(row.get("evidence_nets", [])))
                evidence_nets.update(as_values(row.get("llm_evidence_nets", [])))
                if evidence_nets:
                    connected = [anchor for anchor in anchors
                                 if evidence_nets & set(comp_nets.get(anchor, []))]
            if len(connected) == 1:
                assigned[connected[0]].append({"ref": ref, "score": 0.0,
                                               "shared_nets": sorted(set(comp_nets.get(ref, [])) & set(comp_nets.get(connected[0], []))),
                                               "semantics": ["UNKNOWN"],
                                               "assignment_reason": "explicit_function_label_on_unknown_net"})
            else:
                ambiguous.append(ref)
            continue
        scores.sort(key=lambda x: (-x[0], x[1]))
        if len(scores) > 1 and abs(scores[0][0] - scores[1][0]) < 1e-9:
            ambiguous.append(ref)
        else:
            assigned[scores[0][1]].append({"ref": ref, "score": round(scores[0][0], 4),
                                           "shared_nets": scores[0][2], "semantics": scores[0][3]})
    domains = []
    for index, anchor in enumerate(anchors, 1):
        members = [anchor] + [row["ref"] for row in assigned[anchor]]
        domains.append({"id": f"D-{index:03d}", "anchor": anchor,
                        "members": sorted(set(members)),
                        "assignments": sorted(assigned[anchor], key=lambda x: x["ref"]),
                        "assignment_reason": "strongest_local_non_ground_connection"})
    if ambiguous:
        domains.append({"id": f"D-{len(domains)+1:03d}", "anchor": None,
                        "members": sorted(ambiguous),
                        "assignments": [],
                        "assignment_reason": "shared_or_ambiguous_domain_evidence"})
    # If a role overrides/tag combination caused a component to be treated as
    # both anchor and peripheral, keep it only in its own anchor domain.
    for domain in domains:
        anchor = domain.get("anchor")
        if anchor:
            domain["members"] = sorted(set(domain["members"]) - (anchor_refs - {anchor}))
            domain["assignments"] = [row for row in domain.get("assignments", [])
                                     if row.get("ref") not in anchor_refs]
    covered = {ref for domain in domains for ref in domain["members"]}
    missing = sorted(set(refs) - covered)
    if missing:
        domains.append({"id": f"D-{len(domains)+1:03d}", "anchor": None,
                        "members": missing, "assignments": [],
                        "assignment_reason": "no_non_ground_domain_evidence"})
    return domains


def _structural_candidates(topology, semantics, roles, hits, annotation, soft_scores,
                           manifest_path=None, domains=None, trace_only_out=None):
    """Generate second-level functional candidates before the final selector."""
    refs = sorted(c["designator"] for c in topology.get("components", []))
    comp_nets = _component_nets(topology)
    anchor_refs = {ref for ref in refs if _is_anchor(roles, ref, topology)}
    hit_by_pair = defaultdict(list)
    for hit in hits:
        hit_by_pair[frozenset((hit.get("a"), hit.get("b")))].append(hit)
    candidates = []
    domain_rows = domains if domains is not None else _make_hierarchical_domains(
        topology, semantics, roles, hits, soft_scores)
    domain_by_ref = {ref: domain.get("id") for domain in domain_rows for ref in domain.get("members", [])}
    intermediate_rows = {}
    if annotation:
        from .llm_intermediate import build_intermediate_representation
        intermediate_rows = {row["designator"]: row for row in
                             build_intermediate_representation(topology, annotation).get("components", [])}

    def add_candidate(function, members, evidence=None, source="topology", policy="anchor_excluded", anchor=None,
                      reason="", l1_1_domain=None, function_type=None, evidence_nets=None):
        members = sorted(set(members) & set(refs))
        if len(members) < 2:
            return
        candidate_domains = {domain_by_ref.get(ref) for ref in members}
        if len(candidate_domains) > 1 or None in candidate_domains:
            return
        if l1_1_domain is None:
            l1_1_domain = next(iter(candidate_domains))
        evidence = list(evidence or [])
        candidates.append({"function": function, "function_type": function_type or function,
                           "members": members, "evidence": evidence,
                           "source": source, "anchor_policy": policy, "anchor": anchor,
                           "reason": reason, "l1_1_domain": l1_1_domain,
                           "evidence_nets": _filter_evidence_nets(topology, evidence_nets or []),
                           "score": _candidate_score(members, evidence, function, soft_scores)})

    # Use validated LLM evidence as a local candidate seed.  The seed is kept
    # conservative: related components must be topology-connected through at
    # least one evidence net. Anchor inclusion is decided by the final
    # selector, so an explicit topology candidate can retain its anchor.
    for ref, row in intermediate_rows.items():
        function = row.get("standard_function")
        if not function or ref in anchor_refs:
            continue
        neighbors = set()
        for net_name in row.get("evidence_nets", []):
            neighbors.update(ep.get("c") for ep in topology.get("nets", {}).get(net_name, [])
                             if ep.get("c") in refs and ep.get("c") != ref)
        related = set(row.get("related_components", [])) & neighbors
        members = {ref} | related
        if len(members) < 2:
            continue
        add_candidate(row.get("candidate_type") or function, members,
                      source="llm_intermediate", reason="validated_llm_function_and_net_evidence",
                      function_type=function, evidence_nets=row.get("evidence_nets", []))

    def role_group(role, semantic, function):
        role_refs = [ref for ref in refs if role in _canonical_roles(roles, ref)]
        anchor_role = {
            "input_bypass_capacitor": "switching_controller",
            "output_filter_capacitor": "power_inductor",
            "feedback_resistor": "switching_controller",
        }.get(role)
        for net_name, net_refs in _refs_for_semantic(topology, semantics, semantic,
                                                     exclude=anchor_refs).items():
            if anchor_role:
                connected_anchors = {
                    ref for ref in refs
                    if anchor_role in _canonical_roles(roles, ref)
                    and ref in [endpoint.get("c") for endpoint in topology["nets"].get(net_name, [])]
                }
                # A shared rail is infrastructure when multiple anchors use
                # it. Without a channel-local phase/net, grouping passives
                # would merge two otherwise independent Buck channels.
                if len(connected_anchors) > 1:
                    continue
            members = [ref for ref in role_refs if ref in net_refs]
            if len(members) >= 2:
                evidence = [hit for pair, values in hit_by_pair.items()
                            if pair.issubset(members) for hit in values]
                add_candidate(function, members, evidence, reason=f"same_{semantic}_net")

    # Rails are grouped by exact net identity, preventing two Buck channels
    # that merely share a global VIN from collapsing into one functional cluster.
    role_group("input_bypass_capacitor", "VIN", "input_bypass_stage")
    role_group("output_filter_capacitor", "VOUT", "output_filter_stage")
    # Battery chargers often expose the post-inductor rail as VBAT rather than
    # VOUT.  Keep it as a separate semantic and create only a candidate motif;
    # it does not promote the reviewed VOUT rule to a hard rule.
    role_group("output_filter_capacitor", "VBAT", "output_filter_stage")
    role_group("output_filter_capacitor", "BAT", "output_filter_stage")
    # Charger-specific support parts may be connected directly to a controller
    # pin rather than a named semantic rail.  Group only by exact pin-local
    # topology, keeping anchors out of L1-2.
    pin_groups = {
        "charging_current_setting": {"anchor": "battery_charger_controller", "roles": {"charging_current_setting_resistor"}, "pins": {"ICHG"}},
        "battery_type_selection": {"anchor": "battery_charger_controller", "roles": {"battery_type_selection_resistor"}, "pins": {"D1"}},
        "test_configuration": {"anchor": "battery_charger_controller", "roles": {"test_pin_resistor"}, "pins": {"TEST"}},
    }
    for function, spec in pin_groups.items():
        members = []
        for anchor in refs:
            if spec["anchor"] not in _canonical_roles(roles, anchor):
                continue
            for net_name, endpoints in topology.get("nets", {}).items():
                anchor_pins = {str(ep.get("name", ep.get("pin", ""))).upper() for ep in endpoints if ep.get("c") == anchor}
                if not anchor_pins & spec["pins"]:
                    continue
                net_refs = {ep.get("c") for ep in endpoints}
                members.extend(ref for ref in refs if ref in net_refs and ref != anchor and spec["roles"] & _canonical_roles(roles, ref))
        if members:
            add_candidate(function + "_network", members, source="topology", reason="controller_pin_local_support")
    role_group("feedback_resistor", "FB", "feedback_network")
    feedforward = [ref for ref in refs if "feedforward_capacitor" in _canonical_roles(roles, ref)]
    feedback = [ref for ref in refs if "feedback_resistor" in _canonical_roles(roles, ref)]
    for net_name, net_refs in _refs_for_semantic(topology, semantics, "FB", exclude=anchor_refs).items():
        members = [ref for ref in feedforward + feedback if ref in net_refs]
        if len(members) >= 2:
            add_candidate("feedback_network", members, reason="feedback_and_feedforward_same_FB_net")

    # LLM function tags are stronger than generic component kinds.  Materialize
    # them into local, exact-net candidates before processing broad LLM groups.
    # Ground and UNKNOWN nets are deliberately excluded from the graph so a
    # board-wide ground rail cannot merge unrelated functions.
    component_by_ref = {c.get("designator"): c for c in topology.get("components", [])}
    non_ground_nets = {
        name for name, values in semantics.items()
        if set(str(value).upper() for value in values) - {"GND", "UNKNOWN"}
    }
    graph = defaultdict(set)
    # Explicit semantic nets are always useful.  For UNKNOWN nets, only small
    # local nets are admitted so a board-wide unnamed rail cannot merge every
    # tagged component into one candidate; this still captures local divider,
    # ADC-filter and gate-drive connections when the net name has no semantic.
    graph_nets = set(non_ground_nets)
    for name, endpoints in topology.get("nets", {}).items():
        values = {str(value).upper() for value in semantics.get(name, [])}
        refs_on_net = {ep.get("c") for ep in endpoints if ep.get("c") in refs}
        if values <= {"GND", "UNKNOWN"} and len(refs_on_net) <= 4:
            graph_nets.add(name)
    for name in graph_nets:
        endpoints = [ep.get("c") for ep in topology.get("nets", {}).get(name, [])
                     if ep.get("c") in refs]
        for left in endpoints:
            for right in endpoints:
                if left != right:
                    graph[left].add(right)

    def canonical_component_tags(ref):
        row = roles.get(ref, {})
        values = as_values(row.get("canonical_function_tags", []))
        values += as_values(row.get("function_tags", []))
        component = component_by_ref.get(ref, {})
        values += as_values(component.get("canonical_function_tags", []))
        values += as_values(component.get("function_tags", []))
        return tag_functions(values)

    tag_families = (
        "input_voltage_sense", "output_voltage_sense",
        "voltage_divider", "input_current_sense", "output_current_sense",
        "power_current_sense", "inductor_current_sense", "adc_filter",
        "adc_reference",
        "temperature_sense", "gate_drive_protection",
        "isolated_gate_drive_power", "auxiliary_power", "uart_debug",
        "user_input", "fan_control", "input_power_path", "output_power_path",
        "power_stage", "controller_decoupling", "switching_loop", "bootstrap",
    )
    role_family = {
        "input_voltage_sense_resistor": {"input_voltage_sense"},
        "output_voltage_sense_resistor": {"output_voltage_sense"},
        "power_current_sense_resistor": {"power_current_sense", "input_current_sense", "output_current_sense"},
        "inductor_current_sense_resistor": {"inductor_current_sense", "power_current_sense"},
        "input_current_sense_amplifier": {"input_current_sense"},
        "output_current_sense_amplifier": {"output_current_sense"},
        "adc_filter_capacitor": {"adc_filter"},
        "temperature_sense_resistor": {"temperature_sense", "adc_filter"},
        "isolated_gate_drive_capacitor": {"isolated_gate_drive_power"},
        "gate_drive_protection_diode": {"gate_drive_protection"},
        "gate_drive_protection_resistor": {"gate_drive_protection"},
        "gate_drive_resistor": {"gate_drive_protection"},
        "gate_turn_off_resistor": {"gate_drive_protection"},
        "gate_driver_input_resistor": {"gate_drive_protection"},
        "user_interface_filter": {"user_input"},
        "current_sense_amplifier": {"input_current_sense", "output_current_sense"},
        "current_sense_resistor": {"input_current_sense", "output_current_sense"},
        "shunt_resistor": {"power_current_sense", "input_current_sense", "output_current_sense"},
        "temperature_sensor": {"temperature_sense"},
        "gate_driver": {"gate_drive_protection"},
        "isolated_gate_drive_power": {"isolated_gate_drive_power"},
        "auxiliary_power_module": {"auxiliary_power"},
        "power_inductor": {"switching_loop", "power_stage"},
        "power_mosfet": {"power_stage"},
        "bootstrap_capacitor": {"bootstrap"},
    }
    family_alias = {
        "switching_loop": "switching_loop_stage",
        "gate_drive_protection": "gate_drive_protection_stage",
        "isolated_gate_drive_power": "isolated_gate_drive_power_stage",
        "auxiliary_power": "auxiliary_power_stage",
        "input_power_path": "input_power_path_stage",
        "output_power_path": "output_power_path_stage",
        "power_stage": "power_stage",
        "controller_decoupling": "controller_decoupling",
    }

    # Some board exports retain only pin-local UNKNOWN net names.  The
    # component roles still identify a complete local function, so construct
    # bounded role motifs from the exact nets that connect the labelled parts.
    # This is intentionally role-specific and never uses board-wide GND/VCC.
    role_motif_specs = (
        ("input_voltage_sense", {"input_voltage_sense_resistor", "voltage_sense_resistor"},
         {"input_voltage_sense_resistor", "voltage_sense_resistor"}),
        ("output_voltage_sense", {"output_voltage_sense_resistor", "voltage_sense_resistor"},
         {"output_voltage_sense_resistor", "voltage_sense_resistor"}),
        ("input_current_sense", {"input_current_sense_resistor", "input_current_sense_amplifier"},
         {"input_current_sense_resistor", "input_current_sense_amplifier", "input_current_sense_jumper"}),
        ("output_current_sense", {"output_current_sense_resistor", "output_current_sense_amplifier"},
         {"output_current_sense_resistor", "output_current_sense_amplifier", "output_current_sense_jumper"}),
        ("adc_filter", {"adc_filter_capacitor", "temperature_sense_resistor"},
         {"adc_filter_capacitor", "temperature_sense_resistor"}),
        ("temperature_sense", {"temperature_sensor", "temperature_sense_resistor"},
         {"temperature_sensor", "temperature_sense_resistor"}),
    )
    role_sets = {ref: _canonical_roles(roles, ref) for ref in refs}

    # A functional sensing path is often split over several unnamed nets:
    # divider resistor -> series resistor -> ADC filter/amplifier. Build the
    # closure over all role-labelled parts, while retaining only local nets
    # and preventing a board-wide GND/VCC/UNKNOWN rail from joining channels.
    def role_motif_component(function, required_roles, allowed_roles):
        family_refs = {ref for ref in refs if role_sets[ref] & required_roles}
        if len(family_refs) < 2:
            return
        local_graph = defaultdict(set)
        local_evidence = defaultdict(set)
        for net_name, endpoints in topology.get("nets", {}).items():
            values = {str(value).upper() for value in semantics.get(net_name, [])}
            net_refs = [ep.get("c") for ep in endpoints if ep.get("c") in family_refs]
            # UNKNOWN pin-local nets are valid evidence here when they have a
            # small endpoint count. They are the normal representation of
            # exported PCB pad connections in 0056.
            if values <= {"GND", "VCC", "UNKNOWN"} and len(net_refs) < 2:
                continue
            if len(net_refs) < 2:
                continue
            for left in net_refs:
                for right in net_refs:
                    if left != right:
                        local_graph[left].add(right)
                        local_evidence[frozenset((left, right))].add(net_name)
        pending = set(family_refs)
        while pending:
            root = min(pending)
            pending.remove(root)
            component = {root}
            frontier = [root]
            while frontier:
                current = frontier.pop()
                for other in local_graph.get(current, set()):
                    if other in pending:
                        pending.remove(other)
                        component.add(other)
                        frontier.append(other)
            if len(component) < 2:
                continue
            evidence = sorted({net for pair, nets in local_evidence.items()
                               if pair.issubset(component) for net in nets})
            add_candidate(function + "_network", component, source="topology",
                          function_type=function, reason="role_motif_local_net_closure",
                          evidence_nets=evidence)

    for spec in role_motif_specs:
        role_motif_component(*spec)

    # Gate-drive channels often carry distinct LLM tags but generic pin names.
    # Group tagged gate parts only when they share a local non-ground net path;
    # this keeps Q3/Q4 channels separate while allowing resistor/diode support
    # parts to join the corresponding driver channel.
    gate_roles = {"gate_drive_resistor", "gate_turn_off_resistor",
                  "gate_driver_input_resistor", "gate_drive_protection_resistor",
                  "gate_drive_protection_diode", "gate_driver", "power_mosfet"}
    gate_refs = {ref for ref in refs
                 if _canonical_roles(roles, ref) & gate_roles
                 or "gate_drive_protection" in canonical_component_tags(ref)}
    # Preserve channel identity from the LLM tags. These labels are stronger
    # than an UNKNOWN net name and prevent Q3/Q4 support parts from merging.
    gate_channel = {}
    for ref in gate_refs:
        text = " ".join(sorted(_canonical_roles(roles, ref) | canonical_component_tags(ref))).lower()
        if any(token in text for token in ("q3", "left_gate", "high_side")):
            gate_channel[ref] = "q3"
        elif any(token in text for token in ("q4", "right_gate", "low_side")):
            gate_channel[ref] = "q4"
    gate_graph = defaultdict(set)
    gate_evidence = defaultdict(set)
    for net_name, endpoints in topology.get("nets", {}).items():
        net_refs = {ep.get("c") for ep in endpoints if ep.get("c") in gate_refs}
        if len(net_refs) < 2:
            continue
        values = {str(value).upper() for value in semantics.get(net_name, [])}
        # Board-wide rails are not channel evidence. Keep only small local
        # rails that touch a clearly gate-related part.
        if values <= {"GND", "VCC", "+5V", "UNKNOWN"}:
            if len(net_refs) > 3 or not any(
                    "gate_drive_protection" in canonical_component_tags(ref)
                    or "gate_driver" in _canonical_roles(roles, ref)
                    for ref in net_refs):
                continue
        for left in net_refs:
            for right in net_refs:
                if left != right:
                    if gate_channel.get(left) and gate_channel.get(right) and gate_channel[left] != gate_channel[right]:
                        continue
                    gate_graph[left].add(right)
                    gate_evidence[frozenset((left, right))].add(net_name)
    pending_gate = set(gate_refs) - anchor_refs
    while pending_gate:
        root = min(pending_gate)
        pending_gate.remove(root)
        component = {root}
        frontier = [root]
        while frontier:
            current = frontier.pop()
            for other in gate_graph.get(current, set()):
                if other in pending_gate and other not in anchor_refs:
                    pending_gate.remove(other)
                    component.add(other)
                    frontier.append(other)
        # A tagged gate resistor connected only to its driver anchor still
        # forms a valid channel; include the resistor with that anchor's local
        # gate support, while never placing the anchor itself in the cluster.
        if len(component) == 1:
            # A tagged resistor may connect to an untagged clamp diode and one
            # MOSFET gate. Include the local support parts while excluding all
            # driver/controller anchors and unrelated power-switch anchors.
            frontier = list(component)
            while frontier:
                current = frontier.pop()
                for other in graph.get(current, set()):
                    if other in anchor_refs or other in component:
                        continue
                    if ("gate_drive_protection" in canonical_component_tags(other)
                            or _canonical_roles(roles, other) & gate_roles):
                        component.add(other)
                        frontier.append(other)
            # A net named for a gate contains the corresponding driver anchor
            # and passive network, which disambiguates Q3 vs Q4 channels.
            for name, endpoints in topology.get("nets", {}).items():
                if root not in {ep.get("c") for ep in endpoints}:
                    continue
                endpoint_refs = {ep.get("c") for ep in endpoints}
                if len(endpoint_refs & anchor_refs) == 1:
                    channel = gate_channel.get(root)
                    component.update(ref for ref in (endpoint_refs & gate_refs - anchor_refs)
                                     if not channel or not gate_channel.get(ref) or gate_channel.get(ref) == channel)
        if len(component) >= 2:
            evidence = sorted({net for pair, names in gate_evidence.items()
                               if pair.issubset(component) for net in names})
            add_candidate("gate_drive_protection_stage", component, source="topology",
                          reason="local_gate_drive_channel", function_type="gate_drive_protection",
                          evidence_nets=evidence)

    for family in tag_families:
        direct = set()
        for ref in refs:
            tags = canonical_component_tags(ref)
            roles_for_ref = _canonical_roles(roles, ref)
            role_families = set().union(*(role_family.get(role, set())
                                          for role in roles_for_ref))
            if family in tags or family in role_families:
                direct.add(ref)
        if not direct:
            continue
        # Connected components of the direct/compatible tag graph keep two
        # channels separate even when they share only a global rail.
        eligible = set(direct)
        for ref in refs:
            if ref in anchor_refs or ref in direct:
                continue
            tags = canonical_component_tags(ref)
            if compatible_tag(family, tags) and any(ref in graph.get(seed, set()) or
                                                   seed in graph.get(ref, set())
                                                   for seed in direct):
                eligible.add(ref)
        pending = set(eligible)
        while pending:
            root = min(pending)
            component = {root}
            frontier = [root]
            while frontier:
                current = frontier.pop()
                for other in graph.get(current, set()):
                    if other in pending and other in eligible:
                        pending.remove(other)
                        component.add(other)
                        frontier.append(other)
            pending.discard(root)
            component -= anchor_refs
            if len(component) < 2:
                continue
            # A direct family label always wins over a compatible helper tag;
            # do not create a large generic decoupling cluster from every cap.
            add_candidate(family_alias.get(family, family), component,
                          source="topology", reason=f"canonical_function_tags:{family}",
                          function_type=family,
                          evidence_nets=sorted({name for name in non_ground_nets
                                                if component & {ep.get("c") for ep in topology.get("nets", {}).get(name, [])}}))

    # For large real-world schematics, names may be absent but a repeated
    # local passive pattern is still meaningful. Group same-role passives on
    # an exact non-ground net only when that net belongs to one L1-1 domain.
    for role, function in (("generic_passive", "passive_support"),
                           ("compensation_resistor", "compensation_network"),
                           ("compensation_capacitor", "compensation_network")):
        role_refs = [ref for ref in refs if role in _canonical_roles(roles, ref)]
        by_net = defaultdict(list)
        for name, endpoints in topology.get("nets", {}).items():
            if set(semantics.get(name, [])) <= {"GND", "UNKNOWN"}:
                continue
            for endpoint in endpoints:
                if endpoint.get("c") in role_refs:
                    by_net[name].append(endpoint.get("c"))
        for name, members in by_net.items():
            member_domains = {domain_by_ref.get(ref) for ref in members if domain_by_ref.get(ref)}
            if len(members) >= 2 and len(member_domains) == 1:
                add_candidate(function, members, source="topology",
                              reason=f"same_exact_net:{name};role={role}")

    # Reviewed hard must-links are eligible functional clusters, but anchors
    # stay excluded by policy and hard rules retain the top selector priority.
    approved_pairs = defaultdict(list)
    for hit in hits:
        if hit.get("status") == "approved" and hit.get("relation") == "must_link":
            approved_pairs[hit.get("rule_id")].append(hit)
    hard_groups = defaultdict(set)
    for hit in hits:
        if hit.get("status") == "approved" and hit.get("relation") == "must_link":
            pair = {hit.get("a"), hit.get("b")} - anchor_refs
            if len(pair) == 2:
                hard_groups[hit.get("rule_id", "approved_hard_rule")].update(pair)
    for rule_id, members in hard_groups.items():
        add_candidate(f"approved_hard_rule:{rule_id}", members,
                      evidence=approved_pairs[rule_id], source="approved_hard_rule",
                      reason="approved_hard_rule_must_link")

    # Suppress topology proposals that duplicate a reviewed hard-rule group;
    # otherwise the same members could occupy the selector before the hard
    # candidate despite their lower source priority.
    hard_member_sets = [set(candidate["members"]) for candidate in candidates
                        if candidate.get("source") == "approved_hard_rule"]
    if hard_member_sets:
        candidates = [candidate for candidate in candidates
                      if candidate.get("source") != "topology"
                      or not any(set(candidate["members"]).issubset(members)
                                 for members in hard_member_sets)]

    # Explicit LLM candidate groups are soft, reviewable evidence.  A raw
    # model group may span several functions even when all members happen to
    # belong to one L1-1 domain, so infer a function for each member from its
    # role and local net semantics before materializing candidates.
    from .soft_evidence import classify_soft_candidate
    domain_by_ref = {ref: domain.get("id") for domain in domains for ref in domain.get("members", [])}
    function_cluster_names = {
        "input_bypass": "input_bypass_stage",
        "output_filter": "output_filter_stage",
        "feedback": "feedback_network",
        "compensation": "compensation_network",
        "bootstrap": "bootstrap_network",
        "switching_loop": "switching_loop_stage",
    }
    role_functions = {
        "input_bypass_capacitor": "input_bypass",
        "output_filter_capacitor": "output_filter",
        "feedback_resistor": "feedback",
        "feedforward_capacitor": "feedback",
        "compensation_resistor": "compensation",
        "compensation_capacitor": "compensation",
        "bootstrap_capacitor": "bootstrap",
        "bootstrap_diode": "bootstrap",
        "power_inductor": "switching_loop",
    }
    semantic_functions = {
        "VIN": "input_bypass", "VCC": "input_bypass",
        "VOUT": "output_filter", "VBAT": "output_filter", "BAT": "output_filter",
        "FB": "feedback", "VSENSE": "feedback", "COMP": "compensation",
        "BOOT": "bootstrap", "SW": "switching_loop",
    }

    def member_function_hints(ref):
        hints = {role_functions[role] for role in _canonical_roles(roles, ref)
                 if role in role_functions}
        tags = canonical_component_tags(ref)
        for family in tag_families:
            if family in tags or compatible_tag(family, tags):
                hints.add(family)
        for net_name in comp_nets.get(ref, []):
            for semantic in semantics.get(net_name, []):
                function = semantic_functions.get(str(semantic).upper())
                if function:
                    hints.add(function)
        return hints

    def candidate_function_hints(item):
        labels = set()
        for key in ("function", "function_type", "cluster_id", "name"):
            value = item.get(key)
            if value:
                label = classify_soft_candidate({"function": value})
                if label != "other":
                    labels.add(label)
        for value in item.get("functions", []) or []:
            label = classify_soft_candidate({"function": value})
            if label != "other":
                labels.add(label)
        for nested in item.get("evidence", []) or []:
            if isinstance(nested, dict):
                label = classify_soft_candidate(nested)
                if label != "other":
                    labels.add(label)
        return labels

    def item_semantic_labels(item):
        labels = set(as_values(item.get("evidence_nets", [])))
        labels.update(as_values(item.get("shared_semantics", [])))
        for nested in item.get("evidence", []) or []:
            if isinstance(nested, dict):
                labels.update(as_values(nested.get("evidence_nets", [])))
                labels.update(as_values(nested.get("shared_semantics", [])))
        return set(_filter_evidence_nets(topology, labels))

    llm_trace_candidates = []
    for item_index, item in enumerate((annotation or {}).get("candidate_clusters", []) or []):
        if not isinstance(item, dict):
            continue
        members = item.get("members", [])
        if not isinstance(members, list):
            continue
        raw_members = sorted(set(ref for ref in members if ref in refs))
        candidate_anchors = sorted(set(raw_members) & anchor_refs)
        # Keep one explicit anchor available to the selector.  The previous
        # implementation removed every anchor before function inference, so a
        # valid LLM proposal such as {controller, Cin1, Cin2} could never
        # become an anchor-included L1 cluster.  Multiple anchors remain
        # ineligible because one L1 cluster cannot own two domain roots.
        if len(candidate_anchors) > 1:
            llm_trace_candidates.append({
                "function": str(item.get("function", "llm_candidate_cluster")),
                "function_type": str(item.get("function_type") or item.get("function", "llm_candidate_cluster")),
                "members": raw_members, "evidence": item.get("evidence", []),
                "source": "llm_candidate_cluster", "anchor_policy": "anchor_excluded",
                "reason": str(item.get("reason", "")), "l1_1_domain": None,
                "evidence_nets": sorted(item_semantic_labels(item)),
                "score": _candidate_score(raw_members, item.get("evidence", []),
                                           str(item.get("function", "llm_candidate_cluster")), soft_scores),
                "ineligible_reason": "anchor_conflict",
            })
            continue
        filtered = [ref for ref in raw_members if ref not in anchor_refs]
        minimum_members = 1 if len(candidate_anchors) == 1 else 2
        if len(filtered) < minimum_members:
            continue
        explicit_functions = candidate_function_hints(item)
        raw_function = str(item.get("function", "llm_candidate_cluster"))
        raw_text = (raw_function + " " + str(item.get("function_type", "")) + " "
                    + str(item.get("reason", ""))).lower()
        # Split explicit gate-driver groups by q3/q4 channel before the
        # generic domain/function logic. The annotation often names the
        # complete stage, while its members carry exact channel tags.
        if any(token in raw_text for token in ("q3", "high-side", "high side", "left gate")):
            explicit_functions.add("gate_drive_protection")
            filtered = [ref for ref in filtered if not any(
                token in " ".join(sorted(_canonical_roles(roles, ref) | canonical_component_tags(ref))).lower()
                for token in ("q4", "low_side", "right_gate"))]
        elif any(token in raw_text for token in ("q4", "low-side", "low side", "right gate")):
            explicit_functions.add("gate_drive_protection")
            filtered = [ref for ref in filtered if not any(
                token in " ".join(sorted(_canonical_roles(roles, ref) | canonical_component_tags(ref))).lower()
                for token in ("q3", "high_side", "left_gate"))]
        if len(filtered) < minimum_members:
            continue
        member_groups = defaultdict(list)
        for ref in filtered:
            hints = member_function_hints(ref)
            selected_functions = (hints & explicit_functions) if explicit_functions else hints
            # If the LLM supplied a known function but the local metadata has
            # no matching hint, keep that function as the least-assumptive
            # interpretation. Unknown broad groups are handled as trace-only.
            if not selected_functions and len(hints) == 0 and len(explicit_functions) == 1:
                selected_functions = set(explicit_functions)
            for function in selected_functions:
                member_groups[function].append(ref)
        item_nets = item_semantic_labels(item)
        grouped = False
        for function, function_members in sorted(member_groups.items()):
            by_domain = defaultdict(list)
            for ref in function_members:
                by_domain[domain_by_ref.get(ref, "unassigned")].append(ref)
            for domain_key, domain_members in sorted(by_domain.items()):
                if len(domain_members) < minimum_members:
                    continue
                # Role composition and semantic scope are part of the key so
                # repeated LLM groups cannot collapse into one broad domain.
                role_key = tuple(sorted(tuple(sorted(_canonical_roles(roles, ref)))
                                        for ref in domain_members))
                semantic_key = tuple(_filter_evidence_nets(topology, item_nets or {
                    semantic for ref in domain_members
                    for net_name in comp_nets.get(ref, [])
                    for semantic in semantics.get(net_name, [])
                    if str(semantic).upper() not in {"GND", "UNKNOWN"}
                }))
                cluster_function = function_cluster_names.get(function, function)
                candidate_members = list(domain_members)
                if len(candidate_anchors) == 1 and len(explicit_functions) == 1:
                    anchor = candidate_anchors[0]
                    if domain_by_ref.get(anchor) == domain_key:
                        candidate_members = sorted(set(candidate_members) | {anchor})
                add_candidate(cluster_function, candidate_members,
                              evidence=item.get("evidence", []),
                              source="llm_candidate_cluster",
                              reason=(f"llm_function_split:{function};domain={domain_key};"
                                      f"roles={role_key};semantics={semantic_key}"),
                              l1_1_domain=domain_key, function_type=function,
                              evidence_nets=semantic_key)
                grouped = True
        member_domains = {domain_by_ref.get(ref, "unassigned") for ref in filtered}
        if len(member_domains) > 1:
            llm_trace_candidates.append({
                "function": raw_function, "function_type": raw_function,
                "members": raw_members, "evidence": item.get("evidence", []),
                "source": "llm_candidate_cluster", "anchor_policy": "anchor_excluded",
                "reason": str(item.get("reason", "")), "l1_1_domain": None,
                "evidence_nets": sorted(item_nets), "score": _candidate_score(
                    filtered, item.get("evidence", []), raw_function, soft_scores),
                "ineligible_reason": "mixed_l1_1_domains",
            })
        elif not grouped:
            # A context-free broad LLM group is useful in the audit trail but
            # is not a selectable L1-2 function cluster. This prevents a
            # generic llm_soft_candidate from swallowing an entire domain.
            llm_trace_candidates.append({
                "function": raw_function, "function_type": raw_function,
                "members": raw_members, "evidence": item.get("evidence", []),
                "source": "llm_candidate_cluster", "anchor_policy": "anchor_excluded",
                "reason": str(item.get("reason", "")), "l1_1_domain": None,
                "evidence_nets": sorted(item_nets), "score": _candidate_score(
                    filtered, item.get("evidence", []), raw_function, soft_scores),
                "ineligible_reason": "untyped_function",
            })
        elif not explicit_functions:
            # Preserve the original broad proposal for auditability when it
            # was successfully split into functional subgroups.
            llm_trace_candidates.append({
                "function": raw_function, "function_type": raw_function,
                "members": raw_members, "evidence": item.get("evidence", []),
                "source": "llm_candidate_cluster", "anchor_policy": "anchor_excluded",
                "reason": str(item.get("reason", "")), "l1_1_domain": None,
                "evidence_nets": sorted(item_nets), "score": _candidate_score(
                    filtered, item.get("evidence", []), raw_function, soft_scores),
                "ineligible_reason": "split_functional_candidate",
            })
    if trace_only_out is not None:
        trace_only_out.extend(llm_trace_candidates)

    # Soft records are grouped by functional family, L1-1 domain, role
    # composition and network semantics. The score_pairs() metadata may carry
    # several functions for the same pair; iterate each one independently.
    partitioned_soft_groups = defaultdict(lambda: {
        "members": set(), "evidence": [], "evidence_nets": set(),
        "shared_semantics": set(), "confidence": 0.0,
    })
    for item in soft_scores:
        if item.get("decision") not in {"proposal", "hard_linked"}:
            continue
        left, right = item.get("a"), item.get("b")
        if not left or not right or left in anchor_refs or right in anchor_refs:
            continue
        functions = item.get("functions")
        if not isinstance(functions, (list, tuple, set)):
            functions = [classify_soft_candidate(item)]
        functions = [str(function) for function in functions if str(function) != "other"]
        if not functions:
            continue
        left_domain, right_domain = domain_by_ref.get(left), domain_by_ref.get(right)
        if left_domain and right_domain and left_domain != right_domain:
            continue
        domain_key = left_domain or right_domain or "unassigned"
        left_roles = tuple(sorted(_canonical_roles(roles, left)))
        right_roles = tuple(sorted(_canonical_roles(roles, right)))
        role_key = tuple(sorted((left_roles, right_roles)))
        base_evidence_nets = set(_filter_evidence_nets(
            topology, item.get("evidence_nets", [])))
        base_shared_semantics = set(_filter_evidence_nets(
            topology, item.get("shared_semantics", [])))
        function_evidence = item.get("function_evidence", {})
        for function in functions:
            item_evidence_nets = set(base_evidence_nets)
            item_shared_semantics = set(base_shared_semantics)
            selected_evidence = (function_evidence.get(function, [])
                                 if isinstance(function_evidence, dict) else item.get("evidence", []))
            for evidence_row in selected_evidence or []:
                if isinstance(evidence_row, dict):
                    item_evidence_nets.update(_filter_evidence_nets(
                        topology, evidence_row.get("evidence_nets", [])))
                    item_shared_semantics.update(_filter_evidence_nets(
                        topology, evidence_row.get("shared_semantics", [])))
            # Keep the semantic key and evidence update inside the function
            # loop. A single pair may legitimately have multiple functional
            # interpretations; calculating these values after the loop used
            # to retain only the last function's evidence.
            semantic_key = tuple(sorted(item_evidence_nets | item_shared_semantics))
            if not semantic_key:
                evidence_labels = []
                for evidence in selected_evidence or item.get("evidence", []) or []:
                    if isinstance(evidence, dict):
                        evidence_labels.extend(str(value) for key in
                                               ("net", "name", "semantic")
                                               for value in ([evidence.get(key)] if evidence.get(key) else []))
                    elif evidence:
                        evidence_labels.append(str(evidence))
                semantic_key = tuple(_filter_evidence_nets(topology, evidence_labels))
            key = (domain_key, function, role_key, semantic_key)
            group = partitioned_soft_groups[key]
            group["members"].update((left, right))
            group["evidence"].extend(selected_evidence or item.get("evidence", []))
            group["evidence_nets"].update(item_evidence_nets)
            group["shared_semantics"].update(item_shared_semantics)
            group["confidence"] = max(group["confidence"], float(item.get("confidence", 0) or 0))
    for (domain_key, function, role_key, semantic_key), group in partitioned_soft_groups.items():
        evidence_nets = _filter_evidence_nets(
            topology, group["evidence_nets"] | group["shared_semantics"] | set(semantic_key))
        add_candidate(function_cluster_names.get(function, function + "_stage"),
                      group["members"], evidence=group["evidence"], source="soft_evidence",
                      reason=(f"grouped_soft_evidence:{function};domain={domain_key};"
                              f"roles={role_key};semantics={tuple(evidence_nets)}"),
                      l1_1_domain=domain_key, function_type=function,
                      evidence_nets=evidence_nets)

    # Topology candidates can be selected ahead of soft evidence, but retain
    # the semantic nets supplied by matching soft records for the same
    # function/member set so the final cluster remains auditable.
    for candidate in candidates:
        if candidate.get("evidence_nets"):
            continue
        member_set = set(candidate.get("members", []))
        nets = set()
        for item in soft_scores:
            if {item.get("a"), item.get("b")} <= member_set:
                nets.update(_filter_evidence_nets(topology, item.get("evidence_nets", [])))
                for evidence_row in item.get("evidence", []):
                    if isinstance(evidence_row, dict):
                        nets.update(_filter_evidence_nets(
                            topology, evidence_row.get("evidence_nets", [])))
        if nets:
            candidate["evidence_nets"] = _filter_evidence_nets(topology, nets)

    # Use function patterns for singleton peripheral relationships and for
    # anchor-included patterns (for example input protection).  Patterns with
    # anchor_excluded policy contribute peer members only.
    patterns = load_json("function_patterns.json", manifest_path).get("patterns", [])
    for pattern in patterns:
        function = pattern.get("function", pattern.get("pattern_id", "pattern"))
        anchor_role = pattern.get("anchor_role")
        policy = pattern.get("anchor_policy", "anchor_included")
        required = set(pattern.get("required_roles", []))
        relation = pattern.get("relation", "")
        semantic_tokens = re.findall(r"[A-Z][A-Z0-9_]*", relation)
        semantic_tokens = [token for token in semantic_tokens if token in {"VIN", "VOUT", "VBAT", "BAT", "FB", "COMP", "VCC", "BOOT", "SW", "SS", "EN", "MODE", "PGOOD"}]
        for anchor in refs:
            if anchor_role not in _canonical_roles(roles, anchor):
                continue
            members = [anchor]
            evidence = []
            for other in refs:
                if other == anchor:
                    continue
                other_roles = _canonical_roles(roles, other)
                if required - {anchor_role} and not (required - {anchor_role}).intersection(other_roles):
                    continue
                shared, shared_sem = _shared_semantics(topology, semantics, anchor, other)
                if semantic_tokens and not set(semantic_tokens).issubset(shared_sem):
                    continue
                if not shared or not (shared_sem - {"GND", "UNKNOWN"}):
                    continue
                members.append(other)
                evidence.extend(hit_by_pair.get(frozenset((anchor, other)), []))
            if policy == "anchor_excluded":
                members = [ref for ref in members if ref != anchor]
            if policy == "anchor_included":
                add_candidate(function, members, evidence, policy=policy, anchor=anchor,
                              reason=f"pattern:{pattern.get('pattern_id')}")
            elif len(members) >= 2:
                add_candidate(function, members, evidence, policy=policy, anchor=anchor,
                              reason=f"pattern:{pattern.get('pattern_id')}")
    return candidates


def _dedupe_candidates(candidates):
    def stable_unique(values):
        """Deduplicate JSON-like evidence while preserving insertion order."""
        result = []
        seen = set()
        for value in values or []:
            try:
                marker = json.dumps(value, ensure_ascii=False, sort_keys=True)
            except (TypeError, ValueError):
                marker = repr(value)
            if marker in seen:
                continue
            seen.add(marker)
            result.append(value)
        return result

    def snapshot(candidate):
        """Keep a trace-safe copy of a candidate absorbed by deduplication."""
        row = dict(candidate)
        row.pop("_deduped_candidates", None)
        for field in ("members", "evidence", "evidence_nets", "shared_semantics"):
            if isinstance(row.get(field), list):
                row[field] = list(row[field])
        return row

    def merge(primary, secondary):
        # Source priority chooses the primary candidate, but evidence from every
        # equivalent source must survive so the selected cluster remains auditable.
        primary["evidence"] = stable_unique(primary.get("evidence", []) +
                                             secondary.get("evidence", []))
        for field in ("evidence_nets", "shared_semantics"):
            merged = stable_unique((primary.get(field) or []) + (secondary.get(field) or []))
            if merged:
                primary[field] = sorted(merged)
        if "confidence" in secondary:
            primary["confidence"] = max(float(primary.get("confidence", 0) or 0),
                                         float(secondary.get("confidence", 0) or 0))
        absorbed = list(primary.get("_deduped_candidates", []))
        absorbed.extend(secondary.get("_deduped_candidates", []))
        absorbed.append(snapshot(secondary))
        primary["_deduped_candidates"] = absorbed
        return primary

    deduped = {}
    for candidate in candidates:
        key = (candidate.get("function"), tuple(candidate.get("members", [])))
        previous = deduped.get(key)
        if (previous is None or
                (_candidate_priority(candidate), candidate.get("score", 0)) >
                (_candidate_priority(previous), previous.get("score", 0))):
            if previous is not None:
                candidate = merge(candidate, previous)
            deduped[key] = candidate
        elif previous is not None:
            merge(previous, candidate)
    return list(deduped.values())


def _prioritize_approved_hard_candidates(candidates):
    hard_groups = [candidate for candidate in candidates
                   if candidate.get("source") == "approved_hard_rule"]
    if not hard_groups:
        return candidates
    return [candidate for candidate in candidates
            if candidate.get("source") != "topology"
            or not any(set(candidate["members"]).issubset(set(hard["members"]))
                       for hard in hard_groups)]


def hierarchical_partition(topology, semantics, roles, hits, motifs=None, annotation=None,
                            soft_scores=None, rules_path=None, manifest_path=None,
                            materialize_unresolved_singletons=True):
    """Select one disjoint set of functional clusters from scored candidates."""
    soft_scores = soft_scores or []
    domains = _make_hierarchical_domains(topology, semantics, roles, hits, soft_scores)
    trace_only_candidates = []
    anchor_refs = {ref for ref in (c.get("designator") for c in topology.get("components", []))
                   if _is_anchor(roles, ref, topology)}
    candidates = _prioritize_approved_hard_candidates(_dedupe_candidates(_structural_candidates(
        topology, semantics, roles, hits, annotation or {}, soft_scores, manifest_path, domains,
        trace_only_candidates)))
    # Penalize a broad candidate when it covers several smaller candidates with
    # different functional meanings.  The penalty is deliberately calculated
    # before ranking so a large LLM group cannot win merely because it contains
    # more members or more soft links.  Approved hard rules are never penalized.
    def candidate_label(candidate):
        text = str(candidate.get("function_type") or candidate.get("function") or "").lower()
        for label in ("input_bypass", "output_filter", "feedback", "compensation",
                      "bootstrap", "switching_loop", "passive_support"):
            if label in text:
                return label
        return "broad" if any(token in text for token in
                               ("llm", "global", "broad", "candidate", "unknown", "other")) else text

    for candidate in candidates:
        candidate["overlap_penalty"] = 0.0
        if candidate.get("source") not in {"llm_candidate_cluster", "soft_evidence"}:
            continue
        label = candidate_label(candidate)
        if label == "broad":
            candidate["overlap_penalty"] += 35.0
        member_set = set(candidate.get("members", []))
        alternatives = []
        for other in candidates:
            if other is candidate or len(other.get("members", [])) < 2:
                continue
            other_label = candidate_label(other)
            if other_label in {label, "broad"}:
                continue
            other_members = set(other.get("members", []))
            if not other_members.intersection(member_set):
                continue
            alternatives.append(other_members)
        # Count disjoint functional alternatives covered by this candidate;
        # overlapping alternatives are counted once to avoid excessive costs.
        covered = set()
        for alternative in sorted(alternatives, key=lambda values: (len(values), sorted(values))):
            if alternative <= member_set and not alternative.intersection(covered):
                covered.update(alternative)
                candidate["overlap_penalty"] += 70.0
        candidate["overlap_penalty"] += round(
            25.0 * len(covered) / max(1, len(member_set)), 4)
        candidate["overlap_penalty"] = round(candidate["overlap_penalty"], 4)

    # Rank using the requested source priority, with the overlap penalty able
    # to demote a broad proposal when it would erase multiple meaningful
    # functional clusters. Scores are normalized by size as a second guard
    # against member-count inflation.
    def selector_score(candidate):
        size = max(1, len(candidate.get("members", [])))
        base = float(candidate.get("score", 0)) / size
        return base - float(candidate.get("overlap_penalty", 0))

    def selector_priority_score(candidate):
        return _candidate_priority(candidate) * 100.0 - float(candidate.get("overlap_penalty", 0))

    ranked = sorted(candidates, key=lambda x: (-selector_priority_score(x), -selector_score(x),
                                                x.get("function", ""), x.get("members", [])))
    used = set()
    selected = []
    trace = []
    for index, candidate in enumerate(ranked, 1):
        overlap = sorted(used.intersection(candidate["members"]))
        row = dict(candidate)
        absorbed = row.pop("_deduped_candidates", [])
        row["candidate_id"] = f"HC-{index:03d}"
        if row.get("ineligible_reason"):
            row["decision"] = {
                "mixed_l1_1_domains": "rejected_mixed_domain",
                "anchor_conflict": "rejected_anchor_conflict",
                "untyped_function": "rejected_untyped_function",
                "split_functional_candidate": "rejected_split_function",
            }.get(row["ineligible_reason"], "rejected_ineligible")
            trace.append(row)
            continue
        anchor_overlap = sorted(anchor_refs.intersection(candidate["members"]))
        if len(anchor_overlap) > 1:
            row["decision"] = "rejected_anchor_conflict"
            row["rejected_members"] = anchor_overlap
        elif overlap:
            # Record the explicit cost even though exclusivity rejects this
            # candidate; it makes the selection trace explainable.
            row["overlap_penalty"] = round(float(candidate.get("overlap_penalty", 0)) +
                                            25.0 * len(overlap) / max(1, len(candidate["members"])), 4)
            row["decision"] = "rejected_overlap"
            row["rejected_members"] = sorted(set(candidate["members"]))
        else:
            if anchor_overlap:
                # A candidate with one explicit anchor is a complete local
                # function unit. Keep the anchor in L1 and expose it in the
                # audit payload instead of dropping the whole candidate.
                candidate["anchor"] = anchor_overlap[0]
                candidate["anchor_policy"] = "anchor_included"
                row["anchor"] = anchor_overlap[0]
                row["anchor_policy"] = "anchor_included"
            row["decision"] = "selected"
            selected.append(candidate)
            used.update(candidate["members"])
        trace.append(row)
        # A higher-priority candidate may have absorbed an equivalent soft or
        # LLM candidate during deduplication.  Keep each absorbed proposal in
        # the audit trace without allowing it to compete a second time.
        for absorbed_candidate in absorbed:
            absorbed_row = dict(absorbed_candidate)
            absorbed_row.pop("_deduped_candidates", None)
            absorbed_row["candidate_id"] = f"HC-{len(trace) + 1:03d}"
            absorbed_row["decision"] = "rejected_deduplicated"
            absorbed_row["deduplicated_into"] = row["candidate_id"]
            trace.append(absorbed_row)
    for candidate in trace_only_candidates:
        candidate["candidate_id"] = f"HC-{len(trace) + 1:03d}"
        candidate["decision"] = {
            "mixed_l1_1_domains": "rejected_mixed_domain",
            "anchor_conflict": "rejected_anchor_conflict",
            "untyped_function": "rejected_untyped_function",
            "split_functional_candidate": "rejected_split_function",
        }.get(candidate.get("ineligible_reason"), "rejected_ineligible")
        candidate["rejected_members"] = sorted(candidate.get("members", []))
        trace.append(candidate)
    # A mixed-domain proposal is the audit-level explanation for all of its
    # domain-split rows.  Put the complete membership on the first matching
    # row so consumers do not need to reconstruct the original LLM proposal.
    for mixed in trace_only_candidates:
        matching = [row for row in trace
                    if row.get("function") == mixed.get("function")
                    and row.get("source") == "llm_candidate_cluster"]
        if matching:
            full_members = sorted(set(mixed.get("members", [])))
            matching[0]["rejected_members"] = full_members
    # Internal provenance is already represented in decision_trace; do not
    # expose the private deduplication field in selected candidate payloads.
    for candidate in candidates:
        candidate.pop("_deduped_candidates", None)
    refs = sorted(c["designator"] for c in topology.get("components", []))
    clusters = []
    for index, candidate in enumerate(selected, 1):
        clusters.append({"id": f"L2-{index:03d}", "level": "L2", "members": sorted(candidate["members"]),
                         "function": candidate.get("function"), "source": candidate.get("source"),
                         "function_type": candidate.get("function_type") or candidate.get("function"),
                         "evidence_nets": candidate.get("evidence_nets", []),
                         "anchor": candidate.get("anchor"),
                         "anchor_policy": candidate.get("anchor_policy", "anchor_excluded"),
                         "score": candidate.get("score", 0),
                         "reason": candidate.get("reason", "")})
    unresolved = []
    for ref in refs:
        if ref not in used:
            unresolved.append(ref)
    clusters.sort(key=lambda c: c["members"][0])
    assignment = {member: cluster["id"] for cluster in clusters for member in cluster["members"]}
    assignment.update({ref: None for ref in unresolved})
    hard_links = [hit for hit in hits if hit.get("relation") == "must_link"
                  and hit.get("status") == "approved"]
    # Public hierarchy: L2 is the coarse domain, L1 is the fine functional
    # cluster. Legacy l1_1/l1_2 aliases remain below for old consumers.
    l1_1_domains = []
    for index, domain in enumerate(domains, 1):
        row = dict(domain)
        row["id"] = f"L2-{index:03d}"
        row["level"] = "L2"
        l1_1_domains.append(row)
    l1_2_clusters = []
    domain_by_member = {ref: domain["id"] for domain in l1_1_domains
                        for ref in domain.get("members", [])}
    for index, cluster in enumerate(clusters, 1):
        row = dict(cluster)
        row["id"] = f"L1-{index:03d}"
        row["level"] = "L1"
        # Keep L1-1 ownership visible on each fine cluster for auditability.
        row["l1_1_domain"] = sorted({domain_by_member.get(ref) for ref in row["members"]
                                     if domain_by_member.get(ref)})
        # Preserve candidate evidence through the L1-1/L1-2 materialization
        # step.  This is especially important for soft candidates, whose
        # network semantics are part of the audit trail and selector output.
        if not row.get("evidence_nets") and cluster.get("evidence_nets"):
            row["evidence_nets"] = sorted(set(cluster["evidence_nets"]))
        if not row.get("function_type") and cluster.get("function_type"):
            row["function_type"] = cluster["function_type"]
        if row.get("function_type", "").endswith("_stage"):
            row["function_type"] = row["function_type"][:-6]
        if not row.get("l1_1_domain") and cluster.get("l1_1_domain"):
            row["l1_1_domain"] = [cluster["l1_1_domain"]]
        l1_2_clusters.append(row)
    # Major components are explicit L2 ownership units when they do not belong
    # to a functional multi-part cluster. Their singleton status is intentional.
    assigned_refs = {ref for cluster in l1_2_clusters for ref in cluster["members"]}
    anchor_singletons = []
    for ref in sorted(anchor_refs - assigned_refs):
        anchor_singletons.append({
            "id": f"L1-{len(l1_2_clusters)+1:03d}", "level": "L1",
            "members": [ref], "function": "major_component_anchor",
            "function_type": "major_component_anchor", "source": "anchor_singleton",
            "evidence_nets": [], "anchor": ref, "anchor_policy": "anchor_included",
            "reason": "major_component_singleton",
            "l1_domain": domain_by_member.get(ref),
        })
    l1_2_clusters.extend(anchor_singletons)
    for index, cluster in enumerate(l1_2_clusters, 1):
        cluster["id"] = f"L1-{index:03d}"
    # Materialize the hierarchy explicitly.  L2 is the parent ownership unit:
    # every L1 cluster whose members belong to one L2 domain is nested below
    # that domain.  This prevents directly connected small-device clusters
    # from appearing as unrelated top-level clusters in downstream UIs.
    domain_by_member = {ref: domain["id"] for domain in l1_1_domains
                        for ref in domain.get("members", [])}
    domain_children = defaultdict(list)
    for cluster in l1_2_clusters:
        member_domains = {domain_by_member.get(ref) for ref in cluster.get("members", [])}
        member_domains.discard(None)
        if len(member_domains) == 1:
            parent_id = next(iter(member_domains))
            cluster["parent_l2_domain"] = parent_id
            parent = next((domain for domain in l1_1_domains if domain.get("id") == parent_id), None)
            cluster["parent_l2_anchor"] = parent.get("anchor") if parent else None
            domain_children[parent_id].append(cluster)
        else:
            cluster["parent_l2_domain"] = None
            cluster["parent_l2_anchor"] = None
    for domain in l1_1_domains:
        children = sorted(domain_children.get(domain.get("id"), []),
                          key=lambda row: row.get("id", ""))
        domain["children_l1"] = [row.get("id") for row in children]
        # Keep a compact nested copy for consumers that want one L2 tree
        # without having to join IDs against the separate L1 list.
        domain["children_l1_clusters"] = [
            {"id": row.get("id"), "level": row.get("level"),
             "members": list(row.get("members", [])),
             "function": row.get("function"),
             "function_type": row.get("function_type"),
             "source": row.get("source"),
             "reason": row.get("reason", "")}
            for row in children
        ]
    trace_by_ref = defaultdict(list)
    for row in trace:
        for member in row.get("members", []) or []:
            trace_by_ref[member].append(row)
    component_nets = _component_nets(topology)
    unresolved_rows = []
    for ref in unresolved:
        if ref in {member for cluster in l1_2_clusters for member in cluster["members"]}:
            continue
        domain = next((d for d in l1_1_domains if ref in d.get("members", [])), None)
        is_anchor = _is_anchor(roles, ref, topology)
        if is_anchor:
            reason = "intentional_anchor_root"
        elif domain is None or not domain.get("anchor"):
            reason = "no_anchor_domain"
        else:
            rows_for_ref = trace_by_ref.get(ref, [])
            decisions = {str(row.get("decision")) for row in rows_for_ref}
            functions = [str(row.get("function_type") or row.get("function") or "")
                         for row in rows_for_ref]
            if any(row.get("decision") == "rejected_overlap" and
                   float(row.get("overlap_penalty", 0) or 0) >= 70 for row in rows_for_ref):
                reason = "broad_candidate_rejected"
            elif "rejected_overlap" in decisions:
                reason = "rejected_overlap"
            elif any(row.get("decision") in {"rejected_untyped_function", "rejected_ineligible"}
                     for row in rows_for_ref):
                reason = "untyped_function"
            elif any(row.get("decision") == "rejected_mixed_domain" for row in rows_for_ref):
                reason = "mixed_l1_1_domain"
            elif "rejected_anchor_conflict" in decisions:
                reason = "anchor_conflict"
            else:
                semantic_values = {str(value).upper()
                                   for name in component_nets.get(ref, [])
                                   for value in semantics.get(name, [])}
                reason = ("missing_net_semantics" if not semantic_values - {"GND", "UNKNOWN"}
                          else "no_candidate_generated")
        unresolved_rows.append({"ref": ref, "reason": reason,
                                "l1_1_domain": domain.get("id") if domain else None,
                                "is_anchor": is_anchor})
    # Rebuild ownership from final L2 clusters plus unresolved rows. This is
    # the global invariant consumed by metrics and downstream outputs.
    final_owner = {}
    duplicate_members = []
    for cluster in l1_2_clusters:
        for member in cluster.get("members", []):
            if member in final_owner:
                duplicate_members.append({"ref": member, "kept": final_owner[member],
                                          "duplicate": cluster.get("id")})
            else:
                final_owner[member] = cluster.get("id")
    final_unresolved = [row for row in unresolved_rows if row.get("ref") not in final_owner]
    final_assignment = dict(final_owner)
    final_assignment.update({row["ref"]: None for row in final_unresolved})
    functional_l1_clusters = [row for row in l1_2_clusters
                              if row.get("source") != "anchor_singleton"]
    result = {"mode": "hierarchical", "l2_domains": l1_1_domains,
            "l1_clusters": l1_2_clusters, "functional_l1_clusters": functional_l1_clusters,
            "l1_domains": l1_1_domains,
            "l2_clusters": l1_2_clusters, "functional_l2_clusters": functional_l1_clusters,
            "l1_1_domains": l1_1_domains,
            # Compatibility fields for callers that still use the old names.
            "l1_2_clusters": functional_l1_clusters, "domains": l1_1_domains,
            "clusters": l1_2_clusters,
            "unresolved_components": final_unresolved,
            "assignment": final_assignment,
            "duplicate_ownership": duplicate_members,
            "all_components_once": sorted(final_assignment) == refs and len(final_assignment) == len(refs) and not duplicate_members,
            "hard_links_applied": hard_links,
            "selected_candidates": selected, "decision_trace": trace,
            "motifs": motifs or [],
            "note": "先建立 L2 粗功能域，再由互斥选择器选择 L1 细功能簇；未形成多器件细簇的器件最终作为带原因的 L1 单成员簇保留"}
    if materialize_unresolved_singletons:
        _materialize_unresolved_singletons(result, expected_refs=refs)
    return result


def _materialize_unresolved_singletons(result, *, expected_refs=None):
    """Turn every remaining unresolved component into an auditable L1 singleton.

    ``unresolved_components`` remains an internal/audit list until this step so
    the optional LLM recovery pass can still inspect the unresolved population.
    The final public partition has no unowned components: each fallback member
    carries its original reason on the singleton cluster itself.
    """
    clusters = result.get("l1_clusters", result.get("l2_clusters", []))
    unresolved = list(result.get("unresolved_components") or [])
    existing_refs = {member for cluster in clusters for member in cluster.get("members", [])}
    fallback_rows = []
    for item in unresolved:
        ref = item.get("ref") if isinstance(item, dict) else item
        if not ref or ref in existing_refs:
            continue
        domain = item.get("l1_1_domain") if isinstance(item, dict) else None
        fallback_rows.append({
            "members": [ref],
            "function": "unresolved_component_singleton",
            "function_type": "unresolved_component_singleton",
            "source": "unresolved_singleton",
            "evidence_nets": [],
            "anchor": ref if isinstance(item, dict) and item.get("is_anchor") else None,
            "anchor_policy": ("anchor_included"
                              if isinstance(item, dict) and item.get("is_anchor")
                              else "anchor_excluded"),
            "reason": item.get("reason", "unresolved_component") if isinstance(item, dict) else "unresolved_component",
            "l1_1_domain": [domain] if domain else [],
        })
        existing_refs.add(ref)
    clusters.extend(fallback_rows)
    for index, cluster in enumerate(clusters, 1):
        cluster["id"] = f"L1-{index:03d}"
        cluster["level"] = "L1"
    result["l1_clusters"] = clusters
    result["l2_clusters"] = clusters
    result["clusters"] = clusters
    functional = [cluster for cluster in clusters
                  if len(cluster.get("members", [])) >= 2
                  and cluster.get("source") not in {"anchor_singleton", "unresolved_singleton"}]
    result["functional_l1_clusters"] = functional
    result["functional_l2_clusters"] = functional
    result["l1_2_clusters"] = functional
    diagnostics = []
    for cluster in fallback_rows:
        diagnostics.append({
            "ref": cluster["members"][0],
            "reason": cluster.get("reason", "unresolved_component"),
            "l1_1_domain": (cluster.get("l1_1_domain") or [None])[0],
            "singleton_cluster_id": cluster["id"],
        })
    result["unresolved_diagnostics"] = diagnostics
    result["unresolved_components"] = []
    owner = {}
    duplicate_ownership = []
    for cluster in clusters:
        for ref in cluster.get("members", []):
            if ref in owner:
                duplicate_ownership.append({"ref": ref, "kept": owner[ref],
                                            "duplicate": cluster.get("id")})
            else:
                owner[ref] = cluster.get("id")
    result["assignment"] = owner
    result["duplicate_ownership"] = duplicate_ownership
    expected = sorted(expected_refs or owner)
    result["all_components_once"] = (sorted(owner) == expected
                                      and len(owner) == len(expected)
                                      and not duplicate_ownership)
    result["singleton_fallback_count"] = len(fallback_rows)
    _refresh_l2_children(result)
    return result


def _refresh_l2_children(result):
    """Nest every final L1 cluster under its owning L2 domain.

    This is deliberately run after unresolved singleton materialization, since
    those fallback clusters are also children of the corresponding major
    device domain and must not remain visually detached.
    """
    domains = result.get("l2_domains") or result.get("l1_1_domains") or []
    clusters = result.get("l1_clusters") or result.get("l2_clusters") or []
    domain_by_member = {ref: domain.get("id")
                        for domain in domains
                        for ref in domain.get("members", [])}
    by_domain = defaultdict(list)
    for cluster in clusters:
        ids = {domain_by_member.get(ref) for ref in cluster.get("members", [])}
        ids.discard(None)
        parent_id = next(iter(ids)) if len(ids) == 1 else None
        cluster["parent_l2_domain"] = parent_id
        parent = next((domain for domain in domains if domain.get("id") == parent_id), None)
        cluster["parent_l2_anchor"] = parent.get("anchor") if parent else None
        if parent_id:
            by_domain[parent_id].append(cluster)
    for domain in domains:
        children = sorted(by_domain.get(domain.get("id"), []),
                          key=lambda row: row.get("id", ""))
        domain["children_l1"] = [row.get("id") for row in children]
        domain["children_l1_clusters"] = [
            {"id": row.get("id"), "level": row.get("level", "L1"),
             "members": list(row.get("members", [])),
             "function": row.get("function"),
             "function_type": row.get("function_type"),
             "source": row.get("source"),
             "reason": row.get("reason", "")}
            for row in children
        ]


def run(topology_path, overrides=None, semantic_overrides=None, annotation_path=None, rules_path=None,
        partition_mode="hierarchical", knowledge_base_path=None, learn_soft_constraints=False,
        project_id=None, promote_soft_constraints=True, unresolved_llm=False):
    """Run the deterministic partition pipeline.

    ``annotation_path``, ``learn_soft_constraints``, ``promote_soft_constraints``
    and ``unresolved_llm`` remain accepted for source compatibility with older
    callers, but are deliberately ignored.  The v0.1 runtime is algorithm-only:
    it never reads an LLM annotation, calls an LLM service, or learns/promotes
    model-generated soft constraints during a partition run.
    """
    manifest = load_manifest(knowledge_base_path)
    manifest_path = manifest["_path"]
    topology = topology_path if isinstance(topology_path, dict) else json.loads(Path(topology_path).read_text(encoding="utf-8"))
    validate_topology(topology)
    current_project = infer_project_id(topology, project_id)
    # The old annotation path is intentionally not consumed.  This keeps old
    # integrations import-compatible while making it impossible for model
    # output to affect deterministic roles, semantics, or cluster selection.
    annotation = None
    llm_intermediate = None
    annotation_semantic_evidence = None
    semantics = net_semantics(topology, semantic_overrides, manifest_path)
    roles = infer_roles(topology, semantics, overrides, use_llm_labels=False,
                        manifest_path=manifest_path)
    hits = match_rules(topology, semantics, roles, rules_path, manifest_path)
    motifs = match_patterns(topology, semantics, roles, hits, manifest_path)
    conservative_result = partition(topology, hits, motifs, rules_path, manifest_path)
    # Soft evidence and historical model priors are intentionally disabled.
    # Only topology-derived candidates and approved deterministic rules are
    # allowed to influence the result.
    soft_path = Path(manifest_path).parent / manifest.get("soft_constraints", "soft_constraints.jsonl")
    historical_records = []
    soft_scores = []
    soft_proposals = []
    learning_result = {"enabled": False, "appended": 0, "skipped": 0,
                       "path": str(soft_path.resolve()),
                       "reason": "algorithm_only"}
    promotion_result = {"enabled": False, "reason": "algorithm_only"}
    proposal = propose_disjoint_clusters(topology, motifs, rules_path, manifest_path)
    if partition_mode == "hierarchical":
        result = hierarchical_partition(topology, semantics, roles, hits, motifs, annotation,
                                        soft_scores, rules_path, manifest_path,
                                        materialize_unresolved_singletons=False)
    elif partition_mode == "conservative":
        result = conservative_result
    else:
        raise ValueError("partition_mode must be hierarchical or conservative")
    expected_refs = sorted(c.get("designator") for c in topology.get("components", []) if c.get("designator"))
    # Unresolved components are always materialized locally.  This preserves
    # the one-component/one-cluster contract without a model recovery pass.
    _materialize_unresolved_singletons(result, expected_refs=expected_refs)
    semantic_evidence = net_semantics_with_evidence(topology, semantic_overrides, manifest_path)
    unknown_net_diagnostics = classify_unknown_nets(topology, semantic_evidence)
    return {"status": "ok", "algorithm_only": True, "annotation_review_warnings": [],
            "llm_intermediate": llm_intermediate,
            "net_semantics": semantics, "net_semantics_evidence": semantic_evidence,
            "unknown_net_diagnostics": unknown_net_diagnostics, "roles": roles, "rule_hits": hits,
            "motifs": motifs, "partition": result, "proposal": proposal,
            "soft_evidence": soft_scores, "soft_proposals": soft_proposals,
            "soft_prior_source": str(soft_path.resolve()) if historical_records else None,
            "learned_soft_constraints": learning_result,
            "llm_unresolved_partition": None,
            "soft_constraint_promotion": promotion_result,
            "knowledge_base": {**knowledge_provenance(manifest_path, rules_path),
                               "project_id": current_project,
                               "historical_soft_constraint_count": len(historical_records),
                               "learning_policy": manifest.get("learning_policy", {})},
            "domains": result.get("domains", []),
            "component_metadata": topology.get("components", []),
            "topology_source": topology.get("source", {}),
            "annotation_source": {"mode": "disabled", "reason": "algorithm_only"}}


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("topology", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    data = run(args.topology)
    text = json.dumps(data, ensure_ascii=False, indent=2)
    if args.output: args.output.write_text(text + "\n", encoding="utf-8")
    else: print(text)
