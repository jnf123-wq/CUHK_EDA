"""Build the auditable intermediate representation between LLM labels and partitioning.

The representation keeps the model's raw wording in the annotation while exposing
only validated topology references to downstream code.
"""
from __future__ import annotations

from .taxonomy import normalize_function, normalize_function_tags, normalize_roles


_CANDIDATE_TYPES = {
    "input_voltage_sense": "adc_sampling_cluster",
    "output_voltage_sense": "adc_sampling_cluster",
    "input_current_sense": "adc_sampling_cluster",
    "output_current_sense": "adc_sampling_cluster",
    "adc_filter": "adc_sampling_cluster",
    "adc_reference": "adc_reference_cluster",
    "temperature_sense": "temperature_sensing_cluster",
    "feedback": "feedback_network",
    "compensation": "compensation_network",
    "input_bypass": "input_filter",
    "output_filter": "output_filter",
    "gate_drive_protection": "gate_drive_protection",
    "isolated_gate_drive_power": "gate_drive_power",
    "auxiliary_power": "auxiliary_power",
    "input_power_path": "input_power_path",
    "output_power_path": "output_power_path",
    "power_stage": "power_stage",
    "bootstrap": "bootstrap_network",
    "switching_loop": "switching_loop",
    "controller_decoupling": "controller_decoupling",
    "uart_debug": "user_interface",
    "user_input": "user_interface",
    "fan_control": "fan_control",
}


def _values(value):
    if value is None:
        return []
    if isinstance(value, (list, tuple, set)):
        return [str(item) for item in value if str(item).strip()]
    return [str(value)] if str(value).strip() else []


def _actual_component_nets(topology):
    result = {c.get("designator"): [] for c in topology.get("components", [])}
    for name, endpoints in topology.get("nets", {}).items():
        for endpoint in endpoints or []:
            ref = endpoint.get("c", endpoint.get("designator", endpoint.get("ref")))
            if ref in result:
                result[ref].append(name)
    return {ref: sorted(set(names)) for ref, names in result.items()}


def _candidate_type(function, roles):
    if function in _CANDIDATE_TYPES:
        return _CANDIDATE_TYPES[function]
    role_text = " ".join(roles).lower()
    if "resistor" in role_text and "sense" in role_text:
        return "adc_sampling_cluster"
    if "capacitor" in role_text and "filter" in role_text:
        return "filter_network"
    return "functional_cluster"


def build_intermediate_representation(topology, annotation):
    """Return normalized, topology-validated LLM component evidence."""
    refs = {c.get("designator") for c in topology.get("components", [])}
    actual_nets = _actual_component_nets(topology)
    rows = {row.get("ref"): row for row in (annotation or {}).get("components", [])
            if isinstance(row, dict) and row.get("ref") in refs}
    result = []
    for ref in sorted(refs):
        row = rows.get(ref, {})
        raw_roles, canonical_roles = normalize_roles(row.get("roles", row.get("role", [])))
        raw_tags, canonical_tags = normalize_function_tags(row.get("function_tags", []))
        functions = [normalize_function(value) for value in canonical_tags or raw_tags]
        functions = [value for value in functions if value != "other"]
        standard_function = functions[0] if functions else None
        supplied_nets = _values(row.get("evidence_nets", []))
        # Some model responses put net names inside structured evidence rows.
        # Keep only scalar net-like values here; prose evidence must never be
        # promoted into topology references.
        for evidence in _values(row.get("evidence", [])):
            if evidence in actual_nets.get(ref, []):
                supplied_nets.append(evidence)
        evidence_nets = [name for name in supplied_nets if name in actual_nets.get(ref, [])]
        if not evidence_nets:
            evidence_nets = [name for name in actual_nets.get(ref, [])
                             if str(name).upper() not in {"GND", "AGND", "PGND"}]
        related_values = _values(row.get("related_components"))
        related = sorted({value for value in related_values if value in refs and value != ref})
        confidence = row.get("confidence")
        try:
            confidence = float(confidence) if confidence is not None else None
        except (TypeError, ValueError):
            confidence = None
        result.append({
            "designator": ref,
            "standard_function": standard_function,
            "standard_functions": sorted(set(functions)),
            "raw_function_tags": raw_tags,
            "canonical_function_tags": canonical_tags,
            "roles": canonical_roles,
            "raw_roles": raw_roles,
            "evidence_nets": sorted(set(evidence_nets)),
            "actual_nets": actual_nets.get(ref, []),
            "related_components": related,
            "confidence": confidence,
            "candidate_type": _candidate_type(standard_function, canonical_roles),
            "source": "llm_annotation",
            "warnings": (["missing_function_type"] if not standard_function else []) +
                        (["evidence_nets_fallback_to_actual"] if not _values(row.get("evidence_nets", [])) else []) +
                        (["filtered_related_components"] if len(related) != len(related_values) else []),
        })
    return {"schema": "llm-intermediate-v1", "components": result}
