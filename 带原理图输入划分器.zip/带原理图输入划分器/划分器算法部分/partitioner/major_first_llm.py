"""Prompt and orchestration helpers for major-component-first annotation.

This module does not call a remote model itself.  It prepares deterministic
stages so an adapter can call the configured LLM or replay saved responses.
"""
from __future__ import annotations

import json

try:
    from .bom import major_datasheet_facts
except ImportError:
    from bom import major_datasheet_facts


MAJOR_KINDS = {
    "ic", "mcu", "controller", "power_module", "driver", "connector",
    "isolator", "module", "fpga", "processor"
}


def split_components(topology):
    major, peripheral = [], []
    for component in topology.get("components", []):
        kind = str(component.get("kind", "")).lower()
        name = f"{component.get('name', '')} {component.get('value', '')}".lower()
        if (kind in MAJOR_KINDS or str(component.get("designator", "")).upper().startswith(("U", "IC"))
                or any(x in name for x in ("tps", "mp", "lgs", "mc340", "stm32", "esp32"))):
            major.append(component)
        else:
            peripheral.append(component)
    return major, peripheral


def build_major_prompt(topology, datasheet_facts=None):
    major, _ = split_components(topology)
    datasheet_facts = datasheet_facts if datasheet_facts is not None else major_datasheet_facts(topology)
    return {
        "stage": "major_component_identification",
        "instructions": [
            "识别大器件型号、类别、关键引脚和工作拓扑",
            "优先核对 BOM 提供的数据手册路径或 URL；路径本身只能作为来源记录，不能冒充手册内容",
            "如果 datasheet_text_excerpt 非空，必须以其中可见内容为手册证据；如果读取失败，明确标记 read_status/read_error，不得补写手册事实",
            "仅输出可由拓扑或数据手册支持的事实",
            "为每个事实记录证据和置信度",
            "不要把外围器件直接划入最终簇"
        ],
        "components": major,
        "datasheet_facts": datasheet_facts or []
    }


def build_peripheral_prompt(topology, major_annotation, datasheet_facts=None):
    _, peripheral = split_components(topology)
    datasheet_facts = datasheet_facts if datasheet_facts is not None else major_datasheet_facts(topology)
    return {
        "stage": "peripheral_component_annotation",
        "instructions": [
            "依据已识别的大器件引脚和数据手册事实识别外围器件角色",
            "把手册直接支持、原理图连接推断、元件值推断分别写入 evidence",
            "区分手册直接支持、拓扑推断和经验推断",
            "输出候选簇和软连接，不输出全局硬约束；每条软约束必须包含 confidence、evidence、evidence_source 和 reason",
            "可以输出 datasheet_facts，但只能记录输入数据手册摘录实际支持的事实",
        ],
        "major_annotation": major_annotation,
        "datasheet_facts": datasheet_facts or [],
        "components": peripheral
    }


def merge_staged_annotations(major, peripheral):
    """Merge stage responses while preserving provenance."""
    result = dict(peripheral or {})
    result.setdefault("schema", "llm-annotation-v1")
    result["components"] = list((major or {}).get("components", [])) + list((peripheral or {}).get("components", []))
    result["major_component_annotations"] = (major or {}).get("components", [])
    result["peripheral_component_annotations"] = (peripheral or {}).get("components", [])
    result["datasheet_facts"] = list((major or {}).get("datasheet_facts", [])) + list((peripheral or {}).get("datasheet_facts", []))
    result["soft_links"] = list((major or {}).get("soft_links", [])) + list((peripheral or {}).get("soft_links", []))
    result["candidate_clusters"] = list((major or {}).get("candidate_clusters", [])) + list((peripheral or {}).get("candidate_clusters", []))
    return result


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("topology")
    args = parser.parse_args()
    data = json.loads(open(args.topology, encoding="utf-8").read())
    print(json.dumps(build_major_prompt(data), ensure_ascii=False, indent=2))
