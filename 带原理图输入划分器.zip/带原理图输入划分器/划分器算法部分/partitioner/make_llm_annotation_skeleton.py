"""Build a compact, deterministic input skeleton for LLM annotation."""
from __future__ import annotations


def build(topology):
    components = []
    for component in topology.get("components", []):
        if not isinstance(component, dict):
            continue
        components.append({key: component.get(key) for key in
                           ("designator", "kind", "name", "value", "part_name", "footprint")
                           if component.get(key) not in (None, "")})
    nets = {}
    for name, endpoints in topology.get("nets", {}).items():
        if not isinstance(endpoints, list):
            continue
        nets[str(name)] = [{key: endpoint.get(key) for key in ("c", "pin", "name")
                            if endpoint.get(key) not in (None, "")}
                           for endpoint in endpoints if isinstance(endpoint, dict)]
    return {"schema": "llm-annotation-skeleton-v1", "components": components, "nets": nets,
            "required_fields": ["roles", "function_tags", "confidence"],
            "output_requirements": ["complete_components", "complete_nets", "candidate_clusters", "soft_links"]}
