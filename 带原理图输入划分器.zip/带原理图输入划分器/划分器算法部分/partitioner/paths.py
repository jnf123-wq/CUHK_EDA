"""Paths shared by the command-line tools.

All paths are derived from the installed project location instead of being
tied to a particular user's desktop or drive letter.  Callers may still
override every input/output location through their command-line arguments.
"""
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_INPUT_ROOT = PROJECT_ROOT / "examples"
DEFAULT_OUTPUT_ROOT = PROJECT_ROOT / "outputs"
