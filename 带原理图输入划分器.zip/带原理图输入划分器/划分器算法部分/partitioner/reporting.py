"""Human-readable reports for the two-layer partition results."""
from __future__ import annotations

import csv
import json
from pathlib import Path


def _canonical(clusters):
    return tuple(sorted(tuple(sorted(c.get("members", []))) for c in clusters))


def _ari(clusters_a, clusters_b):
    from math import comb

    labels_a = {ref: i for i, cluster in enumerate(clusters_a) for ref in cluster.get("members", [])}
    labels_b = {ref: i for i, cluster in enumerate(clusters_b) for ref in cluster.get("members", [])}
    refs = sorted(set(labels_a) | set(labels_b))
    n = len(refs)
    if n < 2:
        return 1.0
    count_a, count_b, contingency = {}, {}, {}
    for ref in refs:
        a, b = labels_a.get(ref, f"__unassigned_a__:{ref}"), labels_b.get(ref, f"__unassigned_b__:{ref}")
        count_a[a] = count_a.get(a, 0) + 1
        count_b[b] = count_b.get(b, 0) + 1
        contingency[(a, b)] = contingency.get((a, b), 0) + 1
    index = sum(comb(value, 2) for value in contingency.values())
    sum_a = sum(comb(value, 2) for value in count_a.values())
    sum_b = sum(comb(value, 2) for value in count_b.values())
    total = comb(n, 2)
    expected = sum_a * sum_b / total
    maximum = (sum_a + sum_b) / 2
    return 1.0 if maximum == expected else (index - expected) / (maximum - expected)


def _finding_key(value):
    """Return a deterministic sortable key for scalar or structured findings."""
    if isinstance(value, (dict, list, tuple)):
        return json.dumps(value, ensure_ascii=False, sort_keys=True, default=str)
    return str(value)


def _unique_findings(findings):
    """Deduplicate quality findings without requiring them to be hashable."""
    unique = []
    seen = set()
    for finding in findings:
        key = _finding_key(finding)
        if key in seen:
            continue
        seen.add(key)
        unique.append(finding)
    return sorted(unique, key=_finding_key)


def quality_metrics(result):
    roles = result.get("roles", {})
    metadata = result.get("component_metadata", [])
    refs = {c.get("designator") for c in metadata if c.get("designator")}
    partition = result.get("partition", {})
    intermediate = result.get("llm_intermediate") or {}
    intermediate_components = intermediate.get("components", []) if isinstance(intermediate, dict) else []
    intermediate_typed = sum(bool(c.get("standard_function")) for c in intermediate_components if isinstance(c, dict))
    intermediate_warnings = sum(len(c.get("warnings") or []) for c in intermediate_components if isinstance(c, dict))
    clusters = partition.get("l1_clusters") or partition.get("l2_clusters") or partition.get("l1_2_clusters") or partition.get("clusters", [])
    l1_1_domains = partition.get("l2_domains") or partition.get("l1_domains") or partition.get("l1_1_domains") or partition.get("domains", [])
    l1_2_clusters = clusters
    assigned = [ref for cluster in clusters for ref in cluster.get("members", [])]
    unresolved = partition.get("unresolved_components", [])
    unresolved_refs = [row.get("ref") if isinstance(row, dict) else row for row in unresolved]
    assignment_rows = assigned + [ref for ref in unresolved_refs if ref]
    unique_assignment = len(assignment_rows) == len(set(assignment_rows))
    coverage_matches = not refs or set(assignment_rows) == refs
    complete_assignment = (bool(partition.get("all_components_once")) and unique_assignment and
                           coverage_matches and not partition.get("duplicate_ownership"))
    unknown_roles = sum("unknown_component" in (role.get("roles") or []) for role in roles.values())
    unknown_nets = sum("UNKNOWN" in semantics for semantics in result.get("net_semantics", {}).values())
    unknown_diagnostics = result.get("unknown_net_diagnostics") or {}
    unknown_category_counts = {}
    for row in unknown_diagnostics.values():
        category = row.get("category", "unclassified") if isinstance(row, dict) else "unclassified"
        unknown_category_counts[category] = unknown_category_counts.get(category, 0) + 1
    reviewed = sum(bool(hit.get("review_required")) for hit in result.get("rule_hits", []))
    bom_matches = sum(bool(c.get("bom_match")) for c in metadata)
    ds_refs = sum(bool(c.get("datasheet") or c.get("datasheet_url") or c.get("datasheet_path")) for c in metadata)
    ds_local = sum(bool(c.get("datasheet_exists")) for c in metadata)
    ds_read = sum((c.get("datasheet_read") or {}).get("status") in {"read", "read_html"} for c in metadata)
    sizes = [len(c.get("members", [])) for c in clusters]
    singleton_fallback_count = sum(c.get("source") == "unresolved_singleton" for c in clusters)
    l1_1_sizes = [len(c.get("members", [])) for c in l1_1_domains]
    l1_2_sizes = [len(c.get("members", [])) for c in l1_2_clusters]
    major = [c for c in metadata if c.get("is_major_candidate") or str(c.get("kind", "")).lower() == "ic_module" or str(c.get("designator", "")).upper().startswith(("U", "IC"))]
    major_ds_refs = sum(bool(c.get("datasheet") or c.get("datasheet_url") or c.get("datasheet_path") or (c.get("bom") or {}).get("datasheet")) for c in major)
    # Quality is a gate over input completeness and partition usability, not
    # only the invariant that every component appears once.
    hard_ok = complete_assignment
    input_review = bool(unknown_roles or (unknown_nets and unknown_nets / max(1, len(result.get("net_semantics", {}))) > 0.2))
    clustering_review = bool(sizes and sum(s == 1 for s in sizes) / len(sizes) > 0.8 and len(sizes) > 10)
    findings = list(result.get("annotation_quality_findings") or [])
    if input_review:
        findings.append("input_semantics_incomplete")
    if clustering_review:
        findings.append("mostly_singleton_clusters")
    return {
        "status": "PASS" if hard_ok and not findings else "REVIEW",
        "hard_assignment_gate": "PASS" if hard_ok else "FAIL",
        "input_completeness_gate": "REVIEW" if input_review else "PASS",
        "cluster_usability_gate": "REVIEW" if clustering_review else "PASS",
        "quality_findings": _unique_findings(findings),
        "component_count": len(refs) or len(roles), "cluster_count": len(clusters),
        "all_components_once": complete_assignment,
        "l1_clustered_component_count": len(assigned),
        "l2_clustered_component_count": sum(len(c.get("members", [])) for c in l1_1_domains),
        "l2_unresolved_component_count": len(unresolved),
        "l1_2_clustered_component_count": len(assigned),
        "l1_2_unresolved_component_count": len(unresolved),
        "assignment_count": len(assignment_rows),
        "unique_assignment_count": len(set(assignment_rows)),
        "duplicate_assignment_count": len(assignment_rows) - len(set(assignment_rows)),
        "uncovered_component_count": len(refs - set(assignment_rows)) if refs else 0,
        "unknown_role_count": unknown_roles,
        "unknown_role_rate": unknown_roles / len(roles) if roles else 0.0, "unknown_net_count": unknown_nets,
        "unknown_net_rate": unknown_nets / len(result.get("net_semantics", {})) if result.get("net_semantics") else 0.0,
        "unknown_net_category_counts": unknown_category_counts,
        "review_hit_count": reviewed, "hard_link_count": len(partition.get("hard_links_applied", [])),
        "max_cluster_size": max(sizes) if sizes else 0,
        "singleton_cluster_rate": sum(s == 1 for s in sizes) / len(sizes) if sizes else 0.0,
        "singleton_fallback_count": singleton_fallback_count,
        "l2_domain_count": len(l1_1_domains),
        "l1_cluster_count": len(l1_2_clusters),
        "l1_singleton_rate": sum(s == 1 for s in l1_2_sizes) / len(l1_2_sizes) if l1_2_sizes else 0.0,
        "l1_domain_count": len(l1_1_domains),
        "l1_1_domain_count": len(l1_1_domains),
        "l1_1_singleton_rate": sum(s == 1 for s in l1_1_sizes) / len(l1_1_sizes) if l1_1_sizes else 0.0,
        "l2_cluster_count": len(l1_1_domains),
        "l1_2_cluster_count": len(partition.get("functional_l1_clusters") or partition.get("functional_l2_clusters") or [c for c in l1_2_clusters if c.get("source") != "anchor_singleton"]),
        "l1_2_singleton_rate": sum(s == 1 for s in l1_2_sizes) / len(l1_2_sizes) if l1_2_sizes else 0.0,
        # Keep the two notions separate: unresolved means not in a selected
        # functional L1-2 cluster, while uncovered means absent from the full
        # L1-1/L1-2 assignment altogether.
        "l1_2_unresolved_component_count": len(unresolved),
        "unassigned_component_count": len(refs - set(assignment_rows)) if refs else 0,
        "bom_match_count": bom_matches, "bom_match_rate": bom_matches / len(metadata) if metadata else 0.0,
        "datasheet_reference_count": ds_refs, "datasheet_reference_rate": ds_refs / len(metadata) if metadata else 0.0,
        "local_datasheet_count": ds_local, "local_datasheet_rate": ds_local / len(metadata) if metadata else 0.0,
        "datasheet_read_count": ds_read, "datasheet_read_rate": ds_read / len(metadata) if metadata else 0.0,
        "major_component_count": len(major), "major_datasheet_reference_count": major_ds_refs,
        "major_datasheet_reference_rate": major_ds_refs / len(major) if major else 0.0,
        "llm_intermediate_component_count": len(intermediate_components),
        "llm_intermediate_typed_count": intermediate_typed,
        "llm_intermediate_typed_rate": intermediate_typed / len(intermediate_components) if intermediate_components else 0.0,
        "llm_intermediate_warning_count": intermediate_warnings,
    }


def stability_metrics(result, *, fixed_runs=None, llm_runs=None, reference=None):
    baseline = result.get("partition", {}).get("l1_clusters", result.get("partition", {}).get("l2_clusters", result.get("partition", {}).get("clusters", [])))
    fixed = fixed_runs or [baseline]
    llm = llm_runs or []
    fixed_canonical = [_canonical(x) for x in fixed]
    llm_canonical = [_canonical(x) for x in llm]
    fixed_ari = [_ari(baseline, x) for x in fixed[1:]]
    llm_ari = [_ari(baseline, x) for x in llm[1:]] if llm else []
    metrics = {
        "algorithm_repeat_count": len(fixed),
        "algorithm_exact_match_rate": sum(x == fixed_canonical[0] for x in fixed_canonical) / len(fixed_canonical),
        "algorithm_ari_mean": sum(fixed_ari) / len(fixed_ari) if fixed_ari else 1.0,
        "llm_repeat_count": len(llm),
        "llm_exact_match_rate": (sum(x == llm_canonical[0] for x in llm_canonical) / len(llm_canonical)) if llm_canonical else None,
        "llm_ari_mean": (sum(llm_ari) / len(llm_ari)) if llm_ari else None,
        "llm_stability_status": ("PASS" if len(llm) >= 2 else ("INSUFFICIENT_SAMPLE" if llm else "NOT_RUN")),
        "reference_ari_status": "UNAVAILABLE",
    }
    if reference is not None:
        metrics["reference_ari"] = _ari(baseline, reference.get("clusters", []))
        metrics["reference_name"] = reference.get("name", "unnamed_reference")
        metrics["reference_ari_status"] = "AVAILABLE"
    return metrics


def write_reports(result, output_json, *, fixed_runs=None, llm_runs=None, reference=None):
    output_json = Path(output_json)
    stem = output_json.with_suffix("")
    roles = result.get("roles", {})
    intermediate = result.get("llm_intermediate") or {}
    intermediate_components = intermediate.get("components", []) if isinstance(intermediate, dict) else []
    partition = result.get("partition", {})
    clusters = partition.get("l1_clusters") or partition.get("l2_clusters") or partition.get("l1_2_clusters") or partition.get("clusters", [])
    quality = quality_metrics(result)
    stability = stability_metrics(result, fixed_runs=fixed_runs, llm_runs=llm_runs, reference=reference)
    result["quality"] = quality
    result["stability"] = stability
    output_json.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    l1_csv = stem.with_name(stem.name + "_L1.csv")
    with l1_csv.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f); writer.writerow(["level", "cluster_id", "function", "anchor", "anchor_policy", "member_ref", "roles", "confidence", "source", "reason"])
        for cluster in clusters:
            for ref in cluster.get("members", []):
                role = roles.get(ref, {})
                writer.writerow([cluster.get("level", "L1"), cluster.get("id", ""), cluster.get("function", "L1_function_cluster"), cluster.get("anchor", ""), cluster.get("anchor_policy", ""), ref, ";".join(role.get("roles", [])), role.get("confidence", ""), cluster.get("source", ""), cluster.get("reason", "")])
        for item in partition.get("unresolved_components", []):
            ref = item.get("ref", "")
            role = roles.get(ref, {})
            writer.writerow(["", "", "unresolved_component", "", "", ref, ";".join(role.get("roles", [])), role.get("confidence", ""), "unresolved", item.get("reason", "")])

    l2_domains = partition.get("l2_domains") or partition.get("l1_domains") or partition.get("l1_1_domains") or partition.get("domains", [])
    l2_csv = stem.with_name(stem.name + "_L2.csv")
    with l2_csv.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)
        writer.writerow(["level", "domain_id", "anchor", "member_ref", "assignment_reason", "shared_nets", "semantics", "children_l1"])
        for domain in l2_domains:
            assignments = {row.get("ref"): row for row in domain.get("assignments", []) if isinstance(row, dict)}
            for ref in domain.get("members", []):
                assignment = assignments.get(ref, {})
                shared_nets = assignment.get("shared_nets", [])
                semantics = assignment.get("semantics", [])
                writer.writerow([
                    domain.get("level", "L2"), domain.get("id", ""), domain.get("anchor", ""), ref,
                    domain.get("assignment_reason", ""),
                    ";".join(str(x) for x in shared_nets) if isinstance(shared_nets, (list, tuple)) else shared_nets,
                    ";".join(str(x) for x in semantics) if isinstance(semantics, (list, tuple)) else semantics,
                    ";".join(str(x) for x in domain.get("children_l1", [])),
                ])

    # Keep the former filename for existing consumers; it contains the same
    # L1 rows as the new dedicated L1 file.
    clusters_csv = stem.with_name(stem.name + "_clusters.csv")
    clusters_csv.write_text(l1_csv.read_text(encoding="utf-8-sig"), encoding="utf-8-sig")

    rules_csv = stem.with_name(stem.name + "_rule_hits.csv")
    with rules_csv.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f); writer.writerow(["rule_id", "a", "b", "relation", "status", "shared_nets", "evidence", "review_required", "reason"])
        for hit in result.get("rule_hits", []):
            writer.writerow([hit.get("rule_id", ""), hit.get("a", ""), hit.get("b", ""), hit.get("relation", ""), hit.get("status", ""), ";".join(hit.get("shared_nets", [])), ";".join(hit.get("evidence", [])), hit.get("review_required", False), hit.get("reason", "")])

    soft_csv = stem.with_name(stem.name + "_soft_evidence.csv")
    with soft_csv.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f); writer.writerow(["a", "b", "confidence", "sources", "decision", "hard_already_linked", "reason"])
        for item in result.get("soft_evidence", []):
            writer.writerow([item.get("a", ""), item.get("b", ""), item.get("confidence", ""), ";".join(item.get("sources", [])), item.get("decision", ""), item.get("hard_already_linked", False), ";".join(x.get("reason", "") for x in item.get("evidence", []))])

    trace_csv = stem.with_name(stem.name + "_datasheet_trace.csv")
    with trace_csv.open("w", newline="", encoding="utf-8-sig") as f:
        fields = ["ref", "part", "bom_match", "bom_source", "datasheet", "datasheet_url", "datasheet_path", "datasheet_exists", "datasheet_read_status", "datasheet_read_error", "datasheet_pages", "datasheet_text_chars", "is_major_candidate"]
        writer = csv.DictWriter(f, fieldnames=fields); writer.writeheader()
        for c in result.get("component_metadata", []):
            if not isinstance(c, dict):
                continue
            bom = c.get("bom") or {}
            if not isinstance(bom, dict):
                bom = {}
            read = c.get("datasheet_read") or {}
            source = result.get("topology_source", {})
            if not isinstance(source, dict):
                source = {}
            writer.writerow({"ref": c.get("designator", ""), "part": c.get("manufacturer_part") or c.get("bom_part") or c.get("name", ""), "bom_match": bool(c.get("bom_match")), "bom_source": bom.get("bom_source", source.get("bom", "")), "datasheet": c.get("datasheet") or bom.get("datasheet", ""), "datasheet_url": c.get("datasheet_url") or bom.get("datasheet_url", ""), "datasheet_path": c.get("datasheet_path") or bom.get("datasheet_path", ""), "datasheet_exists": bool(c.get("datasheet_exists") or bom.get("datasheet_exists")), "datasheet_read_status": read.get("status", "not_read"), "datasheet_read_error": read.get("error", ""), "datasheet_pages": read.get("pages", 0), "datasheet_text_chars": read.get("chars", 0), "is_major_candidate": str(c.get("kind", "")).lower() in {"ic_module", "mcu", "controller", "power_module", "driver", "processor", "fpga"} or str(c.get("designator", "")).upper().startswith(("U", "IC"))})

    intermediate_csv = None
    if intermediate_components:
        intermediate_csv = stem.with_name(stem.name + "_llm_intermediate.csv")
        with intermediate_csv.open("w", newline="", encoding="utf-8-sig") as f:
            fields = ["designator", "standard_function", "standard_functions", "raw_function_tags", "canonical_function_tags", "roles", "raw_roles", "evidence_nets", "actual_nets", "related_components", "confidence", "candidate_type", "source", "warnings"]
            writer = csv.DictWriter(f, fieldnames=fields)
            writer.writeheader()
            for item in intermediate_components:
                if not isinstance(item, dict):
                    continue
                row = {key: item.get(key, "") for key in fields}
                for key in ("standard_functions", "raw_function_tags", "canonical_function_tags", "roles", "raw_roles", "evidence_nets", "actual_nets", "related_components", "warnings"):
                    value = row.get(key, "")
                    row[key] = ";".join(str(x) for x in value) if isinstance(value, (list, tuple)) else value
                writer.writerow(row)

    quality_csv = stem.with_name(stem.name + "_quality_stability.csv")
    with quality_csv.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f); writer.writerow(["metric", "value"])
        for group in (quality, stability):
            for key, value in group.items(): writer.writerow([key, value])

    report = stem.with_name(stem.name + "_report.md")
    lines = [f"- L2 粗功能域：{quality['l2_domain_count']} 个", f"- L1 细功能簇：{quality['l1_cluster_count']} 个（多成员功能簇：{quality['l1_2_cluster_count']} 个；单例率：{quality['l1_singleton_rate']:.3f}；保底单例：{quality['singleton_fallback_count']} 个）", f"- 尚未形成可靠 L1 多器件细功能簇：{quality['l2_unresolved_component_count']} 个器件（均已转为单成员簇）"]
    reference_line = (f"- 与人工参考分区的 ARI：`{stability['reference_ari']:.6f}`（{stability['reference_name']}）"
                      if stability.get("reference_ari_status") == "AVAILABLE"
                      else "- 与人工参考分区的 ARI：`未提供参考标签`")
    lines = ["# PCB 两层功能分区总结报告", "", "- 运行模式：`algorithm_only`（不调用 LLM、不读取模型标注或历史软先验）。", "- 层级定义：L2 为大器件父域，L1 为挂载在 L2 下的细功能簇。", f"- 质量状态：`{quality['status']}`", f"- 器件/最终 L1 簇：{quality['component_count']} / {quality['cluster_count']}", f"- 每个器件恰好一次：`{quality['all_components_once']}`（硬性归属判据：`{quality['hard_assignment_gate']}`）", f"- 输入完整性：`{quality['input_completeness_gate']}`；簇可用性：`{quality['cluster_usability_gate']}`", f"- 最大 L1 簇规模：{quality['max_cluster_size']}；L1 单例簇比例：{quality['singleton_cluster_rate']:.3f}；保底单例：{quality['singleton_fallback_count']}", f"- 未知角色/网络比例：{quality['unknown_role_rate']:.3f} / {quality['unknown_net_rate']:.3f}", f"- 固定算法重复稳定性：exact={stability['algorithm_exact_match_rate']:.3f}, ARI={stability['algorithm_ari_mean']:.3f}（n={stability['algorithm_repeat_count']}）", reference_line, "（重复运行 ARI 只表示一致性，不表示正确率。）", "", "## L2 大器件父域", "", "|L2 域|大器件根|成员|挂载的 L1 簇|", "|---|---|---|---|"]
    for domain in l2_domains:
        lines.append(f"| {domain.get('id', '')} | {domain.get('anchor') or 'unresolved'} | {', '.join(domain.get('members', []))} | {', '.join(domain.get('children_l1', []))} |")
    lines += ["", "## L1 细功能簇", "", "|簇|器件|来源|原因|", "|---|---|---|---|"]
    for cluster in clusters: lines.append(f"| {cluster.get('id', '')} ({cluster.get('function', '')}) | {', '.join(cluster.get('members', []))} | {cluster.get('source', '')} | {cluster.get('reason', '')} |")
    unresolved = partition.get("unresolved_components", [])
    if unresolved:
        lines += ["", "## 尚未形成细功能簇的器件", "", "|器件|L2 粗功能簇|原因|", "|---|---|---|"]
        for item in unresolved:
            lines.append(f"| {item.get('ref', '')} | {item.get('l1_domain') or item.get('l1_1_domain') or '未分配'} | {item.get('reason', '')} |")
    lines += ["", "## 审核提示", ""]
    review_hits = [h for h in result.get("rule_hits", []) if h.get("review_required")]
    lines.extend([f"- `{h['rule_id']}` ({h['a']}, {h['b']})：{', '.join(h.get('review_reasons', []))}" for h in review_hits] or ["- 当前规则命中没有额外审核提示。"])
    lines += ["", "详细数据见同目录的 `_L1.csv`、`_L2.csv`、`_rule_hits.csv`、`_soft_evidence.csv`、`_datasheet_trace.csv` 和 `_quality_stability.csv`。"]
    report.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return {"clusters_csv": clusters_csv, "l1_csv": l1_csv, "l2_csv": l2_csv, "rule_hits_csv": rules_csv, "soft_evidence_csv": soft_csv, "datasheet_trace_csv": trace_csv, "intermediate_csv": intermediate_csv, "quality_stability_csv": quality_csv, "report": report}
