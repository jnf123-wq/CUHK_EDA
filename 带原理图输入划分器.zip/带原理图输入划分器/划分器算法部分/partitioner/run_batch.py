"""Batch entry point for the deterministic, algorithm-only partitioner."""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

from .enet_to_topology import convert
from .knowledge_base import DEFAULT_MANIFEST, load_manifest
from .l1_partition import run, validate_topology
from .reporting import quality_metrics, stability_metrics, write_reports


def run_batch(source: Path, output: Path, *, api_key=None, model="", base_url="",
              project_files=None, llm_repeats=0, algorithm_repeats=2,
              manifest_path=None, rules_path=None, llm_timeout=None,
              bom_root=None, datasheet_timeout=30):
    """Run every schematic through local topology rules only.

    Legacy LLM-shaped keyword arguments are accepted for old scripts but are
    intentionally ignored. No API key is read and no network request occurs.
    """
    source, output = Path(source).resolve(), Path(output).resolve()
    output.mkdir(parents=True, exist_ok=True)
    manifest = Path(manifest_path) if manifest_path else DEFAULT_MANIFEST
    load_manifest(manifest)  # fail early on a malformed local knowledge base
    files = [Path(p) for p in project_files] if project_files else sorted(source.rglob("*.enet"))
    files = [p for p in files if p.is_file() and "pcb" not in p.parent.name.lower()]
    run_dir = output / "offline"
    run_dir.mkdir(parents=True, exist_ok=True)
    rows = []
    for schematic in files:
        project = schematic.stem
        target = run_dir / f"{project}_l1.json"
        try:
            topology = convert(schematic)
            validate_topology(topology)
            result = run(topology, project_id=project, knowledge_base_path=manifest,
                         rules_path=rules_path, learn_soft_constraints=False,
                         unresolved_llm=False)
            fixed = [result["partition"].get("l1_clusters", result["partition"].get("clusters", []))]
            for _ in range(max(0, int(algorithm_repeats) - 1)):
                repeated = run(topology, project_id=project, knowledge_base_path=manifest,
                               rules_path=rules_path, learn_soft_constraints=False,
                               unresolved_llm=False)
                fixed.append(repeated["partition"].get("l1_clusters", repeated["partition"].get("clusters", [])))
            result["algorithm_only"] = True
            result["batch_input"] = {"schematic_enet": str(schematic), "project": project,
                                      "accepted_input_types": ["schematic.enet"]}
            result["llm_call"] = {"provider": None, "attempted": False,
                                   "succeeded": False, "disabled": True}
            reports = write_reports(result, target, fixed_runs=fixed, llm_runs=None)
            quality = quality_metrics(result)
            stability = stability_metrics(result, fixed_runs=fixed, llm_runs=None)
            rows.append({"project": project, "schematic": str(schematic), "run_mode": "offline",
                         "component_count": quality["component_count"], "l2_domain_count": quality["l2_domain_count"],
                         "l1_cluster_count": quality["l1_cluster_count"], "multi_member_l1_count": quality["l1_2_cluster_count"],
                         "singleton_fallback_count": quality.get("singleton_fallback_count", 0),
                         "unknown_net_rate": quality["unknown_net_rate"],
                         "unassigned_component_count": quality["unassigned_component_count"],
                         "all_components_once": quality["all_components_once"], "quality_status": quality["status"],
                         "algorithm_exact_match_rate": stability["algorithm_exact_match_rate"],
                         "algorithm_ari_mean": stability["algorithm_ari_mean"],
                         "llm_exact_match_rate": None, "llm_ari_mean": None,
                         "json": str(target), "report": str(reports["report"]),
                         "l1_csv": str(reports["l1_csv"]), "l2_csv": str(reports["l2_csv"]), "error": ""})
        except Exception as exc:
            rows.append({"project": project, "schematic": str(schematic), "run_mode": "failed",
                         "error": f"{type(exc).__name__}: {exc}"})
    fields = sorted({key for row in rows for key in row}) or ["project", "run_mode", "error"]
    with (run_dir / "batch_summary.csv").open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader(); writer.writerows(rows)
    (run_dir / "batch_summary.json").write_text(json.dumps(rows, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (run_dir / "llm_call_summary.json").write_text(json.dumps({
        "provider": None, "attempted": False, "disabled": True,
        "successful_projects": 0, "failed_projects": 0, "errors": []
    }, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return rows, run_dir


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--knowledge-base", type=Path)
    parser.add_argument("--rules", type=Path)
    parser.add_argument("--algorithm-repeats", type=int, default=2)
    parser.add_argument("--offline", action="store_true", help="compatibility no-op")
    parser.add_argument("--api-key-file", type=Path, help="compatibility no-op")
    parser.add_argument("--model", default="", help="compatibility no-op")
    parser.add_argument("--base-url", default="", help="compatibility no-op")
    parser.add_argument("--llm-repeats", type=int, default=0, help="compatibility no-op")
    parser.add_argument("--llm-timeout", type=int, default=None, help="compatibility no-op")
    args = parser.parse_args(argv)
    rows, run_dir = run_batch(args.source, args.output, algorithm_repeats=args.algorithm_repeats,
                              manifest_path=args.knowledge_base, rules_path=args.rules)
    modes = {}
    for row in rows:
        modes[row["run_mode"]] = modes.get(row["run_mode"], 0) + 1
    print(json.dumps({"run_mode": "offline", "run_modes": modes,
                      "projects": len(rows), "output": str(run_dir)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
