"""Fuse real-time LLM suggestions and historical project priors.

Soft evidence is deliberately separate from approved hard rules.  It can
produce reviewable proposals and scores, but cannot silently change the final
hard partition.
"""
from __future__ import annotations

from collections import defaultdict
import json
from pathlib import Path

try:
    from .taxonomy import as_values, normalize_function
except ImportError:
    from taxonomy import as_values, normalize_function


def _confidence(value, default=0.0):
    try:
        return max(0.0, min(1.0, float(value)))
    except (TypeError, ValueError):
        return default


def _component_map(topology):
    return {c["designator"]: c for c in topology.get("components", [])}


def _pairs(values):
    for group in values or []:
        if isinstance(group, dict):
            group = group.get("members", [])
        if isinstance(group, (list, tuple)) and len(group) >= 2:
            for i, left in enumerate(group):
                for right in group[i + 1:]:
                    yield str(left), str(right)


def load_priors(path):
    if not path:
        return {}
    p = Path(path)
    if not p.exists():
        return {}
    value = json.loads(p.read_text(encoding="utf-8"))
    return value if isinstance(value, dict) else {}


def _current_descriptors(topology, annotation):
    components = _component_map(topology)
    rows = {
        row.get("ref"): row for row in (annotation or {}).get("components", [])
        if isinstance(row, dict) and row.get("ref")
    }
    descriptors = {}
    for ref, component in components.items():
        row = rows.get(ref, {})
        roles = row.get("roles", row.get("role", component.get("llm_roles", [])))
        if isinstance(roles, str):
            roles = [roles]
        tags = row.get("function_tags", component.get("function_tags", []))
        if isinstance(tags, str):
            tags = [tags]
        descriptors[ref] = {
            "kind": str(component.get("kind", "")),
            "roles": set(str(value) for value in roles if value),
            "function_tags": set(str(value) for value in tags if value),
        }
    return descriptors


def _signature_matches(signature, descriptor):
    if not isinstance(signature, dict):
        return False
    expected_roles = set(signature.get("roles", []))
    expected_tags = set(signature.get("function_tags", []))
    expected_kind = str(signature.get("kind", ""))
    if expected_roles and not expected_roles.intersection(descriptor["roles"]):
        return False
    if expected_tags and not expected_tags.intersection(descriptor["function_tags"]):
        return False
    return not expected_kind or expected_kind == descriptor["kind"]


def _historical_pairs(prior, topology=None, annotation=None):
    result = []
    for key in ("soft_links", "candidate_clusters", "clusters"):
        values = prior.get(key, []) if isinstance(prior, dict) else []
        for a, b in _pairs(values):
            result.append((a, b, "historical_prior", 0.7, ["historical_project"]))
    # The active append-only store keeps exact refs and role signatures.  Exact
    # refs are preferred when a project reuses them; otherwise signatures allow
    # evidence to transfer across projects with different reference names.
    refs = set(_component_map(topology)) if topology else set()
    descriptors = _current_descriptors(topology, annotation) if topology else {}
    for record in prior.get("soft_constraints", []) if isinstance(prior, dict) else []:
        members = record.get("members", []) if isinstance(record, dict) else []
        signatures = record.get("member_signatures", []) if isinstance(record, dict) else []
        confidence = _confidence(record.get("confidence"), .65)
        evidence = list(record.get("evidence", [])) if isinstance(record, dict) else []
        evidence.append("historical_project")
        source = record.get("source", "knowledge_base") if isinstance(record, dict) else "knowledge_base"
        metadata = {"function": record.get("function_type", ""),
                    "l1_1_domain": record.get("l1_1_domain", ""),
                    "evidence_nets": record.get("evidence_nets", []),
                    "shared_semantics": record.get("evidence_nets", []),
                    "review_status": record.get("review_status", "candidate")}
        # A historical rule is reusable only when its functional evidence is
        # compatible with the current topology.  Exact references are still
        # preferred, but a stored function/net scope must not silently turn a
        # same-kind passive into a cross-domain link.
        function_type = str(record.get("function_type") or "").lower()
        evidence_nets = {str(value).upper() for value in as_values(record.get("evidence_nets", [])) if value}
        current_net_names = set(topology.get("nets", {})) if topology else set()
        current_semantics = {
            str(semantic).upper()
            for values in (annotation or {}).get("nets", {}).values()
            if isinstance(values, dict)
            for semantic in values.get("semantics", [])
        }
        current_semantics.update(str(name).upper() for name in current_net_names)
        if evidence_nets and current_semantics and not evidence_nets.intersection(current_semantics):
            continue
        if len(members) >= 2 and refs and all(member in refs for member in members):
            for index, left in enumerate(members):
                for right in members[index + 1:]:
                    result.append((left, right, source, confidence, evidence, metadata))
            continue
        if len(signatures) < 2 or not descriptors:
            continue
        candidates = [
            [ref for ref, descriptor in descriptors.items() if _signature_matches(signature, descriptor)]
            for signature in signatures
        ]
        for index, left_refs in enumerate(candidates):
            for right_refs in candidates[index + 1:]:
                for left in left_refs:
                    for right in right_refs:
                        if left != right:
                            result.append((left, right, source, confidence, evidence, metadata))
    # Reconstructed annotations may store candidate groups under components.
    for row in prior.get("components", []) if isinstance(prior, dict) else []:
        group = row.get("candidate_cluster") or row.get("cluster_members")
        if group:
            for a, b in _pairs([group]):
                result.append((a, b, "historical_prior", _confidence(row.get("confidence"), .65),
                               row.get("evidence", ["historical_project"])))
    return result


def collect_soft_evidence(topology, annotation=None, prior=None):
    """Return normalized pair evidence with no hard partition side effects."""
    refs = set(_component_map(topology))
    evidence = []
    annotation = annotation or {}
    for key in ("soft_links", "links", "candidate_links"):
        for item in annotation.get(key, []) or []:
            members = item.get("members") if isinstance(item, dict) else None
            if members is None and isinstance(item, dict):
                members = [item.get("a"), item.get("b")]
            for a, b in _pairs([members]):
                if a in refs and b in refs:
                    evidence.append({"a": a, "b": b,
                                     "source": item.get("evidence_source", item.get("source", "llm_realtime")),
                                     "confidence": _confidence(item.get("confidence")),
                                     "evidence": item.get("evidence", []),
                                     "evidence_nets": item.get("evidence_nets", []),
                                     "shared_semantics": item.get("shared_semantics", []),
                                     "function": item.get("function", ""),
                                     "reason": item.get("reason", "")})
    for item in annotation.get("candidate_clusters", []) or []:
        if not isinstance(item, dict):
            continue
        for a, b in _pairs([item.get("members", [])]):
            if a in refs and b in refs:
                evidence.append({"a": a, "b": b,
                                 "source": item.get("evidence_source", item.get("source", "llm_candidate_cluster")),
                                 "confidence": _confidence(item.get("confidence")),
                                 "evidence": item.get("evidence", []),
                                 "evidence_nets": item.get("evidence_nets", []),
                                 "shared_semantics": item.get("shared_semantics", []),
                                 "function": item.get("function", ""),
                                 "reason": item.get("reason", "")})
    for historical in _historical_pairs(prior or {}, topology, annotation):
        a, b, source, confidence, evidence_items = historical[:5]
        metadata = historical[5] if len(historical) > 5 else {}
        if a in refs and b in refs:
            evidence.append({"a": a, "b": b, "source": source,
                             "confidence": confidence, "evidence": evidence_items,
                             "reason": "历史项目相似候选关系", **metadata})
    return evidence


def score_pairs(topology, annotation=None, prior=None, hard_hits=None):
    """Aggregate soft evidence and return explainable pair scores."""
    by_pair = defaultdict(list)
    for item in collect_soft_evidence(topology, annotation, prior):
        key = tuple(sorted((item["a"], item["b"])))
        by_pair[key].append(item)
    hard_pairs = {tuple(sorted((h["a"], h["b"]))) for h in (hard_hits or [])
                  if h.get("relation") == "must_link" and h.get("status") == "approved"}
    result = []
    for (a, b), items in sorted(by_pair.items()):
        sources = {x["source"] for x in items}
        # A pair can be mentioned by more than one functional explanation
        # (for example a resistor on both VOUT and FB).  Keep every label and
        # its evidence instead of letting classify_soft_candidate() choose
        # the first matching label and silently discard the other one.
        function_items = defaultdict(list)
        for item in items:
            labels = set()
            direct = classify_soft_candidate(item)
            if direct != "other":
                labels.add(direct)
            for nested in item.get("evidence", []) or []:
                if isinstance(nested, dict):
                    nested_function = classify_soft_candidate(nested)
                    if nested_function != "other":
                        labels.add(nested_function)
            if not labels:
                labels.add("other")
            for label in labels:
                function_items[label].append(item)
        functions = sorted(function_items)
        evidence_nets = set()
        shared_semantics = set()
        for item in items:
            evidence_nets.update(str(value) for value in as_values(item.get("evidence_nets", [])) if value)
            shared_semantics.update(str(value) for value in as_values(item.get("shared_semantics", [])) if value)
            for nested in item.get("evidence", []) or []:
                if not isinstance(nested, dict):
                    continue
                evidence_nets.update(str(value) for value in as_values(nested.get("evidence_nets", [])) if value)
                shared_semantics.update(str(value) for value in as_values(nested.get("shared_semantics", [])) if value)
        function_confidences = {
            label: round(1.0 - __import__("math").prod(
                1.0 - _confidence(item.get("confidence"))
                for item in function_items[label]
            ), 6)
            for label in functions
        }
        # Independent sources increase confidence, but never above 1.
        confidence = 1.0 - __import__("math").prod(1.0 - _confidence(x["confidence"]) for x in items)
        if len(sources) > 1:
            confidence = min(1.0, confidence + 0.05)
        result.append({"a": a, "b": b, "confidence": round(confidence, 6),
                       "sources": sorted(sources), "evidence_source": sorted(sources), "evidence": items,
                       "functions": functions,
                       "function_confidences": function_confidences,
                       "function_evidence": {
                           label: function_items[label] for label in functions
                       },
                       "evidence_nets": sorted(evidence_nets),
                       "shared_semantics": sorted(shared_semantics),
                       "hard_already_linked": (a, b) in hard_pairs,
                       "decision": "hard_linked" if (a, b) in hard_pairs else
                                  ("proposal" if confidence >= .75 else "evidence_only")})
    return result


def classify_soft_candidate(item, roles=None, semantics=None, topology=None):
    """Classify a soft relation into a functional candidate family."""
    item = item if isinstance(item, dict) else {}
    labels = [item.get(key, "") for key in
              ("function", "function_type", "cluster_id", "candidate_id", "name",
               "reason", "evidence_source")]
    text = " ".join(str(value) for value in labels if value).lower()
    for value in labels:
        normalized = normalize_function(value)
        if normalized != "other":
            return normalized
    mapping = (
        ("input_voltage_sense", ("input_voltage_sense", "input voltage sense", "输入电压采样", "输入电压分压采样", "输入电压检测")),
        ("output_voltage_sense", ("output_voltage_sense", "output voltage sense", "输出电压采样", "输出电压分压采样", "输出电压检测")),
        ("input_current_sense", ("input_current_sense", "input current sense", "输入电流采样", "输入电流检测")),
        ("output_current_sense", ("output_current_sense", "output current sense", "输出电流采样", "输出电流检测")),
        ("adc_reference", ("adc_reference", "adc reference", "模拟参考", "参考电压", "2v5_reference")),
        ("temperature_sense", ("temperature_sense", "temperature sense", "temperature monitor", "温度检测", "温度传感", "温度监测")),
        ("gate_drive_protection", ("gate_drive_protection", "gate drive and protection", "栅极驱动与保护", "栅极驱动")),
        ("isolated_gate_drive_power", ("isolated_gate_drive_power", "隔离栅极驱动供电", "isolated dc/dc")),
        ("auxiliary_power", ("auxiliary_power", "aux power", "5v_supply", "辅助电源", "辅助5v电源", "辅助 5v 电源")),
        ("uart_debug", ("uart_debug", "uart", "debug port", "串口", "调试接口")),
        ("user_input", ("user_input", "user input encoder", "用户输入", "旋转编码器", "用户交互")),
        ("fan_control", ("fan_control", "fan control", "风扇控制")),
        ("input_power_path", ("input_power_path", "input power path", "输入功率路径")),
        ("output_power_path", ("output_power_path", "output power path", "输出功率路径")),
        ("power_stage", ("power_stage", "power stage switching", "升降压功率级", "功率级")),
        ("input_bypass", ("input_bypass", "input decoupl", "vin")),
        ("output_filter", ("output_filter", "output decoupl", "vout", "vbat")),
        ("feedback", ("feedback", "fb", "sense")),
        ("compensation", ("compensation", "comp", "soft_start")),
        ("bootstrap", ("bootstrap", "boot")),
        ("switching_loop", ("switching_loop", "power_stage", "inductor", "sw")),
    )
    for label, needles in mapping:
        if any(needle in text for needle in needles):
            return label
    shared = {str(value).upper() for value in as_values(item.get("shared_semantics", [])) if value}
    for semantic, function in (("VIN", "input_bypass"), ("VOUT", "output_filter"),
                               ("VBAT", "output_filter"), ("BAT", "output_filter"),
                               ("FB", "feedback"), ("COMP", "compensation"),
                               ("BOOT", "bootstrap"), ("SW", "switching_loop")):
        if semantic in shared:
            return function
    semantic_map = {"VIN": "input_bypass", "VOUT": "output_filter",
                    "VBAT": "output_filter", "BAT": "output_filter",
                    "FB": "feedback", "COMP": "compensation",
                    "BOOT": "bootstrap", "SW": "switching_loop"}
    candidates = []
    if isinstance(item, dict):
        for key in ("evidence_nets", "nets"):
            values = as_values(item.get(key, []))
            for name in values:
                name = str(name).upper()
                for token, function in semantic_map.items():
                    if token in name:
                        candidates.append(function)
        for evidence in item.get("evidence", []) or []:
            if isinstance(evidence, dict):
                classified = classify_soft_candidate(evidence, roles, semantics, topology)
                if classified != "other":
                    candidates.append(classified)
    for function in ("input_bypass", "output_filter", "feedback", "compensation",
                     "bootstrap", "switching_loop"):
        if function in candidates:
            return function
    return "other"


def proposal_clusters(topology, pair_scores, hard_clusters=None, threshold=.75):
    """Build non-overlapping review proposals without modifying final clusters."""
    refs = sorted(_component_map(topology))
    parent = {r: r for r in refs}
    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x
    def union(a, b):
        a, b = find(a), find(b)
        if a != b:
            parent[b] = a
    for score in sorted(pair_scores, key=lambda x: (-x["confidence"], x["a"], x["b"])):
        if score["confidence"] >= threshold and not score["hard_already_linked"]:
            union(score["a"], score["b"])
    groups = defaultdict(list)
    for ref in refs:
        groups[find(ref)].append(ref)
    return [{"id": f"SP-{i:03d}", "members": members,
             "confidence": round(min((s["confidence"] for s in pair_scores
                                       if set((s["a"], s["b"])).issubset(members)), default=0.0), 6)}
            for i, members in enumerate(sorted(groups.values(), key=lambda x: x[0]), 1)]
