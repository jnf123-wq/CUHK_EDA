"""Shared vocabulary for LLM labels and deterministic partition logic.

The annotation format intentionally keeps the model's original words.  This
module adds a small, stable vocabulary beside those words so downstream code
does not have to know every Chinese or English phrasing used by the model.
"""
from __future__ import annotations

import re


ROLE_ALIASES = {
    "controller": "mcu_controller",
    "mcu": "mcu_controller",
    "main_mcu": "mcu_controller",
    "main_controller": "mcu_controller",
    "controller_mcu": "mcu_controller",
    "controller/mcu": "mcu_controller",
    # DeepSeek sometimes emits the functional role as a component role. Keep
    # the original wording in the raw annotation, but give the selector one
    # stable vocabulary for controller and sensing paths.
    "main_control": "mcu_controller",
    "microcontroller": "mcu_controller",
    "switch_controller": "switching_controller",
    "input_voltage_divider_resistor": "input_voltage_sense_resistor",
    "input_voltage_divider_low_resistor": "input_voltage_sense_resistor",
    "input_voltage_divider_high_resistor": "input_voltage_sense_resistor",
    "input_voltage_adc_series_resistor": "input_voltage_sense_resistor",
    "output_voltage_divider_resistor": "output_voltage_sense_resistor",
    "output_voltage_divider_low_resistor": "output_voltage_sense_resistor",
    "output_voltage_divider_high_resistor": "output_voltage_sense_resistor",
    "output_voltage_adc_series_resistor": "output_voltage_sense_resistor",
    "input_current_adc_series_resistor": "input_current_sense_resistor",
    "output_current_adc_series_resistor": "output_current_sense_resistor",
    "power_mosfet_current_sense_resistor": "power_current_sense_resistor",
    "inductor_current_sense_resistor": "inductor_current_sense_resistor",
    "input_current_sense_amplifier": "input_current_sense_amplifier",
    "output_current_sense_amplifier": "output_current_sense_amplifier",
    "adc_filter_capacitor": "adc_filter_capacitor",
    "isolation_output_filter_capacitor": "isolated_gate_drive_capacitor",
    "gate_drive_speedup_diode": "gate_drive_protection_diode",
    "gate_protection_tvs": "gate_drive_protection_diode",
    "gate_drive_protection_resistor": "gate_drive_protection_resistor",
    "gate_resistor": "gate_drive_resistor",
    "gate_turn_off_resistor": "gate_drive_resistor",
    "gate_driver_input_resistor": "gate_drive_resistor",
    "gate_pull_down_resistor": "gate_drive_resistor",
    "low_side_gate_zener": "gate_drive_protection_diode",
    "high_side_gate_zener": "gate_drive_protection_diode",
    "low_side_gate_driver": "gate_driver",
    "high_side_gate_driver": "gate_driver",
    "low_side_isolated_dcdc": "isolated_gate_drive_power",
    "high_side_isolated_dcdc": "isolated_gate_drive_power",
    "auxiliary_5v_regulator": "auxiliary_power_module",
    "aux_power_or_ing_diode": "auxiliary_power_diode",
    "bulk_decoupling_capacitor": "ic_decoupling_capacitor",
    "decoupling_capacitor": "ic_decoupling_capacitor",
    "input_filter_capacitor": "input_filter_capacitor",
    "output_filter_capacitor": "output_filter_capacitor",
    "encoder_filter_capacitor": "user_interface_filter",
    "temperature_sensor_output_resistor": "temperature_sense_resistor",
    "voltage_reference": "adc_reference",
    "temperature_sensor": "temperature_sensor",
    "main_mcu": "mcu_controller",
    "power_module": "auxiliary_power_module",
    "dc_dc_converter": "auxiliary_power_module",
    "isolated_dc_dc": "isolated_gate_drive_power",
    "isolated_dcdc": "isolated_gate_drive_power",
    "inductor": "power_inductor",
    "power_mosfet": "power_mosfet",
    "gate_driver": "gate_driver",
    "low_side_gate_driver": "gate_driver",
    "high_side_gate_driver": "gate_driver",
    "half_bridge_gate_driver": "gate_driver",
    "isolated_gate_driver": "gate_driver",
    "input_power_connector": "input_connector",
    "power_input_connector": "input_connector",
    "output_power_connector": "output_connector",
    "auxiliary_5v_regulator": "auxiliary_power_module",
    "auxiliary_regulator": "auxiliary_power_module",
    "aux_power_regulator": "auxiliary_power_module",
    "voltage_reference": "adc_reference",
    "current_sense_amplifier": "current_sense_amplifier",
    "temperature_sensor": "temperature_sensor",
}


_FUNCTION_ALIASES = {
    "input_bypass": "input_bypass",
    "output_filter": "output_filter",
    "feedback": "feedback",
    "compensation": "compensation",
    "bootstrap": "bootstrap",
    "switching_loop": "switching_loop",
    "power_stage_switching": "power_stage",
    "power_stage": "power_stage",
    "input_voltage_sense": "input_voltage_sense",
    "input_voltage_sensing": "input_voltage_sense",
    "input_voltage_divider": "input_voltage_sense",
    "output_voltage_sense": "output_voltage_sense",
    "output_voltage_sensing": "output_voltage_sense",
    "output_voltage_divider": "output_voltage_sense",
    "input_current_sense": "input_current_sense",
    "input_current_sensing": "input_current_sense",
    "output_current_sense": "output_current_sense",
    "output_current_sensing": "output_current_sense",
    "power_current_sense": "power_current_sense",
    "inductor_current_sense": "inductor_current_sense",
    "adc_filter": "adc_filter",
    "adc_reference": "adc_reference",
    "temperature_sense": "temperature_sense",
    "temperature_monitor": "temperature_sense",
    "gate_drive_protection": "gate_drive_protection",
    "low_side_gate_drive": "gate_drive_protection",
    "high_side_gate_drive": "gate_drive_protection",
    "gate_drive_low_side": "gate_drive_protection",
    "gate_drive_high_side": "gate_drive_protection",
    "pwm_gate_drive_low": "gate_drive_protection",
    "pwm_gate_drive_high": "gate_drive_protection",
    "isolated_gate_drive_power": "isolated_gate_drive_power",
    "auxiliary_power": "auxiliary_power",
    "aux_power": "auxiliary_power",
    "5v_supply": "auxiliary_power",
    "uart_debug": "uart_debug",
    "user_input": "user_input",
    "user_input_encoder": "user_input",
    "fan_control": "fan_control",
    "input_power_path": "input_power_path",
    "output_power_path": "output_power_path",
    "input_protection": "input_protection",
    "protection_and_clamping": "protection",
    "mcu_controller_core": "controller_decoupling",
    "voltage_reference_and_temperature": "reference_temperature",
    "user_interface_and_io": "user_interface",
    "decoupling": "controller_decoupling",
    "vcc_filter": "controller_decoupling",
    "reference_temperature": "reference_temperature",
    "user_interface": "user_interface",
}


# Long phrases come first so a generic "sense" token cannot win prematurely.
_FUNCTION_PATTERNS = (
    ("input_voltage_sense", ("input_voltage_sense", "input_voltage_sensing", "input voltage sense", "input voltage sensing", "输入电压采样", "输入电压分压采样", "输入电压检测")),
    ("output_voltage_sense", ("output_voltage_sense", "output_voltage_sensing", "output voltage sense", "output voltage sensing", "输出电压采样", "输出电压分压采样", "输出电压检测")),
    ("input_current_sense", ("input_current_sense", "input_current_sensing", "input current sense", "input current sensing", "输入电流采样", "输入电流检测")),
    ("output_current_sense", ("output_current_sense", "output_current_sensing", "output current sense", "output current sensing", "输出电流采样", "输出电流检测")),
    ("adc_reference", ("adc_reference", "adc reference", "voltage reference", "模拟参考", "参考电压", "2v5_reference")),
    ("temperature_sense", ("temperature_sense", "temperature sense", "temperature monitor", "温度检测", "温度传感", "温度监测")),
    ("gate_drive_protection", ("gate_drive_protection", "gate drive and protection", "栅极驱动与保护", "栅极驱动", "mosfet 栅极")),
    ("isolated_gate_drive_power", ("isolated_gate_drive_power", "isolated gate drive power", "隔离栅极驱动供电", "隔离 dc/dc")),
    ("auxiliary_power", ("auxiliary_power", "auxiliary power", "aux power", "5v_supply", "辅助电源", "辅助5v电源", "辅助 5v 电源")),
    ("input_power_path", ("input_power_path", "input power path", "输入功率路径", "输入功率路径与保护")),
    ("output_power_path", ("output_power_path", "output power path", "输出功率路径", "输出功率路径与滤波")),
    ("power_stage", ("power_stage", "power stage switching", "升降压功率级", "功率级", "功率开关")),
    ("uart_debug", ("uart_debug", "uart", "debug port", "串口", "调试接口")),
    ("user_input", ("user_input", "user input encoder", "rotary encoder", "用户输入", "旋转编码器", "用户交互")),
    ("fan_control", ("fan_control", "fan", "风扇控制", "风扇")),
    ("input_bypass", ("input_bypass", "input decoupl", "输入去耦")),
    ("output_filter", ("output_filter", "output decoupl", "输出滤波")),
    ("feedback", ("feedback", "反馈")),
    ("compensation", ("compensation", "soft_start", "补偿")),
    ("bootstrap", ("bootstrap", "boot", "自举")),
    ("switching_loop", ("switching_loop", "inductor", "储能电感")),
    ("adc_filter", ("adc_filter", "adc滤波", "adc 滤波", "sense_filter", "采样滤波")),
    ("controller_decoupling", ("controller_decoupling", "decoupling", "bypass", "去耦")),
    ("reference_temperature", ("reference_temperature", "voltage_reference_and_temperature", "参考与温度", "模拟参考与温度")),
    ("user_interface", ("user_interface", "user_interface_and_io", "用户接口")),
)


# Tags that are useful members of a larger functional path but are not by
# themselves a cluster family.
TAG_TO_FUNCTION = {
    # Labels observed in the 0056 DeepSeek response.
    "controller": "switching_controller",
    "mcu_controller": "switching_controller",
    "sampling": "adc_filter",
    "filtering": "filtering",
    "voltage_sensing": "voltage_sense",
    "voltage_sense": "voltage_sense",
    "current_sense": "current_sense",
    "reference": "adc_reference",
    "thermal": "temperature_sense",
    "gate_drive": "gate_drive_protection",
    "q3_gate_turn_off": "gate_drive_protection",
    "q4_gate_turn_off": "gate_drive_protection",
    "right_gate_driver_input": "gate_drive_protection",
    "left_gate_driver_input": "gate_drive_protection",
    "protection": "protection",
    "power_filter": "isolated_gate_drive_power",
    "aux_power": "auxiliary_power",
    "power_input": "input_power_path",
    "power_output": "output_power_path",
    "power_decoupling": "controller_decoupling",
    "+5v": "controller_decoupling",
    "communication": "user_interface",
    "mcu_peripheral": "user_interface",
    "configuration": "configuration",
    "filtering": "filtering",
    "input_voltage_sense": "input_voltage_sense",
    "voltage_divider": "voltage_divider",
    "output_voltage_sense": "output_voltage_sense",
    "input_current_sense": "input_current_sense",
    "output_current_sense": "output_current_sense",
    "power_current_sense": "power_current_sense",
    "inductor_current_sense": "inductor_current_sense",
    "shunt": "power_current_sense",
    "current_sense_config": "power_current_sense",
    "adc_input": "adc_filter",
    "signal_filter": "adc_filter",
    "pwm_filter": "adc_filter",
    "mcu_pin_filter": "adc_filter",
    "adc_reference": "adc_reference",
    "2v5_reference": "adc_reference",
    "temperature_monitor": "temperature_sense",
    "analog_sensor": "temperature_sense",
    "temp_sensor_filter": "temperature_sense",
    "adc_filter": "adc_filter",
    "sense_filter": "adc_filter",
    "current_sense_filter": "adc_filter",
    "voltage_reference_filter": "adc_filter",
    "gate_drive": "gate_drive_protection",
    "gate_resistor": "gate_drive_protection",
    "gate_pulldown": "gate_drive_protection",
    "gate_drive_diode": "gate_drive_protection",
    "gate_voltage_clamp": "gate_drive_protection",
    "gate_drive_decoupling": "gate_drive_protection",
    "gate_drive_power": "isolated_gate_drive_power",
    "gate_drive_power_routing": "isolated_gate_drive_power",
    "low_side_aux": "isolated_gate_drive_power",
    "high_side_aux": "isolated_gate_drive_power",
    "low_side_driver": "gate_drive_protection",
    "high_side_driver": "gate_drive_protection",
    "bootstrap_capacitor": "bootstrap",
    "isolated_gate_drive": "gate_drive_protection",
    "isolated_gate_drive_power": "isolated_gate_drive_power",
    "aux_power": "auxiliary_power",
    "5v_regulator": "auxiliary_power",
    "vcc_filter": "auxiliary_power",
    "input_filter": "input_power_path",
    "input_routing": "input_power_path",
    "input_fuse": "input_power_path",
    "input_surge_protection": "input_power_path",
    "bulk_capacitor": "input_power_path",
    "power_input": "input_power_path",
    "power_output": "output_power_path",
    "output_filter": "output_power_path",
    "power_stage": "power_stage",
    "energy_storage": "power_stage",
    "power": "power_stage",
    "low_side_switch": "power_stage",
    "high_side_switch": "power_stage",
    "pwm_output": "gate_drive_protection",
    "uart": "uart_debug",
    "uart_interface": "uart_debug",
    "debug_port": "uart_debug",
    "user_input": "user_input",
    "rotary_encoder": "user_input",
    "fan_control": "fan_control",
    "fan_driver": "fan_control",
}


def as_values(value):
    """Treat a string as one label, rather than an iterable of characters."""
    if value is None:
        return []
    if isinstance(value, str):
        return [value]
    if isinstance(value, (list, tuple, set)):
        return list(value)
    return [value]


def normalize_role(value):
    raw = str(value or "").strip().lower()
    return ROLE_ALIASES.get(raw, raw)


def normalize_roles(values):
    raw = [str(value) for value in as_values(values) if str(value).strip()]
    return raw, sorted({normalize_role(value) for value in raw})


def normalize_function(value):
    """Return a canonical function label while accepting model prose."""
    raw = str(value or "").strip()
    if not raw:
        return "other"
    lowered = raw.lower().replace("-", "_")
    if lowered in _FUNCTION_ALIASES:
        return _FUNCTION_ALIASES[lowered]
    for label, phrases in _FUNCTION_PATTERNS:
        if any(phrase.lower() in lowered for phrase in phrases):
            return label
    # Tokenized model labels such as ``input-voltage-sense``.
    compact = re.sub(r"[^a-z0-9]+", "_", lowered).strip("_")
    return _FUNCTION_ALIASES.get(compact, "other")


def normalize_function_tags(values):
    raw = [str(value) for value in as_values(values) if str(value).strip()]
    canonical = []
    for value in raw:
        key = value.strip().lower()
        function = TAG_TO_FUNCTION.get(key) or normalize_function(value)
        if function != "other":
            canonical.append(function)
    return raw, sorted(set(canonical))


def tag_functions(values):
    """Canonical functional families represented by component tags."""
    _, canonical = normalize_function_tags(values)
    return set(canonical)


def compatible_tag(function, tag_functions_set):
    """Whether a tag can participate in a named path candidate."""
    function = normalize_function(function)
    values = set(tag_functions_set)
    if function in values:
        return True
    related = {
        "input_voltage_sense": {"adc_filter", "input_power_path"},
        "output_voltage_sense": {"adc_filter", "output_power_path"},
        "voltage_divider": {"adc_filter", "input_power_path", "output_power_path"},
        "input_current_sense": {"adc_filter", "power_current_sense", "inductor_current_sense"},
        "output_current_sense": {"adc_filter", "power_current_sense", "inductor_current_sense"},
        "adc_reference": {"adc_filter", "temperature_sense"},
        "temperature_sense": {"adc_filter", "adc_reference"},
        "gate_drive_protection": {"isolated_gate_drive_power", "bootstrap", "power_stage"},
        "auxiliary_power": {"input_power_path", "output_power_path", "controller_decoupling"},
        "power_stage": {"power_current_sense", "inductor_current_sense", "gate_drive_protection"},
        "controller_decoupling": {"auxiliary_power"},
        "isolated_gate_drive_power": {"gate_drive_protection", "auxiliary_power"},
        "input_power_path": {"input_voltage_sense", "voltage_divider", "auxiliary_power"},
        "output_power_path": {"output_voltage_sense", "voltage_divider", "power_stage"},
        "uart_debug": {"user_interface"},
        "user_input": {"user_interface"},
        "fan_control": {"user_interface"},
        "user_interface": {"uart_debug", "user_input", "fan_control"},
    }
    return bool(values.intersection(related.get(function, set())))


def annotation_component_fields(row):
    """Normalize one annotation row without discarding original labels."""
    raw_roles, canonical_roles = normalize_roles(row.get("roles", row.get("role", [])))
    raw_tags, canonical_tags = normalize_function_tags(row.get("function_tags", []))
    return {
        "llm_roles_raw": raw_roles,
        "canonical_roles": canonical_roles,
        "function_tags_raw": raw_tags,
        "canonical_function_tags": canonical_tags,
        "normalization_method": "taxonomy-v1",
        "normalization_confidence": 1.0 if canonical_roles or canonical_tags else 0.0,
    }
