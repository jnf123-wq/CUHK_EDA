"""Launch the local Partition GUI."""
from partitioner.gui import main


if __name__ == "__main__":
    main()
