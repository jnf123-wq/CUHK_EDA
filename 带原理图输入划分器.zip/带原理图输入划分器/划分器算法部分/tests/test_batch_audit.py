import json
import tempfile
import unittest
from pathlib import Path

from partitioner.batch_audit import audit_batch


class BatchAuditTests(unittest.TestCase):
    def test_audits_complete_batch_and_metrics(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            row = {
                "project": "p1", "run_mode": "offline", "l1_1_domain_count": 1,
                "l1_2_cluster_count": 1, "multi_member_cluster_count": 1,
                "valid_cluster_ratio": 1, "unresolved_component_count": 0,
                "l1_2_unresolved_component_count": 0, "unassigned_component_count": 0,
                "singleton_rate": 0, "algorithm_stability": 1, "quality_status": "PASS",
                "deepseek_reviewed_soft_constraints": 0, "promoted_hard_rule_count": 0,
                "promotion_conflict_count": 0,
            }
            (root / "batch_summary.json").write_text(json.dumps([row]), encoding="utf-8")
            (root / "llm_call_summary.json").write_text(json.dumps({
                "attempted": False, "successful_projects": 0,
                "failed_projects": 0, "unavailable_projects": 1,
            }), encoding="utf-8")
            result = audit_batch(root, expected_projects=1)
            self.assertTrue(result["pass"])
            self.assertEqual(result["metrics"]["l1_2_clusters"], 1)

    def test_detects_missing_projects_and_promotion_without_review(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            row = {
                "project": "p1", "run_mode": "offline", "l1_1_domain_count": 1,
                "l1_2_cluster_count": 0, "multi_member_cluster_count": 0,
                "valid_cluster_ratio": 0, "unresolved_component_count": 1,
                "singleton_rate": 0, "algorithm_stability": 1, "quality_status": "REVIEW",
                    "l1_2_unresolved_component_count": 1, "unassigned_component_count": 0,
                "deepseek_reviewed_soft_constraints": 0, "promoted_hard_rule_count": 1,
                "promotion_conflict_count": 0,
            }
            (root / "batch_summary.json").write_text(json.dumps([row]), encoding="utf-8")
            (root / "llm_call_summary.json").write_text(json.dumps({
                "attempted": False, "successful_projects": 0,
                "failed_projects": 0, "unavailable_projects": 1,
            }), encoding="utf-8")
            result = audit_batch(root)
            self.assertFalse(result["pass"])
            self.assertIn("expected_9_projects_got_1", result["findings"])
            self.assertIn("row_0_promotion_without_review", result["findings"])

    def test_rejects_attempted_deepseek_batch_without_success(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            rows = []
            for i in range(9):
                rows.append({
                    "project": f"p{i}", "run_mode": "deepseek_failed", "l1_1_domain_count": 1,
                    "l1_2_cluster_count": 0, "multi_member_cluster_count": 0,
                    "valid_cluster_ratio": 0, "unresolved_component_count": 1,
                    "l1_2_unresolved_component_count": 1, "unassigned_component_count": 0,
                    "singleton_rate": 0, "algorithm_stability": 1, "quality_status": "REVIEW",
                    "deepseek_reviewed_soft_constraints": 0, "promoted_hard_rule_count": 0,
                    "promotion_conflict_count": 0,
                })
            (root / "batch_summary.json").write_text(json.dumps(rows), encoding="utf-8")
            (root / "llm_call_summary.json").write_text(json.dumps({
                "provider": "deepseek", "attempted": True, "successful_projects": 0,
                "failed_projects": 9, "unavailable_projects": 0,
            }), encoding="utf-8")
            result = audit_batch(root)
            self.assertFalse(result["pass"])
            self.assertIn("deepseek_no_successful_projects", result["findings"])


if __name__ == "__main__":
    unittest.main()
