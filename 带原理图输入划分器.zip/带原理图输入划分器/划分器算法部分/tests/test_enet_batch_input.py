import tempfile
import unittest
from pathlib import Path

from partitioner.enet_batch import run_batch


class EnetBatchInputTests(unittest.TestCase):
    def test_missing_schematic_is_reported(self):
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory) / "source"
            output = Path(directory) / "output"
            (source / "project_without_schematic" / "pcb").mkdir(parents=True)
            (source / "project_without_schematic" / "pcb" / "layout.enet").write_text("{}", encoding="utf-8")
            rows = run_batch(source, output, use_llm=False, algorithm_repeats=1)
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["run_mode"], "input_failed")
        self.assertEqual(rows[0]["error"], "missing_schematic_enet")

    def test_invalid_enet_json_is_reported_as_input_failure(self):
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory) / "source"
            output = Path(directory) / "output"
            schematic = source / "broken_project" / "schematic"
            schematic.mkdir(parents=True)
            (schematic / "broken.enet").write_text("{not-json", encoding="utf-8")
            rows = run_batch(source, output, use_llm=False, algorithm_repeats=1)
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["run_mode"], "input_failed")
        self.assertTrue(rows[0]["error"].startswith("invalid_enet_json:"))


if __name__ == "__main__":
    unittest.main()
