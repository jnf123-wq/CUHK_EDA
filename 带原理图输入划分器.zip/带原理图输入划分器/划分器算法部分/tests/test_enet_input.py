import json
import tempfile
import unittest
from pathlib import Path

from partitioner.enet_to_topology import convert


class EnetInputTests(unittest.TestCase):
    def test_schematic_enet_is_normalized_without_pcb_pad_aliases(self):
        project_root = Path(__file__).resolve().parents[1]
        candidates = sorted(project_root.glob(
            "_validation_iteration_20261005/source/*/schematic/*.enet"
        ))
        self.assertTrue(candidates, "bundled validation schematic fixture is missing")
        path = candidates[0]
        topology = convert(path)
        self.assertEqual(topology["schema"], "moduplace-topology-v1")
        self.assertGreater(len(topology["components"]), 0)
        self.assertGreater(len(topology["nets"]), 0)
        self.assertTrue(all("pad" not in ep for net in topology["nets"].values() for ep in net))


if __name__ == "__main__":
    unittest.main()
