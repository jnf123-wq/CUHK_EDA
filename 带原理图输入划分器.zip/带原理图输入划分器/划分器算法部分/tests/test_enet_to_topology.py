import json
import tempfile
import unittest
from pathlib import Path

from partitioner.enet_to_topology import convert


class EnetTopologyTests(unittest.TestCase):
    def test_duplicate_designators_are_aliased_in_components_and_nets(self):
        data = {
            "components": {
                "a": {"props": {"Designator": "R1", "Value": "1k"},
                      "pinInfoMap": {"1": {"number": "1", "name": "A", "net": "N1"}}},
                "b": {"props": {"Designator": "R1", "Value": "2k"},
                      "pinInfoMap": {"1": {"number": "1", "name": "B", "net": "N2"}}},
            }
        }
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "schematic.enet"
            path.write_text(json.dumps(data), encoding="utf-8")
            topology = convert(path)
        refs = {row["designator"] for row in topology["components"]}
        endpoints = {endpoint["c"] for rows in topology["nets"].values() for endpoint in rows}
        self.assertEqual(refs, {"R1", "R1__dup2"})
        self.assertEqual(endpoints, refs)


if __name__ == "__main__":
    unittest.main()
