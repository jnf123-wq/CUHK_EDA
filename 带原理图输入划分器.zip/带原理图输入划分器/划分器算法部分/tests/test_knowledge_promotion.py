import json
import tempfile
import unittest
from pathlib import Path

from partitioner.knowledge_base import (audit_soft_constraint_schema,
                                         backfill_l1_1_domains,
                                         promote_high_confidence,
                                         normalize_stored_soft_constraints,
                                         summarize_soft_constraints)


class KnowledgePromotionTests(unittest.TestCase):

    def test_soft_schema_audit_reports_missing_metadata(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "soft.jsonl"
            path.write_text(json.dumps({"constraint_id": "SC-1", "confidence": 0.8}) + "\n", encoding="utf-8")
            result = audit_soft_constraint_schema(path)
            self.assertFalse(result["pass"])
            self.assertEqual(result["findings"][0]["error"], "missing_fields")

    def test_soft_schema_audit_accepts_complete_candidate(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "soft.jsonl"
            path.write_text(json.dumps({
                "constraint_id": "SC-1", "source_project": "board-a",
                "l1_1_domain": "D-001", "function_type": "feedback",
                "confidence": 0.91, "evidence_nets": ["FB"],
                "review_status": "candidate", "status": "candidate",
            }) + "\n", encoding="utf-8")
            self.assertTrue(audit_soft_constraint_schema(path)["pass"])

    def test_legacy_records_are_backfilled_without_promotion(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "soft.jsonl"
            path.write_text(json.dumps({"constraint_id": "SC-old", "project_id": "p", "status": "candidate"}) + "\n", encoding="utf-8")
            result = normalize_stored_soft_constraints(path)
            self.assertEqual(result["updated"], 1)
            row = json.loads(path.read_text(encoding="utf-8"))
            self.assertEqual(row["source_project"], "p")
            self.assertEqual(row["review_status"], "candidate")
            self.assertEqual(row["function_type"], "other")

    def test_historical_domain_backfill_is_source_qualified_and_explicitly_unresolved(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            soft_path = root / "soft.jsonl"
            history = root / "history"
            history.mkdir()
            rows = [
                {"constraint_id": "SC-match", "source_project": "history-project",
                 "members": ["A", "B"], "l1_1_domain": "unknown"},
                {"constraint_id": "SC-miss", "source_project": "history-project",
                 "members": ["A", "Z"], "l1_1_domain": "unknown"},
            ]
            soft_path.write_text("".join(json.dumps(row) + "\n" for row in rows), encoding="utf-8")
            result_payload = {
                "knowledge_base": {"project_id": "history-project"},
                "partition": {"domains": [{"id": "L1-1-001", "members": ["A", "B", "C"]}]},
            }
            history_file = history / "run_history-project_hierarchical_l1.json"
            history_file.write_text(json.dumps(result_payload), encoding="utf-8")

            result = backfill_l1_1_domains(soft_path, history)
            self.assertEqual(result["resolved"], 1)
            self.assertEqual(result["unresolved"], 1)
            updated = [json.loads(line) for line in soft_path.read_text(encoding="utf-8").splitlines()]
            matched = next(row for row in updated if row["constraint_id"] == "SC-match")
            missing = next(row for row in updated if row["constraint_id"] == "SC-miss")
            self.assertEqual(matched["l1_1_domain"], "L1-1-001")
            self.assertEqual(matched["l1_1_domain_key"], "history-project::L1-1-001")
            self.assertEqual(matched["l1_1_domain_status"], "resolved_historical")
            self.assertEqual(matched["l1_1_domain_source"], str(history_file.resolve()))
            self.assertEqual(missing["l1_1_domain"], "unresolved")
            self.assertEqual(missing["l1_1_domain_status"], "unresolved")
            self.assertEqual(missing["l1_1_domain_resolution"], "members_not_in_one_historical_domain")

    def test_summary_separates_function_status_and_kind(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "soft.jsonl"
            rows = [
                {"constraint_id": "a", "function_type": "input_bypass", "review_status": "candidate", "kind": "cluster"},
                {"constraint_id": "b", "function_type": "feedback", "review_status": "deepseek_approved", "kind": "pair"},
            ]
            path.write_text("".join(json.dumps(row) + "\n" for row in rows), encoding="utf-8")
            summary = summarize_soft_constraints(path)
            self.assertEqual(summary["by_function"], {"feedback": 1, "input_bypass": 1})
            self.assertEqual(summary["by_kind"], {"cluster": 1, "pair": 1})
            self.assertEqual(summary["promotable_pair_candidates"], 1)
    def _record(self, relation="prefer_link"):
        return {"constraint_id": "SC-test", "review_status": "deepseek_approved",
                "review_provider": "deepseek", "review_confidence": .98,
                "name": "input caps", "members": ["C1", "C2"], "weight": 98,
                "when": {"role_pairs": [["input_bypass_capacitor", "input_bypass_capacitor"]],
                         "shared_semantics": ["VIN"]}, "reason": "shared VIN",
                "relation": relation}

    def test_promotes_high_confidence_unconflicted_rule(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "rules.json"
            path.write_text(json.dumps({"rules": []}), encoding="utf-8")
            result = promote_high_confidence([self._record()], path)
            self.assertEqual(len(result["promoted"]), 1)
            self.assertEqual(json.loads(path.read_text(encoding="utf-8"))["rules"][0]["status"], "approved")

    def test_detects_semantically_overlapping_conflict(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "rules.json"
            rules = [{"rule_id": "R1", "status": "approved", "relation": "must_link",
                      "when": {"role_pairs": [["input_bypass_capacitor", "input_bypass_capacitor"]],
                               "shared_semantics": ["VIN"]}}]
            path.write_text(json.dumps({"rules": rules}), encoding="utf-8")
            result = promote_high_confidence([self._record("prefer_link")], path)
            self.assertEqual(result["promoted"], [])
            self.assertEqual(result["conflicts"][0]["conflicting_rule_ids"], ["R1"])

    def test_ignores_unreviewed_and_low_confidence_records(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "rules.json"
            path.write_text(json.dumps({"rules": []}), encoding="utf-8")
            pending = self._record()
            pending["review_status"] = "pending_review"
            low = self._record()
            low["review_confidence"] = .5
            result = promote_high_confidence([pending, low], path)
            self.assertEqual(result["promoted"], [])
            self.assertEqual(json.loads(path.read_text(encoding="utf-8"))["rules"], [])

    def test_does_not_promote_broad_cluster_record(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "rules.json"
            path.write_text(json.dumps({"rules": []}), encoding="utf-8")
            record = self._record()
            record["kind"] = "cluster"
            result = promote_high_confidence([record], path)
            self.assertEqual(result["promoted"], [])

    def test_detects_must_link_cannot_link_conflict(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "rules.json"
            rules = [{"rule_id": "R1", "status": "approved", "relation": "must_link",
                      "function_type": "feedback",
                      "when": {"role_pairs": [["feedback_resistor", "feedback_capacitor"]],
                               "shared_semantics": ["FB"]}}]
            path.write_text(json.dumps({"rules": rules}), encoding="utf-8")
            record = self._record("cannot_link")
            record["function_type"] = "feedback"
            record["when"] = {"role_pairs": [["feedback_resistor", "feedback_capacitor"]],
                              "shared_semantics": ["FB"]}
            result = promote_high_confidence([record], path)
            self.assertEqual(result["promoted"], [])
            self.assertEqual(result["conflicts"][0]["conflicting_rule_ids"], ["R1"])


if __name__ == "__main__":
    unittest.main()
