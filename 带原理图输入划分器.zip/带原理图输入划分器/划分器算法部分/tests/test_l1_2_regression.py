import unittest

from partitioner.l1_partition import hierarchical_partition


class L12RegressionTests(unittest.TestCase):
    def _design(self):
        components = [
            ("U1", "ic_module"), ("CIN1", "capacitor"), ("CIN2", "capacitor"),
            ("L1", "inductor"), ("COUT1", "capacitor"), ("COUT2", "capacitor"),
            ("RFB1", "resistor"), ("RFB2", "resistor"),
        ]
        topology = {
            "schema": "moduplace-topology-v1",
            "components": [{"designator": ref, "kind": kind} for ref, kind in components],
            "nets": {
                "VIN": [{"c": ref} for ref in ("U1", "CIN1", "CIN2")],
                "VOUT": [{"c": ref} for ref in ("L1", "COUT1", "COUT2")],
                "FB": [{"c": ref} for ref in ("U1", "RFB1", "RFB2")],
                "GND": [{"c": ref} for ref in ("U1", "CIN1", "CIN2", "COUT1", "COUT2", "RFB2")],
            },
        }
        roles = {
            "U1": {"roles": ["switching_controller"]},
            "CIN1": {"roles": ["input_bypass_capacitor"]},
            "CIN2": {"roles": ["input_bypass_capacitor"]},
            "L1": {"roles": ["power_inductor"]},
            "COUT1": {"roles": ["output_filter_capacitor"]},
            "COUT2": {"roles": ["output_filter_capacitor"]},
            "RFB1": {"roles": ["feedback_resistor"]},
            "RFB2": {"roles": ["feedback_resistor"]},
        }
        return topology, roles, {name: [name] for name in topology["nets"]}

    def test_functional_domains_survive_selection(self):
        topology, roles, semantics = self._design()
        scores = [
            {"a": "CIN1", "b": "CIN2", "decision": "proposal", "confidence": .96,
             "function": "input_bypass", "evidence_nets": ["VIN"]},
            {"a": "COUT1", "b": "COUT2", "decision": "proposal", "confidence": .96,
             "function": "output_filter", "evidence_nets": ["VOUT"]},
            {"a": "RFB1", "b": "RFB2", "decision": "proposal", "confidence": .96,
             "function": "feedback", "evidence_nets": ["FB"]},
        ]
        result = hierarchical_partition(topology, semantics, roles, [], soft_scores=scores)
        functions = {row["function"] for row in result["l1_2_clusters"]}
        self.assertTrue({"input_bypass_stage", "output_filter_stage", "feedback_network"}.issubset(functions))

    def test_mixed_candidate_cannot_merge_domains_or_anchors(self):
        topology, roles, semantics = self._design()
        # Keep this selector regression independent of shared-ground L2
        # connectivity; power/ground edges are intentionally traversable in
        # the pure-topology L2 graph now.
        topology["nets"].pop("GND")
        semantics.pop("GND")
        result = hierarchical_partition(
            topology, semantics, roles, [],
            annotation={"candidate_clusters": [{
                "function": "global_llm", "members": ["U1", "CIN1", "CIN2", "COUT1", "COUT2", "RFB1", "RFB2"]
            }]},
            soft_scores=[
                {"a": "CIN1", "b": "CIN2", "decision": "proposal", "confidence": .95,
                 "function": "input_bypass", "evidence_nets": ["VIN"]},
                {"a": "COUT1", "b": "COUT2", "decision": "proposal", "confidence": .95,
                 "function": "output_filter", "evidence_nets": ["VOUT"]},
            ])
        self.assertTrue(all("U1" not in row["members"] for row in result["l1_2_clusters"]))
        self.assertTrue(any(row.get("function") == "global_llm" and row["decision"] == "rejected_mixed_domain"
                            for row in result["decision_trace"]))

    def test_assignment_is_complete_unique_and_non_singleton(self):
        topology, roles, semantics = self._design()
        result = hierarchical_partition(topology, semantics, roles, [], soft_scores=[
            {"a": "CIN1", "b": "CIN2", "decision": "proposal", "confidence": .95,
             "function": "input_bypass", "evidence_nets": ["VIN"]},
            {"a": "COUT1", "b": "COUT2", "decision": "proposal", "confidence": .95,
             "function": "output_filter", "evidence_nets": ["VOUT"]},
        ])
        members = [ref for cluster in result["l1_2_clusters"] for ref in cluster["members"]]
        self.assertTrue(result["all_components_once"])
        self.assertEqual(len(members), len(set(members)))
        self.assertFalse(any(len(cluster["members"]) == 1 for cluster in result["l1_2_clusters"]))

    def test_same_domain_broad_llm_candidate_does_not_beat_two_function_candidates(self):
        topology, roles, semantics = self._design()
        # Force one L1-1 domain so this exercises overlap handling rather than
        # only the mixed-domain guard.
        topology["nets"]["VIN"].append({"c": "RFB1"})
        result = hierarchical_partition(
            topology, semantics, roles, [],
            annotation={"candidate_clusters": [{
                "function": "broad_same_domain", "members": ["CIN1", "CIN2", "COUT1", "COUT2"]
            }]},
            soft_scores=[
                {"a": "CIN1", "b": "CIN2", "decision": "proposal", "confidence": .99,
                 "function": "input_bypass", "evidence_nets": ["VIN"]},
                {"a": "COUT1", "b": "COUT2", "decision": "proposal", "confidence": .99,
                 "function": "output_filter", "evidence_nets": ["VOUT"]},
            ])
        functions = {row["function"] for row in result["l1_2_clusters"]}
        self.assertIn("input_bypass_stage", functions)
        self.assertIn("output_filter_stage", functions)
        broad = [row for row in result["decision_trace"] if row.get("function") == "broad_same_domain"]
        self.assertTrue(broad)
        self.assertTrue(all(row["decision"] != "selected" for row in broad))

    def test_structured_soft_evidence_is_hash_safe(self):
        """Evidence dictionaries from normalized annotations must remain usable."""
        topology, roles, semantics = self._design()
        result = hierarchical_partition(topology, semantics, roles, [], soft_scores=[
            {"a": "RFB1", "b": "RFB2", "decision": "proposal", "confidence": .95,
             "function": "feedback", "evidence": [{"name": "FB sense relationship"}]},
        ])
        cluster = next(row for row in result["l1_2_clusters"]
                       if set(row["members"]) == {"RFB1", "RFB2"})
        self.assertIn(cluster["function_type"], {"feedback", "feedback_network"})
        self.assertTrue(result["all_components_once"])

    def test_multifunction_soft_pair_keeps_each_function_network_evidence(self):
        topology, roles, semantics = self._design()
        result = hierarchical_partition(
            topology, semantics, roles, [],
            soft_scores=[{
                "a": "CIN1", "b": "CIN2", "decision": "proposal", "confidence": .95,
                "functions": ["input_bypass", "output_filter"],
                "function_evidence": {
                    "input_bypass": [{"evidence_nets": ["VIN"], "function": "input_bypass"}],
                    "output_filter": [{"evidence_nets": ["VOUT"], "function": "output_filter"}],
                },
            }])
        traces = [row for row in result["decision_trace"]
                  if row.get("source") == "soft_evidence"
                  and set(row.get("members", [])) == {"CIN1", "CIN2"}]
        by_function = {row["function_type"]: set(row.get("evidence_nets", [])) for row in traces}
        self.assertEqual(by_function.get("input_bypass"), {"VIN"})
        self.assertEqual(by_function.get("output_filter"), {"VOUT"})


if __name__ == "__main__":
    unittest.main()
