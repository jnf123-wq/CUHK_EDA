import unittest

from partitioner.l1_partition import hierarchical_partition


class L12SelectionTests(unittest.TestCase):
    def setUp(self):
        self.topology = {
            "schema": "moduplace-topology-v1",
            "components": [
                {"designator": "U1", "kind": "ic_module", "part_name": "TPS54360"},
                {"designator": "CIN1", "kind": "capacitor"},
                {"designator": "CIN2", "kind": "capacitor"},
                {"designator": "L1", "kind": "inductor"},
                {"designator": "COUT1", "kind": "capacitor"},
                {"designator": "COUT2", "kind": "capacitor"},
                {"designator": "RFB1", "kind": "resistor"},
                {"designator": "RFB2", "kind": "resistor"},
                {"designator": "RC1", "kind": "resistor"},
                {"designator": "CC1", "kind": "capacitor"},
            ],
            "nets": {
                "VIN": [{"c": "U1"}, {"c": "CIN1"}, {"c": "CIN2"}],
                "VOUT": [{"c": "L1"}, {"c": "COUT1"}, {"c": "COUT2"}, {"c": "RFB1"}],
                "FB": [{"c": "U1", "pin": "FB"}, {"c": "RFB1"}, {"c": "RFB2"}],
                "COMP": [{"c": "U1", "pin": "COMP"}, {"c": "RC1"}, {"c": "CC1"}],
                "GND": [{"c": ref} for ref in ("U1", "CIN1", "CIN2", "COUT1", "COUT2", "RFB2", "CC1")],
            },
        }
        self.roles = {
            "U1": {"roles": ["switching_controller"]},
            "CIN1": {"roles": ["input_bypass_capacitor"]},
            "CIN2": {"roles": ["input_bypass_capacitor"]},
            "L1": {"roles": ["power_inductor"]},
            "COUT1": {"roles": ["output_filter_capacitor"]},
            "COUT2": {"roles": ["output_filter_capacitor"]},
            "RFB1": {"roles": ["feedback_resistor"]},
            "RFB2": {"roles": ["feedback_resistor"]},
            "RC1": {"roles": ["compensation_resistor"]},
            "CC1": {"roles": ["compensation_capacitor"]},
        }
        self.semantics = {name: [name] for name in self.topology["nets"]}

    def test_separate_function_clusters_anchors_and_coverage(self):
        result = hierarchical_partition(self.topology, self.semantics, self.roles, [],
            annotation={"candidate_clusters": [{
                "function": "llm_soft_candidate", "members": ["CIN1", "CIN2", "COUT1", "COUT2", "RFB1", "RFB2", "RC1", "CC1"]
            }]},
            soft_scores=[
                {"a": "CIN1", "b": "CIN2", "decision": "proposal", "confidence": .95,
                 "function": "input_bypass", "evidence_nets": ["VIN", "GND"]},
                {"a": "COUT1", "b": "COUT2", "decision": "proposal", "confidence": .95,
                 "function": "output_filter", "evidence_nets": ["VOUT", "GND"]},
                {"a": "RFB1", "b": "RFB2", "decision": "proposal", "confidence": .95,
                 "function": "feedback", "evidence_nets": ["FB"]},
            ])
        funcs = {row["function"] for row in result["l1_2_clusters"]}
        self.assertIn("input_bypass_stage", funcs)
        self.assertIn("output_filter_stage", funcs)
        self.assertIn("feedback_network", funcs)
        self.assertNotIn("llm_soft_candidate", funcs)
        self.assertTrue(all("U1" not in row["members"] and "L1" not in row["members"]
                            for row in result["l1_2_clusters"]))
        assigned = [ref for row in result["l1_2_clusters"] for ref in row["members"]]
        self.assertEqual(len(assigned), len(set(assigned)))
        self.assertTrue(result["all_components_once"])
        self.assertTrue(any(len(row["members"]) >= 2 for row in result["l1_2_clusters"]))

    def test_soft_candidates_are_split_by_l1_domain_and_function(self):
        result = hierarchical_partition(self.topology, self.semantics, self.roles, [],
            soft_scores=[
                {"a": "CIN1", "b": "CIN2", "decision": "proposal", "confidence": .95,
                 "function": "input_bypass", "evidence_nets": ["VIN"]},
                {"a": "COUT1", "b": "COUT2", "decision": "proposal", "confidence": .95,
                 "function": "output_filter", "evidence_nets": ["VOUT"]},
                {"a": "RFB1", "b": "RFB2", "decision": "proposal", "confidence": .95,
                 "function": "feedback", "evidence_nets": ["FB"]},
            ])
        self.assertEqual({row["function"] for row in result["l1_2_clusters"]},
                         {"input_bypass_stage", "output_filter_stage", "feedback_network"})

    def test_soft_candidates_preserve_role_composition(self):
        result = hierarchical_partition(self.topology, self.semantics, self.roles, [],
            soft_scores=[
                {"a": "CIN1", "b": "CIN2", "decision": "proposal", "confidence": .95,
                 "function": "input_bypass", "evidence_nets": ["VIN"]},
                {"a": "COUT1", "b": "COUT2", "decision": "proposal", "confidence": .95,
                 "function": "input_bypass", "evidence_nets": ["VIN"]},
            ])
        input_clusters = [row for row in result["l1_2_clusters"] if set(row["members"]) == {"CIN1", "CIN2"}]
        output_clusters = [row for row in result["l1_2_clusters"] if set(row["members"]) == {"COUT1", "COUT2"}]
        self.assertEqual(len(input_clusters), 1)
        self.assertEqual(input_clusters[0]["function"], "input_bypass_stage")
        self.assertEqual(len(output_clusters), 1)

    def test_selected_soft_cluster_retains_domain_function_and_network_metadata(self):
        result = hierarchical_partition(self.topology, self.semantics, self.roles, [],
            soft_scores=[
                {"a": "CIN1", "b": "CIN2", "decision": "proposal", "confidence": .95,
                 "function": "input_bypass", "evidence_nets": ["VIN"]},
            ])
        cluster = next(row for row in result["l1_2_clusters"] if row["members"] == ["CIN1", "CIN2"])
        self.assertEqual(cluster["function_type"], "input_bypass")
        self.assertEqual(cluster["evidence_nets"], ["VIN"])
        self.assertTrue(cluster["l1_1_domain"])

    def test_selector_priority_is_source_order_not_candidate_size(self):
        result = hierarchical_partition(self.topology, self.semantics, self.roles, [],
            annotation={"candidate_clusters": [{"function": "broad_llm", "members":
                ["CIN1", "CIN2", "COUT1", "COUT2", "RFB1", "RFB2"]}]},
            soft_scores=[
                {"a": "CIN1", "b": "CIN2", "decision": "proposal", "confidence": .99,
                 "function": "input_bypass", "evidence_nets": ["VIN"]},
                {"a": "COUT1", "b": "COUT2", "decision": "proposal", "confidence": .99,
                 "function": "output_filter", "evidence_nets": ["VOUT"]},
            ])
        funcs = {row["function"] for row in result["l1_2_clusters"]}
        self.assertIn("input_bypass_stage", funcs)
        self.assertIn("output_filter_stage", funcs)
        self.assertNotIn("broad_llm", funcs)

    def test_approved_hard_rule_candidate_is_highest_priority(self):
        result = hierarchical_partition(self.topology, self.semantics, self.roles,
            [{"rule_id": "H1", "a": "CIN1", "b": "CIN2", "relation": "must_link",
              "status": "approved", "weight": 100}],
            annotation={"candidate_clusters": [{"function": "llm_input", "members": ["CIN1", "CIN2"]}]})
        chosen = next(row for row in result["l1_2_clusters"] if "CIN1" in row["members"])
        self.assertEqual(chosen["source"], "approved_hard_rule")

    def test_unknown_passives_assign_to_unique_anchor_domain(self):
        topology = {"schema": "moduplace-topology-v1",
                    "components": [{"designator": "U1", "kind": "ic_module"},
                                   {"designator": "C1", "kind": "capacitor"},
                                   {"designator": "C2", "kind": "capacitor"}],
                    "nets": {"N1": [{"c": "U1"}, {"c": "C1"}, {"c": "C2"}],
                             "N2": [{"c": "C1"}, {"c": "C2"}]}}
        roles = {"U1": {"roles": ["switching_controller"]},
                 "C1": {"roles": ["generic_passive"]},
                 "C2": {"roles": ["generic_passive"]}}
        result = hierarchical_partition(topology, {"N1": ["UNKNOWN"], "N2": ["UNKNOWN"]}, roles, [])
        self.assertEqual(len(result["l1_1_domains"]), 1)
        self.assertEqual(set(result["l1_1_domains"][0]["members"]), {"U1", "C1", "C2"})
        self.assertTrue(result["all_components_once"])

    def test_unknown_shared_net_does_not_create_a_passive_cluster(self):
        topology = {"schema": "moduplace-topology-v1",
                    "components": [{"designator": "U1", "kind": "ic_module"},
                                   {"designator": "R1", "kind": "resistor"},
                                   {"designator": "R2", "kind": "resistor"}],
                    "nets": {"N1": [{"c": "U1"}, {"c": "R1"}, {"c": "R2"}]}}
        roles = {"U1": {"roles": ["switching_controller"]},
                 "R1": {"roles": ["generic_passive"]},
                 "R2": {"roles": ["generic_passive"]}}
        result = hierarchical_partition(topology, {"N1": ["UNKNOWN"]}, roles, [])
        self.assertEqual(result["l1_2_clusters"], [])
        anchor_singleton = next(row for row in result["l1_clusters"]
                                if row.get("source") == "anchor_singleton")
        self.assertEqual(anchor_singleton["anchor_policy"], "anchor_included")
        self.assertTrue(result["all_components_once"])

    def test_single_anchor_candidate_is_kept_in_l1_cluster(self):
        topology = {"schema": "moduplace-topology-v1",
                    "components": [{"designator": "L1", "kind": "inductor"},
                                   {"designator": "C1", "kind": "capacitor"},
                                   {"designator": "C2", "kind": "capacitor"}],
                    "nets": {"SW": [{"c": "L1"}, {"c": "C1"}, {"c": "C2"}],
                             "GND": [{"c": "L1"}, {"c": "C1"}, {"c": "C2"}]}}
        roles = {"L1": {"roles": ["power_inductor", "generic_passive"]},
                 "C1": {"roles": ["generic_passive"]},
                 "C2": {"roles": ["generic_passive"]}}
        result = hierarchical_partition(topology, {"SW": ["SW"], "GND": ["GND"]}, roles, [])
        cluster = next(row for row in result["l1_2_clusters"]
                       if set(row["members"]) == {"L1", "C1", "C2"})
        self.assertEqual(cluster["anchor"], "L1")
        self.assertEqual(cluster["anchor_policy"], "anchor_included")
        self.assertTrue(result["all_components_once"])
        self.assertFalse(any(row.get("source") == "anchor_singleton" and "L1" in row["members"]
                             for row in result["l1_clusters"]))

    def test_llm_candidate_with_one_anchor_is_kept_in_l1_cluster(self):
        topology = {"schema": "moduplace-topology-v1",
                    "components": [{"designator": "U1", "kind": "ic_module"},
                                   {"designator": "C1", "kind": "capacitor"}],
                    "nets": {"VIN": [{"c": "U1"}, {"c": "C1"}]}}
        roles = {"U1": {"roles": ["switching_controller"]},
                 "C1": {"roles": ["generic_passive"]}}
        result = hierarchical_partition(
            topology, {"VIN": ["VIN"]}, roles, [],
            annotation={"candidate_clusters": [{
                "function": "input_bypass", "members": ["U1", "C1"]
            }]})
        cluster = next(row for row in result["l1_clusters"]
                       if set(row["members"]) == {"U1", "C1"})
        self.assertEqual(cluster["anchor"], "U1")
        self.assertEqual(cluster["anchor_policy"], "anchor_included")
        self.assertTrue(result["all_components_once"])

    def test_unknown_direct_net_assigns_component_to_major_domain(self):
        topology = {"schema": "moduplace-topology-v1",
                    "components": [{"designator": "U1", "kind": "ic_module"},
                                   {"designator": "R1", "kind": "resistor"}],
                    "nets": {"N1": [{"c": "U1"}, {"c": "R1"}]}}
        roles = {"U1": {"roles": ["switching_controller"]},
                 "R1": {"roles": ["generic_passive"]}}
        result = hierarchical_partition(topology, {"N1": ["UNKNOWN"]}, roles, [])
        domain = next(row for row in result["l1_1_domains"] if row.get("anchor") == "U1")
        self.assertEqual(domain["members"], ["R1", "U1"])
        singletons = [row for row in result["l1_clusters"]
                      if row.get("source") == "unresolved_singleton"]
        self.assertEqual(len(singletons), 1)
        self.assertEqual(singletons[0]["members"], ["R1"])
        self.assertEqual(singletons[0]["reason"], "missing_net_semantics")
        self.assertEqual(result["unresolved_components"], [])
        self.assertEqual(result["singleton_fallback_count"], 1)
        self.assertTrue(result["all_components_once"])
        self.assertEqual(result["l1_2_clusters"], [])

    def test_overlap_is_traced_and_small_function_cluster_wins(self):
        result = hierarchical_partition(self.topology, self.semantics, self.roles, [],
            annotation={"candidate_clusters": [{"function": "broad_llm", "members":
                ["CIN1", "CIN2", "COUT1", "COUT2", "RFB1", "RFB2"]}]},
            soft_scores=[
                {"a": "CIN1", "b": "CIN2", "decision": "proposal", "confidence": .99,
                 "function": "input_bypass", "evidence_nets": ["VIN"]},
                {"a": "COUT1", "b": "COUT2", "decision": "proposal", "confidence": .99,
                 "function": "output_filter", "evidence_nets": ["VOUT"]},
            ])
        broad = next(row for row in result["decision_trace"] if row["function"] == "broad_llm")
        self.assertIn(broad["decision"], {
            "rejected_overlap", "rejected_mixed_domain", "rejected_split_function"
        })
        self.assertTrue({"CIN1", "CIN2", "COUT1", "COUT2"}.issubset(set(broad["rejected_members"])))
        self.assertTrue(all(row["function"] != "broad_llm" or row["decision"] != "selected"
                            for row in result["decision_trace"]))

    def test_explicit_broad_llm_cluster_is_split_by_function(self):
        result = hierarchical_partition(
            self.topology, self.semantics, self.roles, [],
            annotation={"candidate_clusters": [{
                "function": "broad_llm",
                "members": ["CIN1", "CIN2", "COUT1", "COUT2", "RFB1", "RFB2", "RC1", "CC1"],
            }]})
        functions = {row["function"] for row in result["l1_2_clusters"]}
        self.assertTrue({"input_bypass_stage", "output_filter_stage",
                         "feedback_network", "compensation_network"}.issubset(functions))
        broad = next(row for row in result["decision_trace"] if row["function"] == "broad_llm")
        self.assertNotEqual(broad["decision"], "selected")
        self.assertTrue({"CIN1", "CIN2", "COUT1", "COUT2"}.issubset(set(broad["rejected_members"])))


if __name__ == "__main__":
    unittest.main()
