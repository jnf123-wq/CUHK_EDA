import unittest

from partitioner.l1_partition import hierarchical_partition


class L2MajorDomainTests(unittest.TestCase):
    @staticmethod
    def _run(components, nets, semantics=None, roles=None):
        topology = {
            "schema": "moduplace-topology-v1",
            "components": [{"designator": ref, "kind": kind}
                           for ref, kind in components],
            "nets": nets,
        }
        return hierarchical_partition(topology, semantics or {}, roles or {}, [])

    def test_each_major_device_owns_direct_pin_connections(self):
        result = self._run(
            [("U1", "ic_module"), ("U2", "ic_module"),
             ("C1", "capacitor"), ("C2", "capacitor"),
             ("R1", "resistor"), ("R2", "resistor")],
            {
                "U1_SIG": [{"c": "U1"}, {"c": "R1"}],
                "U2_SIG": [{"c": "U2"}, {"c": "R2"}],
                "U1_VIN": [{"c": "U1"}, {"c": "C1"}],
                "U2_VIN": [{"c": "U2"}, {"c": "C2"}],
            },
            {"U1_SIG": ["UNKNOWN"], "U2_SIG": ["UNKNOWN"],
             "U1_VIN": ["VIN"], "U2_VIN": ["VIN"]},
        )
        domains = {row["anchor"]: set(row["members"])
                   for row in result["l2_domains"] if row.get("anchor")}
        self.assertEqual(domains["U1"], {"U1", "C1", "R1"})
        self.assertEqual(domains["U2"], {"U2", "C2", "R2"})
        self.assertTrue(result["all_components_once"])

    def test_shared_connection_is_owned_by_earlier_major_root(self):
        result = self._run(
            [("U1", "ic_module"), ("U2", "ic_module"), ("X1", "resistor")],
            {"SHARED": [{"c": "U1"}, {"c": "U2"}, {"c": "X1"}]},
            {"SHARED": ["UNKNOWN"]},
        )
        owners = [row for row in result["l2_domains"] if "X1" in row["members"]]
        self.assertEqual(len(owners), 1)
        self.assertEqual(owners[0]["anchor"], "U1")
        self.assertTrue(result["all_components_once"])

    def test_root_ground_connection_is_not_traversed(self):
        result = self._run(
            [("U1", "ic_module"), ("C1", "capacitor")],
            {"GND": [{"c": "U1"}, {"c": "C1"}]},
            {"GND": ["GND"]},
        )
        u1_domain = next(row for row in result["l2_domains"] if row.get("anchor") == "U1")
        self.assertEqual(u1_domain["members"], ["U1"])
        unresolved = next(row for row in result["l2_domains"] if row.get("anchor") is None)
        self.assertEqual(unresolved["members"], ["C1"])
        self.assertTrue(result["all_components_once"])

    def test_isolated_major_device_still_forms_a_domain(self):
        result = self._run(
            [("U1", "ic_module"), ("R1", "resistor")],
            {"UNRELATED": [{"c": "R1"}]},
            {"UNRELATED": ["UNKNOWN"]},
        )
        u1_domain = next(row for row in result["l2_domains"] if row.get("anchor") == "U1")
        self.assertEqual(u1_domain["members"], ["U1"])
        self.assertTrue(result["all_components_once"])

    def test_small_device_clusters_are_nested_under_major_domain(self):
        result = self._run(
            [("U1", "ic_module"), ("C1", "capacitor"), ("R1", "resistor")],
            {"VIN": [{"c": "U1"}, {"c": "C1"}],
             "FB": [{"c": "U1"}, {"c": "R1"}]},
            {"VIN": ["VIN"], "FB": ["FB"]},
        )
        domain = result["l2_domains"][0]
        child_ids = set(domain["children_l1"])
        self.assertTrue(child_ids)
        self.assertEqual(child_ids,
                         {cluster["id"] for cluster in result["l1_clusters"]})
        self.assertTrue(all(cluster["parent_l2_domain"] == domain["id"]
                            for cluster in result["l1_clusters"]))
        self.assertEqual({ref for child in domain["children_l1_clusters"]
                          for ref in child["members"]}, set(domain["members"]))

    def test_recursively_connected_small_devices_join_major_domain(self):
        result = self._run(
            [("U1", "ic_module"), ("C1", "capacitor"),
             ("R1", "resistor"), ("D1", "diode")],
            {
                "U1_VIN": [{"c": "U1"}, {"c": "C1"}],
                "C1_R1": [{"c": "C1"}, {"c": "R1"}],
                "R1_D1": [{"c": "R1"}, {"c": "D1"}],
            },
            {"U1_VIN": ["VIN"], "C1_R1": ["UNKNOWN"],
             "R1_D1": ["UNKNOWN"]},
        )
        domain = next(row for row in result["l2_domains"] if row.get("anchor") == "U1")
        self.assertEqual(set(domain["members"]), {"U1", "C1", "R1", "D1"})
        recursive = {row["ref"]: row for row in domain["assignments"]
                     if row.get("assignment_reason") == "recursive_pin_connection"}
        self.assertEqual(set(recursive), {"R1", "D1"})
        self.assertEqual(recursive["D1"]["connection_distance"], 3)
        self.assertEqual(recursive["D1"]["connection_path"], ["U1", "C1", "R1", "D1"])
        self.assertEqual(
            [(step["from_component"], step["from_pin"],
              step["to_component"], step["to_pin"])
             for step in recursive["D1"]["connection_pin_path"]],
            [("U1", "", "C1", ""),
             ("C1", "", "R1", ""),
             ("R1", "", "D1", "")],
        )
        self.assertEqual(recursive["D1"]["connection_edge_nets"],
                         ["U1_VIN", "C1_R1", "R1_D1"])
        self.assertTrue(result["all_components_once"])

    def test_recursive_shared_path_is_owned_by_earlier_major_root(self):
        result = self._run(
            [("U1", "ic_module"), ("U2", "ic_module"),
             ("C1", "capacitor"), ("C2", "capacitor"),
             ("R1", "resistor")],
            {
                "U1_LOCAL": [{"c": "U1"}, {"c": "C1"}],
                "U2_LOCAL": [{"c": "U2"}, {"c": "C2"}],
                "BRANCH": [{"c": "C1"}, {"c": "C2"}, {"c": "R1"}],
            },
            {"U1_LOCAL": ["VIN"], "U2_LOCAL": ["VIN"],
             "BRANCH": ["UNKNOWN"]},
        )
        owners = [row for row in result["l2_domains"] if "R1" in row["members"]]
        self.assertEqual(len(owners), 1)
        self.assertEqual(owners[0]["anchor"], "U1")
        self.assertTrue(result["all_components_once"])

    def test_rail_net_is_contracted_and_recursion_continues(self):
        result = self._run(
            [("U1", "ic_module"), ("C1", "capacitor"),
             ("R1", "resistor"), ("D1", "diode")],
            {
                "U1_LOCAL": [{"c": "U1"}, {"c": "C1"}],
                "5V": [{"c": "C1"}, {"c": "R1"}],
                "R1_D1": [{"c": "R1"}, {"c": "D1"}],
            },
            {"U1_LOCAL": ["VIN"], "5V": ["UNKNOWN"],
             "R1_D1": ["UNKNOWN"]},
        )
        domain = next(row for row in result["l2_domains"] if row.get("anchor") == "U1")
        self.assertEqual(set(domain["members"]), {"U1", "C1"})
        unresolved = next(row for row in result["l2_domains"] if row.get("anchor") is None)
        self.assertEqual(set(unresolved["members"]), {"R1", "D1"})

    def test_root_supply_rail_endpoints_are_not_assigned(self):
        result = self._run(
            [("U1", "ic_module"), ("C1", "capacitor"),
             ("R1", "resistor")],
            {
                "5V": [{"c": "U1"}, {"c": "C1"}],
                "C1_R1": [{"c": "C1"}, {"c": "R1"}],
            },
            {"5V": ["5V"], "C1_R1": ["UNKNOWN"]},
        )
        domain = next(row for row in result["l2_domains"] if row.get("anchor") == "U1")
        self.assertEqual(domain["members"], ["U1"])
        unresolved = next(row for row in result["l2_domains"] if row.get("anchor") is None)
        self.assertEqual(set(unresolved["members"]), {"C1", "R1"})

    def test_root_high_fanout_power_and_ground_endpoints_do_not_connect(self):
        result = self._run(
            [("U1", "ic_module"), ("U2", "ic_module"),
             ("C1", "capacitor"), ("C2", "capacitor"),
             ("R1", "resistor"), ("R2", "resistor")],
            {
                "VCC": [{"c": ref} for ref in ("U1", "U2", "C1", "C2")],
                "GND": [{"c": ref} for ref in ("U1", "U2", "C1", "C2", "R1", "R2")],
                "C1_LOCAL": [{"c": "C1"}, {"c": "R1"}],
                "C2_LOCAL": [{"c": "C2"}, {"c": "R2"}],
            },
            {"VCC": ["VCC"], "C1_LOCAL": ["UNKNOWN"],
             "C2_LOCAL": ["UNKNOWN"], "GND": ["GND"]},
        )
        domains = {row["anchor"]: set(row["members"])
                   for row in result["l2_domains"] if row.get("anchor")}
        # Shared power/ground rails are not ownership evidence.
        self.assertEqual(domains["U1"], {"U1"})
        self.assertEqual(domains["U2"], {"U2"})
        unresolved = next(row for row in result["l2_domains"] if row.get("anchor") is None)
        self.assertEqual(set(unresolved["members"]), {"C1", "C2", "R1", "R2"})

    def test_high_fanout_ground_does_not_join_or_expand_a_domain(self):
        result = self._run(
            [("U1", "ic_module"), ("C1", "capacitor"),
             ("C2", "capacitor"), ("R1", "resistor")],
            {"GND": [{"c": ref} for ref in ("U1", "C1", "C2", "R1")]},
            {"GND": ["GND"]},
        )
        domain = next(row for row in result["l2_domains"] if row.get("anchor") == "U1")
        self.assertEqual(domain["members"], ["U1"])

    def test_ground_net_does_not_extend_a_non_ground_path(self):
        result = self._run(
            [("U1", "ic_module"), ("C1", "capacitor"),
             ("R1", "resistor")],
            {
                "LOCAL": [{"c": "U1"}, {"c": "C1"}],
                "GND": [{"c": "C1"}, {"c": "R1"}],
            },
            {"LOCAL": ["UNKNOWN"], "GND": ["GND"]},
        )
        domain = next(row for row in result["l2_domains"] if row.get("anchor") == "U1")
        self.assertEqual(set(domain["members"]), {"U1", "C1"})
        assignment = next(row for row in domain["assignments"] if row["ref"] == "C1")
        self.assertEqual(assignment["connection_nets"], ["LOCAL"])
        self.assertEqual(assignment["connection_distance"], 1)
        self.assertEqual(assignment["connection_path_display"], "U1 → C1")
        unresolved = next(row for row in result["l2_domains"] if row.get("anchor") is None)
        self.assertEqual(unresolved["members"], ["R1"])

    def test_root_power_net_does_not_create_pin_adjacency(self):
        result = self._run(
            [("U1", "ic_module"), ("C1", "capacitor")],
            {"VCC": [{"c": "U1", "pin": "1", "name": "VHV"},
                     {"c": "C1", "pin": "2", "name": "2"}]},
            {"VCC": ["VCC"]},
        )
        domain = next(row for row in result["l2_domains"] if row.get("anchor") == "U1")
        self.assertEqual(domain["members"], ["U1"])
        unresolved = next(row for row in result["l2_domains"] if row.get("anchor") is None)
        self.assertEqual(unresolved["members"], ["C1"])

    def test_3v3_rail_is_contracted_and_recursion_continues(self):
        result = self._run(
            [("U1", "ic_module"), ("C1", "capacitor"),
             ("R1", "resistor")],
            {
                "U1_LOCAL": [{"c": "U1"}, {"c": "C1"}],
                "3V3": [{"c": "C1"}, {"c": "R1"}],
            },
            {"U1_LOCAL": ["VIN"], "3V3": ["UNKNOWN"]},
        )
        domain = next(row for row in result["l2_domains"] if row.get("anchor") == "U1")
        self.assertEqual(set(domain["members"]), {"U1", "C1"})

    def test_named_supply_rails_are_contracted(self):
        for rail in ("VCC", "VSS", "VDD", "VEE", "VBUS"):
            with self.subTest(rail=rail):
                result = self._run(
                    [("U1", "ic_module"), ("C1", "capacitor"),
                     ("R1", "resistor")],
                    {
                        "U1_LOCAL": [{"c": "U1"}, {"c": "C1"}],
                        rail: [{"c": "C1"}, {"c": "R1"}],
                    },
                    {"U1_LOCAL": ["VIN"], rail: [rail]},
                )
                domain = next(row for row in result["l2_domains"]
                              if row.get("anchor") == "U1")
                self.assertEqual(set(domain["members"]), {"U1", "C1"})

    def test_major_roots_use_natural_designator_order(self):
        result = self._run(
            [("U10", "ic_module"), ("U2", "ic_module"), ("R1", "resistor")],
            {"SHARED": [{"c": "U10"}, {"c": "U2"}, {"c": "R1"}]},
            {"SHARED": ["UNKNOWN"]},
        )
        owner = next(row for row in result["l2_domains"] if "R1" in row["members"])
        self.assertEqual(owner["anchor"], "U2")


if __name__ == "__main__":
    unittest.main()
