import unittest
import tempfile
import json
from pathlib import Path
from unittest.mock import patch

from partitioner.deepseek_annotate import DeepSeekRequestError, _normalize_annotation, request_annotation
from partitioner.l1_partition import validate_llm_annotation, validate_topology
from partitioner.reporting import _ari
from partitioner.run_batch import run_batch


class LiveAnnotationNormalizationTests(unittest.TestCase):
    def setUp(self):
        self.topology = {
            "schema": "moduplace-topology-v1",
            "components": [{"designator": "U1"}, {"designator": "C1"}, {"designator": "R1"}],
            "nets": {"VIN": [{"c": "U1", "name": "VCC"}, {"c": "C1", "name": "1"}],
                     "FB": [{"c": "U1", "name": "FB"}, {"c": "R1", "name": "2"}]},
        }

    def test_normalizes_designator_and_net_endpoint_arrays(self):
        raw = {"components": [{"designator": "C1", "roles": ["input_bypass_capacitor"]},
                              {"designator": "R1", "role": "feedback_resistor"}],
               "nets": {"VIN": [{"designator": "U1", "pad": "VCC"},
                                 {"designator": "C1", "pad": "1"}],
                        "FB": [{"designator": "U1", "pad": "FB"},
                               {"designator": "R1", "pad": "2"}]}}
        normalized = _normalize_annotation(raw, self.topology)
        self.assertTrue(validate_llm_annotation(normalized, self.topology))
        self.assertEqual(normalized["components"][0]["ref"], "U1")
        self.assertEqual(normalized["nets"]["FB"]["connections"][1]["ref"], "R1")
        self.assertEqual(normalized["nets"]["VIN"]["connections"][0]["pin"], "VCC")

    def test_ignores_unknown_nets_and_unknown_component_refs(self):
        normalized = _normalize_annotation({"components": [{"ref": "NOT_A_REF", "roles": ["x"]}],
                                            "nets": {"GHOST": [], "VIN": {"semantics": "input_power"}}},
                                           self.topology)
        self.assertTrue(validate_llm_annotation(normalized, self.topology))
        self.assertEqual(normalized["components"][0]["ref"], "U1")
        self.assertNotIn("GHOST", normalized["nets"])
        self.assertEqual(normalized["nets"]["VIN"]["semantics"], ["input_power"])

    def test_normalizes_soft_link_member_aliases_and_member_objects(self):
        raw = {
            "soft_links": [{
                "refs": [{"ref": "C1"}, {"designator": "R1"}],
                "function": "feedback",
            }],
            "candidate_clusters": [{"components": ["U1", {"designator": "C1"}],
                                     "function": "input_bypass"}],
        }
        normalized = _normalize_annotation(raw, self.topology)
        self.assertEqual(normalized["soft_links"][0]["members"], ["C1", "R1"])
        self.assertEqual(normalized["candidate_clusters"][0]["members"], ["U1", "C1"])
        self.assertTrue(validate_llm_annotation(normalized, self.topology))

    def test_layout_endpoint_aliases_are_canonicalized_before_annotation(self):
        topology = {
            "schema": "pcb-topology-v1",
            "components": [{"designator": "U1"}, {"designator": "C1"}],
            "nets": {"VIN": [{"designator": "U1", "pad": "VCC"},
                               {"designator": "C1", "pad": "1"}]},
        }
        validate_topology(topology)
        self.assertEqual(topology["schema"], "moduplace-topology-v1")
        self.assertEqual(topology["nets"]["VIN"][0]["c"], "U1")
        self.assertEqual(topology["nets"]["VIN"][0]["name"], "VCC")
        normalized = _normalize_annotation({"components": [], "nets": {}}, topology)
        self.assertEqual(normalized["nets"]["VIN"]["connections"],
                         [{"ref": "U1", "pin": "VCC"}, {"ref": "C1", "pin": "1"}])
        self.assertTrue(validate_llm_annotation(normalized, topology))

    def test_missing_net_semantics_use_local_fallback_without_overwriting_llm_values(self):
        raw = {
            "components": [],
            "nets": {
                "VIN": {"semantics": ["llm_vin"], "connections": []},
                "FB": {"connections": []},
            },
        }
        normalized = _normalize_annotation(raw, self.topology)
        self.assertEqual(normalized["nets"]["VIN"]["semantics"], ["llm_vin"])
        self.assertTrue(normalized["nets"]["FB"]["semantics"])
        self.assertIn("FB", normalized.get("semantic_fallbacks", []))
        self.assertTrue(validate_llm_annotation(normalized, self.topology))

    def test_omitted_topology_nets_are_filled_before_semantic_fallback(self):
        normalized = _normalize_annotation(
            {"components": [], "nets": {"VIN": {"semantics": ["llm_vin"]}}},
            self.topology,
        )
        self.assertEqual(set(normalized["nets"]), set(self.topology["nets"]))
        self.assertTrue(normalized["nets"]["FB"]["semantics"])
        self.assertIn("FB", normalized.get("semantic_fallbacks", []))
        self.assertTrue(validate_llm_annotation(normalized, self.topology))

    def test_drops_invalid_soft_links_and_candidate_clusters_with_warning(self):
        raw = {
            "soft_links": [
                {"members": ["C1"]},
                {"members": ["C1", "NOT_A_REF"]},
                {"members": ["C1", "R1"]},
            ],
            "candidate_clusters": [{"refs": [{"designator": "U1"}]}],
        }
        normalized = _normalize_annotation(raw, self.topology)
        self.assertEqual([row["members"] for row in normalized["soft_links"]], [["C1", "R1"]])
        self.assertEqual(normalized["candidate_clusters"], [])
        self.assertEqual(len(normalized["normalization_warnings"]), 3)
        self.assertTrue(validate_llm_annotation(normalized, self.topology))

    def test_ari_is_adjusted_rand_not_label_accuracy(self):
        a = [{"members": ["A", "B"]}, {"members": ["C", "D"]}]
        b = [{"members": ["A", "C"]}, {"members": ["B", "D"]}]
        self.assertAlmostEqual(_ari(a, b), -0.5)
        self.assertEqual(_ari(a, a), 1.0)

    def test_live_attempt_without_credentials_is_not_reported_as_offline(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            source = root / "source"
            source.mkdir()
            files = []
            for index in range(9):
                path = source / f"project_{index}.json"
                path.write_text(json.dumps(self.topology), encoding="utf-8")
                files.append(path)
            with patch.dict("os.environ", {"DEEPSEEK_API_KEY": "", "OPENAI_API_KEY": ""}):
                rows, run_dir = run_batch(source, root / "outputs", api_key="", model="test",
                                          base_url="https://invalid", project_files=files,
                                          llm_repeats=1, algorithm_repeats=1)
            self.assertEqual(run_dir.name, "offline")
            self.assertTrue(all(row["run_mode"] == "offline" for row in rows))

            rows, run_dir = run_batch(source, root / "outputs_live", api_key="present", model="test",
                                      base_url="https://invalid", project_files=files,
                                      llm_repeats=1, algorithm_repeats=1)
            self.assertEqual(run_dir.name, "deepseek_attempt")
            self.assertTrue(all(row["run_mode"] == "deepseek_failed" for row in rows))
            artifact = json.loads(Path(rows[0]["json"]).read_text(encoding="utf-8"))
            self.assertTrue(artifact["llm_call"]["attempted"])
            self.assertFalse(artifact["llm_call"]["succeeded"])
            self.assertTrue(artifact["llm_call"]["errors"])

    def test_api_key_file_is_process_local_cli_input(self):
        from partitioner.run_batch import main
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            key_file = root / "key.txt"
            key_file.write_text("secret-key\n", encoding="utf-8")
            source = root / "source"
            source.mkdir()
            for index in range(9):
                (source / f"project_{index}.json").write_text(json.dumps(self.topology), encoding="utf-8")
            # A deliberately unreachable endpoint proves the file was read and
            # the run entered attempted-live mode without exposing the secret.
            with patch.dict("os.environ", {"DEEPSEEK_API_KEY": "", "OPENAI_API_KEY": ""}):
                main(["--source", str(source), "--output", str(root / "out"),
                      "--api-key-file", str(key_file), "--base-url", "https://invalid",
                      "--llm-repeats", "1", "--algorithm-repeats", "1"])
            summary = (root / "out" / "deepseek_attempt" / "llm_call_summary.json").read_text(encoding="utf-8")
            self.assertNotIn("secret-key", summary)
            self.assertIn('"attempted": true', summary)

    def test_http_failure_does_not_trigger_single_stage_fallback(self):
        with patch("partitioner.deepseek_annotate._call_model",
                   side_effect=DeepSeekRequestError(402, "Insufficient Balance")) as call:
            with self.assertRaises(DeepSeekRequestError):
                request_annotation(self.topology, api_key="present", model="test",
                                   base_url="https://invalid", major_first=True)
        call.assert_called_once()

    def test_scalar_source_provenance_is_canonicalized(self):
        with patch("partitioner.deepseek_annotate._single_stage_annotation",
                   return_value={"source": "flash", "components": [], "nets": {}}):
            annotation = request_annotation(self.topology, api_key="present",
                                             model="deepseek-flash", major_first=False)
        self.assertIsInstance(annotation["source"], dict)
        self.assertEqual(annotation["source"]["model_source"], "flash")
        self.assertEqual(annotation["source"]["provider"], "deepseek")

    def test_live_batch_reviews_soft_constraints_after_analysis_phase(self):
        from partitioner import run_batch as run_batch_module

        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            source = root / "source"
            source.mkdir()
            files = []
            for index in range(9):
                path = source / f"project_{index}.json"
                path.write_text(json.dumps(self.topology), encoding="utf-8")
                files.append(path)
            record = {
                "constraint_id": "SC-live-test", "source_project": "project_0",
                "project_id": "project_0", "l1_1_domain": "D-001",
                "function_type": "feedback", "confidence": .95,
                "evidence_nets": ["FB"], "review_status": "candidate",
                "kind": "pair", "members": ["R1", "C1"],
                "when": {"role_pairs": [["feedback_resistor", "feedback_capacitor"]],
                         "shared_semantics": ["FB"]},
                "relation": "prefer_link", "reason": "test candidate", "schema": "partition-placement-rule-v1",
            }

            def fake_run(topology, *, knowledge_base_path, project_id, **kwargs):
                from partitioner.knowledge_base import normalize_soft_constraints, append_soft_constraints
                manifest = json.loads(Path(knowledge_base_path).read_text(encoding="utf-8"))
                fresh = normalize_soft_constraints({"soft_links": [
                    {"a": "R1", "b": "C1", "function": "feedback",
                     "confidence": .95, "evidence_nets": ["FB"],
                     "reason": "test candidate"}]}, topology, project_id)
                append_soft_constraints(fresh, Path(manifest["soft_constraints"]))
                partition = {"l1_1_domains": [], "l1_2_clusters": [],
                             "clusters": [], "unresolved_components": [
                                 {"ref": "U1"}, {"ref": "C1"}, {"ref": "R1"}]}
                return {"status": "ok", "partition": partition, "roles": {},
                        "component_metadata": topology["components"], "net_semantics": {},
                        "topology_source": {}, "soft_constraint_promotion": None}

            def fake_review(records, **kwargs):
                return [dict(row, review_provider="deepseek", review_status="deepseek_approved",
                             review_confidence=.99, review_reason="strong evidence") for row in records]

            annotation = {"source": {"provider": "deepseek"}, "components": [], "nets": {},
                          "soft_links": [{"a": "C1", "b": "R1", "function": "feedback",
                                          "confidence": .95, "evidence_nets": ["FB"],
                                          "reason": "test candidate"}]}
            def fake_request(topology, **kwargs):
                return dict(annotation, source={"provider": "deepseek"})
            with patch.object(run_batch_module, "run", side_effect=fake_run), \
                 patch("partitioner.deepseek_annotate.request_annotation", side_effect=fake_request), \
                 patch("partitioner.deepseek_annotate._normalize_annotation", side_effect=lambda x, _: x), \
                 patch("partitioner.deepseek_annotate.review_soft_constraints", side_effect=fake_review):
                rows, run_dir = run_batch_module.run_batch(
                    source, root / "outputs", api_key="test-key", model="test",
                    base_url="https://invalid", project_files=files,
                    llm_repeats=1, algorithm_repeats=1)

            summary = json.loads((run_dir / "soft_constraint_review_summary.json").read_text(encoding="utf-8"))
            manifest = json.loads((root / "outputs" / "kb_manifest.json").read_text(encoding="utf-8"))
            rules = json.loads(Path(manifest["active_rules"]).read_text(encoding="utf-8"))["rules"]
            soft_rows = [json.loads(line) for line in Path(manifest["soft_constraints"]).read_text(encoding="utf-8").splitlines()]
            self.assertEqual(summary["reviewed"], 1)
            self.assertEqual(summary["status"], "complete")
            reviewed_rows = [row for row in soft_rows
                             if row.get("review_status") == "deepseek_approved"
                             and row.get("source_project") == "project_0"]
            self.assertEqual(len(reviewed_rows), 1)
            new_rules = [rule for rule in rules if rule.get("constraint_id") == "SC-"
                         or rule.get("source_project") in {"project_0"}]
            self.assertEqual(len(new_rules), 1)
            self.assertTrue(all(rule["review_provider"] == "deepseek" and rule["confidence"] >= .92
                                for rule in new_rules))
            self.assertEqual(rows[0]["promoted_hard_rule_count"], 1)

    def test_review_failure_keeps_batch_candidates_explicitly_unreviewed(self):
        from partitioner import run_batch as run_batch_module
        from partitioner.knowledge_base import DEFAULT_MANIFEST, append_soft_constraints

        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            source_manifest = json.loads(DEFAULT_MANIFEST.read_text(encoding="utf-8"))
            manifest_path = root / "kb_manifest.json"
            rules_path = root / "placement_rules.json"
            soft_path = root / "soft_constraints.jsonl"
            manifest = dict(source_manifest, active_rules=str(rules_path),
                            soft_constraints=str(soft_path))
            manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
            rules_path.write_text(json.dumps(json.loads(
                (DEFAULT_MANIFEST.parent / source_manifest["active_rules"]).read_text(encoding="utf-8"))),
                encoding="utf-8")
            append_soft_constraints([{
                "constraint_id": "SC-review-failure", "source_project": "project_0",
                "project_id": "project_0", "l1_1_domain": "L1-1-001",
                "function_type": "feedback", "confidence": .95,
                "evidence_nets": ["FB"], "review_status": "candidate",
                "kind": "pair", "members": ["C1", "R1"],
                "relation": "prefer_link", "reason": "test candidate",
                "schema": "partition-placement-rule-v1",
            }], soft_path)
            run_dir = root / "run"
            run_dir.mkdir()
            (run_dir / "batch_summary.json").write_text(
                json.dumps([{"project": "project_0"}]), encoding="utf-8")

            with patch("partitioner.deepseek_annotate.review_soft_constraints",
                       side_effect=RuntimeError("HTTP 402: Insufficient Balance")):
                summary = run_batch_module._review_and_promote_batch(
                    run_dir, manifest_path, rules_path, soft_path,
                    api_key="present", model="test", base_url="https://invalid",
                    timeout=1, threshold=.92)

            soft_rows = [json.loads(line) for line in soft_path.read_text(encoding="utf-8").splitlines()]
            self.assertEqual(summary["status"], "review_failed")
            self.assertEqual(summary["knowledge_state"], "candidates_unreviewed")
            self.assertEqual(summary["candidate_count"], 1)
            self.assertTrue(all(row["review_status"] == "candidate" for row in soft_rows))


if __name__ == "__main__":
    unittest.main()

