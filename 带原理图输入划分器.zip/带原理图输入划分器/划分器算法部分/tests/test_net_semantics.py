import unittest

from partitioner.l1_partition import net_semantics, net_semantics_with_evidence


class NetSemanticsTests(unittest.TestCase):
    def test_auto_numbered_nets_use_pin_names(self):
        topology = {
            "schema": "moduplace-topology-v1",
            "components": [{"designator": "U1"}, {"designator": "R1"}],
            "nets": {
                "$1N1": [{"c": "U1", "pin": "1", "name": "SS"}, {"c": "C1", "pin": "1", "name": ""}],
                "$1N2": [{"c": "U1", "pin": "2", "name": "FB"}, {"c": "R1", "pin": "1", "name": ""}],
                "$1N3": [{"c": "U1", "pin": "3", "name": "SW"}, {"c": "L1", "pin": "1", "name": ""}],
                "$1N4": [{"c": "U1", "pin": "4", "name": "BST"}, {"c": "C2", "pin": "1", "name": ""}],
                "$1N5": [{"c": "U1", "pin": "5", "name": "2"}, {"c": "R2", "pin": "1", "name": ""}],
            },
        }
        semantics = net_semantics(topology)
        self.assertEqual(semantics["$1N1"], ["SS"])
        self.assertEqual(semantics["$1N2"], ["FB"])
        self.assertEqual(semantics["$1N3"], ["SW"])
        self.assertEqual(semantics["$1N4"], ["BOOT"])
        self.assertEqual(semantics["$1N5"], ["UNKNOWN"])
        evidence = net_semantics_with_evidence(topology)
        self.assertEqual(evidence["$1N4"][0]["source"], "pin_name")
        self.assertEqual(evidence["$1N5"][0]["source"], "fallback")

    def test_internal_regulator_pin_maps_to_control_supply(self):
        topology = {
            "schema": "moduplace-topology-v1",
            "components": [{"designator": "U1"}, {"designator": "C8"}],
            "nets": {
                "$1N2": [
                    {"c": "U1", "pin": "3", "name": "VREG5"},
                    {"c": "C8", "pin": "2", "name": "2"},
                ],
            },
        }
        self.assertEqual(net_semantics(topology)["$1N2"], ["VCC"])
        evidence = net_semantics_with_evidence(topology)["$1N2"]
        self.assertEqual(evidence[0]["semantic"], "VCC")
        self.assertEqual(evidence[0]["source"], "pin_name")


if __name__ == "__main__":
    unittest.main()
