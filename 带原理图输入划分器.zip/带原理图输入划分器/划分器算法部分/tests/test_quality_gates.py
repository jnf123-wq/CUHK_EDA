import unittest

from partitioner.reporting import quality_metrics


class QualityGateTests(unittest.TestCase):
    def test_duplicate_and_uncovered_assignments_fail_hard_gate(self):
        result = quality_metrics({
            "roles": {"A": {"roles": []}, "B": {"roles": []}, "C": {"roles": []}},
            "component_metadata": [{"designator": "A"}, {"designator": "B"}, {"designator": "C"}],
            "net_semantics": {},
            "partition": {
                "clusters": [{"members": ["A", "B"]}, {"members": ["B"]}],
                "l1_1_domains": [], "l1_2_clusters": [],
                "unresolved_components": [], "all_components_once": True,
            },
        })
        self.assertFalse(result["all_components_once"])
        self.assertEqual(result["duplicate_assignment_count"], 1)
        self.assertEqual(result["uncovered_component_count"], 1)

    def test_unresolved_rows_are_counted_by_reference(self):
        result = quality_metrics({
            "roles": {"A": {"roles": []}},
            "component_metadata": [{"designator": "A"}],
            "net_semantics": {},
            "partition": {
                "clusters": [], "l1_1_domains": [], "l1_2_clusters": [],
                "unresolved_components": [{"ref": "A"}], "all_components_once": True,
            },
        })
        self.assertTrue(result["all_components_once"])
        self.assertEqual(result["assignment_count"], 1)
        self.assertEqual(result["l1_2_unresolved_component_count"], 1)
        self.assertEqual(result["unassigned_component_count"], 0)

    def test_structured_quality_findings_are_deduplicated(self):
        result = quality_metrics({
            "roles": {"A": {"roles": []}},
            "component_metadata": [{"designator": "A"}],
            "net_semantics": {},
            "annotation_quality_findings": [
                {"type": "missing_roles", "refs": ["A"]},
                {"type": "missing_roles", "refs": ["A"]},
            ],
            "partition": {
                "clusters": [], "l1_1_domains": [], "l1_2_clusters": [],
                "unresolved_components": [], "all_components_once": True,
            },
        })
        self.assertEqual(result["quality_findings"],
                         [{"type": "missing_roles", "refs": ["A"]}])


if __name__ == "__main__":
    unittest.main()
