import tempfile
import unittest
from pathlib import Path

from partitioner.reporting import write_reports


class ReportingExportTests(unittest.TestCase):
    def test_writes_separate_l1_and_l2_csv_files(self):
        with tempfile.TemporaryDirectory() as temporary:
            output = Path(temporary) / "demo.json"
            result = {
                "roles": {"U1": {"roles": ["controller"]}, "C1": {"roles": ["capacitor"]}},
                "component_metadata": [{"designator": "U1"}, {"designator": "C1"}],
                "net_semantics": {"VIN": ["VIN"]},
                "partition": {
                    "l1_clusters": [{"id": "L1-001", "level": "L1", "members": ["C1"],
                                     "function": "input_bypass", "source": "test"}],
                    "l2_domains": [{"id": "L2-001", "level": "L2", "anchor": "U1",
                                    "members": ["U1", "C1"], "assignments": [{
                                        "ref": "C1", "shared_nets": ["VIN"], "semantics": ["VIN"]
                                    }], "assignment_reason": "test_domain"}],
                    "unresolved_components": [],
                    "all_components_once": True,
                },
            }
            reports = write_reports(result, output)
            self.assertEqual(reports["l1_csv"].name, "demo_L1.csv")
            self.assertEqual(reports["l2_csv"].name, "demo_L2.csv")
            l1_text = reports["l1_csv"].read_text(encoding="utf-8-sig")
            l2_text = reports["l2_csv"].read_text(encoding="utf-8-sig")
            self.assertIn("L1-001", l1_text)
            self.assertNotIn("L2-001", l1_text)
            self.assertIn("L2-001", l2_text)
            self.assertNotIn("L1-001", l2_text)


if __name__ == "__main__":
    unittest.main()
