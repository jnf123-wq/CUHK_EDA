import json
import unittest

from partitioner.soft_evidence import collect_soft_evidence, score_pairs, proposal_clusters


class SoftEvidenceTests(unittest.TestCase):
    def setUp(self):
        self.topology = {
            "schema": "moduplace-topology-v1",
            "components": [
                {"designator": "U1", "kind": "ic"},
                {"designator": "C1", "kind": "capacitor"},
                {"designator": "C2", "kind": "capacitor"},
            ], "nets": {}
        }

    def test_independent_sources_raise_proposal_confidence(self):
        annotation = {"soft_links": [{"a": "U1", "b": "C1", "confidence": .85,
                                       "evidence": ["VCC"]}]}
        prior = {"soft_links": [{"members": ["U1", "C1"]}]}
        scores = score_pairs(self.topology, annotation, prior)
        self.assertEqual(len(scores), 1)
        self.assertEqual(scores[0]["decision"], "proposal")
        self.assertIn("llm_realtime", scores[0]["sources"])
        self.assertIn("historical_prior", scores[0]["sources"])

    def test_low_confidence_stays_evidence_only(self):
        scores = score_pairs(self.topology, {"soft_links": [{"a": "U1", "b": "C2", "confidence": .4}]}, {})
        self.assertEqual(scores[0]["decision"], "evidence_only")

    def test_proposals_cover_every_component(self):
        scores = score_pairs(self.topology, {"soft_links": [{"a": "U1", "b": "C1", "confidence": .9}]}, {})
        proposals = proposal_clusters(self.topology, scores)
        members = sorted(x for group in proposals for x in group["members"])
        self.assertEqual(members, ["C1", "C2", "U1"])

    def test_historical_constraint_function_and_net_are_preserved(self):
        topology = {"components": [{"designator": "A"}, {"designator": "B"}], "nets": {}}
        prior = {"soft_constraints": [{
            "members": ["A", "B"], "confidence": .8, "function_type": "feedback",
            "l1_1_domain": "L1-1-001", "evidence_nets": ["FB"],
            "review_status": "candidate", "source": "knowledge_base",
        }]}
        evidence = collect_soft_evidence(topology, prior=prior)
        self.assertEqual(len(evidence), 1)
        self.assertEqual(evidence[0]["function"], "feedback")
        self.assertEqual(evidence[0]["evidence_nets"], ["FB"])

    def test_historical_network_scope_must_match_current_design(self):
        topology = {
            "components": [{"designator": "A"}, {"designator": "B"}],
            "nets": {"VIN": [{"c": "A"}, {"c": "B"}]},
        }
        prior = {"soft_constraints": [{
            "members": ["A", "B"], "confidence": .95,
            "function_type": "feedback", "evidence_nets": ["FB"],
            "review_status": "deepseek_approved", "source": "knowledge_base",
        }]}
        self.assertEqual(collect_soft_evidence(topology, prior=prior), [])

    def test_historical_network_scope_matches_by_semantics(self):
        topology = {
            "components": [{"designator": "A"}, {"designator": "B"}],
            "nets": {"$NET42": [{"c": "A"}, {"c": "B"}]},
        }
        annotation = {"nets": {"$NET42": {"semantics": ["FB"]}}}
        prior = {"soft_constraints": [{
            "members": ["A", "B"], "confidence": .95,
            "function_type": "feedback", "evidence_nets": ["FB"],
            "review_status": "deepseek_approved", "source": "knowledge_base",
        }]}
        evidence = collect_soft_evidence(topology, annotation=annotation, prior=prior)
        self.assertEqual(len(evidence), 1)

    def test_pair_keeps_multiple_function_labels_and_networks(self):
        annotation = {"soft_links": [
            {"a": "C1", "b": "C2", "confidence": .86,
             "function": "input_bypass", "evidence_nets": ["VIN"]},
            {"a": "C1", "b": "C2", "confidence": .81,
             "function": "output_filter", "evidence_nets": ["VOUT"]},
        ]}
        scores = score_pairs(self.topology, annotation)
        self.assertEqual(len(scores), 1)
        self.assertEqual(set(scores[0]["functions"]), {"input_bypass", "output_filter"})
        self.assertEqual(set(scores[0]["evidence_nets"]), {"VIN", "VOUT"})
        self.assertEqual(set(scores[0]["function_evidence"]), {"input_bypass", "output_filter"})

