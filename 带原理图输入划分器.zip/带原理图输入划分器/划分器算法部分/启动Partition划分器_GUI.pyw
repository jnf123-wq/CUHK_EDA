"""双击启动 Partition 划分器 GUI（无控制台窗口）。"""
from pathlib import Path
import sys

# Ensure imports work when this file is launched from a Windows shortcut.
PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

try:
    from partitioner.gui import main
    main()
except Exception as exc:
    # pythonw.exe has no console, so surface startup failures as a dialog.
    import tkinter as tk
    from tkinter import messagebox

    root = tk.Tk()
    root.withdraw()
    messagebox.showerror("Partition 划分器启动失败", str(exc))
    root.destroy()
